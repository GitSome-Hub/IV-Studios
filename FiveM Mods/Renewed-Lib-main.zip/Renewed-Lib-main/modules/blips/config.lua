return {
    store = {
        id = 12,
        Name = 'Stores'
    },
    clothing = {
        id = 13,
        Name = 'Clothing Stores'
    },
    gas = {
        id = 14,
        Name = 'Gas Stations'
    },
    job = {
        id = 15,
        Name = 'Jobs'
    },
    police = {
        id = 16,
        Name = 'Police Officers'
    },
    police_vehicles = {
        id = 17,
        Name = 'Police Vehicles'
    },
    pd = {
        id = 18,
        Name = 'Police Station'
    },
}