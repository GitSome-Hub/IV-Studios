-- Please place your Discord webhook here
config.main.logging.webhook = ''