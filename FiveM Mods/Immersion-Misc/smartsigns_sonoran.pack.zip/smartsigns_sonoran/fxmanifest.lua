fx_version 'bodacious'
game 'gta5'

author 'London Studios'
description 'Setup and control dynamic traffic signs'
version '1.5.4'
config_version '1.5'
lua54 'yes'

client_scripts {
    'cl_utils.lua',
    'cl_smartsigns.lua',
    'cl_setuputil.lua'
}

shared_script 'config.lua'

shared_script '@es_extended/imports.lua'

server_scripts {
    -- "@vrp/lib/utils.lua",
    'sonoran.lua',
    'sv_smartsigns.lua',
    'server/update.lua',
    'server/util/unzip.js',
    'server/util/utils.lua'
}

files {
    'stream/data/*.ytyp',
    'locations.json',
    'locations_default.json'
}

escrow_ignore {
    'stream/*',
    'stream/data/*',
    'cl_utils.lua',
    'locations.json',
    'locations_default.json',
    'config_RENAMEME.lua',
    'sv_discordConfig_RENAMEME'
}

data_file 'DLC_ITYP_REQUEST' 'stream/data/*.ytyp'
dependency '/assetpacks'