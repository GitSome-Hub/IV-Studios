fx_version 'bodacious'
games {'gta5'}

lua54 'yes'
server_only 'yes'
server_scripts {'s.lua', 'utility.lua'}

dependency '/assetpacks'