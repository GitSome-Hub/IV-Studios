return {
	[1] = {
		groups = {'mechanic','police'},
		moneytype = 'money',
		label = 'MechanicSupply 1', -- identifier for each stores. do not rename once player already buy this store
		coord = vec3(-206.28778076172,-1341.0858154297,35.23713684082), -- owner manage coord
		--cashier = vec3(-1194.4945068359,-895.02117919922,13.97), -- cashier coord for robbing or onduty ondemand
		price = 1000000,
		supplieritem = shared.Storeitems.MechanicSupply,
	}
}