return {
	[1] = {
		moneytype = 'money',
		label = 'BeanMachine 1', -- identifier for each stores. do not rename once player already buy this store
		coord = vec3(1135.8199462891,-1556.6519775391,35.227054595947), -- owner manage coord
		--cashier = vec3(-570.81573486328,-411.60275268555,34.91), -- cashier coord for robbing or onduty ondemand
		price = 50000,
		supplieritem = shared.Storeitems.BeanMachine,
		--playertoplayer = true,
		--stash = vec3(-578.48022460938,-410.11697387695,34.917),
		-- crafting = {
		-- 	coord = vec3(-566.13116455078,-413.51715087891,34.91),
		-- 	label = 'Cook',
		-- },

	}
}