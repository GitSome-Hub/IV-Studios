return {
	[1] = {
		--groups = 'ClothingShop',
		moneytype = 'money',
		label = 'Pet Shop', -- identifier for each stores. do not rename once player already buy this store
		coord = vec3(405.32431030273,318.54266357422,102.86719512939), -- owner manage coord
		--cashier = vec3(-1587.1876220703,-995.619140625,13.162528991699), -- cashier coord for robbing or onduty ondemand
		price = 1000000,
		supplieritem = shared.Storeitems.Petshop,
	}
}