let allPlayerInfractions = [];
let currentPage = 1;
const infractionsPerPage = 10;
let currentlySelectedRadar = null;
let userSettings = {};
let confirmationData = null;
let batteryInterval = null;
let trikojisLimits = [];

const licenseTypeTranslations = {
    'drive': 'Car',             // You can change 'Car' text
    'drive_bike': 'Motorcycle', // You can change 'Motorcyle' text
    'drive_truck': 'Truck',     // You can change 'Truck' text
};

// NUI CALLBACK HELPER FUNCTION
async function post(eventName, data = {}) {
    try {
        const response = await fetch(`https://${GetParentResourceName()}/${eventName}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json; charset=UTF-8' },
            body: JSON.stringify(data),
        });
        return await response.json();
    } catch (e) { return null; }
}

// GENERAL NOTIFICATION HANDLING FUNCTION
window.addEventListener('message', function (event) {
    const item = event.data;
    const applyStyles = (settings) => {
        userSettings = settings;
        const detectorUI = document.getElementById('detector-ui');
        const editorPanel = document.getElementById('editor-panel');
        if (!detectorUI || !editorPanel) return;
        if (settings.y > 50) { detectorUI.style.top = 'auto'; detectorUI.style.bottom = (100 - settings.y) + 'vh'; }
        else { detectorUI.style.bottom = 'auto'; detectorUI.style.top = settings.y + 'vh'; }
        if (settings.x > 50) { detectorUI.style.left = 'auto'; detectorUI.style.right = (100 - settings.x) + 'vw'; detectorUI.style.transform = `translateX(50%) scale(${settings.scale})`; }
        else { detectorUI.style.left = settings.x + 'vw'; detectorUI.style.right = 'auto'; detectorUI.style.transform = `translateX(-50%) scale(${settings.scale})`; }
        syncThemeToggles(settings.theme === 'dark');
    };
    const updateEditorValues = (settings) => {
        userSettings = settings;
        document.getElementById('y-pos').value = settings.y;
        document.getElementById('x-pos').value = settings.x;
        document.getElementById('scale').value = settings.scale;
        document.getElementById('theme-toggle').checked = settings.theme === 'dark';
    };
    switch (item.action) {
        case 'showCollectPrompt':
            const promptData = item.data;
            const prompt = $('#collect-prompt');
            $('#radar-name').text(promptData.radarName);
            $('#radar-amount').text(promptData.amount.toFixed(2) + '$');
            $('#collect-key').text(promptData.key);
            $('#last-collector-name').text(promptData.lastCollector || 'N/A');
            const nameText = $('#radar-name').text();
            const lastCollectedText = $('#last-collector-name').text();
            const baseWidth = 320;
            const charWidth = 7;
            const longestTextLength = Math.max(nameText.length, lastCollectedText.length);
            const requiredWidth = Math.min(600, Math.max(baseWidth, (longestTextLength * charWidth) + 160)); 
            prompt.css('width', `${requiredWidth}px`);
            prompt.removeClass('hidden');
            break;

        case 'hideCollectPrompt':
            $('#collect-prompt').addClass('hidden');
            break;

        case 'set_detector_visibility':
            $('#detector-container').toggleClass('force-hidden', !item.visible);
            break;

        case 'toggleUI': document.getElementById('detector-ui').classList.toggle('hidden', !item.show); break;
        case 'showMockPlayerDetector':
            document.getElementById('detector-ui').classList.toggle('hidden', !item.show);
        break;
        case 'setUiVisibility': document.getElementById('detector-ui').classList.toggle('force-hidden', !item.visible); break;
        case 'update':
            document.querySelectorAll('.light').forEach(light => light.classList.remove('active'));
            if (item.inRange) {
                document.querySelector('.main-display').style.display = 'none';
                document.querySelector('.info-display').style.display = 'block';
                //document.getElementById('detector-lights').style.display = 'flex';
                document.getElementById('distance').innerText = item.distance;
                document.getElementById('limit').innerText = item.limit;
                document.getElementById('type').innerText = item.type;
                if (item.light && item.light !== 'none') {
                    const activeLight = document.getElementById('light-' + item.light);
                    if (activeLight) activeLight.classList.add('active');
                }
            } else {
                document.querySelector('.main-display').style.display = 'flex';
                document.querySelector('.info-display').style.display = 'none';
                //document.getElementById('detector-lights').style.display = 'none';
            }
            break;
        case 'toggleEditor':
            document.getElementById('editor-panel').classList.toggle('hidden', !item.show);
                        const policeBtn = document.getElementById('police-menu-btn');
            if (policeBtn) {
                policeBtn.classList.toggle('hidden', !item.isPolice);
            }
            if (item.show) { applyStyles(item.settings); updateEditorValues(item.settings); }
            break;
        case 'applyStyles':
            applyStyles(item.settings);
            if (!document.getElementById('editor-panel').classList.contains('hidden')) { updateEditorValues(item.settings); }
            break;
        case 'toggleLogsMenu':
            const logsApp = document.getElementById('radar-logs-app');
            logsApp.classList.toggle('hidden', !item.show);

            if (item.show) {
                void logsApp.offsetHeight;
                document.getElementById('statistics-view').classList.add('hidden');
                document.querySelector('.sidebar').style.display = 'flex';
                document.getElementById('player-details-placeholder').classList.remove('hidden');
                post('requestSummary');
            }
            else {
                document.getElementById('player-list').innerHTML = '<li class="no-results">No data.</li>';
                document.getElementById('player-details-placeholder').classList.remove('hidden');
                document.getElementById('player-details-view').classList.add('hidden');
                document.getElementById('player-search').value = '';
            }
            break;
        case 'updateSummaryList': updatePlayerList(item.summary); break;
        case 'updatePlayerDetails': updatePlayerDetails(item); break;
        case 'updateStatistics': renderStatistics(item.statistics); break;
        case 'showAvgZoneCreator':
            document.getElementById('avg-zone-creator').classList.remove('hidden');
            document.getElementById('avg-zone-creator').classList.remove('is-finalizing');
            const placeBtn = document.getElementById('place-object-btn');
            if (placeBtn) {
                placeBtn.innerHTML = `<i class="fa-solid fa-cube"></i> Place Object (0/2)`;
                placeBtn.disabled = false;
            }
            break;
        case 'promptAvgZoneDetails':
            document.getElementById('avg-zone-creator').classList.add('is-finalizing');
            const placeBtnFinalize = document.getElementById('place-object-btn');
            if (placeBtnFinalize) placeBtnFinalize.disabled = true;
            break;
        case 'hideAvgZoneCreator':
            document.getElementById('avg-zone-creator').classList.add('hidden');
            document.getElementById('zone-name').value = '';
            document.getElementById('zone-limit').value = '';
            for (let i = 1; i <= 3; i++) {
                document.getElementById(`p${i}_from`).value = '';
                document.getElementById(`p${i}_to`).value = '';
                document.getElementById(`p${i}_points`).value = '';
                document.getElementById(`p${i}_fine`).value = '';
            }
            const placeBtnHide = document.getElementById('place-object-btn');
            if (placeBtnHide) placeBtnHide.disabled = false;
            break;
        case 'showStationaryRadarCreator':
            document.getElementById('stationary-radar-creator').classList.remove('hidden');
            const placeObjBtn = document.getElementById('place-stationary-object');
            placeObjBtn.innerHTML = `<i class="fa-solid fa-cube"></i> Place Object`;
            placeObjBtn.classList.remove('success');
            break;
        case 'hideStationaryRadarCreator':
            document.getElementById('stationary-radar-creator').classList.add('hidden');
            document.getElementById('radar-name').value = '';
            document.getElementById('radar-limit').value = '';
            for (let i = 1; i <= 3; i++) {
                document.getElementById(`sr_p${i}_from`).value = '';
                document.getElementById(`sr_p${i}_to`).value = '';
                document.getElementById(`sr_p${i}_points`).value = '';
                document.getElementById(`sr_p${i}_fine`).value = '';
            }
            break;
        case 'toggleStationaryCreator':
            const creator = document.getElementById('stationary-radar-creator');
            creator.classList.toggle('hidden', !item.show);
            if (item.objectPlaced) {
                const btn = document.getElementById('place-stationary-object');
                btn.innerHTML = `<i class="fa-solid fa-check"></i> Object Placed`;
                btn.classList.add('success');
            }
            break;
        case 'toggleStationaryPlacementBar':
            document.getElementById('stationary-object-placement-bar').classList.toggle('hidden', !item.show);
            break;
        case 'toggleAdminMenu':
            document.getElementById('radar-admin-app').classList.toggle('hidden', !item.show);
            if (item.show) {
                post('admin:requestRadarList');
                syncThemeToggles(userSettings.theme === 'dark');
            }
            break;
        case 'updateRadarList':
            updateRadarList(item.radars, item.zones);
            break;
        case 'updateObjectCount':
            const btn = document.getElementById('place-object-btn');
            if (btn) {
                btn.innerHTML = `<i class="fa-solid fa-cube"></i> Place Object (${item.count}/2)`;
                if (item.count >= 2) {
                    btn.disabled = true;
                }
            }
            break;
        case 'toggleAvgZoneBar':
            document.getElementById('avg-zone-creator')?.classList.toggle('hidden', !item.show);
            break;
        case 'toggleObjectPlacementBar':
            const objBar = document.getElementById('object-placement-bar');
            if (objBar) {
                objBar.classList.toggle('hidden', !item.show);
                if (item.show) {
                    const counter = document.getElementById('object-placement-counter');
                    if (counter) {
                        counter.innerHTML = `<i class="fa-solid fa-cube"></i> Objects: ${item.count}/2`;
                    }
                }
            }
            break;
        case 'toggleHeightBar':
            document.getElementById('polyzone-height-bar').classList.toggle('hidden', !item.show);
            if (item.show) {
                document.getElementById('polyzone-height-value').textContent = `Height: ${item.value.toFixed(1)}m`;
            }
            break;
        case 'toggleTriggerBar':
            document.getElementById('trigger-regulation-bar').classList.toggle('hidden', !item.show);
            if (item.show) {
                document.getElementById('trigger-size-value').textContent = `Width: ${item.radius.toFixed(1)}m | Height: ${item.height.toFixed(1)}m`;
            }
            break;
        case 'updatePolyzoneHeight':
            document.getElementById('polyzone-height-value').textContent = `Height: ${item.value.toFixed(1)}m`;
            break;
        case 'updateTriggerSize':
            document.getElementById('trigger-size-value').textContent = `Width: ${item.radius.toFixed(1)}m | Height: ${item.height.toFixed(1)}m`;
            break;
        case 'showConfirmation':
            confirmationData = item;
            const dialog = document.getElementById('confirmation-dialog');
            const textEl = document.getElementById('confirmation-text');
            let message = '';

            if (item.type === 'stationary') {
                message = "We recommend placing the object where it is visible to players. You can also collect money from objects. Are you sure you want to save without it?";
            } else if (item.type === 'avg') {
                const remaining = 2 - item.objectCount;
                message = `You have only placed ${item.objectCount}/2 objects. We recommend placing the remaining ${remaining} object(s). Are you sure you want to save?`;
            }

            textEl.textContent = message;
            dialog.classList.remove('hidden');
            break;
        
        case 'toggleTrikojisPlacementBar':
            document.getElementById('trikojis-object-placement-bar').classList.toggle('hidden', !item.show);
            break;
        
        case 'showTrikojisConfig':
            const panel = document.getElementById('trikojis-creator-panel');
            document.getElementById('trikojis-error-message').classList.add('hidden');

            trikojisLimits = item.limits;
            
            document.getElementById('trikojis-limit').value = item.currentLimit || '';
            document.getElementById('trikojis-blip').checked = item.currentBlip || false;

            const defaults = item.defaults || [];
            for (let i = 0; i < 3; i++) {
                document.getElementById(`trikojis_p${i + 1}_from`).value = defaults[i]?.from || '';
                document.getElementById(`trikojis_p${i + 1}_to`).value = defaults[i]?.to || '';
                document.getElementById(`trikojis_p${i + 1}_points`).value = defaults[i]?.points || '';
                document.getElementById(`trikojis_p${i + 1}_fine`).value = defaults[i]?.fine || '';
            }
            panel.classList.remove('hidden');
            break;
        case 'hideTrikojisConfig':
            document.getElementById('trikojis-creator-panel').classList.add('hidden');
            document.getElementById('trikojis-error-message').classList.add('hidden');
            break;

        case 'showTrikojisValidationError':
            const errorBox = document.getElementById('trikojis-error-message');
            if (errorBox) {
                errorBox.textContent = item.error;
                errorBox.classList.remove('hidden');
            }
            break;
                        case 'toggle_police_editor':
                $('#police-editor-panel').toggleClass('hidden', !item.show);
                if (item.show) {
                    $('#police-y-pos').val(item.settings.y);
                    $('#police-x-pos').val(item.settings.x);
                    $('#police-scale').val(item.settings.scale);
                }
                break;
            
            case 'apply_police_styles':
                const policeDetector = document.getElementById('detector-container');
                const settings = item.settings;
                if (!policeDetector) return;
                
                if (settings.y > 50) {
                    policeDetector.style.top = 'auto';
                    policeDetector.style.bottom = (100 - settings.y) + 'vh';
                } else {
                    policeDetector.style.bottom = 'auto';
                    policeDetector.style.top = settings.y + 'vh';
                }
                
                if (settings.x > 50) {
                    policeDetector.style.left = 'auto';
                    policeDetector.style.right = (100 - settings.x) + 'vw';
                } else {
                    policeDetector.style.left = settings.x + 'vw';
                    policeDetector.style.right = 'auto';
                }
                policeDetector.style.transform = `translate(-50%, -50%) scale(${settings.scale})`;
                break;
                case 'hideMockPlayerDetector':
                if (!$('#detector-ui').hasClass('force-hidden')) {
                    $('#detector-ui').addClass('hidden');
                }
                $('#mock-detector-toggle').prop('checked', false);
                break;

            case 'hideMockPoliceDetector':
                if (!$('#detector-container').hasClass('force-hidden')) {
                    $('#detector-container').addClass('hidden');
                }
                $('#mock-police-detector-toggle').prop('checked', false);
                break;

        case 'showTrikojisInfo':
            const infoPanel = document.getElementById('trikojis-info-panel');
            const radarInfo = item.data;

            document.getElementById('trikojis-info-limit').textContent = `${radarInfo.limit} ${item.speedLabel}`;
            document.getElementById('trikojis-info-owner').textContent = radarInfo.ownerName;
            document.getElementById('trikojis-info-fines').textContent = radarInfo.stats.finesCount;
            document.getElementById('trikojis-info-money').textContent = `${radarInfo.stats.moneyCollected}$`;
            
            document.getElementById('trikojis-edit-text').innerHTML = `Press <kbd>${item.editKeyName}</kbd> to edit`;
            document.getElementById('trikojis-collect-text').innerHTML = `Press <kbd>${item.collectKeyName}</kbd> to collect`;
            document.getElementById('trikojis-remove-text').innerHTML = `Press <kbd>${item.removeKeyName}</kbd> to remove`;

            if (batteryInterval) clearInterval(batteryInterval);

            const endTime = radarInfo.creationTime + item.batteryLife;
            const batteryEl = document.getElementById('trikojis-info-battery');

            function updateTimer() {
                const now = Math.floor(Date.now() / 1000);
                const remaining = endTime - now;

                batteryEl.classList.remove('discharged');

                if (remaining <= 0) {
                    batteryEl.textContent = 'Discharged';
                    batteryEl.classList.add('discharged');
                    clearInterval(batteryInterval);
                    return;
                }
                const minutes = Math.floor(remaining / 60);
                const seconds = remaining % 60;
                batteryEl.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
            updateTimer();
            batteryInterval = setInterval(updateTimer, 1000);

            infoPanel.classList.remove('hidden');
            break;

        case 'hideTrikojisInfo':
            document.getElementById('trikojis-info-panel').classList.add('hidden');
            if (batteryInterval) clearInterval(batteryInterval);
            batteryInterval = null;
            break;
        case 'updateTrikojisStats':
            const stats = item.data;
            if (stats) {
                const finesEl = document.getElementById('trikojis-info-fines');
                const moneyEl = document.getElementById('trikojis-info-money');
                if (finesEl) finesEl.textContent = stats.finesCount;
                if (moneyEl) moneyEl.textContent = `${stats.moneyCollected}$`;
            }
            break;
        case 'flashRequiredAction':
            const removeEl = document.getElementById('trikojis-remove-text');
            const collectEl = document.getElementById('trikojis-collect-text');

            if (removeEl && collectEl) {
                removeEl.classList.add('flash-red');
                collectEl.classList.add('flash-green');

                setTimeout(() => {
                    removeEl.classList.remove('flash-red');
                    collectEl.classList.remove('flash-green');
                }, 1500);
            }
            break;
            case 'showViolationSnapshot':
    const snap = document.getElementById('snapshot-container');
    const data = item.data;

    document.getElementById('snap-radar-name').textContent = data.radarName;
    document.getElementById('snap-vehicle-model').textContent = data.model;
    document.getElementById('snap-vehicle-plate').textContent = data.plate;
    document.getElementById('snap-timestamp').textContent = new Date(data.timestamp * 1000).toLocaleString('lt-LT');
    document.getElementById('snap-speed-clocked').textContent = data.speed;
    document.getElementById('snap-speed-limit').textContent = data.limit;

    snap.classList.remove('hidden');
    snap.classList.add('visible');

    setTimeout(() => {
        snap.classList.remove('visible');
        setTimeout(() => snap.classList.add('hidden'), 500);
    }, 10000);
    break;
 case 'show_detector':
                $('#detector-container').removeClass('hidden');
                $('#distance-value').text('--');
                $('#plate-value').text('--');
                $('#signal-bars .bar').removeClass('active');
                $('#detector-display').removeClass('found-animation');
                break;
            case 'hide_detector':
                $('#detector-container').addClass('hidden');
                break;
            case 'found_detector':
                var distance = item.distance ? Math.round(item.distance) + 'm' : '--';
                var signalStrength = item.distance ? Math.max(1, Math.min(5, Math.ceil((75 - item.distance) / 15))) : 0;

                $('#distance-value').text(distance);
                $('#plate-value').text(item.plate);
                $('#detector-display').addClass('found-animation');
                $('#signal-bars .bar').removeClass('active');
                for (var i = 0; i < signalStrength; i++) {
                    $('#signal-bars .bar').eq(i).addClass('active');
                }
                break;
            case 'notFound_detector':
                $('#distance-value').text('--');
                $('#plate-value').text('NO SIGNAL');
                $('#signal-bars .bar').removeClass('active');
                $('#detector-display').removeClass('found-animation');

                setTimeout(function() {
                    if (!$('#detector-container').hasClass('hidden') && $('#plate-value').text() === 'NO SIGNAL') {
                        $('#plate-value').text(' ');
                    }
                }, 1500);
                break;
    }
});

function syncThemeToggles(isDark) {
    document.body.classList.toggle('dark-theme', isDark);
    const editorToggle = document.getElementById('theme-toggle');
    if (editorToggle) editorToggle.checked = isDark;
    const adminToggle = document.getElementById('admin-theme-toggle');
    if (adminToggle) adminToggle.checked = isDark;
}

function gatherCurrentSettings() {
    const isDark = document.body.classList.contains('dark-theme');
    userSettings.theme = isDark ? 'dark' : 'light';

    const editorPanel = document.getElementById('editor-panel');
    const yPos = document.getElementById('y-pos');
    if (editorPanel && !editorPanel.classList.contains('hidden') && yPos) {
        userSettings.y = parseFloat(yPos.value);
        userSettings.x = parseFloat(document.getElementById('x-pos').value);
        userSettings.scale = parseFloat(document.getElementById('scale').value);
    }
    return userSettings;
}

document.addEventListener('DOMContentLoaded', () => {
    const yPosSlider = document.getElementById('y-pos');
    const xPosSlider = document.getElementById('x-pos');
    const scaleSlider = document.getElementById('scale');
    function updatePreview() {
        const settings = { y: parseFloat(yPosSlider.value), x: parseFloat(xPosSlider.value), scale: parseFloat(scaleSlider.value) };
        const detectorUI = document.getElementById('detector-ui');
        if (settings.y > 50) { detectorUI.style.top = 'auto'; detectorUI.style.bottom = (100 - settings.y) + 'vh'; }
        else { detectorUI.style.bottom = 'auto'; detectorUI.style.top = settings.y + 'vh'; }
        if (settings.x > 50) { detectorUI.style.left = 'auto'; detectorUI.style.right = (100 - settings.x) + 'vw'; detectorUI.style.transform = `translateX(50%) scale(${settings.scale})`; }
        else { detectorUI.style.left = settings.x + 'vw'; detectorUI.style.right = 'auto'; detectorUI.style.transform = `translateX(-50%) scale(${settings.scale})`; }
    }
    if (yPosSlider && xPosSlider && scaleSlider) {
        [yPosSlider, xPosSlider, scaleSlider].forEach(slider => { slider.addEventListener('input', updatePreview); });
    }
    document.getElementById('save-settings')?.addEventListener('click', () => {
        const latestSettings = gatherCurrentSettings();
        post('saveRadarSettings', latestSettings);
    });
    document.getElementById('place-object-btn')?.addEventListener('click', () => {
        post('startObjectPlacement');
    });
    document.getElementById('police-menu-btn')?.addEventListener('click', () => {
        post('openPoliceMenu');
    });
    document.getElementById('reset-settings')?.addEventListener('click', () => post('resetRadarSettings'));
    document.getElementById('close-editor-btn')?.addEventListener('click', () => post('closeEditor'));

    const themeToggle = document.getElementById('theme-toggle');
    const adminThemeToggle = document.getElementById('admin-theme-toggle');
    function handleThemeChange(e) {
        syncThemeToggles(e.target.checked);
        const latestSettings = gatherCurrentSettings();
        post('saveUiSettingsBackground', latestSettings);
    }
    if (themeToggle) themeToggle.addEventListener('change', handleThemeChange);
    if (adminThemeToggle) adminThemeToggle.addEventListener('change', handleThemeChange);

    const playerSearchInput = document.getElementById('player-search');
    const searchButton = document.getElementById('search-button');
    const prevPageBtn = document.getElementById('prev-page');
    const nextPageBtn = document.getElementById('next-page');
    const showStatsBtn = document.getElementById('show-statistics-btn');
    const backToLogsBtn = document.getElementById('back-to-logs-btn');
    showStatsBtn?.addEventListener('click', () => {
        document.querySelector('.sidebar').style.display = 'none';
        document.getElementById('player-details-placeholder').classList.add('hidden');
        document.getElementById('player-details-view').classList.add('hidden');
        document.getElementById('statistics-view').classList.remove('hidden');
        post('requestStatistics');
    });
    backToLogsBtn?.addEventListener('click', () => {
        document.getElementById('statistics-view').classList.add('hidden');
        document.querySelector('.sidebar').style.display = 'flex';
        if (document.querySelector('#player-list li.active')) {
            document.getElementById('player-details-view').classList.remove('hidden');
        } else {
            document.getElementById('player-details-placeholder').classList.remove('hidden');
        }
    });
    searchButton?.addEventListener('click', () => { post('searchPlayers', { query: playerSearchInput.value.trim() }); });
    playerSearchInput?.addEventListener('keyup', (event) => { if (event.key === 'Enter') { searchButton.click(); } });
    document.getElementById('close-logs-app')?.addEventListener('click', () => { post('closeLogsMenu'); });
    prevPageBtn?.addEventListener('click', () => {
        if (currentPage > 1) { currentPage--; renderInfractionsPage(currentPage); }
    });
    nextPageBtn?.addEventListener('click', () => {
        const totalPages = Math.ceil(allPlayerInfractions.length / infractionsPerPage);
        if (currentPage < totalPages) { currentPage++; renderInfractionsPage(currentPage); }
    });

    const saveZoneBtn = document.getElementById('save-zone-btn');
    const cancelZoneBtn = document.getElementById('cancel-zone-creation');
    saveZoneBtn?.addEventListener('click', () => {
        const zoneData = {
            name: document.getElementById('zone-name').value.trim(),
            limit: parseInt(document.getElementById('zone-limit').value, 10),
            speedingThreshold: parseInt(document.getElementById('zone-threshold').value, 10) || null,
            penalties: [
                { from: parseInt(document.getElementById('p1_from').value, 10), to: parseInt(document.getElementById('p1_to').value, 10), points: parseInt(document.getElementById('p1_points').value, 10), fine: parseInt(document.getElementById('p1_fine').value, 10) },
                { from: parseInt(document.getElementById('p2_from').value, 10), to: parseInt(document.getElementById('p2_to').value, 10), points: parseInt(document.getElementById('p2_points').value, 10), fine: parseInt(document.getElementById('p2_fine').value, 10) },
                { from: parseInt(document.getElementById('p3_from').value, 10), to: parseInt(document.getElementById('p3_to').value, 10), points: parseInt(document.getElementById('p3_points').value, 10), fine: parseInt(document.getElementById('p3_fine').value, 10) }
            ].filter(p => !isNaN(p.from) && !isNaN(p.to) && !isNaN(p.points) && !isNaN(p.fine))
        };
        if (!zoneData.name || isNaN(zoneData.limit)) { return; }
        post('saveNewAverageZone', zoneData);
    });
    cancelZoneBtn?.addEventListener('click', () => post('cancelAverageZoneCreation'));
    document.getElementById('add-objects-btn')?.addEventListener('click', () => {
        document.getElementById('avg-zone-creator').classList.remove('is-finalizing');
        post('startObjectPlacement');
        post('unfocusNuiForPlacement');
    });

    const saveStationaryBtn = document.getElementById('save-stationary-btn');
    const cancelStationaryBtn = document.getElementById('cancel-stationary-creation');
    const placeStationaryObjBtn = document.getElementById('place-stationary-object');
    placeStationaryObjBtn?.addEventListener('click', () => post('startStationaryObjectPlacement'));
    saveStationaryBtn?.addEventListener('click', () => {
        const radarData = {
            name: document.getElementById('new-radar-name').value.trim(),
            limit: parseInt(document.getElementById('radar-limit').value, 10),
            speedingThreshold: parseInt(document.getElementById('new-radar-threshold').value, 10) || null,
            penalties: [
                { from: parseInt(document.getElementById('sr_p1_from').value, 10), to: parseInt(document.getElementById('sr_p1_to').value, 10), points: parseInt(document.getElementById('sr_p1_points').value, 10), fine: parseInt(document.getElementById('sr_p1_fine').value, 10) },
                { from: parseInt(document.getElementById('sr_p2_from').value, 10), to: parseInt(document.getElementById('sr_p2_to').value, 10), points: parseInt(document.getElementById('sr_p2_points').value, 10), fine: parseInt(document.getElementById('sr_p2_fine').value, 10) },
                { from: parseInt(document.getElementById('sr_p3_from').value, 10), to: parseInt(document.getElementById('sr_p3_to').value, 10), points: parseInt(document.getElementById('sr_p3_points').value, 10), fine: parseInt(document.getElementById('sr_p3_fine').value, 10) }
            ].filter(p => !isNaN(p.from) && !isNaN(p.to) && !isNaN(p.points) && !isNaN(p.fine))
        };
        if (!radarData.name || isNaN(radarData.limit)) { return; }
        post('saveNewStationaryRadar', radarData);
    });
    cancelStationaryBtn?.addEventListener('click', () => post('cancelStationaryRadarCreation'));

    document.getElementById('close-admin-app')?.addEventListener('click', () => {
        document.getElementById('radar-details-view').classList.add('hidden');
        document.getElementById('radar-details-placeholder').classList.remove('hidden');
        currentlySelectedRadar = null;
        post('admin:closeMenu');
    });
    document.getElementById('admin-create-stationary')?.addEventListener('click', () => post('admin:startStationaryCreation'));
    document.getElementById('admin-create-avg-zone')?.addEventListener('click', () => post('admin:startAvgZoneCreation'));
    document.getElementById('teleport-to-radar')?.addEventListener('click', () => {
        if (currentlySelectedRadar) { post('admin:teleportToRadar', { radar: currentlySelectedRadar }); }
    });
    document.getElementById('set-gps-location')?.addEventListener('click', () => {
        if (currentlySelectedRadar) { post('admin:setGpsLocation', { radar: currentlySelectedRadar }); }
    });
    document.getElementById('delete-radar')?.addEventListener('click', () => {
        if (currentlySelectedRadar) { post('admin:deleteRadar', { radar: currentlySelectedRadar }); }
    });
    document.getElementById('save-radar-changes')?.addEventListener('click', () => {
        if (!currentlySelectedRadar) return;
        const newPenalties = [];
        for (let i = 1; i <= 3; i++) {
            const from = parseInt(document.getElementById(`edit_p${i}_from`).value, 10);
            const to = parseInt(document.getElementById(`edit_p${i}_to`).value, 10);
            const points = parseInt(document.getElementById(`edit_p${i}_points`).value, 10);
            const fine = parseInt(document.getElementById(`edit_p${i}_fine`).value, 10);
            if (!isNaN(from) && !isNaN(to) && !isNaN(points) && !isNaN(fine)) {
                newPenalties.push({ from, to, points, fine });
            }
        }
        const updatedData = {
            originalName: currentlySelectedRadar.name, type: currentlySelectedRadar.type,
            limit: parseInt(document.getElementById('edit-radar-limit').value, 10),
            speedingThreshold: parseInt(document.getElementById('edit-radar-threshold').value, 10) || null,
            penalties: newPenalties,
        };
        post('admin:saveRadarChanges', { data: updatedData });
    });
    document.getElementById('confirm-btn-no')?.addEventListener('click', () => {
        document.getElementById('confirmation-dialog').classList.add('hidden');
        confirmationData = null;
    });
    document.getElementById('confirm-btn-yes')?.addEventListener('click', () => {
        document.getElementById('confirmation-dialog').classList.add('hidden');
        if (confirmationData) {
            if (confirmationData.type === 'stationary') { post('proceedWithStationarySave', confirmationData.data); }
            else if (confirmationData.type === 'avg') { post('proceedWithAvgZoneSave', confirmationData.data); }
        }
        confirmationData = null;
    });
    let debounceTimer;
    const handleNameValidation = async (inputElement, saveButtonElement, type) => {
        const name = inputElement.value.trim();
        const errorElement = inputElement.nextElementSibling;
        const symbolLimitElement = errorElement.nextElementSibling;
        const maxLength = parseInt(inputElement.getAttribute('maxlength'), 10);
        inputElement.classList.remove('invalid');
        errorElement.classList.add('hidden');
        symbolLimitElement.classList.add('hidden');
        saveButtonElement.disabled = false;
        if (name === '') { saveButtonElement.disabled = true; return; }
        if (name.length >= maxLength) { symbolLimitElement.classList.remove('hidden'); }
        else { symbolLimitElement.classList.add('hidden'); }
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(async () => {
            const result = await post('checkNameExists', { name: name, type: type });
            if (result && result.exists) {
                inputElement.classList.add('invalid');
                errorElement.classList.remove('hidden');
                saveButtonElement.disabled = true;
            } else {
                inputElement.classList.remove('invalid');
                errorElement.classList.add('hidden');
                saveButtonElement.disabled = name.length > maxLength;
            }
        }, 300);
    };
    const newRadarNameInput = document.getElementById('new-radar-name');
    if (newRadarNameInput && saveStationaryBtn) {
        newRadarNameInput.addEventListener('input', () => { handleNameValidation(newRadarNameInput, saveStationaryBtn, 'stationary'); });
        saveStationaryBtn.disabled = true;
    }
    const zoneNameInput = document.getElementById('zone-name');
    if (zoneNameInput && saveZoneBtn) {
        zoneNameInput.addEventListener('input', () => { handleNameValidation(zoneNameInput, saveZoneBtn, 'avg'); });
        saveZoneBtn.disabled = true;
    }

    document.getElementById('trikojis-save')?.addEventListener('click', () => {
        const errorBox = document.getElementById('trikojis-error-message');
        errorBox.classList.add('hidden');

        const radarData = {
            limit: parseInt(document.getElementById('trikojis-limit').value, 10),
            showBlip: document.getElementById('trikojis-blip').checked,
            penalties: [
                { from: parseInt(document.getElementById('trikojis_p1_from').value, 10), to: parseInt(document.getElementById('trikojis_p1_to').value, 10), points: parseInt(document.getElementById('trikojis_p1_points').value, 10), fine: parseInt(document.getElementById('trikojis_p1_fine').value, 10) },
                { from: parseInt(document.getElementById('trikojis_p2_from').value, 10), to: parseInt(document.getElementById('trikojis_p2_to').value, 10), points: parseInt(document.getElementById('trikojis_p2_points').value, 10), fine: parseInt(document.getElementById('trikojis_p2_fine').value, 10) },
                { from: parseInt(document.getElementById('trikojis_p3_from').value, 10), to: parseInt(document.getElementById('trikojis_p3_to').value, 10), points: parseInt(document.getElementById('trikojis_p3_points').value, 10), fine: parseInt(document.getElementById('trikojis_p3_fine').value, 10) }
            ].filter(p => !isNaN(p.from) && !isNaN(p.to) && !isNaN(p.points) && !isNaN(p.fine))
        };
        
        const showError = (message) => {
            errorBox.textContent = message;
            errorBox.classList.remove('hidden');
        };

        if (isNaN(radarData.limit) || radarData.limit <= 0) {
            return showError('Error: The speed limit must be a valid number greater than zero.');
        }

        if (trikojisLimits && trikojisLimits.length > 0) {
            for (let i = 0; i < radarData.penalties.length; i++) {
                const tier = radarData.penalties[i];
                const limits = trikojisLimits[i]?.limits;
                if (!limits) continue;

                if (tier.from >= tier.to) {
                    return showError(`Error in Tier ${i + 1}: 'From' value (${tier.from}) must be less than 'To' value (${tier.to}).`);
                }
                if (i > 0) {
                    const prevTier = radarData.penalties[i - 1];
                    if (tier.from <= prevTier.to) {
                        return showError(`Error in Tier ${i + 1}: 'From' value (${tier.from}) must be greater than the previous tier's 'To' value (${prevTier.to}).`);
                    }
                }
                if (tier.from < limits.min_from) return showError(`Error in Tier ${i + 1}: 'From' value cannot be less than ${limits.min_from}.`);
                if (tier.to > limits.max_to) return showError(`Error in Tier ${i + 1}: 'To' value cannot be greater than ${limits.max_to}.`);
                if (tier.points < 0 || tier.points > limits.max_points) return showError(`Error in Tier ${i + 1}: Points cannot be more than ${limits.max_points}.`);
                if (tier.fine < 0 || tier.fine > limits.max_fine) return showError(`Error in Tier ${i + 1}: Fine cannot be more than ${limits.max_fine}.`);
            }
        }

        post('saveTrikojisConfig', radarData);
    });

    document.getElementById('trikojis-cancel')?.addEventListener('click', () => {
        post('cancelTrikojisPlacement');
        document.getElementById('trikojis-creator-panel').classList.add('hidden');
        document.getElementById('trikojis-error-message').classList.add('hidden');
    });
});

// HELPER FUNCTIONS FOR LOGS
function updatePlayerList(summary) {
    const playerList = document.getElementById('player-list');
    const tooltip = document.getElementById('custom-tooltip');
    if (!playerList || !tooltip) return;
    playerList.innerHTML = '';
    if (summary && summary.length > 0) {
        summary.forEach(player => {
            const li = document.createElement('li');
            li.setAttribute('data-identifier', player.identifier);
            li.innerHTML = `<span class="player-name">${player.player_name || 'Unknown'}</span>`;
            li.addEventListener('mouseenter', () => {
                tooltip.textContent = player.identifier;
                tooltip.classList.remove('hidden');
            });
            li.addEventListener('mousemove', (e) => {
                tooltip.style.left = (e.clientX + 15) + 'px';
                tooltip.style.top = (e.clientY + 15) + 'px';
            });
            li.addEventListener('mouseleave', () => { tooltip.classList.add('hidden'); });
            li.addEventListener('click', () => {
                if (playerList.querySelector('li.active')) {
                    playerList.querySelector('li.active').classList.remove('active');
                }
                li.classList.add('active');
                document.getElementById('player-details-placeholder').classList.add('hidden');
                document.getElementById('player-details-view').classList.remove('hidden');
                document.getElementById('selected-player-name').textContent = player.player_name || 'Unknown';
                post('requestPlayerInfractions', { identifier: player.identifier });
            });
            playerList.appendChild(li);
        });
    } else {
        playerList.innerHTML = '<li class="no-results">No results found for the search.</li>';
    }
};

function updatePlayerDetails(data) {
    allPlayerInfractions = data.infractions || [];
    currentPage = 1;
    document.getElementById('revocation-count').textContent = `${data.revocationCount || 0} times.`;
    const licenseStatusEl = document.getElementById('license-status');
    if (data.revokedLicenses && data.revokedLicenses.length > 0) {
        const friendlyNames = data.revokedLicenses.map(type => licenseTypeTranslations[type] || type).join(', ');
        licenseStatusEl.textContent = `Revoked (${friendlyNames})`;
        licenseStatusEl.className = 'stat-value revoked';
    } else {
        licenseStatusEl.textContent = 'Valid';
        licenseStatusEl.className = 'stat-value valid';
    }
    document.getElementById('total-fines').textContent = `${data.totalFines || 0}$`;
    if (data.maxSpeeding && data.maxSpeeding.difference > 0) { document.getElementById('max-speeding').textContent = `${data.maxSpeeding.speed} / ${data.maxSpeeding.limit} km/h or mph`; }
    else { document.getElementById('max-speeding').textContent = 'N/A'; }
    if (data.mostFrequentZone && data.mostFrequentZone.count > 0) { document.getElementById('frequent-zone').textContent = `${data.mostFrequentZone.name} (${data.mostFrequentZone.count} times.)`; }
    else { document.getElementById('frequent-zone').textContent = 'N/A'; }
    renderInfractionsPage(currentPage);
};

function renderInfractionsPage(page) {
    const infractionsTableBody = document.getElementById('infractions-table-body');
    const pageInfoEl = document.getElementById('page-info');
    const prevPageBtn = document.getElementById('prev-page');
    const nextPageBtn = document.getElementById('next-page');
    if (!infractionsTableBody || !pageInfoEl || !prevPageBtn || !nextPageBtn) return;
    infractionsTableBody.innerHTML = '';
    const totalPages = Math.ceil(allPlayerInfractions.length / infractionsPerPage);
    pageInfoEl.textContent = `Page ${page} of ${totalPages > 0 ? totalPages : 1}`;
    prevPageBtn.disabled = page === 1;
    nextPageBtn.disabled = page === totalPages || allPlayerInfractions.length === 0;
    if (allPlayerInfractions.length === 0) {
        infractionsTableBody.innerHTML = '<tr><td colspan="5" class="no-infractions">This player has no violations.</td></tr>';
        return;
    }
    const startIndex = (page - 1) * infractionsPerPage;
    const endIndex = startIndex + infractionsPerPage;
    const pageInfractions = allPlayerInfractions.slice(startIndex, endIndex);
    pageInfractions.forEach(infraction => {
        const date = new Date(infraction.timestamp).toLocaleString('lt-LT', { dateStyle: 'short', timeStyle: 'short' });
        const row = `
            <tr>
                <td>${date}</td>
                <td>${infraction.radar_name || 'N/A'} (${infraction.radar_type || 'N/A'})</td>
                <td><span class="log-speed-value">${infraction.player_speed}</span> / ${infraction.speed_limit} km/h or mph</td>
                <td>${infraction.fine_amount}$</td>
                <td>+${infraction.points_added}</td>
            </tr>
        `;
        infractionsTableBody.innerHTML += row;
    });
}

// HELPER FUNCTIONS FOR ADMIN MENU
function updateRadarList(radars, zones) {
    const radarListEl = document.getElementById('radar-list');
    radarListEl.innerHTML = '';

    document.getElementById('radar-details-view').classList.add('hidden');
    document.getElementById('radar-details-placeholder').classList.remove('hidden');
    currentlySelectedRadar = null;

    const allItems = [
        ...radars.map(r => ({ ...r, type: 'stationary' })),
        ...zones.map(z => ({ ...z, type: 'avg' }))
    ];

    if (allItems.length === 0) {
        radarListEl.innerHTML = '<li class="no-results">No radars or zones found.</li>';
        return;
    }

    allItems.forEach((item, index) => {
        const li = document.createElement('li');
        li.dataset.index = index;
        li.dataset.type = item.type;
        li.innerHTML = `<span class="radar-name">${item.name}</span><span class="radar-type">${item.type === 'stationary' ? 'Stationary Radar' : 'Average Speed'}</span>`;

        li.addEventListener('click', () => {
            const currentActive = radarListEl.querySelector('li.active');
            if (currentActive) currentActive.classList.remove('active');
            li.classList.add('active');

            currentlySelectedRadar = item;
            displayRadarDetails(item);
        });

        radarListEl.appendChild(li);
    });
}

function displayRadarDetails(radar) {
    document.getElementById('radar-details-placeholder').classList.add('hidden');
    document.getElementById('radar-details-view').classList.remove('hidden');

    document.getElementById('selected-radar-name').textContent = radar.name;
    document.getElementById('edit-radar-limit').value = radar.limit;
    document.getElementById('edit-radar-threshold').value = radar.speedingThreshold || '';

    for (let i = 1; i <= 3; i++) {
        document.getElementById(`edit_p${i}_from`).value = '';
        document.getElementById(`edit_p${i}_to`).value = '';
        document.getElementById(`edit_p${i}_points`).value = '';
        document.getElementById(`edit_p${i}_fine`).value = '';
    }

    if (radar.penalties) {
        radar.penalties.forEach((p, i) => {
            if (i < 3) {
                document.getElementById(`edit_p${i + 1}_from`).value = p.from;
                document.getElementById(`edit_p${i + 1}_to`).value = p.to;
                document.getElementById(`edit_p${i + 1}_points`).value = p.points;
                document.getElementById(`edit_p${i + 1}_fine`).value = p.fine;
            }
        });
    }
}


// GENERAL CLOSE FUNCTION WITH THE "ESCAPE" KEY
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        const editorPanel = document.getElementById('editor-panel');
        const logsApp = document.getElementById('radar-logs-app');
        const stationaryCreator = document.getElementById('stationary-radar-creator');
        const avgCreator = document.getElementById('avg-zone-creator');
        const adminApp = document.getElementById('radar-admin-app');

        if (editorPanel && !editorPanel.classList.contains('hidden')) { post('closeEditor'); }
        if (logsApp && !logsApp.classList.contains('hidden')) { post('closeLogsMenu'); }
        if (stationaryCreator && !stationaryCreator.classList.contains('hidden')) { post('cancelStationaryRadarCreation'); }
        if (avgCreator && !avgCreator.classList.contains('hidden')) {
            post('cancelAverageZoneCreation');
        }
        if (adminApp && !adminApp.classList.contains('hidden')) { post('admin:closeMenu'); }
    }
});


// STATISTICS RENDERING FUNCTION
function renderStatistics(stats) {
    const lists = {
        topStationaryRadars: document.getElementById('top-stationary-radars-list'),
        topAverageZones: document.getElementById('top-average-zones-list'),
        topSpeeders: document.getElementById('top-speeders-list'),
        topFinePayers: document.getElementById('top-fine-payers-list'),
        topMobileRadars: document.getElementById('top-mobile-radars-list')
    };
    const tooltip = document.getElementById('custom-tooltip');

    const topOfficersList = document.getElementById('top-officers-radars-list');
    if (topOfficersList && stats.topOfficersByRadar) {
        topOfficersList.innerHTML = '';
        stats.topOfficersByRadar.forEach(item => {
            topOfficersList.innerHTML += `<li><span class="list-item-name">${item.owner_name || 'Unknown Officer'}</span><span class="list-item-value">${item.count} fines</span></li>`;
        });
    }

    for (const list of Object.values(lists)) {
        if (list) list.innerHTML = '';
    }

    stats.topStationaryRadars?.forEach(item => {
        lists.topStationaryRadars.innerHTML += `<li><span class="list-item-name">${item.radar_name || 'N/A'}</span><span class="list-item-value">${item.count} times</span></li>`;
    });
    stats.topAverageZones?.forEach(item => {
        lists.topAverageZones.innerHTML += `<li><span class="list-item-name">${item.radar_name || 'N/A'}</span><span class="list-item-value">${item.count} times</span></li>`;
    });
    stats.topSpeeders?.forEach(item => {
        const li = document.createElement('li');
        li.innerHTML = `<span class="list-item-name">${item.player_name}</span><span class="list-item-value">+${item.max_over_speed} km/h</span>`;
        li.addEventListener('mouseenter', () => {
            tooltip.textContent = item.identifier;
            tooltip.classList.remove('hidden');
        });
        li.addEventListener('mousemove', (e) => {
            tooltip.style.left = (e.clientX + 15) + 'px';
            tooltip.style.top = (e.clientY + 15) + 'px';
        });
        li.addEventListener('mouseleave', () => { tooltip.classList.add('hidden'); });
        lists.topSpeeders.appendChild(li);
    });
    stats.topFinePayers?.forEach(item => {
        const li = document.createElement('li');
        li.innerHTML = `<span class="list-item-name">${item.player_name}</span><span class="list-item-value">${item.total_fines}$</span>`;
        li.addEventListener('mouseenter', () => {
            tooltip.textContent = item.identifier;
            tooltip.classList.remove('hidden');
        });
        li.addEventListener('mousemove', (e) => {
            tooltip.style.left = (e.clientX + 15) + 'px';
            tooltip.style.top = (e.clientY + 15) + 'px';
        });
        li.addEventListener('mouseleave', () => { tooltip.classList.add('hidden'); });
        lists.topFinePayers.appendChild(li);
    });
        stats.topMobileRadars?.forEach(item => {
        lists.topMobileRadars.innerHTML += `<li><span class="list-item-name">${item.radar_name || 'N/A'}</span><span class="list-item-value">${item.count} times</span></li>`;
    });
}

function applyPoliceStylesJS(settings) {
    const policeDetector = document.getElementById('detector-container');
    if (!policeDetector) return;

    policeDetector.style.top = settings.y + 'vh';
    policeDetector.style.left = settings.x + 'vw';
    policeDetector.style.bottom = 'auto';
    policeDetector.style.right = 'auto';
    policeDetector.style.transform = `translate(-50%, -50%) scale(${settings.scale})`;
}

function updatePolicePreview() {
    const settings = {
        y: parseFloat(document.getElementById('police-y-pos').value),
        x: parseFloat(document.getElementById('police-x-pos').value),
        scale: parseFloat(document.getElementById('police-scale').value)
    };
    applyPoliceStylesJS(settings);
}

const policePosSliders = ['police-y-pos', 'police-x-pos', 'police-scale'];
policePosSliders.forEach(id => {
    const slider = document.getElementById(id);
    if (slider) {
        slider.addEventListener('input', updatePolicePreview);
    }
});

document.getElementById('police-save-settings')?.addEventListener('click', () => {
    const settings = {
        y: parseFloat(document.getElementById('police-y-pos').value),
        x: parseFloat(document.getElementById('police-x-pos').value),
        scale: parseFloat(document.getElementById('police-scale').value)
    };
    post('police_editor:save', settings);
});

document.getElementById('police-reset-settings')?.addEventListener('click', () => {
    post('police_editor:reset', {});
});

document.getElementById('police-close-editor-btn')?.addEventListener('click', () => {
    post('police_editor:close', {});
});

document.getElementById('mock-detector-toggle')?.addEventListener('change', (event) => {
    post('toggleMockPlayerDetector', { show: event.target.checked });
});

document.getElementById('mock-police-detector-toggle')?.addEventListener('change', (event) => {
    post('toggleMockPoliceDetector', { show: event.target.checked });
});

document.getElementById('police-back-btn')?.addEventListener('click', () => {
    post('goBackToPlayerMenu');
});