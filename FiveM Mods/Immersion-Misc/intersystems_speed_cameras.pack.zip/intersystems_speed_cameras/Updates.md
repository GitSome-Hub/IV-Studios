## 1.0.7 (SILENT UPDATE)

1. Added esx_billing as requested.

## Changes has been made in config.lua & locales/*
# [config.lua]
# [locales/*]

## 1.0.6

1. Added a police anti-radar detector – now they can catch players using anti-radar devices!
2. Anti-radar & police anti-radar: when you open the game menu, the UI now hidden.
3. In the /eRadar menu, players with the Police job can see an extra button to modify police anti-radar detector positions.
4. Added an extra function in the /eRadar menu to enable a dummy anti-radar for positioning purposes.
5. Multi-language support added. You can now create a file with your own language, and after an update, simply add your language file.
6. Optimised inventory pictures.

## Changes has been made in index.html & notifications.lua & script.js & style.css & config.lua & [img.png] folder.
# [script.js]
# [style.css]
# [config.lua]
# [notifications.lua]
# [index.html]
# [[database]/[item.png]]

## 1.0.5

1. Updated antiradar display & new looks.
2. Now items you can use from inventory.
3. Added one missed text translation in notifications.lua
4. Most wanted racer. If player has speeds more as you set in config.lua from Config.WantedRacer, police will start see blip of that player for short time.
5. Added tooltips in /radarAdmin menu.

## Changes has been made in index.html & notifications.lua & script.js & style.css & config.lua & [img.png] folder.
# [script.js]
# [style.css]
# [config.lua]
# [notifications.lua]
# [index.html]
# [[database]/[item.png]]

## 1.0.4

1. Fixed qb-core framework not recognise admins. Please read in [shared] folder Readme.md instructions.
2. Fixed issue when you creating average speed zone and trying to place 1 object, it has detect as placed 2 objects.

## 1.0.3

1. Added in statistics "Top 10 Officers (Mobile Radars)"
2. Created for statistics of Top 10 Officers (Mobile Radars) the extra database [extra_i_speeding_infractions.sql]. Check this in [database] folder.
3. Fixed issue with Mobile Radar configuration set/edit values & update values.
4. Added For Mobile radars a webhooks, you will find at [server_webhooks_config] folder.

## Changes has been made in script.js & server_webhook_config.lua
# [script.js]
# [server_webhooks_config.lua]

## 1.0.2

1. Added two different radar object types. Now stationary radars and average speed zones have distinct models. See Config.lua.
2. Added options in Config.lua to customize screen effects and sounds.
3. Added mobile speed cameras.
4. Added animations.
5. Added "snapshot".
6. Fixed minor things.
7. Check [database] folder in [item.png] folder you find mobile camera icon.
8. For mobile camera prop:
   ensure_bzzz_pdradar
   ensure intersystems_speed_cameras
#  To download mobile prop camera, please visit this link and download it [FREE] - https://bzzz.tebex.io/package/6631002

## Changes has been made in Config.lua & nofitications.lua & index.html & style.css & script.js
# [Config.lua] - Includes new settings and radar model options.
# [index.html] - Added new NUI elements for mobile cameras.
# [style.css]  - Added styles for the mobile cameras NUI.
# [script.js]  - Implemented new functions for mobile camera logic.
# [notifications.lua] - Added new translations for mobile cameras.

## 1.0.1

1. Fixed imports in some older versions of the ESX Framework.
2. Fixed incorrect display of the Place object key in index.html

## Changes has been made in index.html & Config.lua & fxmanifest.lua
# [fxmanifest.lua] - been added at 9 line: shared_script '@es_extended/imports.lua' -- Qb-core - do we need comment out this line?
# [index.html] - been changed at 384 line: <span><kbd>E</kbd> Place object</span>
# [Config.lua] - been added in 3 line: -- if qb-core please comment out the 9 line in fxmanifest.lua






