## This system was created by International Systems

1. In [server/server_webhooks_config/] folder you find a config.webhooks.lua, please add your discord webhooks.

## Shop adress: [https://international-systems.tebex.io/]
## Discord adress: [https://discord.gg/SrX6jyJfsT]

## Important: This is version 1.0.2 Don't expect anything crazy from this system yet.


## [IMPORTANT!] - For qb-core add in server.cfg:
# add_ace group.admin "radarsystem.admin" allow