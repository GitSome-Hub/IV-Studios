Config = {}
Config.Framework = 'esx'                        -- Choose framework: 'esx' arba 'qb-core'
                                                -- if [qb-core] please comment out the 9 line in fxmanifest.lua
Config.Language = 'en'                          -- To choose your language you need first to check [locales] folder, if you can't find your language, please create a file: notifications_yourlanguage.lua and just copy-paste from original notifications_en.lua and translate into your language.
                                                -- Supported languages codes: ar, de, en, es, et, fr, it, ja, lt, lv, no, pl, ru, sv, tr, zn
Config.CheckVersion = true                      -- RECOMMENDED - true

-- Vehicle class [Debug] settings
Config.ToggleDebugClassCommand = ''             -- Command to toggle vehicle class display. Default: Config.ToggleDebugClassCommand = 'debugclass'
Config.ShowVehicleClassDebug = false            -- Whether to display the vehicle class on screen (disabled by default)

-- General settings
Config.MaxPenaltyPoints = 8                     -- How many points until driving license is revoked (currently for [ESX] license revoke)
Config.PointDecayTime = 30                      -- After how many MINUTES one penalty point is removed when the player has the maximum amount.
Config.RadarImmunitySeconds = 10                -- For how many seconds the player will be "immune" to the radar after a violation is recorded.
Config.AverageZoneGracePeriod = 10              -- How many seconds player can come back to zone to avoid cancel avg speed zone
Config.StationaryRadarDetectionDistance = 25.0  -- Distance (in meters) from which the stationary radar detects a violation.
Config.FinePaymentMethod = 'bank'               -- 'bank', 'cash', or 'billing' (requires esx_billing & check in config.lua below settings for billing.)

-- Commands settings (Only for admins)
Config.RadarAdmin = 'radarAdmin'                -- [MAIN] - command to control whole speed cameras system.
Config.DebugCommands = 'debugspeedzone'
Config.CreateStationaryRadar = 'new_radar'      -- Command to create a stationary radar.        (Only for admins. You can not use these commands; everything is controlled via /radarAdmin)
Config.CreateAverageSpeedZone = 'new_avg_zone'  -- Command to create a new average speed zone.  (Only for admins. You can not use these commands; everything is controlled via /radarAdmin)
Config.ZoneCheckName = 'zonename'               -- Command to check in what zone do you are.    (Only for admins. You can not use these commands; everything is controlled via /radarAdmin)
Config.ZoneDelete = 'delzone'                   -- Command to delete created zones.             (Only for admins. You can not use these commands; everything is controlled via /radarAdmin)
-- for players
Config.CheckPenlatyPoints = 'points'            -- Command to check penalty points.
Config.EditAntiRadarSettings = 'eRadar'         -- Edits radar size and position.

Config.ViolationSnapshot = {
    Enabled = true,                             -- "Set to 'true' if you want to show the 'photo', or 'false' if you want to disable it."
}

-------------------------------------------------------------------------------------------------------------------------------------------------------
-- License settings - this settings for [ESX] currently...
Config.LicenseRevocation = {
    Enabled = true,                             -- Turn On/Off license revocation.
    Duration = 24,                              -- Duration of revoked license. (How long the sistem has hold license and then give back)
    DurationUnit = 'hours',                     -- 'hours' or 'minutes'
    CheckIntervalMinutes = 15,                  -- For testing, set to 1; for real use, 15 is recommended. How often (in minutes) the server will check if it's time to return the licenses.    
    ResetPointsOnReinstatement = false,         -- It will reset penalty points when the player gets their license back.
    TableName = 'user_licenses'                 -- Only for ESX.
}

Config.DefaultLicenseType = 'drive'             -- Default license category that will be revoked if the vehicle class is not found in the list above.
Config.VehicleClassToLicenseMap = {             -- Passenger cars (classes from 0 to 7) will use the default 'drive' type.
    [7] = 'drive',                              -- Class 7 is SUVs (assigned to standard license)
    [8] = 'drive_bike',                         -- Class 8 is motorcycles.
    [9] = 'drive',                              -- Class 9 is SUVs (assigned to standard license)
    [10] = 'drive_truck',                       -- Class 10 is industrial (trucks)
    [11] = 'drive_truck',                       -- Class 11 is utility (often trucks)
    [12] = 'drive_truck',                       -- Class 12 is vans (can be assigned to truck license)
    [20] = 'drive_truck',                       -- Class 20 is vans (can be assigned to truck license)
    -- You can add more classes here as needed
}

Config.LicenseTypeTranslations = {              -- License translation text.
    ['drive']       = 'Car', 
    ['drive_bike']  = 'Motorcycle',
    ['drive_truck'] = 'Truck',
    -- You can add more license types here if needed.
}
-------------------------------------------------------------------------------------------------------------------------------------------------------
-- [Qb-core & Esx] - if max points reached player can't drive (engine vehicle be off), you can this use if LicenseRevocation is set Enabled to false or true. As you like..
Config.MaxPenaltyPointsReachedCantDrive = false
-------------------------------------------------------------------------------------------------------------------------------------------------------

-- Radar logs settings
Config.LogsCommand = 'radarlogs'                -- Command to open the menu.
Config.LogsAccessJobs = {
    ['police'] = 2,                             -- Allowed from rank 2.
    ['sheriff'] = 2,                            -- Allowed from rank 2.
    -- You can add more jobs here, e.g.: ['fbi'] = 4,
}

-- Object settings [NEW]
Config.StationaryRadarObjectModel = 'prop_cctv_pole_03'    -- Model used ONLY for stationary radars.
Config.AverageZoneObjectModel = 'prop_cctv_pole_01a'       -- Model used ONLY for average speed zone radars.

-- Key settings
Config.AddPoint = 38                            -- Add a point (E)
Config.SetRadarA = 47                           -- Set average zone radar A (G)
Config.SetRadarB = 48                           -- Set average zone radar B (Z)
Config.SaveAverageSpeedZone = 105               -- Save the average speed zone (X)
Config.CancelAvaregeSpeedZone = 177             -- Cancel the average speed zone creation (BACKSPACE)
Config.DeletePointKey = 178                     -- Key 'DELETE'.
Config.RegulateHeightKey = 246                  -- Key to regulate PolyZone height during creation (Y)
Config.RegulateTriggerKey = 311                 -- Key to regulate Start/End triggers (K)
Config.StartObjectPlacementKey = 74             -- Start object placement (H)
Config.PlaceObjectKey = 38                      -- Confirm object placement (E)
Config.RotateObjectLeft = 174                   -- Rotate object left (LEFT ARROW)
Config.RotateObjectRight = 175                  -- Rotate object right (RIGHT ARROW)
Config.ObjectZAxisStep = 0.05                   -- Step for changing object height with mouse wheel.

-- Anti-radar settings
Config.RadarDetectorEnabled = true              -- Whether the feature is enabled (true/false)
Config.RemoveRadarDetectorOnUse = false         -- If true it will remove from inventory (I do not recommend this!)
Config.RadarDetectorMaxDistance = 200.0         -- Maximum distance (in meters) at which the anti-radar is can detect of radars.
Config.RadarDetectorItem = 'anti_radar'         -- Item name in the inventory. Default - 'anti_radar'
Config.RadarDetectorToggleCommand = 'antiradar' -- Command triggered by the button. Do not change unless you know what you are doing.
Config.RadarDetectorKeybind = {                 -- If you use item from inventory, better use and keybind.
    description = 'ON/OFF ANTIRADAR',           -- Description shown in Keybinds settings.
    defaultKey = ''                             -- Default key, which the player can change. Like e.g -> defaultKey = 'G'
}

Config.RadarDetectorIndicators = {              -- Enable/disable sound and lights. This is for anti-radar.
    EnableAudio = true,
    EnableLights = true,    
    Tiers = {                                   -- Distance levels for light colors (in meters)
        Close = 75.0,                           -- Red light (very close)
        Medium = 150.0,                         -- Green light (medium distance)
        -- Anything farther than Medium will be Blue light (up to RadarDetectorMaxDistance)
    },
    BeepSound = {                               -- Sound settings.
        set = "HUD_FRONTEND_DEFAULT_SOUNDSET",  -- Sound set.
        name = "NAV_UP_DOWN"                    -- Sound name (short "beep")
    },
    OnSound = {
        set = "HUD_FRONTEND_DEFAULT_SOUNDSET",  -- Sound set.
        name = "NAV_UP_DOWN"                    -- Sound name (short "beep")
    }
}

-- Effects settings [NEW]
Config.Effects = {
    Sound = {
        Enabled = true,                         -- Set to 'false' if you don’t want a sound effect.
        Name = "Camera_Shoot",                  -- Sound name.
        Set = "Phone_Soundset_Franklin"         -- Sound set.
    },
    Screen = {
        Enabled = true,                         -- Set to 'false' if you don’t want a screen effect
        Name = "ExplosionJosh3",                -- Screen effect names
        Duration = 100                          -- Effect duration in milliseconds
    }
}

-- Jobs settings
Config.EnforceSirensForImmunity = true          -- If the police drive without sirens, they will receive a speeding fine.
Config.IgnoredJobs = {                          -- Simple jobs list. Used ONLY when Config.EnforceSirensForImmunity is 'false'.
    'police',
    'ambulance',
}

Config.IgnoredJobsAndVehicles = {               -- Used ONLY when Config.EnforceSirensForImmunity is 'true'.
    police = {
        'police', 'police2', 'police3', 'police4', 'policeb', 'policet', -- Be sure to use the vehicle "spawn" name (model name)
    },
    ambulance = {
        'ambulance',
    },
    -- You can add more jobs and their vehicles here.
}

-- Speed unit settings
Config.SpeedUnit = 'kmh'                        -- Possible options: 'kmh' or 'mph'.
Config.UnitSettings = {                         -- Do not change these values! The script uses them automatically.
    kmh = {
        multiplier = 3.6,                       -- Conversion factor from m/s to KM/H.
        label = 'km/h'                          -- Text label for messages.
    },
    mph = {
        multiplier = 2.23694,                   -- Conversion factor from m/s to MPH.
        label = 'mph'                           -- Text label for messages.
    }
}

-- Blips settings
Config.ShowBlips = true                         -- Set to 'false' if you want to hide the radar blips on the map.
Config.BlipSettings = {
    Name = "Speed Radar",                       -- Blip name.
    Sprite = 184,                               -- Blip sprite (161 is a standard radar icon)
    Display = 4,                                -- Display method (4 = always visible)
    Scale = 0.8,                                -- Blip scale.
    Colour = 1,                                 -- Blip color (1 = red)
    ShortRange = true,                          -- Is the blip visible from afar (true = visible only when close)
}

Config.AverageBlipSettings = {
    Name = "Avg. Speed Zone",                   -- One name for both ends.
    Sprite = 135,                               -- One blip.
    Display = 4,
    Scale = 0.8,
    Colour = 47,                                -- One color (e.g., yellow or blue, which is more neutral)
    ShortRange = true,
}

-- Others settings
Config.Statistics = {
    Enabled = true,                             -- Enable or disable the statistics module.
    RefreshIntervalDays = 7                     -- Specify how often (in days) the statistics will be automatically refreshed. This reduces server load since the data is not recalculated constantly.
}

Config.FineCollection = {
    Enabled = true,                             -- It will charge from player and send to radars object money. If false, only charge from player.
    CollectionMethod = 'bank',                  -- 'bank', 'cash', or 'billing' (deposits money to society account "'billing' ESX Only currently").
    CollectionJobs = {                          -- Specify jobs and minimum rank required to collect the money.
        ['police'] = 3,
        ['sheriff'] = 4,
    },

    CollectionKey = 38,                         -- Key (E) The key that will be pressed to collect money.
    CollectionKeyName = "E",                    -- Shows in game what key player must press to collect money.
    Animation = {
    Enabled = true,
    Dict = "amb@world_human_stand_mobile_fat@male@text@idle_a",
    Name = "idle_b",
    Duration = 2500,
    },
}

-- Mobile speed cameras settings
Config.TemporaryRadars = {
    Enabled = true,                             -- Enables or disables the entire system.
    RemoveItemOnPlacement = true,               -- Do not make false, becouse currently gives back two items. Must be true
    AllowOtherOfficersInteract = true,          -- Allow to other officers to interect with other officers placed mobile cameras. (The low grade officer can't modify ar take mobile camera if placed officer grade is higher is)
    Command = 'mobcamera',                      -- Command to start placing the radar.
    ItemName = 'mobile_camera',                 -- Name of the item required for placement. Default - ItemName = 'mobile_camera',
    ObjectModel = 'bzzz_police_prop_radar_c',   -- Object model used for the radar (can be changed)
    -- [IMPORTANT - ObjectModel = '']           -- You need to download the FREE prop from: https://bzzz.tebex.io/package/6631002, or use your own if you have one.
    RequiredJobs = {                            -- Jobs and ranks allowed to use the feature.
        ['police'] = 1,                         -- 'police' job can use from rank 1.
    },

    MaxPlacedRadars = 5,                        -- Maximum number of radars a single officer can place at once.
    RemovalDistance = 2.0,                      -- Distance in meters from which a radar can be removed.
    DetectionDistance = 25.0,                   -- Distance in meters for detection (in around cylinder form)
    RemoveKey = 47,                             -- Key [G] to remove the radar.
    CollectKey = 74,                            -- Key [H] to collect fines.
    EditKey = 38,                               -- Key [E] to edit radar settings.
    BatteryLife = 3600,                         -- Battery life in seconds (e.g., 3600s = 1 hour)
    CollectionMethod = 'bank',                  -- What type collect money 'cash' or 'bank'?
    KeyNames = {
        [38] = "E",                             -- Displays that key 38 is "E"
        [47] = "G",                             -- Displays that key 47 is "G"
        [74] = "H",                             -- Displays that key 74 is "H"
    },

    MinSpeedLimit = 20,                         -- The minimum speed limit an officer can set for the radar.
    MaxSpeedLimit = 200,                        -- The maximum speed limit an officer can set for the radar.

    -- Default fines that will be shown in the NUI window (the officer will be able to modify them)
    PenaltyTiers = {                            -- Configuration for penalty tiers, including defaults and limits.
        {
            -- Tier 1: Minor speeding
            defaults = { from = 10, to = 19, points = 1, fine = 150 },
            limits = { min_from = 5, max_to = 25, max_points = 1, max_fine = 250 }
        },
        {
            -- Tier 2: Moderate speeding
            defaults = { from = 20, to = 29, points = 2, fine = 300 },
            limits = { min_from = 20, max_to = 40, max_points = 2, max_fine = 500 }
        },
        {
            -- Tier 3: Major speeding
            defaults = { from = 30, to = 999, points = 3, fine = 500 },
            limits = { min_from = 30, max_to = 999, max_points = 4, max_fine = 1000 }
        }
    },

    BlipSettings = {
        Name = "Mobile camera",
        Sprite = 184,
        Display = 4,
        Scale = 0.7,
        Colour = 5,
        ShortRange = true,
    },

    Animations = {
        Place = {
            Enabled = true,
            Dict = "anim@heists@money_grab@briefcase",
            Name = "put_down_case",
            Duration = 2500,
        },
        Remove = {
            Enabled = true,
            Dict = "anim@heists@money_grab@briefcase",
            Name = "put_down_case",
            Duration = 2000,
        }
    }
}

-- Wanted Racer settings
Config.WantedRacer = {
    Enabled = true,                             -- Enable/disable the entire system.
    SpeedingThreshold = 0,                      -- Leave 0. 0 - means not detecting. (check more information in /radarAdmin menu)
    DurationMinutes = 5,                        -- How many minutes the "wanted" player icon will be visible to officers.
    PoliceJobs = {
        ['police'] = 0,
        ['sheriff'] = 0,
    },

    BlipSettings = {
        Name = "Most Wanted Racer",
        Sprite = 634,
        Display = 4,
        Scale = 1.2,
        Colour = 49,
        ShortRange = false,
    },

    Jammer = {
        Enabled = true,
        ItemName = 'racer_jammer_device',       -- Item name.
        Duration = 60,                          -- How long "jammer" be active.
        Cooldown = 180,                         -- How much time player has wait until can use another.
    },
}

-- Police antiradar detector settings
Config.AntiRadarDetector = {
    ItemName = 'police_antiradar_checker',      -- Item name.
    ScanMode = 'persistent',                    -- Scan mode: 'ping' or 'persistent' | 'ping': works like now - single check & 'persistent': works like a toggle, continuously scans the surroundings.
    DisplayTime = 5000,                         -- Milliseconds for how long the UI will be shown after a 'ping' scan. (Not applicable for 'persistent' mode)
    PersistentScanInterval = 1000,              -- Milliseconds, how often the scanner performs a check in 'persistent' mode
    DetectionAngle = 100,                       -- Angle in which the antiradar is detected.
    ScanRadius = 90.0,                          -- Meters, the range at which the detector works.
    RequiredJobs = {                            -- Jobs that can use this tool.
        ['police'] = 0,
        ['sheriff'] = 0,
    },
}

-- Billing settings
Config.Billing = {
    SocietySender = 'society_police',
    Labels = {
        stationary = 'Speeding (Stationary radar)',
        average    = 'Speeding (Average speed zone)',
        mobile     = 'Speeding (Mobile radar)'
    }
}

-------------------------------------------------------------------------------------------------------------------
-- Speed radar list (PLEASE DO NOT TOUCH THIS, THIS IS MUST BE LIKE THIS OR YOU CAN BREAK SCRIPT)                 |
Config.Radars = {}              -- DONT TOUCH THIS                                                                |
Config.AverageSpeedZones = {}   -- DONT TOUCH THIS                                                                |
Config.RadarObjects = {}        -- DONT TOUCH THIS                                                                |
-- All radars and speed average zones automaticly writes into autogenerated_radars.lua & autogenerated_zones.lua  |
-------------------------------------------------------------------------------------------------------------------