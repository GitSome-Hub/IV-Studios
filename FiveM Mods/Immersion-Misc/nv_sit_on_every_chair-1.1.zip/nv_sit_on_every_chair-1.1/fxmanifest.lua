fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Nevera Development'
description '[FREE] Sit on every chair'
version '1.1.0'

shared_scripts {
	'@es_extended/imports.lua',
	'config.lua'
}

client_scripts { 'client/client.lua'}