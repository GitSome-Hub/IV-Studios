return {
    Commands = {
        invite = {
            name = 'invite',
            help = 'Commands that invites player in your garage',
            enable = true
        }
    }
}