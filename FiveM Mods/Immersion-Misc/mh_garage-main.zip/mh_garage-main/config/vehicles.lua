return {
    -- If you have custom vehicles on server you'll have to add them here

    --[[ [spawn_name] = { name = 'label', brand = 'label' } ]]
    -- [`adder`] = { name = 'Adder', brand = 'Truffade' }
}