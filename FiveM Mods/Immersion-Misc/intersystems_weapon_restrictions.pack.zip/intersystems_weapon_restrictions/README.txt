
At https://international-systems.tebex.io/ you will found Weapon Restrictions V2 version

If you appreciate my free systems, you can support me by purchasing one of my paid systems!

If you have any questions, please contact me on Discord: armando_private



Lets readme

1. Check first fxmanifest.lua
2. This system is will be no longer updating.

Updates

1.1.0
Webhooks have been created. Please review the config.lua and server/webhooks_config.lua files for configuration details.

1.0.1
Added an option to support framework notifications for older ESX versions






