Config = {}

Config.Framework = 'esx'                     -- Specify the framework to use: 'esx' or 'qbcore'
Config.NotificationType = 'framework'        -- Options: 'native' or 'framework'
Config.NotificationText = 'You are not allowed to use this weapon!' -- You can change this text as you like
Config.OldEsxVersionNotification = false     -- [ONLY IF] - If you are using an older version of ESX, such as 1.2, and notifications do not work when please to set to "true"

-- List of restricted weapons with allowed jobs and grades
Config.RestrictedWeapons = {
    ["WEAPON_PISTOL"] = {
        allowedJobs = {
            ["police"] = {0, 1, 2, 3},
            ["security"] = {0, 1}
        }
    },
    ["WEAPON_SMG"] = {
        allowedJobs = {
            ["police"] = {1, 2, 3},
            ["swat"] = {0, 1, 2}
        }
    },
    --[[["WEAPON_YOUR_WEAPON"] = {
        allowedJobs = {
            ["police"] = {1, 2, 3},
            ["ambulance"] = {0, 1, 2},
            --["ADD_JOBS_AS_YOU_WHISH"] = {0, 1, 2, 3},
            --["ADD_JOBS_AS_YOU_WHISH"] = {0, 1, 2, 3},
            --["ADD_JOBS_AS_YOU_WHISH"] = {0, 1, 2, 3}
        }
    },
    ["WEAPON_YOUR_WEAPON"] = {
        allowedJobs = {
            ["police"] = {1, 2, 3},
            ["mechanic"] = {0, 1, 2},
            --["ADD_JOBS_AS_YOU_WHISH"] = {0, 1, 2, 3},
            --["ADD_JOBS_AS_YOU_WHISH"] = {0, 1, 2, 3},
            --["ADD_JOBS_AS_YOU_WHISH"] = {0, 1, 2, 3}
        }
    },]]
    ["WEAPON_CARBINERIFLE"] = {
        allowedJobs = {
            ["military"] = {0, 1, 2, 3, 4},
            ["police"] = {3}
        }
    }
}

-- Pause time between webhook notifications (in minutes) / Your webhook adress please add in [server/webhooks_config.lua] file
Config.WebhooksPlayerPauseTime = 5--mins    -- Pause time in minutes if player use same restricted weapon. (This prevents from spamming your Discord channel if a player tries to take out a restricted gun multiple times in short period.)

Config.WebhookText = "🚨 **Restricted Weapon Attempt Alert** 🚨" -- You can change this text as you like
Config.WebhookText2 = "Weapon Usage Alert"  -- You can change this text as you like
Config.WebhookText3 = "A player attempted to use a restricted weapon. Below are the details." -- You can change this text as you like
Config.WebhookText4 = "Player Name"         -- You can change this text as you like
Config.WebhookText5 = "Weapon Used"         -- You can change this text as you like
Config.WebhookText6 = "Player Server ID"    -- You can change this text as you like
Config.WebhookText7 = "Player Steam ID"     -- You can change this text as you like
Config.WebhookText8 = "Player License ID"   -- You can change this text as you like
Config.WebhookText9 = "Timestamp"           -- You can change this text as you like
Config.WebhookText10 = "Steam: `"           -- You can change this text as you like
Config.WebhookText11 = "ID: `"              -- You can change this text as you like
Config.WebhookText12 = "License: `"         -- You can change this text as you like
Config.WebhookText13 = "FiveM Security System" -- You can change this text as you like
Config.WebhookSteamIdentifier = "N/A"       -- You can change this text as you like
Config.WebhookLicenseIdentifier = "N/A"     -- You can change this text as you like
Config.WebhookColor = 16711680              -- You can change webhook design color

--                                        In paid version you can get this, for more information please visit at: https://international-systems.tebex.io/

--[[

Config = {}

Config.Debug = false
Config.Framework = 'esx'                     -- Specify the framework to use: 'esx' or 'qbcore'
Config.NotificationType = 'native'           -- Options: 'native' or 'framework'
Config.NotificationText = 'You are not allowed to use this weapon!' -- You can change this text as you like
Config.OldEsxVersionNotification = false     -- [ONLY IF] - If you are using an older version of ESX, such as 1.2, and notifications do not work when please to set to "true"

-- List of restricted weapons with allowed jobs and grades
Config.RestrictedWeapons = {
    ["WEAPON_PISTO"] = {
        allowedJobs = {
            ["police"] = {0, 1, 2, 3},
            ["security"] = {0, 1}
        }
    },
    ["WEAPON_SMG"] = {
        allowedJobs = {
            ["police"] = {1, 2, 3},
            ["swat"] = {0, 1, 2}
        }
    },

    --[[["WEAPON_YOUR_WEAPON"] = {
        allowedJobs = {
            ["police"] = {1, 2, 3},
            ["ambulance"] = {0, 1, 2},
            --["ADD_JOBS_AS_YOU_WHISH"] = {0, 1, 2, 3},
            --["ADD_JOBS_AS_YOU_WHISH"] = {0, 1, 2, 3},
            --["ADD_JOBS_AS_YOU_WHISH"] = {0, 1, 2, 3}
        }
    },

    ["WEAPON_CARBINERIFLE"] = {
        allowedJobs = {
            ["military"] = {0, 1, 2, 3, 4},
            ["police"] = {3}
        }
    }
}

-- Weapons Ban Section (The ban check only detects if a player tries to use a weapon from Config.RestrictedWeapons )
-- This is a strict restriction. If a player repeatedly tries to take out the same weapon multiple times, they can receive a ban for an adjustable duration across all weapons.
Config.BanCheckOn = true -- If true, please configurate this settings as you like
Config.CrimeReputation = {
    maxStrikes = 3,           -- Number of strikes before a weapon ban
    banTime = 1800,            -- Ban duration in seconds (1800 = 30 mins)
    resetStrikesTime = 86400, -- Time before strikes reset (86400 = 24 hours) or until server restart
}

Config.NotificationReminderOfBan = 300 -- 5 minutes, in seconds it updates the player how much time left until ban removes
Config.CrimeReputationBanText = "You are banned from using weapons. Timeleft to unban %d second(s)!"
Config.CrimeReputationBanText2 = "You used a restricted weapon. Attempt %d/%d. You have %d attempt(s) left before a weapon ban!"
Config.CrimeBanEndText = "Good news! Your weapon ban has ended, and your strike attempts are back to zero."

-- Weapon Restricted Times section
Config.RestrictedTimesOn = false -- Please only make changes if true, if false, ignore this
Config.RestrictedTimesText = "This weapon is restricted from %02d:00 to %02d:00!"
Config.RestrictedTimes = { 
    {
        weapon = "WEAPON_SMG",
        start = 12,  -- Restrict from 12:00 PM
        finish = 17  -- Until 5:00 PM
    },
    {
        weapon = "YOUR_WEAPON",
        start = 12,  -- Restrict from 12:00 PM
        finish = 17  -- Until 5:00 PM
    },
    {
        weapon = "YOUR_WEAPON",
        start = 21,  -- Restrict from 9:00 PM
        finish = 17   -- Until 5:00 PM (Overnight)
    }
}

-- Weather Conditions section
Config.WeatherRestrictionOn = false -- If true, please add or remove your weapons to apply or remove the effect. It will restrict weapon usage during bad weather.
Config.WeatherWeaponRestrictionsText = "This weapon is restricted due to weather conditions!"
Config.WeatherWeaponRestrictions = {
    ["RAIN"] = {"WEAPON_MUSKET"},                                                                               -- Musket is too wet to fire during rain
    ["THUNDER"] = {"WEAPON_SNIPERRIFLE", "WEAPON_HEAVYSNIPER", "WEAPON_MUSKET", "WEAPON_SMG"},                  -- Snipers disabled during thunderstorms
    ["FOGGY"] = {"WEAPON_RPG", "WEAPON_GRENADELAUNCHER"},                                                       -- Explosives disabled in fog
    ["SNOWLIGHT"] = {"WEAPON_MINIGUN", "WEAPON_COMBATMG"},                                                      -- Miniguns disabled in light snow
    ["BLIZZARD"] = {"WEAPON_CARBINERIFLE", "WEAPON_PUMPSHOTGUN", "WEAPON_SNIPERRIFLE", "WEAPON_HEAVYSNIPER"}    -- Rifles & shotguns restricted in blizzards
}

-- Weapon Cooldown section
Config.WeaponAmmoCooldownOn = true -- If true, please add or remove your weapons to apply or remove the effect. Weapon usage will be restricted while a 'hot' weapon is active.
Config.CooldownNotificationText = "This weapon is too hot! You must wait %d seconds before using this weapon again!"
Config.WeaponAmmoCooldowns = {
    ["WEAPON_RPG"] = {maxShots = 1, timeFrame = 60, cooldown = 120},                -- 1 shot per min, else 2 min cooldown
    ["WEAPON_SNIPERRIFLE"] = {maxShots = 5, timeFrame = 60, cooldown = 120},        -- 5 shots per min, else 2 min cooldown
    --["YOUR_WEAPON"] = {maxShots = 5, timeFrame = 60, cooldown = 120},             -- 5 shots per min, else 2 min cooldown
    ["WEAPON_SMG"] = {maxShots = 120, timeFrame = 60, cooldown = 120}                -- 120 bullets per min, else 2 min cooldown
}

Config.JobBypassCooldowns = { -- Create/Add your jobs, to bypass WeaponAmmoCooldowns if you want.
    ["police"] = {"WEAPON_CARBINERIFLE", "WEAPON_PUMPSHOTGUN"},                     -- No cooldown for these weapons
    --["your_job"] = {"WEAPON_MINIGUN", "WEAPON_RPG"},                              -- You can add your job
    ["military"] = {"WEAPON_MINIGUN", "WEAPON_RPG"}                                 -- Military can use heavy weapons freely
}

-- Webhooks section
-- Pause time between webhook notifications (in minutes) / Your webhook adress please add in [server/webhooks_config.lua] file
Config.WebhooksPlayerPauseTime = 5 -- mins    -- Pause time in minutes if player use same restricted weapon. (This prevents from spamming your Discord channel if a player tries to take out a restricted gun multiple times in short period.)

Config.WebhookText = "🚨Restricted Weapon Attempt Alert"                                        -- You can change this text as you like
Config.WebhookText2 = "Weapon Usage Alert"                                                      -- You can change this text as you like
Config.WebhookText3 = "A player attempted to use a restricted weapon. Below are the details."   -- You can change this text as you like
Config.WebhookText4 = "Player Name"                                                             -- You can change this text as you like
Config.WebhookText5 = "Weapon Used"                                                             -- You can change this text as you like
Config.WebhookText6 = "Player Server ID"                                                        -- You can change this text as you like
Config.WebhookText7 = "Player Steam ID"                                                         -- You can change this text as you like
Config.WebhookText8 = "Player License ID"                                                       -- You can change this text as you like
Config.WebhookText9 = "Timestamp"                                                               -- You can change this text as you like
Config.WebhookText10 = "Steam: `"                                                               -- You can change this text as you like
Config.WebhookText11 = "ID: `"                                                                  -- You can change this text as you like
Config.WebhookText12 = "License: `"                                                             -- You can change this text as you like
Config.WebhookText13 = "FiveM Security System"                                                  -- You can change this text as you like
Config.WebhookText14 = "Powered by International Systems"                                       -- You can change this text as you like
Config.WebhookSteamIdentifier = "N/A"                                                           -- You can change this text as you like
Config.WebhookLicenseIdentifier = "N/A"                                                         -- You can change this text as you like
Config.WebhookColor = 16711680                                                                  -- You can change webhook design color

-- Ban Webhooks / Your webhook adress please add in [server/webhooks_config.lua] file
Config.BanText = "🚨 FiveM Security System"                                                     -- You can change this text as you like
Config.BanText2 = "Player Ban Alert"                                                            -- You can change this text as you like
Config.BanText3 = "A player has been banned from weapons. Below are the details."               -- You can change this text as you like
Config.BanText4 = "Player Name"                                                                 -- You can change this text as you like
Config.BanText5 = "Ban Reason"                                                                  -- You can change this text as you like
Config.BanText6 = "Ban Duration"                                                                -- You can change this text as you like
Config.BanText7 = "Player Server ID"                                                            -- You can change this text as you like
Config.BanText8 = "Player License ID"                                                           -- You can change this text as you like
Config.BanText9 = "Timestamp"                                                                   -- You can change this text as you like
Config.BanText10 = "Exceeded weapon restriction violations"                                     -- You can change this text as you like
Config.BanText11 = "Powered by International Systems"                                           -- You can change this text as you like
Config.BanColor = 15086206                                                                      -- You can change webhook design color

]]