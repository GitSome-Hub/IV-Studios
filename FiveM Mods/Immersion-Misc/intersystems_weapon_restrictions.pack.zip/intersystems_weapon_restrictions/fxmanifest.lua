fx_version 'cerulean'
game 'gta5'
author 'International systems'
description 'Weapon restrictions'
version '1.1.0' 
lua54 'yes'

client_scripts {
    'client/*.lua'
}

shared_scripts {
    'config.lua'
} 

server_scripts {
    'server/*.lua'
}

escrow_ignore {
    'config.lua',
    'server/webhook_config.lua'
}

shared_script '@es_extended/imports.lua' -- need uncomment this?
dependency '/assetpacks'