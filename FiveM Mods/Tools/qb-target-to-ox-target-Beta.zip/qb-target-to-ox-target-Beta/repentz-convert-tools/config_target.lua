local config_target = {}

config_target.originalData = {

    --EXAMPLE

    -- ["leisureshop"] = {
    --     name = "leisureshop",
    --     coords = vector3(-1504.88, 1510.56, 115.29),
    --     length = 3.5,
    --     width = 3.5,
    --     heading = 170.0,
    --     debugPoly = false,
    --     options = {
    --         {
    --             type = "client",
    --             event = "qb-shops:247clerk",
    --             icon = "fas fa-shopping-basket",
    --             label = "Open Shop",
    --             gang = {
    --                 ["yee"] = 2,
    --                 ["data"] = 0,
    --             },
    --             job = "data",
    --         },
    --     },
    --     distance = 3.5
    -- },


    --PLACE AS MANY IN HERE AS YOU WANT!

}

return config_target
