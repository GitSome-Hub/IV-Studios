fx_version 'cerulean'
game 'gta5'
description 'Repentz Convert Tools'
version '1.0'

client_scripts {
	'config_target.lua',
	'qb2ox-target-convert.lua',
}

lua54 'yes'