exports('Repair', Repair)

exports('SetVehicleDriveTrain', SetVehicleDriveTrain)

exports('UpgradePackage', UpgradePackage)

exports('CheckVehicle', CheckVehicle)

exports('ItemFunction',ItemFunction)

exports('SetDefaultHandling', SetDefaultHandling)

exports('GetTuningData', GetTuningData)

exports('CheckPerformance', CheckPerformance)

exports('Dyno', Dyno)

exports('SetVehicleManualGears', SetVehicleManualGears) -- @param1 = vehicle entity (int), @param2 = (bool) Dyno?, @param3 = bool (automatic)