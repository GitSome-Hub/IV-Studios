insert into items (name, label, weight) values 
('bitcoin','Bitcoin', 10),
('weed_skunk','Weed skunk', 10),
('weed_purplehaze','Weed Purple Haze', 10),
('coca_leaf','Coca leaf', 10),
('cokebaggy','Coke baggy', 10),
('coke_small_brick','Coke small brick', 10);