--------------------------------------------------------
CORE RESOURCES
--------------------------------------------------------

Basic Installation:

* Put core_focus in resources folder
* Do not rename core_focus and remove qb-target, ox_target, qtarget completly
* Read the config file and choose your framework if any
* Start the resource in your server.cfg straight after framework

