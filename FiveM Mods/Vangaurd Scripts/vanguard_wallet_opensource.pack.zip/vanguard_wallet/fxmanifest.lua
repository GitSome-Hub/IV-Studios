fx_version 'cerulean'
game 'gta5'
lua54 'yes'
description 'Developed by Vanguard Labs'
version '1.0.2'

shared_scripts {
  '@ox_lib/init.lua',
  'configuration/config.lua'
}

client_scripts {
  'client/*.lua'
}

server_scripts {
  'server/*.lua'
}

dependencies {
  'ox_inventory',
  'ox_target',
  'ox_lib'
}

escrow_ignore {
  'client/client.lua',
  'server/server.lua',
  'configuration/config.lua',
  'inventory-images/*.png'
}
dependency '/assetpacks'