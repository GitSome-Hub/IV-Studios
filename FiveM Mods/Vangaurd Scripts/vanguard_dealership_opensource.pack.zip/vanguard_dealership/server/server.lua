ESX = exports["es_extended"]:getSharedObject()

-- Cache for Steam avatars
local steamAvatarCache = {}

-- Function to get Steam avatar URL
function GetSteamAvatarURL(steamId)
    if not steamId then return nil end
    
    if steamAvatarCache[steamId] then
        return steamAvatarCache[steamId]
    end
    
    local steamApiKey = GetConvar('steam_webApiKey', '')
    if steamApiKey == '' then return nil end
    
    local steam64 = tonumber(string.sub(steamId, 7), 16)
    if not steam64 then return nil end
    
    local apiUrl = string.format(
        'http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=%s&steamids=%s',
        steamApiKey,
        steam64
    )
    
    PerformHttpRequest(apiUrl, function(statusCode, responseText, headers)
        if statusCode == 200 then
            local response = json.decode(responseText)
            if response and response.response and response.response.players 
                and response.response.players[1] then
                local avatarUrl = response.response.players[1].avatarfull
                steamAvatarCache[steamId] = avatarUrl
            end
        end
    end, 'GET')
    
    return steamAvatarCache[steamId]
end

-- Handle vehicle purchase
RegisterServerEvent('dealership:purchaseVehicle')
AddEventHandler('dealership:purchaseVehicle', function(vehicleData)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    local price = vehicleData.price
    local money = xPlayer.getMoney()
    
    if money >= price then
        xPlayer.removeMoney(price)
        
        local plate = 'PDM' .. math.random(100, 999)
        vehicleData.plate = plate
        
        -- Vanguard.notifyserver(source, "Success", Config.UI.notifications.purchaseSuccess, 3000, "info")
        TriggerClientEvent('dealership:purchaseResponse', source, true, Config.UI.notifications.purchaseSuccess, vehicleData)
        TriggerClientEvent('dealership:setPlayerMoney', source, xPlayer.getMoney())
    else
        -- Vanguard.notifyserver(source, "Error", Config.UI.notifications.purchaseFailed, 3000, "error")
        TriggerClientEvent('dealership:purchaseResponse', source, false, Config.UI.notifications.purchaseFailed)
    end
end)

-- Set vehicle as owned
RegisterServerEvent('dealership:setVehicleOwned')
AddEventHandler('dealership:setVehicleOwned', function(vehicleProps)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    exports.oxmysql:insert('INSERT INTO owned_vehicles (owner, plate, vehicle, type, stored) VALUES (?, ?, ?, ?, ?)',
    {
        xPlayer.identifier,
        vehicleProps.plate,
        json.encode(vehicleProps),
        'car',
        1
    }, function(id)
        if id then
            print(('[dealership] Vehicle %s stored for %s'):format(vehicleProps.plate, xPlayer.identifier))
        end
    end)
end)

-- Get player Steam avatar
RegisterServerEvent('dealership:getPlayerAvatar')
AddEventHandler('dealership:getPlayerAvatar', function()
    local source = source
    local steamId = nil
    
    for _, identifier in pairs(GetPlayerIdentifiers(source)) do
        if string.find(identifier, 'steam:') then
            steamId = identifier
            break
        end
    end
    
    if steamId then
        local avatarUrl = GetSteamAvatarURL(steamId)
        TriggerClientEvent('dealership:setPlayerAvatar', source, avatarUrl)
    end
end)

-- Event to update player money
RegisterServerEvent('dealership:updatePlayerMoney')
AddEventHandler('dealership:updatePlayerMoney', function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if xPlayer then
        local money = xPlayer.getMoney()
        TriggerClientEvent('dealership:setPlayerMoney', source, money)
    end
end)