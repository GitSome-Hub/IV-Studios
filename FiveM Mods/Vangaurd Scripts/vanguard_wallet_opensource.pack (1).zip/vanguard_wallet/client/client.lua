local ox_inventory = exports.ox_inventory
local isRobbing = false
local lastRobberyTime = 0
local lastNotificationTime = 0
local NOTIFICATION_COOLDOWN = 2000

-- ===========================================
--        ROBBERY FUNCTIONS
-- ===========================================
local function HasRequiredItems()
    if not Config.Robbery.RequireItems then
        return true
    end

    for _, weapon in ipairs(Config.Robbery.RequiredItems.weapons) do
        if HasPedGotWeapon(PlayerPedId(), GetHashKey(weapon), false) then
            return true
        end
    end
    return false
end

local function ShowCooldownNotification()
    local currentTime = GetGameTimer()
    if currentTime - lastNotificationTime >= NOTIFICATION_COOLDOWN then
        lib.notify({
            type = 'error',
            description = Config.Messages.CooldownActive
        })
        lastNotificationTime = currentTime
    end
end

local function CreateTemporaryBlip(coords)
    local blip = AddBlipForCoord(coords)
    SetBlipSprite(blip, Config.Robbery.PoliceAlert.BlipSprite)
    SetBlipColour(blip, Config.Robbery.PoliceAlert.BlipColor)
    SetBlipScale(blip, Config.Robbery.PoliceAlert.BlipScale)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(Config.Robbery.PoliceAlert.BlipText)
    EndTextCommandSetBlipName(blip)
    
    SetTimeout(Config.Robbery.PoliceAlert.BlipDuration * 1000, function()
        RemoveBlip(blip)
    end)
end

local function MakeNPCFlee(npc, playerPed)
    if not DoesEntityExist(npc) then return end
    
    ClearPedTasks(npc)
    TaskReactAndFleePed(npc, playerPed)
    SetBlockingOfNonTemporaryEvents(npc, false)
    SetPedKeepTask(npc, true)
    SetPedMovementClipset(npc, "MOVE_M@QUICK", 3.0)
    
    SetTimeout(30000, function()
        if DoesEntityExist(npc) then
            DeleteEntity(npc)
        end
    end)
end

local function PlayRobberyAnimation(npc)
    if not DoesEntityExist(npc) then return end
    
    local playerPed = PlayerPedId()
    
    TaskHandsUp(npc, -1, playerPed, -1, true)
    TaskAimGunAtEntity(playerPed, npc, -1, true)
    
    local success = lib.progressCircle({
        duration = Config.Robbery.RobberyDuration * 1000,
        position = 'bottom',
        useWhileDead = false,
        canCancel = true,
        disable = {
            move = true,
            car = true,
            combat = true,
            mouse = false
        }
    })
    
    if success then
        local robberySuccess = lib.callback.await('vanguard_wallet:robNPC', false)
        
        if robberySuccess then
            lib.notify({
                type = 'success',
                description = Config.Messages.RobberySuccess
            })
        else
            lib.notify({
                type = 'error',
                description = Config.Messages.RobberyFailed
            })
        end
    end
    
    ClearPedTasks(playerPed)
    if DoesEntityExist(npc) then
        MakeNPCFlee(npc, playerPed)
    end
end

-- ===========================================
--        WALLET FUNCTIONS
-- ===========================================
local function OpenWallet(walletType, data, slot)
    -- First check if slot has metadata with identifier
    if slot and slot.metadata and slot.metadata.identifier then
        local identifier = slot.metadata.identifier
        ox_inventory:openInventory('stash', 'wallet_'..identifier)
        lib.notify({
            type = 'success',
            description = Config.Messages.WalletOpened
        })
        return
    end
    
    -- If no identifier in metadata, get/create one from server
    local identifier = lib.callback.await('vanguard_wallet:getWalletIdentifier', 1000, data.slot, walletType)
    if identifier then
        ox_inventory:openInventory('stash', 'wallet_'..identifier)
        lib.notify({
            type = 'success',
            description = Config.Messages.WalletOpened
        })
    else
        lib.notify({
            type = 'error',
            description = Config.Messages.ErrorOccurred
        })
    end
end

-- ===========================================
--        BLIP AND NPC CREATION
-- ===========================================
local function CreateBlip()
    if not Config.EnableBlip then return end
    
    local blip = AddBlipForCoord(Config.ShopLocation)
    SetBlipSprite(blip, Config.Blip.Sprite)
    SetBlipColour(blip, Config.Blip.Color)
    SetBlipScale(blip, Config.Blip.Scale)
    SetBlipAsShortRange(blip, Config.Blip.ShortRange)
    
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(Config.Blip.Name)
    EndTextCommandSetBlipName(blip)
end

local function CreateShopNPC()
    if not Config.EnableNPC then return end
    
    local model = GetHashKey(Config.NPC.model)
    RequestModel(model)
    while not HasModelLoaded(model) do 
        Wait(1) 
    end
    
    local npc = CreatePed(4, model, 
        Config.NPC.position.x, 
        Config.NPC.position.y, 
        Config.NPC.position.z, 
        Config.NPC.heading, 
        false, true)
    
    SetEntityInvincible(npc, Config.NPC.invincible)
    FreezeEntityPosition(npc, Config.NPC.frozen)
    SetBlockingOfNonTemporaryEvents(npc, true)
    SetPedCanRagdoll(npc, Config.NPC.canRagdoll)
    
    SetModelAsNoLongerNeeded(model)
end

-- ===========================================
--        TARGET SYSTEMS
-- ===========================================
if Config.EnableNPCRobbery then
    exports.ox_target:addGlobalPed({
        {
            name = 'rob_npc_wallet',
            icon = 'fas fa-wallet',
            label = 'Rob Wallet',
            canInteract = function(entity)
                if not Config.EnableNPCRobbery then return false end
                
                if isRobbing then 
                    local currentTime = GetGameTimer()
                    if currentTime - lastNotificationTime >= NOTIFICATION_COOLDOWN then
                        lib.notify({
                            type = 'error',
                            description = Config.Messages.RobberyInProgress
                        })
                        lastNotificationTime = currentTime
                    end
                    return false 
                end
                
                if (GetGameTimer() - lastRobberyTime) < (Config.Robbery.Cooldown * 1000) then 
                    ShowCooldownNotification()
                    return false 
                end
                
                return IsPedHuman(entity) and not IsPedAPlayer(entity) and not IsPedDeadOrDying(entity) and HasRequiredItems()
            end,
            onSelect = function(data)
                local npc = data.entity
                
                if Config.Robbery.RequireItems and not HasRequiredItems() then
                    lib.notify({
                        type = 'error',
                        description = Config.Messages.NoRequiredItems
                    })
                    return
                end
                
                isRobbing = true
                lastRobberyTime = GetGameTimer()
                
                PlayRobberyAnimation(npc)
                
                isRobbing = false
            end
        }
    })
end

if Config.EnableShop then
    exports.ox_target:addSphereZone({
        coords = Config.ShopLocation,
        radius = 1,
        options = {
            {
                name = 'wallet_shop',
                event = 'vanguard_wallet:openShop',
                icon = 'fas fa-wallet',
                label = 'Open Wallet Shop'
            }
        }
    })
end

-- ===========================================
--        EXPORTS
-- ===========================================
exports('openWalletBasic', function(data, slot)
    OpenWallet(1, data, slot)
end)

exports('openWalletPremium', function(data, slot)
    OpenWallet(2, data, slot)
end)

-- ===========================================
--        EVENTS
-- ===========================================
RegisterNetEvent('vanguard_wallet:createRobberyBlip')
AddEventHandler('vanguard_wallet:createRobberyBlip', function(coords)
    CreateTemporaryBlip(coords)
end)

RegisterNetEvent('vanguard_wallet:openShop')
AddEventHandler('vanguard_wallet:openShop', function()
    exports.ox_inventory:openInventory('shop', { type = 'wallet_shop', id = 1 })
    lib.notify({
        type = 'success',
        description = Config.Messages.ShopOpened
    })
end)

-- ===========================================
--        INITIALIZATION
-- ===========================================
CreateThread(function()
    if Config.EnableBlip then CreateBlip() end
    if Config.EnableNPC then CreateShopNPC() end
end)