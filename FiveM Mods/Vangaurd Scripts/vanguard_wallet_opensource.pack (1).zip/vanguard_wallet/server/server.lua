-- ===========================================
--        FRAMEWORK DETECTION
-- ===========================================
local Framework = nil
local GetPlayer = nil
local AddMoney = nil
local GetPlayerJob = nil

-- Auto-detect framework
if GetResourceState('es_extended') == 'started' then
    Framework = 'ESX'
    ESX = exports['es_extended']:getSharedObject()
    GetPlayer = function(source) return ESX.GetPlayerFromId(source) end
    AddMoney = function(source, amount) 
        local xPlayer = GetPlayer(source)
        if xPlayer then xPlayer.addMoney(amount) end
    end
    GetPlayerJob = function(player) return player.job.name end
elseif GetResourceState('qb-core') == 'started' then
    Framework = 'QBCore'
    QBCore = exports['qb-core']:GetCoreObject()
    GetPlayer = function(source) return QBCore.Functions.GetPlayer(source) end
    AddMoney = function(source, amount)
        local Player = GetPlayer(source)
        if Player then Player.Functions.AddMoney('cash', amount) end
    end
    GetPlayerJob = function(player) return player.PlayerData.job.name end
elseif GetResourceState('qbx_core') == 'started' then
    Framework = 'QBox'
    GetPlayer = function(source) return exports.qbx_core:GetPlayer(source) end
    AddMoney = function(source, amount)
        local Player = GetPlayer(source)
        if Player then Player.Functions.AddMoney('cash', amount) end
    end
    GetPlayerJob = function(player) return player.PlayerData.job.name end
else
    print('[Vanguard Wallet] ERROR: No supported framework detected!')
    return
end

print('[Vanguard Wallet] Framework detected: ' .. Framework)

-- ===========================================
--        WALLET PERSISTENCE SYSTEM
-- ===========================================
local walletIdentifiers = {}
local registeredStashes = {}

-- Load wallet identifiers from file
local function LoadWalletIdentifiers()
    local file = LoadResourceFile(GetCurrentResourceName(), 'wallets.json')
    if file then
        local success, data = pcall(json.decode, file)
        if success and data then
            walletIdentifiers = data
            print('[Vanguard Wallet] Loaded ' .. #walletIdentifiers .. ' wallet identifiers')
            
            -- Re-register all stashes
            for _, walletData in ipairs(walletIdentifiers) do
                if not registeredStashes[walletData.walletId] then
                    local walletConfig = Config.Wallets[walletData.walletType]
                    if walletConfig then
                        exports.ox_inventory:RegisterStash(
                            'wallet_' .. walletData.walletId, 
                            walletConfig.label, 
                            walletConfig.slots, 
                            walletConfig.weight, 
                            false
                        )
                        registeredStashes[walletData.walletId] = true
                    end
                end
            end
        end
    else
        walletIdentifiers = {}
        print('[Vanguard Wallet] No wallet data found, starting fresh')
    end
end

-- Save wallet identifiers to file
local function SaveWalletIdentifiers()
    SaveResourceFile(GetCurrentResourceName(), 'wallets.json', json.encode(walletIdentifiers), -1)
end

-- Find wallet by item serial number
local function FindWalletBySerial(itemSerial)
    for _, walletData in ipairs(walletIdentifiers) do
        if walletData.itemSerial == itemSerial then
            return walletData
        end
    end
    return nil
end

-- Save new wallet identifier  
local function SaveWalletIdentifier(playerIdentifier, itemSerial, walletId, walletType)
    local walletData = {
        playerIdentifier = playerIdentifier,
        itemSerial = itemSerial,
        walletId = walletId,
        walletType = walletType,
        created = os.time()
    }
    
    table.insert(walletIdentifiers, walletData)
    SaveWalletIdentifiers()
end

-- ===========================================
--        HELPER FUNCTIONS
-- ===========================================
local function GetPlayerIdentifier(source)
    if Framework == 'ESX' then
        local xPlayer = GetPlayer(source)
        return xPlayer and xPlayer.identifier
    elseif Framework == 'QBCore' or Framework == 'QBox' then
        local Player = GetPlayer(source)
        return Player and Player.PlayerData.citizenid
    end
end

local function GenerateSerial()
    local str = ''
    for i = 1, 3 do 
        str = str .. string.char(math.random(65, 90)) 
    end
    return string.format('%s%s', str, math.random(100000, 999999))
end

local function IsJobAllowed(job, allowedJobs)
    for _, allowedJob in ipairs(allowedJobs) do
        if job == allowedJob then
            return true
        end
    end
    return false
end

local function SendNotification(source, message)
    TriggerClientEvent('ox_lib:notify', source, {
        type = 'error',
        description = message
    })
end

-- ===========================================
--        ROBBERY SYSTEM
-- ===========================================
local function GiveRobberyRewards(source)
    local rewards = Config.Robbery.Rewards
    local success = false
    
    -- Handle money reward
    if rewards.Money.Enabled then
        local moneyAmount = 0
        if rewards.Money.Type == 'fixed' then
            moneyAmount = rewards.Money.Fixed.Amount
        else
            if math.random(1, 100) <= rewards.Money.Random.Chance then
                moneyAmount = math.random(
                    rewards.Money.Random.MinAmount,
                    rewards.Money.Random.MaxAmount
                )
            end
        end
        
        if moneyAmount > 0 then
            AddMoney(source, moneyAmount)
            success = true
        end
    end
    
    -- Handle item rewards
    if rewards.Items.Enabled then
        for _, itemReward in ipairs(rewards.Items.List) do
            if math.random(1, 100) <= itemReward.chance then
                local quantity = math.random(itemReward.min, itemReward.max)
                exports.ox_inventory:AddItem(source, itemReward.item, quantity)
                success = true
            end
        end
    end
    
    return success
end

-- ===========================================
--        SHOP SYSTEM
-- ===========================================
if Config.EnableShop then
    local walletPrices = {}
    for _, wallet in pairs(Config.Wallets) do
        walletPrices[wallet.name] = wallet.price
    end
    
    exports.ox_inventory:RegisterShop('wallet_shop', {
        name = 'Wallet Shop',
        inventory = {
            { name = 'wallet_basic', price = walletPrices['wallet_basic'] or 100 },
            { name = 'wallet_premium', price = walletPrices['wallet_premium'] or 250 },
        },
        locations = {
            Config.ShopLocation,
        },
    })
end

-- ===========================================
--        CALLBACKS
-- ===========================================
lib.callback.register('vanguard_wallet:getWalletIdentifier', function(source, slot, walletType)
    local playerIdentifier = GetPlayerIdentifier(source)
    if not playerIdentifier then return nil end
    
    -- Get item from slot to access its serial
    local item = exports.ox_inventory:GetSlot(source, slot)
    if not item then return nil end
    
    local itemSerial = item.metadata and item.metadata.serial
    if not itemSerial then
        -- Generate a unique serial for this item if it doesn't have one
        itemSerial = GenerateSerial()
        exports.ox_inventory:SetMetadata(source, slot, { serial = itemSerial })
        Wait(100) -- Small delay to ensure metadata is saved
    end
    
    -- Check if wallet already has an identifier based on item serial
    local existingWallet = FindWalletBySerial(itemSerial)
    if existingWallet then
        -- Re-register stash if not already registered
        if not registeredStashes[existingWallet.walletId] then
            local walletConfig = Config.Wallets[existingWallet.walletType]
            if walletConfig then
                exports.ox_inventory:RegisterStash('wallet_'..existingWallet.walletId, walletConfig.label, walletConfig.slots, walletConfig.weight, false)
                registeredStashes[existingWallet.walletId] = true
            end
        end
        
        -- Update item metadata with wallet identifier
        local currentMetadata = item.metadata or {}
        currentMetadata.identifier = existingWallet.walletId
        currentMetadata.serial = itemSerial
        exports.ox_inventory:SetMetadata(source, slot, currentMetadata)
        
        return existingWallet.walletId
    end
    
    -- Create new identifier
    local newId = GenerateSerial()
    local walletConfig = Config.Wallets[walletType]
    
    if walletConfig then
        -- Register stash
        exports.ox_inventory:RegisterStash('wallet_'..newId, walletConfig.label, walletConfig.slots, walletConfig.weight, false)
        registeredStashes[newId] = true
        
        -- Update item metadata
        local currentMetadata = item.metadata or {}
        currentMetadata.identifier = newId
        currentMetadata.serial = itemSerial
        exports.ox_inventory:SetMetadata(source, slot, currentMetadata)
        
        -- Save to persistent storage
        SaveWalletIdentifier(playerIdentifier, itemSerial, newId, walletType)
        
        return newId
    end
    return nil
end)

lib.callback.register('vanguard_wallet:robNPC', function(source)
    local success = GiveRobberyRewards(source)
    
    -- Alert police if enabled
    if Config.Robbery.PoliceAlert.Enable then
        local ped = GetPlayerPed(source)
        local coords = GetEntityCoords(ped)
        local shouldNotify = Config.Robbery.PoliceAlert.AlwaysNotify or 
                           (math.random(1, 100) <= Config.Robbery.PoliceAlert.NotifyChance)
        
        if shouldNotify then
            local players = GetPlayers()
            for _, playerId in ipairs(players) do
                local player = GetPlayer(playerId)
                if player then
                    local job = GetPlayerJob(player)
                    if IsJobAllowed(job, Config.Robbery.PoliceAlert.Jobs) then
                        TriggerClientEvent('vanguard_wallet:createRobberyBlip', playerId, coords)
                        TriggerClientEvent('ox_lib:notify', playerId, {
                            type = 'inform',
                            description = string.format(Config.Messages.PoliceNotification, 
                                string.format('%.0f, %.0f', coords.x, coords.y))
                        })
                    end
                end
            end
        end
    end
    
    return success
end)

-- ===========================================
--        SIMPLIFIED INVENTORY HOOKS (LIKE BACKPACK)
-- ===========================================
CreateThread(function()
    while GetResourceState('ox_inventory') ~= 'started' do 
        Wait(500) 
    end
    
    -- Wait additional time to ensure ox_inventory is fully loaded
    Wait(5000)
    
    -- Load saved wallet identifiers
    LoadWalletIdentifiers()
    
    -- Register inventory hook using the same method as backpack
    local swapHook = exports.ox_inventory:registerHook('swapItems', function(payload)
        local destination = payload.toInventory
        local fromSlot = payload.fromSlot
        
        -- Check if trying to move to a wallet stash
        if destination and string.find(destination, 'wallet_') then
            
            -- 1. Prevent wallet inside wallet
            if Config.BlockWalletsInWallets and fromSlot and fromSlot.name then
                for _, wallet in ipairs(Config.Wallets) do
                    if fromSlot.name == wallet.name then
                        SendNotification(payload.source, Config.Messages.WalletInWallet)
                        return false
                    end
                end
            end
            
            -- 2. Check item whitelist/blacklist
            if Config.ItemWhitelist.Enabled and fromSlot and fromSlot.name then
                local itemName = string.lower(tostring(fromSlot.name))
                local isInList = false
                
                -- Check if item is in the configured list
                for _, listItem in ipairs(Config.ItemWhitelist.Items) do
                    if itemName == string.lower(tostring(listItem)) then
                        isInList = true
                        break
                    end
                end
                
                -- Apply whitelist/blacklist logic
                local allowed = true
                if Config.ItemWhitelist.Mode == 'whitelist' then
                    allowed = isInList -- Only items in list are allowed
                elseif Config.ItemWhitelist.Mode == 'blacklist' then
                    allowed = not isInList -- Items in list are NOT allowed
                end
                
                if not allowed then
                    local message = Config.ItemWhitelist.Mode == 'whitelist' 
                        and Config.Messages.ItemNotAllowed 
                        or Config.Messages.ItemBlacklisted
                    SendNotification(payload.source, message)
                    return false
                end
            end
        end
        
        -- 3. Check one wallet only restriction when moving wallet to player inventory
        if Config.OneWalletOnly and fromSlot and fromSlot.name then
            -- Check if item is a wallet
            local isWallet = false
            for _, wallet in ipairs(Config.Wallets) do
                if fromSlot.name == wallet.name then
                    isWallet = true
                    break
                end
            end
            
            -- If moving a wallet to player inventory, check current wallet count
            if isWallet and (not destination or destination == tostring(payload.source)) then
                local totalWallets = 0
                for _, walletConfig in ipairs(Config.Wallets) do
                    totalWallets = totalWallets + exports.ox_inventory:GetItemCount(payload.source, walletConfig.name)
                end
                
                if totalWallets >= 1 then
                    SendNotification(payload.source, Config.Messages.WalletLimit)
                    return false
                end
            end
        end
        
        return true
    end, {
        print = false,
    })
    
    print('[Vanguard Wallet] Inventory hooks registered successfully')
end)

-- ===========================================
--        INITIALIZATION
-- ===========================================
-- Cleanup on resource stop
AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        -- Save wallet identifiers before stopping
        SaveWalletIdentifiers()
        print('[Vanguard Wallet] Wallet data saved successfully')
    end
end)