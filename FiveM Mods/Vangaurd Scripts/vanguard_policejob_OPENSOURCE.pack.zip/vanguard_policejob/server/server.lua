cuffedPlayers = {}

ESX = nil
if ConfigFramework == 'oldesx' then
    Citizen.CreateThread(function()
        while not ESX do
            TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
            Citizen.Wait(0)
        end
    end)
else
    ESX = exports['es_extended']:getSharedObject()
end

CreateThread(function()
    while ESX == nil do Wait(1000) end
    for i=1, #Config.policeJobs do
        TriggerEvent('esx_society:registerSociety', Config.policeJobs[i], Config.policeJobs[i], 'society_'..Config.policeJobs[i], 'society_'..Config.policeJobs[i], 'society_'..Config.policeJobs[i], {type = 'public'})
    end
end)

AddEventHandler('esx:playerDropped', function(playerId, reason)
    if cuffedPlayers[playerId] then
        cuffedPlayers[playerId] = nil
    end
end)

TriggerEvent('esx_society:registerSociety', 'police', 'police', 'society_police', 'society_police', 'society_police', {type = 'public'})

RegisterServerEvent('vanguard_policejob:attemptTackle')
AddEventHandler('vanguard_policejob:attemptTackle', function(targetId)
    TriggerClientEvent('vanguard_policejob:tackled', targetId, source)
    TriggerClientEvent('vanguard_policejob:tackle', source)
end)

RegisterServerEvent('vanguard_policejob:escortPlayer')
AddEventHandler('vanguard_policejob:escortPlayer', function(targetId)
    local xPlayer = ESX.GetPlayerFromId(source)
    local hasJob
    for i=1, #Config.policeJobs do
        if xPlayer.job.name == Config.policeJobs[i] then
            hasJob = xPlayer.job.name
            break
        end
    end
    if hasJob then
        TriggerClientEvent('vanguard_policejob:setEscort', source, targetId)
        TriggerClientEvent('vanguard_policejob:escortedPlayer', targetId, source)
    end
end)

RegisterServerEvent('vanguard_policejob:inVehiclePlayer')
AddEventHandler('vanguard_policejob:inVehiclePlayer', function(targetId)
    local xPlayer = ESX.GetPlayerFromId(source)
    local hasJob
    for i=1, #Config.policeJobs do
        if xPlayer.job.name == Config.policeJobs[i] then
            hasJob = xPlayer.job.name
            break
        end
    end
    if hasJob then
        TriggerClientEvent('vanguard_policejob:stopEscorting', source)
        TriggerClientEvent('vanguard_policejob:putInVehicle', targetId)
    end
end)

RegisterServerEvent('vanguard_policejob:outVehiclePlayer')
AddEventHandler('vanguard_policejob:outVehiclePlayer', function(targetId)
    local xPlayer = ESX.GetPlayerFromId(source)
    local hasJob
    for i=1, #Config.policeJobs do
        if xPlayer.job.name == Config.policeJobs[i] then
            hasJob = xPlayer.job.name
            break
        end
    end
    if hasJob then
        TriggerClientEvent('vanguard_policejob:takeFromVehicle', targetId)
    end
end)

RegisterServerEvent('vanguard_policejob:setCuff')
AddEventHandler('vanguard_policejob:setCuff', function(isCuffed)
    cuffedPlayers[source] = isCuffed
end)

RegisterServerEvent('vanguard_policejob:handcuffPlayer')
AddEventHandler('vanguard_policejob:handcuffPlayer', function(target)
    local xPlayer = ESX.GetPlayerFromId(source)
    local hasJob
    for i=1, #Config.policeJobs do
        if xPlayer.job.name == Config.policeJobs[i] then
            hasJob = xPlayer.job.name
            break
        end
    end
    if hasJob then
        if cuffedPlayers[target] then
            TriggerClientEvent('vanguard_policejob:uncuffAnim', source, target)
            Wait(4000)
            TriggerClientEvent('vanguard_policejob:uncuff', target)
        else
            TriggerClientEvent('vanguard_policejob:arrested', target, source)
            TriggerClientEvent('vanguard_policejob:arrest', source)
        end
    end
end)

getPoliceOnline = function()
    local players = ESX.GetPlayers()
    local count = 0
    for i = 1, #players do
        local xPlayer = ESX.GetPlayerFromId(players[i])
        for i=1, #Config.policeJobs do
            if xPlayer.job.name == Config.policeJobs[i] then
                count = count + 1
            end
        end
    end
    return count
end

exports('getPoliceOnline', getPoliceOnline)

lib.callback.register('vanguard_policejob:getJobLabel', function(source, job)
    if ESX.Jobs?[job]?.label then
        return ESX.Jobs[job].label
    else
        return Strings.police -- If for some reason ESX.Jobs is malfunctioning(Must love ESX...)
    end
end)

lib.callback.register('vanguard_policejob:isCuffed', function(source, target)
    if cuffedPlayers[target] then
        return true
    else
        return false
    end
end)

lib.callback.register('vanguard_policejob:getVehicleOwner', function(source, plate)
    local owner
    MySQL.Async.fetchAll('SELECT owner FROM owned_vehicles WHERE plate = @plate', {
        ['@plate'] = plate
    }, function(result)
        if result[1] then
            local identifier = result[1].owner
            MySQL.Async.fetchAll('SELECT firstname, lastname FROM users WHERE identifier = @identifier', {
                ['@identifier'] = identifier
            }, function(result2)
                if result2[1] then
                    owner = result2[1].firstname..' '..result2[1].lastname
                else
                    owner = false
                end
            end)
        else
            owner = false
        end
    end)
    while owner == nil do
        Wait()
    end
    return owner
end)

lib.callback.register('vanguard_policejob:canPurchase', function(source, data)
    local xPlayer = ESX.GetPlayerFromId(source)
    local itemData
    if data.grade > #Config.Locations[data.id].armoury.weapons then
        itemData = Config.Locations[data.id].armoury.weapons[#Config.Locations[data.id].armoury.weapons][data.itemId]
    elseif not Config.Locations[data.id].armoury.weapons[data.grade] then
        print('[vanguard_policejob] : Armory not set up properly for job grade: '..data.grade)
    else
        itemData = Config.Locations[data.id].armoury.weapons[data.grade][data.itemId]
    end
    if not itemData.price then
        if not Config.weaponsAsItems then
            if data.itemId:sub(0, 7) == 'WEAPON_' then
                xPlayer.addWeapon(data.itemId, 200)
            else
                xPlayer.addInventoryItem(data.itemId, data.quantity)
            end
        else
            xPlayer.addInventoryItem(data.itemId, data.quantity)
        end
        return true
    else
        local xBank = xPlayer.getAccount('bank').money
        if xBank < itemData.price then
            return false
        else
            xPlayer.removeAccountMoney('bank', itemData.price)
            if not Config.weaponsAsItems then
                if data.itemId:sub(0, 7) == 'WEAPON_' then
                    xPlayer.addWeapon(data.itemId, 200)
                else
                    xPlayer.addInventoryItem(data.itemId, data.quantity)
                end
            else
                xPlayer.addInventoryItem(data.itemId, data.quantity)
            end
            return true
        end
    end
end)

-- Callback para verificar informações do jogador (somente ESX)
ESX.RegisterServerCallback('vanguard_policejob:checkPlayerId', function(source, cb, targetId)
    local xPlayer = ESX.GetPlayerFromId(targetId)
    local data = {
        name = xPlayer.getName(),
        job = xPlayer.job.label,
        position = xPlayer.job.grade_label,
    }
    
    -- Se esxIdentity estiver habilitado
    if Config.esxIdentity then
        data.dob = xPlayer.get('dateofbirth')
        data.sex = xPlayer.get('sex') == 'm' and 'Male' or 'Female'
    end

    -- Status de embriaguez
    TriggerEvent('esx_status:getStatus', targetId, 'drunk', function(status)
        if status then
            data.drunk = ESX.Math.Round(status.percent)
        end
    end)

    -- Licenças, se esxLicense estiver habilitado
    if Config.esxLicense then
        TriggerEvent('esx_license:getLicenses', targetId, function(licenses)
            data.licenses = licenses
            cb(data)
        end)
    else
        cb(data)
    end
end)



-- Mendefinisikan fungsi SendDiscordWebhook
local function SendDiscordWebhook(webhook, message)
    if webhook == nil then return end

    PerformHttpRequest(webhook, function(err, text, headers) end, 'POST', json.encode(message), { ['Content-Type'] = 'application/json' })
end

-- Menggunakan fungsi SendDiscordWebhook di dalam callback server
ESX.RegisterServerCallback('joblock:ToggleClock', function(src, cb, jobName, clockIn)
    local jobTable = Config.Jobs[jobName]
    if jobTable == nil then return cb(false) end

    local xPlayer = ESX.GetPlayerFromId(src)
    local xPlayerJob = xPlayer.getJob()

    local job = jobTable.ClockedOutJob

    if clockIn then
        job = jobTable.ClockedInJob
    end

    if ESX.DoesJobExist(job, xPlayerJob.grade) then
        xPlayer.setJob(job, xPlayerJob.grade)

        local jobDisplayName = jobTable.JobDisplayName or jobName
        local clockStatus = clockIn and "On-Duty" or "Off-Duty"
        local playerName = GetPlayerName(src)

        -- Mendapatkan waktu WIB saat ini
        local currentTime = os.date("!%H:%M:%S", os.time()+25200) -- Menambahkan 7 jam (25200 detik) ke waktu UTC

        local currentDate = os.date("%d/%m/%Y")
        
        -- Menghitung total menit dari "On-Duty" ke "Off-Duty"
        local totalTime = 0
        if clockIn then
            xPlayer.set("jobclock", os.time()) -- Simpan waktu saat "On-Duty"
        else
            local onDutyTime = xPlayer.get("jobclock") -- Dapatkan waktu saat "On-Duty"
            if onDutyTime then
                totalTime = math.floor((os.time() - onDutyTime) / 60) -- Hitung total menit
            end
        end
        
        local statusColor = clockIn and 65280 or 16711680 -- Green or Red color
        
        -- Mengirim webhook dengan avatar
        local webhookMessage = {
            embeds = {
                {
                    title = string.format("Police Deparment | Duty ", GetCurrentResourceName()),
                    description = string.format("**Name**: **%s**\n**Status**: %s\n**Job**: %s\n**Date**: %s\n**Time**: %s WIB\n**Total Duty Minutes**: %d", xPlayer.name, clockStatus, jobDisplayName, currentDate, currentTime, totalTime),
                    color = statusColor,
                    thumbnail = {
                        url = jobTable.Avatar
                    }
                }
            }
        }
        
        SendDiscordWebhook(jobTable.Webhook, webhookMessage)

        cb(true)
    else
        cb(false)
    end
end)

syncedRopes = {}

RegisterNetEvent("obWeaponLanyard:createlanyard")
AddEventHandler("obWeaponLanyard:createlanyard", function()
    TriggerClientEvent("obWeaponLanyard:createlanyard", -1, source)
end)

RegisterNetEvent("obWeaponLanyard:removelanyard")
AddEventHandler("obWeaponLanyard:removelanyard", function()
    TriggerClientEvent("obWeaponLanyard:removelanyard", -1, source)
end)

RegisterServerEvent('VanguardLabsPeds:sendData')
AddEventHandler('VanguardLabsPeds:sendData', function(Nome, Telefone, Grau, Descricao)
    local webhookUrl = Config['VanguardPeds']['discord']['webhookUrl']
    local roleId = Config['VanguardPeds']['discord']['roleId']
    local playerId = source

    sendToDiscord(Nome, Telefone, Grau, Descricao, playerId, roleId, webhookUrl)
end)

function sendToDiscord(name, number, grade, description, playerId, roleId, webhookUrl)
    local discordData = {
        ["username"] = "Police Department",
        ["avatar_url"] = "https://i.imgur.com/BuKIMkc.png",
        ["content"] = "<@&" .. roleId .. ">",
        ["embeds"] = {{
            ["title"] = "Police Department",
            ["color"] = 3447003,
            ["thumbnail"] = {
                ["url"] = "https://i.imgur.com/BuKIMkc.png"
            },
            ["fields"] = {
                {
                    ["name"] = "Name:",
                    ["value"] = name or "N/A",
                    ["inline"] = false
                },
                {
                    ["name"] = "Phone Number:",
                    ["value"] = number or "N/A",
                    ["inline"] = false
                },
                {
                    ["name"] = "Service Level:",  
                    ["value"] = grade or "N/A",        
                    ["inline"] = false
                },
                {
                    ["name"] = "Description:",
                    ["value"] = description or "N/A",
                    ["inline"] = false
                },
                {
                    ["name"] = "Player ID:",
                    ["value"] = tostring(playerId),
                    ["inline"] = false
                }
            },
            ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ"),
            ["footer"] = {
                ["text"] = "Vanguard Labs | Police Department",
                ["icon_url"] = "https://i.imgur.com/BuKIMkc.png"
            }
        }}
    }

    PerformHttpRequest(webhookUrl, function(statusCode, response, headers)
        if statusCode == 204 then
            print("Message sent successfully to Discord!")
        else
            print("Error sending message to Discord. Status code: " .. tostring(statusCode))
        end
    end, "POST", json.encode(discordData), {["Content-Type"] = "application/json"})
end

