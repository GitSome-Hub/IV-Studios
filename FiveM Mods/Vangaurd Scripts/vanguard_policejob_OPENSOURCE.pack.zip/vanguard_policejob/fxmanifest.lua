fx_version 'cerulean'
game 'gta5'
lua54 'yes'
description 'Developed by Vanguard Labs'
version '1.0.1'

shared_scripts {
  '@ox_lib/init.lua',
  'configuration/*.lua'
}

client_scripts {
  'wrapper/cl_wrapper.lua',
  'wrapper/*.lua',
  'client/*.lua'
}

server_scripts {
  'wrapper/sv_wrapper.lua',
  'wrapper/*.lua',
  'server/*.lua',
  '@mysql-async/lib/MySQL.lua'
}

dependencies {
  'es_extended',
  'mysql-async',
  'ox_lib'
}

escrow_ignore {
  'client/client.lua',
  'server/server.lua',
  'configuration/*.lua',
  'client/cl_customize.lua',
}

provides {
  'esx_policejob'
}

dependency '/assetpacks'
dependency '/assetpacks'