ESX = nil
if ConfigFramework == 'oldesx' then
    Citizen.CreateThread(function()
        while not ESX do
            TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
            Citizen.Wait(0)
        end
    end)
else
    ESX = exports['es_extended']:getSharedObject()
end

--Send to jail
RegisterNetEvent('vanguard_policejob:sendToJail', function(target, time)
    -- Add your jail event trigger here? WILL BE ADDING BUILT IN JAIL SYSTEM SOON!
    -- 'target' = Server ID of target / 'time' minutes input for months
    print('Jailing '..target..' for '..time..' minutes')
end)

