ESX = nil
if Config.Framework == 'oldesx' then
    Citizen.CreateThread(function()
        while not ESX do
            TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
            Citizen.Wait(0)
        end
    end)
else
    ESX = exports['es_extended']:getSharedObject()
end

RegisterNetEvent('k9:checkInventory', function(targetId, sniffableItems)
    local itemsFound = {}
    for _, item in ipairs(sniffableItems) do
        local itemCount = exports.ox_inventory:GetItemCount(targetId, item)
        if itemCount > 0 then
            table.insert(itemsFound, {
                name = item,
                count = itemCount
            })
        end
    end

    -- Retornar os itens encontrados para o cliente
    TriggerClientEvent('k9:inventoryChecked', source, itemsFound)
end)
