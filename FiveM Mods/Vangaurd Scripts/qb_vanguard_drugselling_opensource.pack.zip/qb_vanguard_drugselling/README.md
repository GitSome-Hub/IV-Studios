# Dependencies
 - ox_inventory
 - ox_lib
 - ox_target

## Extra Information
Item to add to `ox_inventory/data/items.lua`
```
	["meth"] = {
		label = "Meth",
		weight = 1,
		stack = true,
		close = true,
	},

	["coke"] = {
		label = "Coke",
		weight = 1,
		stack = true,
		close = true,
	},
	
	["weed"] = {
		label = "Weed",
		weight = 1,
		stack = true,
		close = true,
	},
```

