----              _  _     _  _     _  _     _  _     _  _     _  _     _  _     _  _   
----            _| || |_ _| || |_ _| || |_ _| || |_ _| || |_ _| || |_ _| || |_ _| || |_ 
----            _  ..  _|_  ..  _|_  ..  _|_  ..  _|_  ..  _|_  ..  _|_  ..  _|_  ..  _|
----           |_      _|_      _|_      _|_      _|_      _|_      _|_      _|_      _|
----             |_||_|   |_||_|   |_||_|   |_||_|   |_||_|   |_||_|   |_||_|   |_||_|  
----
---
----             __     __                              _   _          _         
----             \ \   / /_ _ _ __   __ _  __ _ _ __ __| | | |    __ _| |__  ___ 
----              \ \ / / _` | '_ \ / _` |/ _` | '__/ _` | | |   / _` | '_ \/ __|
----               \ V / (_| | | | | (_| | (_| | | | (_| | | |__| (_| | |_) \__ \
----                \_/ \__,_|_| |_|\__, |\__,_|_|  \__,_| |_____\__,_|_.__/|___/
----                                |___/                                        
---- 
----                                 VANGUARD LABS | BRIDGE
----
----               Thank you for purchasing our script; we greatly appreciate your preference.
----        If you have any questions or any modifications in mind, please contact us via Discord.
----
----                           Support and More: https://discord.gg/rq5yVBACTf
----
----              _  _     _  _     _  _     _  _     _  _     _  _     _  _     _  _   
----            _| || |_ _| || |_ _| || |_ _| || |_ _| || |_ _| || |_ _| || |_ _| || |_ 
----            _  ..  _|_  ..  _|_  ..  _|_  ..  _|_  ..  _|_  ..  _|_  ..  _|_  ..  _|
----           |_      _|_      _|_      _|_      _|_      _|_      _|_      _|_      _|
----             |_||_|   |_||_|   |_||_|   |_||_|   |_||_|   |_||_|   |_||_|   |_||_|  
----
----

Config = {}

-- ===============================
--    Configuration Framework
-- ===============================

-- Select the framework you are using, supported frameworks: "esx", "qbcore" 
-- Change the value below based on the framework your server uses.
Config.framework = "esx"  -- Adjust this setting based on your server's framework. 

-- ===============================
--    Notification System
-- ===============================

-- Choose the notification system you're using, supported notify: "esx", "qbcore", "Vanguard_notify", "okokNotify", "wasabi_notify", "brutal_notify".
-- Modify this value according to the notification system you prefer.
Config.notify = "Vanguard_notify"  -- Adjust this setting based on your preferred notification system.

-- ===============================
--    Context Menu System
-- ===============================

-- Choose the context menu system you're using, supported: "Vanguard" (Custom Menu), "lib" (Original ox_lib menu).
-- Modify this value according to the conext menu system you prefer.
Config.MenuType = "Vanguard"
Config.MenuBackground = false  -- True to activate Vanguard menu background or false to disable it.