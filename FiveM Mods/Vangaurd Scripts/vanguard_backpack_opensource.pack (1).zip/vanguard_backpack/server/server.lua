-- Multi-Framework Support (ESX, QBCore, Qbox)
local Framework = nil
local FrameworkName = nil

-- Framework Detection
local function DetectFramework()
    if Config.Framework ~= 'auto' then
        FrameworkName = Config.Framework
    else
        -- Auto-detect framework
        if GetResourceState('es_extended') == 'started' then
            FrameworkName = 'esx'
        elseif GetResourceState('qbx_core') == 'started' then
            FrameworkName = 'qbox'
        elseif GetResourceState('qb-core') == 'started' then
            FrameworkName = 'qbcore'
        else
            print('^1[ERROR] No supported framework detected! Please install ESX, QBCore, or Qbox.^0')
            return
        end
    end
    
    print('^2[INFO] Framework detected: ' .. FrameworkName .. '^0')
end

-- Initialize Framework
local function InitializeFramework()
    DetectFramework()
    
    if FrameworkName == 'esx' then
        Framework = exports['es_extended']:getSharedObject()
    elseif FrameworkName == 'qbox' then
        Framework = exports.qbx_core
    elseif FrameworkName == 'qbcore' then
        Framework = exports['qb-core']:GetCoreObject()
    end
end

-- Initialize on resource start
CreateThread(function()
    InitializeFramework()
end)

-- Framework-specific player functions
local function GetPlayer(source)
    if FrameworkName == 'esx' then
        return Framework.GetPlayerFromId(source)
    elseif FrameworkName == 'qbox' then
        return exports.qbx_core:GetPlayer(source)
    elseif FrameworkName == 'qbcore' then
        return Framework.Functions.GetPlayer(source)
    end
    return nil
end

local function GetPlayerIdentifier(player)
    if FrameworkName == 'esx' then
        return player.identifier
    elseif FrameworkName == 'qbox' then
        return player.PlayerData.citizenid
    elseif FrameworkName == 'qbcore' then
        return player.PlayerData.citizenid
    end
    return nil
end

local registeredStashes = {}
local ox_inventory = exports.ox_inventory

local function GenerateText(num)
    local str
    repeat str = {}
        for i = 1, num do str[i] = string.char(math.random(65, 90)) end
        str = table.concat(str)
    until str ~= 'POL' and str ~= 'EMS'
    return str
end

local function GenerateSerial(text)
    if text and text:len() > 3 then
        return text
    end
    return ('%s%s%s'):format(math.random(100000,999999), text == nil and GenerateText(3) or text, math.random(100000,999999))
end

local function SendNotification(source, notificationKey)
    local notification = Config.Notifications[notificationKey]
    if notification then
        TriggerClientEvent('vanguard_backpack:sendNotification', source, notification)
    end
end

RegisterServerEvent('vanguard_backpack:openBackpack')
AddEventHandler('vanguard_backpack:openBackpack', function(identifier, backpackLevel)
    local src = source
    if not src or src <= 0 then return end

    local xPlayer = GetPlayer(src)
    if not xPlayer then 
        SendNotification(src, 'playerNotFound')
        return 
    end

    if not registeredStashes[identifier] then
        local backpackConfig = Config.Backpacks[backpackLevel] or Config.Backpacks[1]
        ox_inventory:RegisterStash('bag_'..identifier, backpackConfig.label, backpackConfig.slots, backpackConfig.weight, false)
        registeredStashes[identifier] = true
    end

    -- Only check PIN if system is globally enabled
    if Config.UsePINSystem then
        MySQL.Async.fetchScalar('SELECT pin FROM user_backpacks WHERE backpackID = @backpackID', {
            ['@backpackID'] = identifier
        }, function(storedPin)
            if storedPin and src and GetPlayerPing(src) > 0 then
                TriggerClientEvent('vanguard_backpack:requestPin', src, identifier, backpackLevel)
            end
        end)
    end
end)

lib.callback.register('vanguard_backpack:getNewIdentifier', function(source, slot, backpackLevel)
    local newId = GenerateSerial()
    local backpackConfig = Config.Backpacks[backpackLevel] or Config.Backpacks[1]
    ox_inventory:SetMetadata(source, slot, {identifier = newId, level = backpackLevel})
    ox_inventory:RegisterStash('bag_'..newId, backpackConfig.label, backpackConfig.slots, backpackConfig.weight, false)
    registeredStashes[newId] = true
    return newId
end)

lib.callback.register('vanguard_backpack:checkOrInsertPin', function(source, backpackID, backpackLevel)
    local xPlayer = GetPlayer(source)
    if not xPlayer then 
        return false, 'Player not found'
    end

    -- If PIN system is globally disabled, don't check PIN
    if not Config.UsePINSystem then
        return false, nil
    end

    if not registeredStashes[backpackID] then
        local backpackConfig = Config.Backpacks[backpackLevel] or Config.Backpacks[1]
        ox_inventory:RegisterStash('bag_'..backpackID, backpackConfig.label, backpackConfig.slots, backpackConfig.weight, false)
        registeredStashes[backpackID] = true
    end

    local result = MySQL.Sync.fetchScalar('SELECT pin FROM user_backpacks WHERE backpackID = @backpackID', {
        ['@backpackID'] = backpackID
    })

    return result ~= nil, result
end)

RegisterNetEvent('vanguard_backpack:setNewPin')
AddEventHandler('vanguard_backpack:setNewPin', function(backpackID, pin)
    local src = source
    local xPlayer = GetPlayer(src)
    if not xPlayer then 
        SendNotification(src, 'playerNotFound')
        return 
    end

    -- Only save PIN if system is enabled
    if Config.UsePINSystem then
        MySQL.Async.execute('INSERT INTO user_backpacks (backpackID, pin) VALUES (@backpackID, @pin)', {
            ['@backpackID'] = backpackID,
            ['@pin'] = pin
        }, function(affectedRows)
            if affectedRows > 0 then
                SendNotification(src, 'pinSet')
            end
        end)
    end
end)

local backpackPrices = {}
for _, backpack in ipairs(Config.Backpacks) do
    backpackPrices[backpack.name] = backpack.price
end

exports.ox_inventory:RegisterShop('backpackshop', {
    name = Config.Texts.backpackShopLabel,
    inventory = {
        { name = 'backpack_level_1', price = backpackPrices['backpack_level_1'] or 10 },
        { name = 'backpack_level_2', price = backpackPrices['backpack_level_2'] or 10 },
        { name = 'backpack_level_3', price = backpackPrices['backpack_level_3'] or 10 },
    },
    locations = {
        vec3(399.8024, 96.92446, 101.48),
    },
})

CreateThread(function()
    while GetResourceState('ox_inventory') ~= 'started' do Wait(500) end
    
    local swapHook = ox_inventory:registerHook('swapItems', function(payload)
        local start, destination, move_type = payload.fromInventory, payload.toInventory, payload.toType
        local item = payload.fromSlot
        
        -- Prevent backpack inside backpack if enabled
        if Config.PreventBackpackInBackpack then
            -- Check if trying to move a backpack into another backpack
            if string.find(destination, 'bag_') and item and item.name then
                for _, backpack in ipairs(Config.Backpacks) do
                    if item.name == backpack.name then
                        -- Trying to put a backpack inside another backpack
                        SendNotification(payload.source, 'backpackInBackpack')
                        return false
                    end
                end
            end
        end
        
        return true
    end, {
        print = false,
        itemFilter = {
            backpack_level_1 = true,
            backpack_level_2 = true,
            backpack_level_3 = true,
        },
    })
end)