-- =====================================================
-- BACKPACK SYSTEM - ORGANIZED STRUCTURE
-- Multi-Framework Support (ESX, QBCore, Qbox)
-- =====================================================

-- =====================================================
-- VARIABLE DECLARATIONS
-- =====================================================

-- Framework Variables
local Framework = nil
local FrameworkName = nil
local PlayerData = {}

-- Backpack System Variables
local bagEquipped = false
local bagObj = nil
local ox_inventory = exports.ox_inventory
local ped = cache.ped
local justConnect = true
local customProps = {}
local playerPed = nil
local isInVehicle = false
local lastPosition = nil
local propAttachTimer = nil
local resourceStarted = false

-- =====================================================
-- UTILITY FUNCTIONS
-- =====================================================

-- Function to check if player has any backpack
local function HasAnyBackpack()
    for _, backpack in ipairs(Config.Backpacks) do
        local count = ox_inventory:Search('count', backpack.name)
        if count > 0 then
            return true
        end
    end
    return false
end

-- Function to send ox_lib notifications
local function SendNotification(notification)
    lib.notify(notification)
end

-- Function to check if a prop name is a valid backpack prop
local function isValidBackpackProp(propName)
    if not Config.EnableCustomProps then return false end
    
    for _, prefix in ipairs(Config.ValidPropPrefixes) do
        if string.sub(string.lower(propName), 1, #prefix) == string.lower(prefix) then
            return true
        end
    end
    return false
end

-- Function to get a valid custom prop
local function getCustomProp()
    if not Config.EnableCustomProps or not next(customProps) then return nil end
    
    -- Return the first valid custom prop found
    for propName in pairs(customProps) do
        return propName
    end
    return nil
end

-- =====================================================
-- FRAMEWORK DETECTION AND INITIALIZATION
-- =====================================================

-- Framework Detection
local function DetectFramework()
    if Config.Framework ~= 'auto' then
        FrameworkName = Config.Framework
    else
        -- Auto-detect framework
        if GetResourceState('es_extended') == 'started' then
            FrameworkName = 'esx'
        elseif GetResourceState('qbx_core') == 'started' then
            FrameworkName = 'qbox'
        elseif GetResourceState('qb-core') == 'started' then
            FrameworkName = 'qbcore'
        else
            print('^1[ERROR] No supported framework detected! Please install ESX, QBCore, or Qbox.^0')
            return
        end
    end
    
    print('^2[INFO] Framework detected: ' .. FrameworkName .. '^0')
end

-- Initialize Framework
local function InitializeFramework()
    DetectFramework()
    
    if FrameworkName == 'esx' then
        Framework = exports['es_extended']:getSharedObject()
        
        RegisterNetEvent('esx:playerLoaded')
        AddEventHandler('esx:playerLoaded', function(xPlayer)
            PlayerData = xPlayer
            justConnect = true
            if Config.EnableBackpackProp and HasAnyBackpack() then
                DelayedPropAttachment()
            end
        end)
        
        RegisterNetEvent('esx:onPlayerSpawn')
        AddEventHandler('esx:onPlayerSpawn', function()
            if Config.EnableBackpackProp then
                RemoveBag()
                if HasAnyBackpack() then
                    DelayedPropAttachment()
                end
            end
        end)
        
    elseif FrameworkName == 'qbcore' then
        Framework = exports['qb-core']:GetCoreObject()
        
        RegisterNetEvent('QBCore:Client:OnPlayerLoaded')
        AddEventHandler('QBCore:Client:OnPlayerLoaded', function()
            PlayerData = Framework.Functions.GetPlayerData()
            justConnect = true
            if Config.EnableBackpackProp and HasAnyBackpack() then
                DelayedPropAttachment()
            end
        end)
        
        RegisterNetEvent('QBCore:Client:OnPlayerUnload')
        AddEventHandler('QBCore:Client:OnPlayerUnload', function()
            PlayerData = {}
        end)
        
        RegisterNetEvent('QBCore:Player:SetPlayerData')
        AddEventHandler('QBCore:Player:SetPlayerData', function(val)
            PlayerData = val
        end)
        
    elseif FrameworkName == 'qbox' then
        Framework = exports.qbx_core
        
        RegisterNetEvent('QBCore:Client:OnPlayerLoaded')
        AddEventHandler('QBCore:Client:OnPlayerLoaded', function()
            PlayerData = exports.qbx_core:GetPlayerData()
            justConnect = true
            if Config.EnableBackpackProp and HasAnyBackpack() then
                DelayedPropAttachment()
            end
        end)
        
        RegisterNetEvent('QBCore:Client:OnPlayerUnload')
        AddEventHandler('QBCore:Client:OnPlayerUnload', function()
            PlayerData = {}
        end)
        
        RegisterNetEvent('QBCore:Player:SetPlayerData')
        AddEventHandler('QBCore:Player:SetPlayerData', function(val)
            PlayerData = val
        end)
    end
end

-- =====================================================
-- BACKPACK PROP MANAGEMENT
-- =====================================================

-- Function to load custom props from the customBackpacks folder
local function loadCustomProps()
    if not Config.EnableCustomProps then return end
    
    local resourceName = GetCurrentResourceName()
    local numFiles = GetNumResourceMetadata(resourceName, 'data_file')
    
    for i = 0, numFiles - 1 do
        local fileName = GetResourceMetadata(resourceName, 'data_file', i)
        if fileName and fileName:match('^' .. Config.CustomPropsFolder .. '/.*%.ydr$') then
            local propName = fileName:match('([^/]+)%.ydr$')
            if isValidBackpackProp(propName) then
                customProps[propName] = true
            end
        end
    end
end

-- Function to safely remove existing bag
function RemoveBag()
    if DoesEntityExist(bagObj) then
        DeleteObject(bagObj)
        SetModelAsNoLongerNeeded(bagObj)
    end
    bagObj = nil
    bagEquipped = false
    
    -- Clear any pending timer
    if propAttachTimer then
        propAttachTimer = nil
    end
end

-- Function to attach backpack to player
function PutOnBag()
    -- Check if backpack props are enabled
    if not Config.EnableBackpackProp then
        return
    end
    
    playerPed = PlayerPedId()
    
    -- Don't attach if player is in a vehicle
    if IsPedInAnyVehicle(playerPed, false) then
        isInVehicle = true
        return
    end
    
    -- Don't attach if already equipped and exists
    if bagEquipped and DoesEntityExist(bagObj) then
        return
    end
    
    -- Remove any existing bag first
    RemoveBag()
    
    -- Find which backpack the player has equipped and get its prop
    local bagType = Config.DefaultBackpackProp
    local customProp = nil
    
    if Config.EnableCustomProps then
        customProp = getCustomProp()
    end
    
    for _, backpack in ipairs(Config.Backpacks) do
        local count = ox_inventory:Search('count', backpack.name)
        if count > 0 then
            bagType = customProp or backpack.prop or Config.DefaultBackpackProp
            break
        end
    end
    
    lib.requestModel(bagType, 5000)

    if HasModelLoaded(bagType) then
        local x, y, z = table.unpack(GetOffsetFromEntityInWorldCoords(playerPed, 0.0, 3.0, 0.5))
        bagObj = CreateObjectNoOffset(bagType, x, y, z, true, false, false)
        
        if DoesEntityExist(bagObj) then
            -- Adjust attachment based on prop type
            local attachmentConfig = {
                ["p_ld_heist_bag_s"] = {
                    bone = 24818,
                    x = -0.050,
                    y = -0.09,
                    z = -0.01,
                    rotX = 0.0,
                    rotY = 90.0,
                    rotZ = 175.0
                },
                default = {
                    bone = 24818,
                    x = 0.07,
                    y = -0.11,
                    z = -0.05,
                    rotX = 0.0,
                    rotY = 90.0,
                    rotZ = 175.0
                }
            }
            
            local config = attachmentConfig[bagType] or attachmentConfig.default
            
            AttachEntityToEntity(bagObj, playerPed, GetPedBoneIndex(playerPed, config.bone),
                config.x, config.y, config.z,
                config.rotX, config.rotY, config.rotZ,
                true, true, false, true, 1, true)
            
            bagEquipped = true
            isInVehicle = false
        end
        SetModelAsNoLongerNeeded(bagType)
    end
end

-- Function to handle prop reattachment with delay
function DelayedPropAttachment()
    if propAttachTimer then return end
    
    propAttachTimer = true
    CreateThread(function()
        Wait(Config.PropRefreshDelay or 1000)
        if HasAnyBackpack() and Config.EnableBackpackProp then
            PutOnBag()
        end
        propAttachTimer = nil
    end)
end

-- Function to detect significant position changes (teleports)
local function CheckForTeleport()
    local currentPed = PlayerPedId()
    local currentPos = GetEntityCoords(currentPed)
    
    if lastPosition then
        local distance = #(currentPos - lastPosition)
        -- If player moved more than 50 units in one frame, consider it a teleport
        if distance > 50.0 and bagEquipped and Config.EnableBackpackProp then
            RemoveBag()
            DelayedPropAttachment()
        end
    end
    
    lastPosition = currentPos
end

-- =====================================================
-- PIN SYSTEM
-- =====================================================

-- Enhanced function to check PIN that respects global configuration
local function OpenBackpackWithPinCheck(backpackID, level)
    -- First check if PIN system is globally enabled
    if not Config.UsePINSystem then
        -- If PIN system is globally disabled, open directly
        ox_inventory:openInventory('stash', 'bag_'..backpackID)
        lib.notify(Config.Notifications.backpackOpened)
        return
    end
    
    -- If PIN system is globally enabled, then check individual configuration
    local backpackConfig = Config.Backpacks[level]
    if backpackConfig and backpackConfig.pin then
        RequestPin(backpackID)
    else
        ox_inventory:openInventory('stash', 'bag_'..backpackID)
        lib.notify(Config.Notifications.backpackOpened)
    end
end

function RequestPin(backpackID, backpackLevel)
    -- Check again if PIN system is enabled before requesting PIN
    if not Config.UsePINSystem then
        ox_inventory:openInventory('stash', 'bag_'..backpackID)
        lib.notify(Config.Notifications.backpackOpened)
        return
    end
    
    lib.callback('vanguard_backpack:checkOrInsertPin', false, function(exists, storedPin)
        if exists and storedPin then
            local pin
            
            if Config.OxLibUseFormForPin then
                pin = lib.inputDialog(Config.Texts.unlockBackpackTitle, { 
                    { type = 'input', label = Config.Texts.pinCodeLabel, password = true, required = true, placeholder = Config.Texts.enterPinPlaceholder }
                })
            else
                pin = { [1] = exports['okokTextUI']:Input('Enter PIN', Config.Texts.pinCodeLabel, '', 10, 'number') }
            end

            if pin and pin[1] then
                if pin[1] == storedPin then
                    ox_inventory:openInventory('stash', 'bag_'..backpackID)
                    lib.notify(Config.Notifications.backpackUnlocked)
                else
                    lib.notify(Config.Notifications.incorrectPin)
                end
            end
        else
            lib.notify(Config.Notifications.setNewPin)
            local newPin
            
            if Config.OxLibUseFormForPin then
                newPin = lib.inputDialog(Config.Texts.setBackpackLockTitle, { 
                    { type = 'input', label = Config.Texts.newPinCodeLabel, password = true, required = true, placeholder = Config.Texts.setPinPlaceholder }
                })
            else
                newPin = { [1] = exports['okokTextUI']:Input('Set PIN', Config.Texts.newPinCodeLabel, '', 10, 'number') }
            end

            if newPin and newPin[1] then
                -- Validate if PIN contains only numbers
                if string.match(newPin[1], '^%d+$') then
                    TriggerServerEvent('vanguard_backpack:setNewPin', backpackID, newPin[1])
                    ox_inventory:openInventory('stash', 'bag_'..backpackID)
                    lib.notify(Config.Notifications.backpackOpened)
                else
                    lib.notify(Config.Notifications.invalidPin)
                end
            end
        end
    end, backpackID, backpackLevel)
end

-- =====================================================
-- BACKPACK EXPORTS (ITEM USAGE)
-- =====================================================

exports('openBackpack1', function(data, slot)
    if not slot?.metadata?.identifier then
        local identifier = lib.callback.await('vanguard_backpack:getNewIdentifier', 100, data.slot, 1)
    else
        TriggerServerEvent('vanguard_backpack:openBackpack', slot.metadata.identifier, 1)
        OpenBackpackWithPinCheck(slot.metadata.identifier, 1)
    end
end)

exports('openBackpack2', function(data, slot)
    if not slot?.metadata?.identifier then
        local identifier = lib.callback.await('vanguard_backpack:getNewIdentifier', 100, data.slot, 2)
    else
        TriggerServerEvent('vanguard_backpack:openBackpack', slot.metadata.identifier, 2)
        OpenBackpackWithPinCheck(slot.metadata.identifier, 2)
    end
end)

exports('openBackpack3', function(data, slot)
    if not slot?.metadata?.identifier then
        local identifier = lib.callback.await('vanguard_backpack:getNewIdentifier', 100, data.slot, 3)
    else
        TriggerServerEvent('vanguard_backpack:openBackpack', slot.metadata.identifier, 3)
        OpenBackpackWithPinCheck(slot.metadata.identifier, 3)
    end
end)

-- =====================================================
-- SHOP SYSTEM
-- =====================================================

-- Only create target zone and shop if enabled in config
if Config.EnableShop then
    exports.ox_target:addSphereZone({
        coords = vec3(399.8024, 96.92446, 101.48),
        radius = 1,
        debug = drawZones,
        options = {
            {
                name = "sphere",
                event = "openshop",
                icon = "fa-solid fa-circle",
                label = Config.Texts.backpackShopTarget,
            }
        }
    })

    RegisterNetEvent("openshop")
    AddEventHandler("openshop", function()
        if Config.EnableShop then
            exports.ox_inventory:openInventory('shop', { type = 'backpackshop', id = 1 })
        end
    end)
end

-- =====================================================
-- MAP ELEMENTS (BLIP & PED)
-- =====================================================

-- Create blip only if enabled in config
local function CreateShopBlip()
    if not Config.EnableBlip then return end
    
    local blip = AddBlipForCoord(Config.BlipLocation)
    SetBlipSprite(blip, Config.Blip.Sprite)
    SetBlipDisplay(blip, Config.Blip.Display)
    SetBlipScale(blip, Config.Blip.Scale)
    SetBlipColour(blip, Config.Blip.Color)
    SetBlipAsShortRange(blip, Config.Blip.ShortRange)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(Config.Blip.Name)
    EndTextCommandSetBlipName(blip)
end

-- Create ped only if enabled in config
local function CreateShopPed()
    if not Config.EnablePed then return end
    
    RequestModel(GetHashKey(Config.PedConfig.model))
    while not HasModelLoaded(GetHashKey(Config.PedConfig.model)) do
        Wait(1)
    end
    
    local ped = CreatePed(4, GetHashKey(Config.PedConfig.model), Config.PedConfig.position, Config.PedConfig.heading, false, true)
    SetEntityHeading(ped, Config.PedConfig.heading)
    FreezeEntityPosition(ped, Config.PedConfig.frozen)
    SetEntityInvincible(ped, Config.PedConfig.invincible)
    SetBlockingOfNonTemporaryEvents(ped, true)
    
    if Config.PedConfig.canRagdoll == false then
        SetPedCanRagdoll(ped, false)
    end
end

-- =====================================================
-- EVENT HANDLERS
-- =====================================================

-- Function to send ox_lib notifications
RegisterNetEvent('vanguard_backpack:sendNotification')
AddEventHandler('vanguard_backpack:sendNotification', function(notification)
    SendNotification(notification)
end)

-- Handle inventory updates
AddEventHandler('ox_inventory:updateInventory', function(changes)
    if justConnect then
        Wait(1000)
        justConnect = nil
    end

    for k, v in pairs(changes) do
        if type(v) == 'table' then
            if HasAnyBackpack() and Config.EnableBackpackProp and (not bagEquipped or not DoesEntityExist(bagObj)) then
                DelayedPropAttachment()
            elseif not HasAnyBackpack() and bagEquipped then
                RemoveBag()
            end
        end
        if type(v) == 'boolean' then
            if not HasAnyBackpack() and bagEquipped then
                RemoveBag()
            end
        end
    end
end)

-- Handle ped cache changes
lib.onCache('ped', function(value)
    ped = value
    -- Player respawned or changed ped
    if Config.EnableBackpackProp then
        RemoveBag()
        if HasAnyBackpack() then
            DelayedPropAttachment()
        end
    end
end)

-- Handle vehicle cache changes
lib.onCache('vehicle', function(value)
    if GetResourceState('ox_inventory') ~= 'started' then return end
    if value then
        RemoveBag()
        isInVehicle = true
    else
        isInVehicle = false
        if HasAnyBackpack() and Config.EnableBackpackProp then
            DelayedPropAttachment()
        end
    end
end)

-- Handle skin changes that might affect prop attachment
RegisterNetEvent('skinchanger:modelLoaded')
AddEventHandler('skinchanger:modelLoaded', function()
    if Config.EnableBackpackProp then
        RemoveBag()
        if HasAnyBackpack() then
            DelayedPropAttachment()
        end
    end
end)

-- Clean up when resource stops
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        RemoveBag()
    end
end)

-- Handle resource start to reattach props
AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        CreateThread(function()
            -- Wait for everything to load
            Wait(3000)
            if HasAnyBackpack() and Config.EnableBackpackProp then
                DelayedPropAttachment()
            end
        end)
    end
end)

-- =====================================================
-- MAIN INITIALIZATION THREADS
-- =====================================================

-- Initialize on resource start
CreateThread(function()
    InitializeFramework()
end)

-- Main initialization thread
CreateThread(function()
    loadCustomProps()
    
    -- Wait for resource to be fully started and ox_inventory to be ready
    while GetResourceState('ox_inventory') ~= 'started' do
        Wait(500)
    end
    
    -- Additional delay to ensure everything is loaded
    Wait(2000)
    resourceStarted = true
    
    -- Check if player has backpack after resource start
    if HasAnyBackpack() and Config.EnableBackpackProp then
        DelayedPropAttachment()
    end
    
    -- Position tracking thread for teleport detection
    while true do
        Wait(500) -- Check every 500ms
        if Config.EnableBackpackProp then
            CheckForTeleport()
        end
    end
end)

-- Thread to monitor player state and fix prop issues
CreateThread(function()
    while true do
        Wait(1000)
        
        if resourceStarted and Config.EnableBackpackProp and HasAnyBackpack() then
            local currentPed = PlayerPedId()
            local inVehicle = IsPedInAnyVehicle(currentPed, false)
            
            -- If player exited vehicle and should have backpack
            if isInVehicle and not inVehicle and bagEquipped == false then
                DelayedPropAttachment()
            end
            
            -- If backpack should exist but doesn't, recreate it
            if not inVehicle and bagEquipped and not DoesEntityExist(bagObj) then
                bagEquipped = false
                DelayedPropAttachment()
            end
            
            -- Update vehicle state
            isInVehicle = inVehicle
        end
    end
end)

-- Create map elements
CreateThread(function()
    CreateShopBlip()
    CreateShopPed()
end)