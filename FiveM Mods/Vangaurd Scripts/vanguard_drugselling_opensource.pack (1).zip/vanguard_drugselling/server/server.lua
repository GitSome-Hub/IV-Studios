ESX = nil
if Config.Framework == 'oldEsx' then
    Citizen.CreateThread(function()
        while not ESX do
            TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
            Citizen.Wait(0)
        end
    end)
else
    ESX = exports['es_extended']:getSharedObject()
end

-- In your server script
RegisterNetEvent('vanguard_drugselling:sellDrug')
AddEventHandler('vanguard_drugselling:sellDrug', function(drugName, finalPrice)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return end
    
    local drugData = Config.Drugs[drugName]
    if not drugData then return end
    
    local drugItem = drugData.item
    local drugCount = xPlayer.getInventoryItem(drugItem).count
    local amountSold = 0

    if drugCount >= 1 then
        amountSold = math.min(drugCount, math.random(1, 5))
    end

    if amountSold > 0 then
        xPlayer.removeInventoryItem(drugItem, amountSold)
        xPlayer.addInventoryItem('black_money', finalPrice)

        local message = string.format(drugData.message, amountSold, finalPrice)
        TriggerClientEvent('ox_lib:notify', source, {
            title = message,
            position = "top",
            type = "success",
            icon = drugData.icon,
        })
    else
        TriggerClientEvent('ox_lib:notify', source, {
            title = "Not enough " .. drugData.label,
            position = "top",
            type = "error",
            icon = drugData.icon,
        })
    end
end)


-- Event to check the number of police officers
RegisterNetEvent('checkC')
AddEventHandler('checkC', function()
    local xPlayers = ESX.GetPlayers()
    local cops = 0
    for i = 1, #xPlayers do
        local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
        for _, job in ipairs(Config.AlertJobs) do
            if xPlayer.job.name == job then
                cops = cops + 1
                break
            end
        end
    end
    TriggerClientEvent("checkC", source, cops)
end)

-- Event to notify police
RegisterNetEvent('drug:notifyPolice')
AddEventHandler('drug:notifyPolice', function(location)
    TriggerClientEvent('drug:notifyPolice', -1, location)
end)