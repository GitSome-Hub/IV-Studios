ESX = exports["es_extended"]:getSharedObject()

-- Duty status tracking
local dutyStatuses = {}

-- Register callbacks for each job
Citizen.CreateThread(function()
    for jobName, _ in pairs(Config.Jobs) do
        -- Get society money
        ESX.RegisterServerCallback('bossmenu_' .. jobName .. ':getSocietyMoney', function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            local society = 'society_' .. xPlayer.job.name
            
            if xPlayer.job.name ~= jobName then
                cb(0)
                return
            end
            
            TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
                if account then
                    cb(account.money)
                else
                    cb(0)
                end
            end)
        end)

        -- Get online employees
        ESX.RegisterServerCallback('bossmenu_' .. jobName .. ':getOnlineEmployees', function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            local onlineEmployees = {}
            
            if xPlayer.job.name ~= jobName then
                cb({})
                return
            end
            
            local xPlayers = ESX.GetExtendedPlayers('job', jobName)
            
            for _, xTarget in pairs(xPlayers) do
                table.insert(onlineEmployees, {
                    source = xTarget.source,
                    identifier = xTarget.identifier,
                    name = xTarget.getName(),
                    grade = xTarget.job.grade
                })
            end
            
            cb(onlineEmployees)
        end)
        
        -- Get duty statuses for this job
        ESX.RegisterServerCallback('bossmenu_' .. jobName .. ':getDutyStatuses', function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            
            if xPlayer.job.name ~= jobName then
                cb({})
                return
            end
            
            -- Get duty statuses for this job only
            local jobDutyStatuses = {}
            for identifier, data in pairs(dutyStatuses) do
                if data.job == jobName then
                    jobDutyStatuses[identifier] = data.status
                end
            end
            
            cb(jobDutyStatuses)
        end)

        -- MELHORADO: Get employees - incluir status online/offline
        ESX.RegisterServerCallback('bossmenu_' .. jobName .. ':getEmployees', function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            local employees = {}
            
            if xPlayer.job.name ~= jobName then
                cb({})
                return
            end
            
            print('[BOSSMENU SERVER] Getting employees for job:', jobName)
            
            MySQL.Async.fetchAll('SELECT identifier, firstname, lastname, job_grade FROM users WHERE job = @job ORDER BY job_grade DESC', {
                ['@job'] = jobName
            }, function(result)
                print('[BOSSMENU SERVER] Found', #result, 'employees in database for job:', jobName)
                
                -- Get online players for this job
                local onlinePlayers = ESX.GetExtendedPlayers('job', jobName)
                local onlineIdentifiers = {}
                for _, xTarget in pairs(onlinePlayers) do
                    onlineIdentifiers[xTarget.identifier] = {
                        source = xTarget.source,
                        name = xTarget.getName()
                    }
                end
                
                for i=1, #result, 1 do
                    local isOnline = onlineIdentifiers[result[i].identifier] ~= nil
                    local employeeData = {
                        identifier = result[i].identifier,
                        name = result[i].firstname .. ' ' .. result[i].lastname,
                        grade = result[i].job_grade,
                        isOnline = isOnline
                    }
                    
                    -- Add server ID if online
                    if isOnline then
                        employeeData.source = onlineIdentifiers[result[i].identifier].source
                    end
                    
                    table.insert(employees, employeeData)
                end
                
                print('[BOSSMENU SERVER] Returning', #employees, 'employees to client')
                cb(employees)
            end)
        end)

        -- Get candidate info
        ESX.RegisterServerCallback('bossmenu_' .. jobName .. ':getCandidateInfo', function(source, cb, targetId)
            local xPlayer = ESX.GetPlayerFromId(source)
            local tPlayer = ESX.GetPlayerFromId(targetId)
            
            if not tPlayer then
                cb(nil)
                return
            end
            
            local candidateData = {
                source = targetId,
                name = tPlayer.getName(),
                job = tPlayer.job.label,
                identifier = tPlayer.identifier
            }
            
            cb(candidateData)
        end)

        -- Get transactions
        ESX.RegisterServerCallback('bossmenu_' .. jobName .. ':getTransactions', function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            local society = 'society_' .. xPlayer.job.name
            
            if xPlayer.job.name ~= jobName then
                cb({})
                return
            end
            
            MySQL.Async.fetchAll('SELECT * FROM society_transactions WHERE society = @society ORDER BY date DESC LIMIT 20', {
                ['@society'] = society
            }, function(result)
                cb(result)
            end)
        end)

        -- Update grade
        ESX.RegisterServerCallback('bossmenu_' .. jobName .. ':updateGrade', function(source, cb, gradeId, newData)
            local xPlayer = ESX.GetPlayerFromId(source)
            
            if xPlayer.job.name ~= jobName then
                cb(false, Config.Texts.InvalidJob)
                return
            end
            
            local jobConfig = Config.Jobs[jobName]
            if not jobConfig then
                cb(false, Config.Texts.InvalidJob)
                return
            end
            
            if xPlayer.job.grade < jobConfig.managePermission then
                cb(false, Config.Texts.NoManagePermission)
                return
            end
            
            MySQL.Async.execute('UPDATE job_grades SET label = @label, salary = @salary WHERE job_name = @job_name AND grade = @grade', {
                ['@label'] = newData.label,
                ['@salary'] = newData.salary,
                ['@job_name'] = jobName,
                ['@grade'] = gradeId
            }, function(rowsChanged)
                if rowsChanged > 0 then
                    cb(true, 'Grade updated successfully')
                else
                    cb(false, 'Failed to update grade')
                end
            end)
        end)

        -- MELHORADO: Hire employee
        ESX.RegisterServerCallback('bossmenu_' .. jobName .. ':hireEmployee', function(source, cb, target, grade)
            local xPlayer = ESX.GetPlayerFromId(source)
            local tPlayer = ESX.GetPlayerFromId(target)
            local jobConfig = Config.Jobs[jobName]
            
            print('[BOSSMENU SERVER] Hire request - Source:', source, 'Target:', target, 'Grade:', grade, 'Job:', jobName)
            
            if not jobConfig then
                cb(false, Config.Texts.InvalidJob)
                return
            end
            
            if xPlayer.job.name ~= jobName or xPlayer.job.grade < jobConfig.hirePermission then
                cb(false, Config.Texts.NoHirePermission)
                return
            end
            
            if not tPlayer then
                cb(false, Config.Texts.PlayerNotFound)
                return
            end
            
            if tPlayer.job.name == jobName then
                cb(false, Config.Texts.AlreadyEmployed)
                return
            end
            
            if grade >= xPlayer.job.grade then
                cb(false, Config.Texts.CannotHireHigherRank)
                return
            end
            
            print('[BOSSMENU SERVER] Setting job for player:', tPlayer.getName(), 'to job:', jobName, 'grade:', grade)
            
            -- Set the job
            tPlayer.setJob(jobName, grade)
            
            -- Wait to ensure job is set
            Citizen.Wait(500)
            
            -- Set default duty status for new employee
            dutyStatuses[tPlayer.identifier] = {
                job = jobName,
                status = "off-duty"
            }
            
            -- Save duty status to database
            SaveDutyStatus(tPlayer.identifier, jobName, "off-duty")
            
            -- Log transaction
            LogTransaction(xPlayer.identifier, 'society_' .. jobName, 'hire', string.format('Hired %s', tPlayer.name), 0)
            
            -- Send notifications
            TriggerClientEvent('bossmenu:notify', source, {
                type = 'success',
                title = 'Officer Recruited',
                message = string.format('Successfully hired %s', tPlayer.name)
            })
            
            TriggerClientEvent('bossmenu:notify', target, {
                type = 'info',
                title = 'Job Assigned',
                message = string.format('You have been hired by %s', jobConfig.label)
            })
            
            print('[BOSSMENU SERVER] Hire successful, broadcasting update...')
            
            cb(true, string.format('Successfully hired %s', tPlayer.name))
            
            -- Broadcast update to all job members
            Citizen.SetTimeout(1000, function()
                print('[BOSSMENU SERVER] Broadcasting employees list update after hire')
                BroadcastEmployeesListUpdate(jobName)
            end)
        end)

        -- MELHORADO: Fire employee
        ESX.RegisterServerCallback('bossmenu_' .. jobName .. ':fireEmployee', function(source, cb, identifier)
            local xPlayer = ESX.GetPlayerFromId(source)
            local jobConfig = Config.Jobs[jobName]
            local society = 'society_' .. jobName
            
            print('[BOSSMENU SERVER] Fire request - Source:', source, 'Identifier:', identifier, 'Job:', jobName)
            
            if not jobConfig then
                cb(false, Config.Texts.InvalidJob)
                return
            end
            
            if xPlayer.job.name ~= jobName or xPlayer.job.grade < jobConfig.firePermission then
                cb(false, Config.Texts.NoFirePermission)
                return
            end
            
            local tPlayer = ESX.GetPlayerFromIdentifier(identifier)
            
            if tPlayer then
                -- Player is online
                print('[BOSSMENU SERVER] Target player is online:', tPlayer.getName())
                
                if tPlayer.job.name ~= jobName then
                    cb(false, Config.Texts.NotAnEmployee)
                    return
                end
                
                if tPlayer.job.grade >= xPlayer.job.grade then
                    cb(false, Config.Texts.CannotFireHigherRank)
                    return
                end
                
                local playerName = tPlayer.name
                
                -- Set job to unemployed
                tPlayer.setJob('unemployed', 0)
                
                -- Wait to ensure job is changed
                Citizen.Wait(500)
                
                -- Remove duty status for fired employee
                dutyStatuses[identifier] = nil
                
                -- Remove from database
                MySQL.Async.execute('DELETE FROM duty_statuses WHERE identifier = @identifier', {
                    ['@identifier'] = identifier
                })
                
                -- Log transaction
                LogTransaction(xPlayer.identifier, society, 'fire', string.format('Fired %s', playerName), 0)
                
                -- Send notifications
                TriggerClientEvent('bossmenu:notify', source, {
                    type = 'success',
                    title = 'Officer Terminated',
                    message = string.format('Successfully fired %s', playerName)
                })
                
                TriggerClientEvent('bossmenu:notify', tPlayer.source, {
                    type = 'warning',
                    title = 'Job Termination',
                    message = 'You have been terminated from your job'
                })
                
                print('[BOSSMENU SERVER] Fire successful, broadcasting update...')
                
                cb(true, string.format('Successfully fired %s', playerName))
            else
                -- Player is offline
                print('[BOSSMENU SERVER] Target player is offline, updating database directly')
                
                MySQL.Async.fetchAll('SELECT firstname, lastname, job_grade FROM users WHERE identifier = @identifier AND job = @job', {
                    ['@identifier'] = identifier,
                    ['@job'] = jobName
                }, function(result)
                    if result[1] then
                        if tonumber(result[1].job_grade) >= xPlayer.job.grade then
                            cb(false, Config.Texts.CannotFireHigherRank)
                            return
                        end
                        
                        MySQL.Async.execute('UPDATE users SET job = @job, job_grade = @job_grade WHERE identifier = @identifier', {
                            ['@job'] = 'unemployed',
                            ['@job_grade'] = 0,
                            ['@identifier'] = identifier
                        }, function(rowsChanged)
                            if rowsChanged > 0 then
                                -- Remove duty status for fired employee
                                dutyStatuses[identifier] = nil
                                
                                -- Remove from database
                                MySQL.Async.execute('DELETE FROM duty_statuses WHERE identifier = @identifier', {
                                    ['@identifier'] = identifier
                                })
                                
                                -- Log transaction
                                local empName = result[1].firstname .. ' ' .. result[1].lastname
                                LogTransaction(xPlayer.identifier, society, 'fire', string.format('Fired %s', empName), 0)
                                
                                -- Send notification
                                TriggerClientEvent('bossmenu:notify', source, {
                                    type = 'success',
                                    title = 'Officer Terminated',
                                    message = string.format('Successfully fired %s', empName)
                                })
                                
                                print('[BOSSMENU SERVER] Fire successful (offline player), broadcasting update...')
                                
                                cb(true, string.format('Successfully fired %s', empName))
                            else
                                cb(false, 'Failed to fire employee')
                            end
                        end)
                    else
                        cb(false, 'Employee not found')
                    end
                end)
            end
            
            -- Broadcast update to all job members
            Citizen.SetTimeout(1000, function()
                print('[BOSSMENU SERVER] Broadcasting employees list update after fire')
                BroadcastEmployeesListUpdate(jobName)
            end)
        end)

        -- MELHORADO: Promote employee
        ESX.RegisterServerCallback('bossmenu_' .. jobName .. ':promoteEmployee', function(source, cb, identifier, newGrade)
            local xPlayer = ESX.GetPlayerFromId(source)
            local jobConfig = Config.Jobs[jobName]
            local society = 'society_' .. jobName
            
            print('[BOSSMENU SERVER] Promote request - Source:', source, 'Identifier:', identifier, 'New Grade:', newGrade, 'Job:', jobName)
            
            if not jobConfig then
                cb(false, Config.Texts.InvalidJob)
                return
            end
            
            if xPlayer.job.name ~= jobName or xPlayer.job.grade < jobConfig.promotePermission then
                cb(false, Config.Texts.NoPromotePermission)
                return
            end
            
            -- Check if new grade is valid
            local gradeExists = false
            local gradeLabel = ""
            
            for _, grade in ipairs(jobConfig.grades) do
                if grade.grade == newGrade then
                    gradeExists = true
                    gradeLabel = grade.label
                    break
                end
            end
            
            if not gradeExists then
                cb(false, Config.Texts.InvalidGrade)
                return
            end
            
            -- Check if new grade is higher than source player's grade
            if newGrade >= xPlayer.job.grade then
                cb(false, Config.Texts.CannotPromoteHigherRank)
                return
            end
            
            local tPlayer = ESX.GetPlayerFromIdentifier(identifier)
            
            if tPlayer then
                -- Player is online
                if tPlayer.job.name ~= jobName then
                    cb(false, Config.Texts.NotAnEmployee)
                    return
                end
                
                if tPlayer.job.grade >= xPlayer.job.grade then
                    cb(false, Config.Texts.CannotPromoteHigherRank)
                    return
                end
                
                if tPlayer.job.grade >= newGrade then
                    cb(false, Config.Texts.AlreadyHigherGrade)
                    return
                end
                
                local playerName = tPlayer.name
                tPlayer.setJob(jobName, newGrade)
                
                -- Wait to ensure job is updated
                Citizen.Wait(500)
                
                -- Log transaction
                LogTransaction(xPlayer.identifier, society, 'promote', string.format('Promoted %s to %s', playerName, gradeLabel), 0)
                
                -- Send notifications
                TriggerClientEvent('bossmenu:notify', source, {
                    type = 'success',
                    title = 'Officer Promoted',
                    message = string.format('Successfully promoted %s to %s', playerName, gradeLabel)
                })
                
                TriggerClientEvent('bossmenu:notify', tPlayer.source, {
                    type = 'success',
                    title = 'Promotion',
                    message = string.format('You have been promoted to %s', gradeLabel)
                })
                
                print('[BOSSMENU SERVER] Promote successful, broadcasting update...')
                
                cb(true, string.format('Successfully promoted %s to %s', playerName, gradeLabel))
            else
                -- Player is offline
                MySQL.Async.fetchAll('SELECT firstname, lastname, job_grade FROM users WHERE identifier = @identifier AND job = @job', {
                    ['@identifier'] = identifier,
                    ['@job'] = jobName
                }, function(result)
                    if result[1] then
                        if tonumber(result[1].job_grade) >= xPlayer.job.grade then
                            cb(false, Config.Texts.CannotPromoteHigherRank)
                            return
                        end
                        
                        if tonumber(result[1].job_grade) >= newGrade then
                            cb(false, Config.Texts.AlreadyHigherGrade)
                            return
                        end
                        
                        MySQL.Async.execute('UPDATE users SET job_grade = @job_grade WHERE identifier = @identifier', {
                            ['@job_grade'] = newGrade,
                            ['@identifier'] = identifier
                        }, function(rowsChanged)
                            if rowsChanged > 0 then
                                -- Log transaction
                                local empName = result[1].firstname .. ' ' .. result[1].lastname
                                LogTransaction(xPlayer.identifier, society, 'promote', string.format('Promoted %s to %s', empName, gradeLabel), 0)
                                
                                -- Send notification
                                TriggerClientEvent('bossmenu:notify', source, {
                                    type = 'success',
                                    title = 'Officer Promoted',
                                    message = string.format('Successfully promoted %s to %s', empName, gradeLabel)
                                })
                                
                                print('[BOSSMENU SERVER] Promote successful (offline player), broadcasting update...')
                                
                                cb(true, string.format('Successfully promoted %s to %s', empName, gradeLabel))
                            else
                                cb(false, 'Failed to promote employee')
                            end
                        end)
                    else
                        cb(false, 'Employee not found')
                    end
                end)
            end
            
            -- Broadcast update to all job members
            Citizen.SetTimeout(1000, function()
                print('[BOSSMENU SERVER] Broadcasting employees list update after promote')
                BroadcastEmployeesListUpdate(jobName)
            end)
        end)

        -- MELHORADO: Demote employee
        ESX.RegisterServerCallback('bossmenu_' .. jobName .. ':demoteEmployee', function(source, cb, identifier, newGrade)
            local xPlayer = ESX.GetPlayerFromId(source)
            local jobConfig = Config.Jobs[jobName]
            local society = 'society_' .. jobName
            
            print('[BOSSMENU SERVER] Demote request - Source:', source, 'Identifier:', identifier, 'New Grade:', newGrade, 'Job:', jobName)
            
            if not jobConfig then
                cb(false, Config.Texts.InvalidJob)
                return
            end
            
            if xPlayer.job.name ~= jobName or xPlayer.job.grade < jobConfig.demotePermission then
                cb(false, Config.Texts.NoDemotePermission)
                return
            end
            
            -- Check if new grade is valid
            local gradeExists = false
            local gradeLabel = ""
            
            for _, grade in ipairs(jobConfig.grades) do
                if grade.grade == newGrade then
                    gradeExists = true
                    gradeLabel = grade.label
                    break
                end
            end
            
            if not gradeExists then
                cb(false, Config.Texts.InvalidGrade)
                return
            end
            
            local tPlayer = ESX.GetPlayerFromIdentifier(identifier)
            
            if tPlayer then
                -- Player is online
                if tPlayer.job.name ~= jobName then
                    cb(false, Config.Texts.NotAnEmployee)
                    return
                end
                
                if tPlayer.job.grade >= xPlayer.job.grade then
                    cb(false, Config.Texts.CannotDemoteHigherRank)
                    return
                end
                
                if tPlayer.job.grade <= newGrade then
                    cb(false, Config.Texts.AlreadyLowerGrade)
                    return
                end
                
                local playerName = tPlayer.name
                tPlayer.setJob(jobName, newGrade)
                
                -- Wait to ensure job is updated
                Citizen.Wait(500)
                
                -- Log transaction
                LogTransaction(xPlayer.identifier, society, 'demote', string.format('Demoted %s to %s', playerName, gradeLabel), 0)
                
                -- Send notifications
                TriggerClientEvent('bossmenu:notify', source, {
                    type = 'warning',
                    title = 'Officer Demoted',
                    message = string.format('Successfully demoted %s to %s', playerName, gradeLabel)
                })
                
                TriggerClientEvent('bossmenu:notify', tPlayer.source, {
                    type = 'warning',
                    title = 'Demotion',
                    message = string.format('You have been demoted to %s', gradeLabel)
                })
                
                print('[BOSSMENU SERVER] Demote successful, broadcasting update...')
                
                cb(true, string.format('Successfully demoted %s to %s', playerName, gradeLabel))
            else
                -- Player is offline
                MySQL.Async.fetchAll('SELECT firstname, lastname, job_grade FROM users WHERE identifier = @identifier AND job = @job', {
                    ['@identifier'] = identifier,
                    ['@job'] = jobName
                }, function(result)
                    if result[1] then
                        if tonumber(result[1].job_grade) >= xPlayer.job.grade then
                            cb(false, Config.Texts.CannotDemoteHigherRank)
                            return
                        end
                        
                        if tonumber(result[1].job_grade) <= newGrade then
                            cb(false, Config.Texts.AlreadyLowerGrade)
                            return
                        end
                        
                        MySQL.Async.execute('UPDATE users SET job_grade = @job_grade WHERE identifier = @identifier', {
                            ['@job_grade'] = newGrade,
                            ['@identifier'] = identifier
                        }, function(rowsChanged)
                            if rowsChanged > 0 then
                                -- Log transaction
                                local empName = result[1].firstname .. ' ' .. result[1].lastname
                                LogTransaction(xPlayer.identifier, society, 'demote', string.format('Demoted %s to %s', empName, gradeLabel), 0)
                                
                                -- Send notification
                                TriggerClientEvent('bossmenu:notify', source, {
                                    type = 'warning',
                                    title = 'Officer Demoted',
                                    message = string.format('Successfully demoted %s to %s', empName, gradeLabel)
                                })
                                
                                print('[BOSSMENU SERVER] Demote successful (offline player), broadcasting update...')
                                
                                cb(true, string.format('Successfully demoted %s to %s', empName, gradeLabel))
                            else
                                cb(false, 'Failed to demote employee')
                            end
                        end)
                    else
                        cb(false, 'Employee not found')
                    end
                end)
            end
            
            -- Broadcast update to all job members
            Citizen.SetTimeout(1000, function()
                print('[BOSSMENU SERVER] Broadcasting employees list update after demote')
                BroadcastEmployeesListUpdate(jobName)
            end)
        end)

        -- Withdraw money
        ESX.RegisterServerCallback('bossmenu_' .. jobName .. ':withdrawMoney', function(source, cb, amount)
            local xPlayer = ESX.GetPlayerFromId(source)
            local jobConfig = Config.Jobs[jobName]
            local society = 'society_' .. jobName
            
            amount = tonumber(amount)
            
            if not jobConfig then
                cb(false, Config.Texts.InvalidJob)
                return
            end
            
            if xPlayer.job.name ~= jobName or xPlayer.job.grade < jobConfig.withdrawPermission then
                cb(false, Config.Texts.NoWithdrawPermission)
                return
            end
            
            if amount == nil or amount <= 0 then
                cb(false, Config.Texts.InvalidAmount)
                return
            end
            
            if amount > Config.MaxWithdrawal then
                cb(false, string.format(Config.Texts.MaxWithdrawal, Config.MaxWithdrawal))
                return
            end
            
            TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
                if amount > account.money then
                    cb(false, Config.Texts.NotEnoughMoney)
                    return
                end
                
                account.removeMoney(amount)
                xPlayer.addMoney(amount)
                
                -- Log transaction
                LogTransaction(xPlayer.identifier, society, 'withdraw', string.format('Withdrew $%d', amount), -amount)
                
                cb(true, string.format('Successfully withdrew $%d', amount), account.money)
            end)
        end)

        -- Deposit money
        ESX.RegisterServerCallback('bossmenu_' .. jobName .. ':depositMoney', function(source, cb, amount)
            local xPlayer = ESX.GetPlayerFromId(source)
            local jobConfig = Config.Jobs[jobName]
            local society = 'society_' .. jobName
            
            amount = tonumber(amount)
            
            if not jobConfig then
                cb(false, Config.Texts.InvalidJob)
                return
            end
            
            if xPlayer.job.name ~= jobName or xPlayer.job.grade < jobConfig.depositPermission then
                cb(false, Config.Texts.NoDepositPermission)
                return
            end
            
            if amount == nil or amount <= 0 then
                cb(false, Config.Texts.InvalidAmount)
                return
            end
            
            if amount > Config.MaxDeposit then
                cb(false, string.format(Config.Texts.MaxDeposit, Config.MaxDeposit))
                return
            end
            
            if xPlayer.getMoney() < amount then
                cb(false, Config.Texts.NotEnoughCash)
                return
            end
            
            TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
                xPlayer.removeMoney(amount)
                account.addMoney(amount)
                
                -- Log transaction
                LogTransaction(xPlayer.identifier, society, 'deposit', string.format('Deposited $%d', amount), amount)
                
                cb(true, string.format('Successfully deposited $%d', amount), account.money)
            end)
        end)
    end
end)

-- Helper functions

-- Get job configuration
function GetJobConfig(jobName)
    return Config.Jobs[jobName]
end

-- Log transaction
function LogTransaction(identifier, society, type, description, amount)
    MySQL.Async.execute('INSERT INTO society_transactions (society, identifier, type, description, amount, date) VALUES (@society, @identifier, @type, @description, @amount, @date)', {
        ['@society'] = society,
        ['@identifier'] = identifier,
        ['@type'] = type,
        ['@description'] = description,
        ['@amount'] = amount,
        ['@date'] = os.date('%Y-%m-%d %H:%M:%S')
    })
end

-- MELHORADO: Broadcast employees list update to all job members with boss menu access
function BroadcastEmployeesListUpdate(jobName)
    local jobConfig = Config.Jobs[jobName]
    if not jobConfig then return end
    
    print(string.format('[BOSSMENU SERVER] Broadcasting employee list update for job: %s', jobName))
    
    local xPlayers = ESX.GetExtendedPlayers('job', jobName)
    
    for _, xPlayer in pairs(xPlayers) do
        if xPlayer.job.grade >= jobConfig.minGrade then
            print(string.format('[BOSSMENU SERVER] Sending refresh to player: %s (ID: %d)', xPlayer.getName(), xPlayer.source))
            TriggerClientEvent('bossmenu:refreshEmployeesList', xPlayer.source)
        end
    end
end

-- Check if society_transactions table exists and create if it doesn't
MySQL.ready(function()
    MySQL.Async.execute([[
        CREATE TABLE IF NOT EXISTS `society_transactions` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `society` varchar(50) DEFAULT NULL,
            `identifier` varchar(60) DEFAULT NULL,
            `type` varchar(50) DEFAULT NULL,
            `description` varchar(255) DEFAULT NULL,
            `amount` int(11) DEFAULT 0,
            `date` timestamp NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`),
            KEY `society` (`society`),
            KEY `identifier` (`identifier`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]], {}, function(rowsChanged)
        print('[^2INFO^7] Ensuring society_transactions table exists')
    end)
    
    -- Create duty_statuses table if it doesn't exist
    MySQL.Async.execute([[
        CREATE TABLE IF NOT EXISTS `duty_statuses` (
            `identifier` varchar(60) NOT NULL,
            `job` varchar(50) NOT NULL,
            `status` varchar(50) NOT NULL DEFAULT 'off-duty',
            `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`identifier`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]], {}, function(rowsChanged)
        print('[^2INFO^7] Ensuring duty_statuses table exists')
        
        -- Load saved duty statuses from database
        LoadDutyStatuses()
    end)
end)

-- Load duty statuses from database
function LoadDutyStatuses()
    MySQL.Async.fetchAll('SELECT * FROM duty_statuses', {}, function(result)
        if result and #result > 0 then
            for _, row in ipairs(result) do
                dutyStatuses[row.identifier] = {
                    job = row.job,
                    status = row.status
                }
            end
            print('[^2INFO^7] Loaded ' .. #result .. ' duty statuses from database')
        end
    end)
end

-- Save duty status to database
function SaveDutyStatus(identifier, job, status)
    MySQL.Async.execute('INSERT INTO duty_statuses (identifier, job, status) VALUES (@identifier, @job, @status) ON DUPLICATE KEY UPDATE job = @job, status = @status', {
        ['@identifier'] = identifier,
        ['@job'] = job,
        ['@status'] = status
    })
end

-- Request duty status event
RegisterNetEvent('bossmenu:requestDutyStatus')
AddEventHandler('bossmenu:requestDutyStatus', function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    local identifier = xPlayer.identifier
    local status = "off-duty" -- Default status
    
    -- Check if we have a saved status
    if dutyStatuses[identifier] and dutyStatuses[identifier].job == xPlayer.job.name then
        status = dutyStatuses[identifier].status
    else
        -- Set default status
        dutyStatuses[identifier] = {
            job = xPlayer.job.name,
            status = status
        }
        
        -- Save to database
        SaveDutyStatus(identifier, xPlayer.job.name, status)
    end
    
    -- Send status to client
    TriggerClientEvent('bossmenu:receiveDutyStatus', source, status)
end)

-- Update duty status event
RegisterNetEvent('bossmenu:updateDutyStatus')
AddEventHandler('bossmenu:updateDutyStatus', function(status)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    local identifier = xPlayer.identifier
    local jobName = xPlayer.job.name
    
    -- Update status
    dutyStatuses[identifier] = {
        job = jobName,
        status = status
    }
    
    -- Save to database
    SaveDutyStatus(identifier, jobName, status)
    
    -- Broadcast to all job members
    local jobMembers = ESX.GetExtendedPlayers('job', jobName)
    for _, xTarget in pairs(jobMembers) do
        TriggerClientEvent('bossmenu:updateDutyStatus', xTarget.source, identifier, status)
    end
    
    -- Log status change
    local society = 'society_' .. jobName
    LogTransaction(identifier, society, 'duty', 'Changed status to ' .. status, 0)
end)

-- Change employee duty status event (for managers)
RegisterNetEvent('bossmenu:changeEmployeeDutyStatus')
AddEventHandler('bossmenu:changeEmployeeDutyStatus', function(targetIdentifier, status)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    local jobName = xPlayer.job.name
    local jobConfig = Config.Jobs[jobName]
    
    -- Check if player has permission
    if not jobConfig or xPlayer.job.grade < jobConfig.managePermission then
        TriggerClientEvent('bossmenu:notify', source, {
            type = 'error',
            title = 'Permission Denied',
            message = "You don't have permission to change duty status"
        })
        return
    end
    
    -- Update status
    if dutyStatuses[targetIdentifier] and dutyStatuses[targetIdentifier].job == jobName then
        dutyStatuses[targetIdentifier].status = status
        
        -- Save to database
        SaveDutyStatus(targetIdentifier, jobName, status)
        
        -- Broadcast to all job members
        local jobMembers = ESX.GetExtendedPlayers('job', jobName)
        for _, xTarget in pairs(jobMembers) do
            TriggerClientEvent('bossmenu:updateDutyStatus', xTarget.source, targetIdentifier, status)
        end
        
        -- Find target player name
        local targetName = "Unknown"
        local xTarget = ESX.GetPlayerFromIdentifier(targetIdentifier)
        if xTarget then
            targetName = xTarget.getName()
            
            -- Notify the target player
            TriggerClientEvent('bossmenu:notify', xTarget.source, {
                type = 'info',
                title = 'Status Updated',
                message = "Your duty status was changed to " .. status
            })
        else
            -- Try to get name from database
            MySQL.Async.fetchAll('SELECT firstname, lastname FROM users WHERE identifier = @identifier', {
                ['@identifier'] = targetIdentifier
            }, function(result)
                if result[1] then
                    targetName = result[1].firstname .. ' ' .. result[1].lastname
                end
            end)
        end
        
        -- Log status change
        local society = 'society_' .. jobName
        LogTransaction(xPlayer.identifier, society, 'duty', 'Changed ' .. targetName .. "'s status to " .. status, 0)
        
        -- Notify the source player
        TriggerClientEvent('bossmenu:notify', source, {
            type = 'success',
            title = 'Status Updated',
            message = "Changed " .. targetName .. "'s status to " .. status
        })
    else
        TriggerClientEvent('bossmenu:notify', source, {
            type = 'error',
            title = 'Update Failed',
            message = "Player not found or not in your organization"
        })
    end
end)

-- Player disconnect handler - don't change duty status on disconnect
AddEventHandler('playerDropped', function(reason)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if xPlayer then
        -- We don't change duty status on disconnect
        -- This way, if a player is on-duty when they disconnect, they'll still be on-duty when they reconnect
        print('[^2INFO^7] Player ' .. xPlayer.getName() .. ' disconnected. Duty status preserved.')
    end
end)