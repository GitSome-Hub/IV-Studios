Made by Lionh34rt#4305
Discord: https://discord.gg/AWyTUEnGeN
Tebex: https://lionh34rt.tebex.io/
GitHub: https://github.com/Lionh34rt/

# Dependencies
* [QBCore Framework](https://github.com/qbcore-framework)
* [PolyZone by mkafrin](https://github.com/mkafrin/PolyZone)
* [qb-target by BerkieBb](https://github.com/BerkieBb/qb-target)

# Installation
* **Install qb-chopshop**
* **Edit the config to your liking**
