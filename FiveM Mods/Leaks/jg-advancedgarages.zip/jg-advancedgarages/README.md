# JG Scripts Advanced Garages v3

Hey there! Thanks so much for purchasing, it really means a lot to me. I've spent a lot of time on this script, and I hope you love it. This document has a bunch of the essential information that should help you out:

## Useful Links

🔧 Configure Advanced Garages in just minutes: https://configurator.jgscripts.com/advanced-garages

📚 Documentation: https://docs.jgscripts.com/advanced-garages/introduction

🔗 Official Website: https://jgscripts.com

🛒 Store: https://store.jgscripts.com

## Support

Join Discord https://discord.jgscripts.com, and we will do whatever it takes to help you out and get you up and running!
