local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
function L0_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = Framework
  L0_2 = L0_2.GetPlayerData
  L0_2 = L0_2()
  if L0_2 then
    L1_2 = L0_2.job
    if L1_2 then
      goto lbl_11
    end
  end
  L1_2 = nil
  L2_2 = nil
  do return L1_2, L2_2 end
  ::lbl_11::
  L1_2 = L0_2.job
  L1_2 = L1_2.name
  L2_2 = 0
  L3_2 = L0_2.job
  L3_2 = L3_2.grade
  if L3_2 then
    L3_2 = type
    L4_2 = L0_2.job
    L4_2 = L4_2.grade
    L3_2 = L3_2(L4_2)
    if "table" == L3_2 then
      L3_2 = L0_2.job
      L3_2 = L3_2.grade
      L3_2 = L3_2.level
      L2_2 = L3_2 or L2_2
      if not L3_2 then
        L2_2 = 0
      end
    else
      L3_2 = L0_2.job
      L2_2 = L3_2.grade
    end
  end
  L3_2 = L1_2
  L4_2 = L2_2
  return L3_2, L4_2
end
function L1_1()
  local L0_2, L1_2
  L0_2 = TriggerEvent
  L1_2 = "fs-government:client:stopTabletAnimation"
  L0_2(L1_2)
end
CleanupGovernmentMenu = L1_1
function L1_1()
  local L0_2, L1_2
  L0_2 = TriggerEvent
  L1_2 = "fs-government:client:stopTabletAnimation"
  L0_2(L1_2)
end
CleanupMainMenuOnly = L1_1
function L1_1(A0_2, A1_2)
  local L2_2, L3_2
  if A1_2 then
    L2_2 = A0_2.onExit
    if not L2_2 then
      function L2_2()
        local L0_3, L1_3
        L0_3 = CleanupMainMenuOnly
        L0_3()
      end
      A0_2.onExit = L2_2
    else
      L2_2 = A0_2.onExit
      function L3_2()
        local L0_3, L1_3
        L0_3 = L2_2
        L0_3()
        L0_3 = CleanupMainMenuOnly
        L0_3()
      end
      A0_2.onExit = L3_2
    end
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = A0_2
  L2_2(L3_2)
end
RegisterGovernmentMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = Framework
  L0_2 = L0_2.GetPlayerData
  L0_2 = L0_2()
  if L0_2 then
    L1_2 = L0_2.job
    if L1_2 then
      goto lbl_15
    end
  end
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "Unable to access player data"
  L3_2 = "error"
  L1_2(L2_2, L3_2)
  do return end
  ::lbl_15::
  L1_2 = L0_2.job
  L1_2 = L1_2.name
  L2_2 = 0
  L3_2 = L0_2.job
  L3_2 = L3_2.grade
  if L3_2 then
    L3_2 = type
    L4_2 = L0_2.job
    L4_2 = L4_2.grade
    L3_2 = L3_2(L4_2)
    if "table" == L3_2 then
      L3_2 = L0_2.job
      L3_2 = L3_2.grade
      L3_2 = L3_2.level
      L2_2 = L3_2 or L2_2
      if not L3_2 then
        L2_2 = 0
      end
    else
      L3_2 = L0_2.job
      L2_2 = L3_2.grade
    end
  end
  L3_2 = Config
  L3_2 = L3_2.Debug
  if L3_2 then
    L3_2 = Utils
    L3_2 = L3_2.DebugPrint
    L4_2 = "Player data retrieved:"
    L3_2(L4_2)
    L3_2 = Utils
    L3_2 = L3_2.DebugPrint
    L4_2 = "- Job: "
    L5_2 = tostring
    L6_2 = L1_2
    L5_2 = L5_2(L6_2)
    L4_2 = L4_2 .. L5_2
    L3_2(L4_2)
    L3_2 = Utils
    L3_2 = L3_2.DebugPrint
    L4_2 = "- Grade: "
    L5_2 = tostring
    L6_2 = L2_2
    L5_2 = L5_2(L6_2)
    L4_2 = L4_2 .. L5_2
    L3_2(L4_2)
    L3_2 = Utils
    L3_2 = L3_2.DebugPrint
    L4_2 = "- Raw job data: "
    L5_2 = json
    L5_2 = L5_2.encode
    L6_2 = L0_2.job
    L5_2 = L5_2(L6_2)
    L4_2 = L4_2 .. L5_2
    L3_2(L4_2)
  end
  L3_2 = {}
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L1_2
  L6_2 = L2_2
  L7_2 = "taxation"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Utils
    L4_2 = L4_2.HasPermission
    L5_2 = L1_2
    L6_2 = L2_2
    L7_2 = "elections"
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    if not L4_2 then
      L4_2 = Utils
      L4_2 = L4_2.HasPermission
      L5_2 = L1_2
      L6_2 = L2_2
      L7_2 = "defcon"
      L4_2 = L4_2(L5_2, L6_2, L7_2)
      if not L4_2 then
        goto lbl_107
      end
    end
  end
  L4_2 = table
  L4_2 = L4_2.insert
  L5_2 = L3_2
  L6_2 = {}
  L6_2.title = "Strategic Functions"
  L6_2.description = "Taxation, elections, laws, DEFCON"
  L6_2.icon = "fas fa-chess"
  function L7_2()
    local L0_3, L1_3
    L0_3 = OpenStrategicMenu
    L0_3()
  end
  L6_2.onSelect = L7_2
  L4_2(L5_2, L6_2)
  ::lbl_107::
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L1_2
  L6_2 = L2_2
  L7_2 = "employee_management"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Utils
    L4_2 = L4_2.HasPermission
    L5_2 = L1_2
    L6_2 = L2_2
    L7_2 = "announcements"
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    if not L4_2 then
      goto lbl_134
    end
  end
  L4_2 = table
  L4_2 = L4_2.insert
  L5_2 = L3_2
  L6_2 = {}
  L6_2.title = "Administrative Functions"
  L6_2.description = "Appointments, roles, announcements"
  L6_2.icon = "fas fa-clipboard-list"
  function L7_2()
    local L0_3, L1_3
    L0_3 = OpenAdministrativeMenu
    L0_3()
  end
  L6_2.onSelect = L7_2
  L4_2(L5_2, L6_2)
  ::lbl_134::
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L1_2
  L6_2 = L2_2
  L7_2 = "surveillance"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Utils
    L4_2 = L4_2.HasPermission
    L5_2 = L1_2
    L6_2 = L2_2
    L7_2 = "seizure"
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    if not L4_2 then
      goto lbl_161
    end
  end
  L4_2 = table
  L4_2 = L4_2.insert
  L5_2 = L3_2
  L6_2 = {}
  L6_2.title = "Security Functions"
  L6_2.description = "Surveillance, seizure, permits"
  L6_2.icon = "fas fa-shield"
  function L7_2()
    local L0_3, L1_3
    L0_3 = OpenSecurityMenu
    L0_3()
  end
  L6_2.onSelect = L7_2
  L4_2(L5_2, L6_2)
  ::lbl_161::
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L1_2
  L6_2 = L2_2
  L7_2 = "subsidy_management"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Utils
    L4_2 = L4_2.HasPermission
    L5_2 = L1_2
    L6_2 = L2_2
    L7_2 = "budget_management"
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    if not L4_2 then
      goto lbl_188
    end
  end
  L4_2 = table
  L4_2 = L4_2.insert
  L5_2 = L3_2
  L6_2 = {}
  L6_2.title = "Economic Functions"
  L6_2.description = "Subsidies, budget, financial reports"
  L6_2.icon = "fas fa-chart-line"
  function L7_2()
    local L0_3, L1_3
    L0_3 = OpenEconomicMenu
    L0_3()
  end
  L6_2.onSelect = L7_2
  L4_2(L5_2, L6_2)
  ::lbl_188::
  L4_2 = table
  L4_2 = L4_2.insert
  L5_2 = L3_2
  L6_2 = {}
  L6_2.title = "Service Status"
  L7_2 = onDuty
  if L7_2 then
    L7_2 = "Currently ON DUTY"
    if L7_2 then
      goto lbl_201
    end
  end
  L7_2 = "Currently OFF DUTY"
  ::lbl_201::
  L6_2.description = L7_2
  L7_2 = onDuty
  if L7_2 then
    L7_2 = "fas fa-toggle-on"
    if L7_2 then
      goto lbl_209
    end
  end
  L7_2 = "fas fa-toggle-off"
  ::lbl_209::
  L6_2.icon = L7_2
  L7_2 = onDuty
  if L7_2 then
    L7_2 = "#27ae60"
    if L7_2 then
      goto lbl_217
    end
  end
  L7_2 = "#e74c3c"
  ::lbl_217::
  L6_2.iconColor = L7_2
  function L7_2()
    local L0_3, L1_3
    L0_3 = ToggleDuty
    L0_3()
  end
  L6_2.onSelect = L7_2
  L4_2(L5_2, L6_2)
  L4_2 = lib
  L4_2 = L4_2.registerContext
  L5_2 = {}
  L5_2.id = "government_main_menu"
  L5_2.title = "\240\159\143\155\239\184\143 Government Management System"
  L5_2.options = L3_2
  function L6_2()
    local L0_3, L1_3
    L0_3 = CleanupGovernmentMenu
    L0_3()
  end
  L5_2.onExit = L6_2
  L4_2(L5_2)
  L4_2 = lib
  L4_2 = L4_2.showContext
  L5_2 = "government_main_menu"
  L4_2(L5_2)
end
OpenGovernmentMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = L0_1
  L0_2, L1_2 = L0_2()
  if not L0_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "Unable to access player data"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
    return
  end
  L2_2 = Config
  L2_2 = L2_2.Debug
  if L2_2 then
    L2_2 = Utils
    L2_2 = L2_2.DebugPrint
    L3_2 = "CoreFunctions: job="
    L4_2 = tostring
    L5_2 = L0_2
    L4_2 = L4_2(L5_2)
    L5_2 = ", grade="
    L6_2 = tostring
    L7_2 = L1_2
    L6_2 = L6_2(L7_2)
    L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
    L2_2(L3_2)
  end
  L2_2 = {}
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "search_players"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Search Player"
    L5_2.description = "Search a nearby player for items"
    L5_2.icon = "fas fa-search"
    function L6_2()
      local L0_3, L1_3
      L0_3 = SearchNearbyPlayer
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "handcuff"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Handcuff/Uncuff"
    L5_2.description = "Restrain or release a nearby player"
    L5_2.icon = "fas fa-handcuffs"
    function L6_2()
      local L0_3, L1_3
      L0_3 = ToggleHandcuffs
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L5_2.title = "Identity Check"
  L5_2.description = "Check nearby player identity and records"
  L5_2.icon = "fas fa-id-badge"
  function L6_2()
    local L0_3, L1_3
    L0_3 = CheckPlayerIdentity
    L0_3()
  end
  L5_2.onSelect = L6_2
  L3_2(L4_2, L5_2)
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "license_management"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "License Management"
    L5_2.description = "Issue, revoke, or check licenses"
    L5_2.icon = "fas fa-id-card"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenLicenseMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "billing"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Billing System"
    L5_2.description = "Send fines and bills to players"
    L5_2.icon = "fas fa-file-invoice-dollar"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenBillingMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "armory_access"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Armory Access"
    L5_2.description = "Access weapons and equipment"
    L5_2.icon = "fas fa-gun"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenArmoryMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "garage_access"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Vehicle Garage"
    L5_2.description = "Spawn or store government vehicles"
    L5_2.icon = "fas fa-car"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenGarageMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L5_2.title = "Storage Access"
  L5_2.description = "Access shared government storage"
  L5_2.icon = "fas fa-box"
  function L6_2()
    local L0_3, L1_3
    L0_3 = Inventory
    L0_3 = L0_3.OpenStash
    L1_3 = "government_storage"
    L0_3(L1_3)
  end
  L5_2.onSelect = L6_2
  L3_2(L4_2, L5_2)
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L5_2.title = "\226\134\144 Back to Main Menu"
  L5_2.description = "Return to government main menu"
  L5_2.icon = "fas fa-arrow-left"
  function L6_2()
    local L0_3, L1_3
    L0_3 = OpenGovernmentMenu
    L0_3()
  end
  L5_2.onSelect = L6_2
  L3_2(L4_2, L5_2)
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "government_core_menu"
  L4_2.title = "\240\159\146\188 Core Functions"
  L4_2.options = L2_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "government_core_menu"
  L3_2(L4_2)
end
OpenCoreFunctionsMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = L0_1
  L0_2, L1_2 = L0_2()
  if not L0_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "Unable to access player data"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
    return
  end
  L2_2 = {}
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "taxation"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Taxation System"
    L5_2.description = "Manage city tax rates and revenue"
    L5_2.icon = "fas fa-coins"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenTaxationMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "elections"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Elections"
    L5_2.description = "Manage city elections and voting"
    L5_2.icon = "fas fa-vote-yea"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenElectionsMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "defcon"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "DEFCON System"
    L5_2.description = "Manage city alert level"
    L5_2.icon = "fas fa-exclamation-triangle"
    L5_2.iconColor = "#e74c3c"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenDefconMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "all"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Laws & Decrees"
    L5_2.description = "Create and manage city laws"
    L5_2.icon = "fas fa-gavel"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenLawsMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L5_2.title = "\226\134\144 Back to Main Menu"
  L5_2.description = "Return to government main menu"
  L5_2.icon = "fas fa-arrow-left"
  function L6_2()
    local L0_3, L1_3
    L0_3 = OpenGovernmentMenu
    L0_3()
  end
  L5_2.onSelect = L6_2
  L3_2(L4_2, L5_2)
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "government_strategic_menu"
  L4_2.title = "\226\153\159\239\184\143 Strategic Functions"
  L4_2.options = L2_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "government_strategic_menu"
  L3_2(L4_2)
end
OpenStrategicMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = L0_1
  L0_2, L1_2 = L0_2()
  if not L0_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "Unable to access player data"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
    return
  end
  L2_2 = {}
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "employee_management"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Appointments"
    L5_2.description = "Manage citizen appointment requests"
    L5_2.icon = "fas fa-calendar-alt"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenAppointmentsMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Employee Management"
    L5_2.description = "Hire, fire, and promote employees"
    L5_2.icon = "fas fa-users-cog"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenEmployeeMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Business Registration"
    L5_2.description = "Register new businesses"
    L5_2.icon = "fas fa-building"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenBusinessRegistrationMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Online Staff"
    L5_2.description = "View currently active staff members"
    L5_2.icon = "fas fa-user-check"
    function L6_2()
      local L0_3, L1_3
      L0_3 = TriggerServerEvent
      L1_3 = "fs-government:server:getOnlineStaff"
      L0_3(L1_3)
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "announcements"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Send Announcement"
    L5_2.description = "Send city-wide announcements"
    L5_2.icon = "fas fa-bullhorn"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenAnnouncementMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L5_2.title = "Business Registry"
  L5_2.description = "View registered businesses"
  L5_2.icon = "fas fa-building"
  function L6_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getBusinesses"
    L0_3(L1_3)
  end
  L5_2.onSelect = L6_2
  L3_2(L4_2, L5_2)
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L5_2.title = "\226\134\144 Back to Main Menu"
  L5_2.description = "Return to government main menu"
  L5_2.icon = "fas fa-arrow-left"
  function L6_2()
    local L0_3, L1_3
    L0_3 = OpenGovernmentMenu
    L0_3()
  end
  L5_2.onSelect = L6_2
  L3_2(L4_2, L5_2)
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "government_admin_menu"
  L4_2.title = "\240\159\147\139 Administrative Functions"
  L4_2.options = L2_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "government_admin_menu"
  L3_2(L4_2)
end
OpenAdministrativeMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = L0_1
  L0_2, L1_2 = L0_2()
  if not L0_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "Unable to access player data"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
    return
  end
  L2_2 = {}
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "surveillance"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Surveillance System"
    L5_2.description = "Access city camera feeds"
    L5_2.icon = "fas fa-video"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenSurveillanceMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "seizure"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Asset Seizure"
    L5_2.description = "Seize vehicles, items, or money"
    L5_2.icon = "fas fa-hand-paper"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenSeizureMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "View Seizures"
    L5_2.description = "View and manage active seizures"
    L5_2.icon = "fas fa-list"
    function L6_2()
      local L0_3, L1_3
      L0_3 = TriggerServerEvent
      L1_3 = "fs-government:server:getSeizures"
      L0_3(L1_3)
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "warrant_issue"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Warrant System"
    L5_2.description = "Issue and check warrants"
    L5_2.icon = "fas fa-file-alt"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenWarrantMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "license_management"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Permit Management"
    L5_2.description = "Create and manage permits"
    L5_2.icon = "fas fa-certificate"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenPermitManagementMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L5_2.title = "\226\134\144 Back to Main Menu"
  L5_2.description = "Return to government main menu"
  L5_2.icon = "fas fa-arrow-left"
  function L6_2()
    local L0_3, L1_3
    L0_3 = OpenGovernmentMenu
    L0_3()
  end
  L5_2.onSelect = L6_2
  L3_2(L4_2, L5_2)
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "government_security_menu"
  L4_2.title = "\240\159\155\161\239\184\143 Security Functions"
  L4_2.options = L2_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "government_security_menu"
  L3_2(L4_2)
end
OpenSecurityMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = L0_1
  L0_2, L1_2 = L0_2()
  if not L0_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "Unable to access player data"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
    return
  end
  L2_2 = {}
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "subsidy_management"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Create Subsidy"
    L5_2.description = "Provide financial aid to citizens"
    L5_2.icon = "fas fa-hand-holding-usd"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenSubsidyCreationMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "View Subsidies"
    L5_2.description = "Review recent subsidy payments"
    L5_2.icon = "fas fa-list-alt"
    function L6_2()
      local L0_3, L1_3
      L0_3 = TriggerServerEvent
      L1_3 = "fs-government:server:getSubsidies"
      L0_3(L1_3)
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "budget_management"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Budget Management"
    L5_2.description = "Manage department budgets"
    L5_2.icon = "fas fa-calculator"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenBudgetMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "financial_reporting"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Financial Reports"
    L5_2.description = "View income and expense reports"
    L5_2.icon = "fas fa-chart-bar"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenFinancialReportMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "business_audit"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Business Audit"
    L5_2.description = "Audit business finances"
    L5_2.icon = "fas fa-search-dollar"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenBusinessAuditMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L5_2.title = "\226\134\144 Back to Main Menu"
  L5_2.description = "Return to government main menu"
  L5_2.icon = "fas fa-arrow-left"
  function L6_2()
    local L0_3, L1_3
    L0_3 = OpenGovernmentMenu
    L0_3()
  end
  L5_2.onSelect = L6_2
  L3_2(L4_2, L5_2)
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "government_economic_menu"
  L4_2.title = "\240\159\147\136 Economic Functions"
  L4_2.options = L2_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "government_economic_menu"
  L3_2(L4_2)
end
OpenEconomicMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = Config
  L0_2 = L0_2.Debug
  if L0_2 then
    L0_2 = Inventory
    L0_2 = L0_2.GetType
    L0_2 = L0_2()
    L1_2 = Utils
    L1_2 = L1_2.DebugPrint
    L2_2 = "Opening armory menu with inventory type: "
    L3_2 = tostring
    L4_2 = L0_2
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
  end
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "Equipment Shop"
  L1_2.description = "Purchase weapons and equipment"
  L1_2.icon = "fas fa-shopping-cart"
  function L2_2()
    local L0_3, L1_3
    L0_3 = Config
    L0_3 = L0_3.Debug
    if L0_3 then
      L0_3 = Utils
      L0_3 = L0_3.DebugPrint
      L1_3 = "Attempting to open armory shop: government_armory_shop"
      L0_3(L1_3)
    end
    L0_3 = Inventory
    L0_3 = L0_3.OpenShop
    L1_3 = "government_armory_shop"
    L0_3(L1_3)
  end
  L1_2.onSelect = L2_2
  L2_2 = {}
  L2_2.title = "Armory Storage"
  L2_2.description = "Access armory stash"
  L2_2.icon = "fas fa-box"
  function L3_2()
    local L0_3, L1_3
    L0_3 = Config
    L0_3 = L0_3.Debug
    if L0_3 then
      L0_3 = Utils
      L0_3 = L0_3.DebugPrint
      L1_3 = "Attempting to open armory stash: government_armory"
      L0_3(L1_3)
    end
    L0_3 = Inventory
    L0_3 = L0_3.OpenStash
    L1_3 = "government_armory"
    L0_3(L1_3)
  end
  L2_2.onSelect = L3_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_armory_menu"
  L2_2.title = "Government Armory"
  L2_2.options = L0_2
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_armory_menu"
  L1_2(L2_2)
end
OpenArmoryMenu = L1_1
function L1_1()
  local L0_2, L1_2
  L0_2 = TriggerServerEvent
  L1_2 = "fs-government:server:getVehicles"
  L0_2(L1_2)
end
OpenGarageMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "Available Funds: Loading..."
  L1_2.description = "Current government treasury balance"
  L1_2.icon = "fas fa-dollar-sign"
  L1_2.iconColor = "#2ecc71"
  L1_2.disabled = true
  L2_2 = {}
  L2_2.title = "Employee Management"
  L2_2.description = "Hire, fire, and promote employees"
  L2_2.icon = "fas fa-users"
  function L3_2()
    local L0_3, L1_3
    L0_3 = OpenEmployeeMenu
    L0_3()
  end
  L2_2.onSelect = L3_2
  L3_2 = {}
  L3_2.title = "View Online Staff"
  L3_2.description = "See who is currently on duty"
  L3_2.icon = "fas fa-user-check"
  function L4_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getOnlineStaff"
    L0_3(L1_3)
  end
  L3_2.onSelect = L4_2
  L4_2 = {}
  L4_2.title = "Government Finances"
  L4_2.description = "View financial information"
  L4_2.icon = "fas fa-chart-line"
  function L5_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getFinances"
    L0_3(L1_3)
  end
  L4_2.onSelect = L5_2
  L5_2 = {}
  L5_2.title = "Withdraw Funds"
  L5_2.description = "Withdraw money from government treasury"
  L5_2.icon = "fas fa-money-bill-wave"
  L5_2.iconColor = "#e74c3c"
  function L6_2()
    local L0_3, L1_3
    L0_3 = OpenWithdrawMenu
    L0_3()
  end
  L5_2.onSelect = L6_2
  L6_2 = {}
  L6_2.title = "Deposit Funds"
  L6_2.description = "Deposit money to government treasury"
  L6_2.icon = "fas fa-piggy-bank"
  L6_2.iconColor = "#27ae60"
  function L7_2()
    local L0_3, L1_3
    L0_3 = OpenDepositMenu
    L0_3()
  end
  L6_2.onSelect = L7_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L0_2[4] = L4_2
  L0_2[5] = L5_2
  L0_2[6] = L6_2
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_boss_menu"
  L2_2.title = "Boss Actions"
  L2_2.options = L0_2
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_boss_menu"
  L1_2(L2_2)
  L1_2 = TriggerServerEvent
  L2_2 = "fs-government:server:getFundsBalance"
  L1_2(L2_2)
end
OpenBossMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Withdraw Government Funds"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "number"
  L3_2.label = "Amount"
  L3_2.placeholder = "10000"
  L3_2.required = true
  L3_2.min = 1
  L4_2 = {}
  L4_2.type = "input"
  L4_2.label = "Reason"
  L4_2.placeholder = "Equipment purchase, salaries, etc."
  L4_2.required = true
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = tonumber
    L2_2 = L0_2[1]
    L1_2 = L1_2(L2_2)
    L2_2 = L0_2[2]
    if L1_2 and L1_2 > 0 and L2_2 then
      L3_2 = TriggerServerEvent
      L4_2 = "fs-government:server:withdrawFunds"
      L5_2 = L1_2
      L6_2 = L2_2
      L3_2(L4_2, L5_2, L6_2)
    else
      L3_2 = Framework
      L3_2 = L3_2.ShowNotification
      L4_2 = "Invalid input provided"
      L5_2 = "error"
      L3_2(L4_2, L5_2)
    end
  end
end
OpenWithdrawMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Deposit to Government Funds"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "number"
  L3_2.label = "Amount"
  L3_2.placeholder = "10000"
  L3_2.required = true
  L3_2.min = 1
  L4_2 = {}
  L4_2.type = "input"
  L4_2.label = "Reason"
  L4_2.placeholder = "Personal donation, budget allocation, etc."
  L4_2.required = true
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = tonumber
    L2_2 = L0_2[1]
    L1_2 = L1_2(L2_2)
    L2_2 = L0_2[2]
    if L1_2 and L1_2 > 0 and L2_2 then
      L3_2 = TriggerServerEvent
      L4_2 = "fs-government:server:depositFunds"
      L5_2 = L1_2
      L6_2 = L2_2
      L3_2(L4_2, L5_2, L6_2)
    else
      L3_2 = Framework
      L3_2 = L3_2.ShowNotification
      L4_2 = "Invalid input provided"
      L5_2 = "error"
      L3_2(L4_2, L5_2)
    end
  end
end
OpenDepositMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "Hire Employee"
  L1_2.description = "Hire a new employee by server ID"
  L1_2.icon = "fas fa-user-plus"
  function L2_2()
    local L0_3, L1_3
    L0_3 = HireEmployee
    L0_3()
  end
  L1_2.onSelect = L2_2
  L2_2 = {}
  L2_2.title = "Employee List"
  L2_2.description = "View and manage all employees"
  L2_2.icon = "fas fa-users"
  function L3_2()
    local L0_3, L1_3
    L0_3 = OpenEmployeeListMenu
    L0_3()
  end
  L2_2.onSelect = L3_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_employee_menu"
  L2_2.title = "Employee Management"
  L2_2.options = L0_2
  L2_2.menu = "government_boss_menu"
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_employee_menu"
  L1_2(L2_2)
end
OpenEmployeeMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L0_2 = {}
  L1_2 = ipairs
  L2_2 = Config
  L2_2 = L2_2.Locations
  L2_2 = L2_2.surveillance
  L2_2 = L2_2.cameras
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = table
    L7_2 = L7_2.insert
    L8_2 = L0_2
    L9_2 = {}
    L10_2 = L6_2.label
    L9_2.title = L10_2
    L9_2.description = "View camera feed"
    L9_2.icon = "fas fa-video"
    function L10_2()
      local L0_3, L1_3
      L0_3 = ViewCamera
      L1_3 = L6_2.id
      L0_3(L1_3)
    end
    L9_2.onSelect = L10_2
    L7_2(L8_2, L9_2)
  end
  L1_2 = table
  L1_2 = L1_2.insert
  L2_2 = L0_2
  L3_2 = {}
  L3_2.title = "\226\134\144 Back to Main Menu"
  L3_2.description = "Return to government main menu"
  L3_2.icon = "fas fa-arrow-left"
  function L4_2()
    local L0_3, L1_3
    L0_3 = OpenGovernmentMenu
    L0_3()
  end
  L3_2.onSelect = L4_2
  L1_2(L2_2, L3_2)
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_surveillance_menu"
  L2_2.title = "Surveillance System"
  L2_2.options = L0_2
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_surveillance_menu"
  L1_2(L2_2)
end
OpenSurveillanceMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "View Tax Settings"
  L1_2.description = "Current tax rates and settings"
  L1_2.icon = "fas fa-percentage"
  function L2_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getTaxSettings"
    L0_3(L1_3)
  end
  L1_2.onSelect = L2_2
  L2_2 = {}
  L2_2.title = "Update Tax Rates"
  L2_2.description = "Modify city tax rates"
  L2_2.icon = "fas fa-edit"
  function L3_2()
    local L0_3, L1_3
    L0_3 = UpdateTaxRates
    L0_3()
  end
  L2_2.onSelect = L3_2
  L3_2 = {}
  L3_2.title = "Tax Revenue Report"
  L3_2.description = "View collected taxes"
  L3_2.icon = "fas fa-chart-bar"
  function L4_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getTaxRevenue"
    L0_3(L1_3)
  end
  L3_2.onSelect = L4_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L1_2 = table
  L1_2 = L1_2.insert
  L2_2 = L0_2
  L3_2 = {}
  L3_2.title = "\226\134\144 Back to Main Menu"
  L3_2.description = "Return to government main menu"
  L3_2.icon = "fas fa-arrow-left"
  function L4_2()
    local L0_3, L1_3
    L0_3 = OpenGovernmentMenu
    L0_3()
  end
  L3_2.onSelect = L4_2
  L1_2(L2_2, L3_2)
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_taxation_menu"
  L2_2.title = "Taxation System"
  L2_2.options = L0_2
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_taxation_menu"
  L1_2(L2_2)
end
OpenTaxationMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "Current Election"
  L1_2.description = "View ongoing election"
  L1_2.icon = "fas fa-poll"
  function L2_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getCurrentElection"
    L0_3(L1_3)
  end
  L1_2.onSelect = L2_2
  L2_2 = {}
  L2_2.title = "Start New Election"
  L2_2.description = "Begin a new election cycle"
  L2_2.icon = "fas fa-play"
  function L3_2()
    local L0_3, L1_3
    L0_3 = StartNewElection
    L0_3()
  end
  L2_2.onSelect = L3_2
  L3_2 = {}
  L3_2.title = "Election Results"
  L3_2.description = "View past election results"
  L3_2.icon = "fas fa-trophy"
  function L4_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getElectionResults"
    L0_3(L1_3)
  end
  L3_2.onSelect = L4_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_elections_menu"
  L2_2.title = "Elections System"
  L2_2.options = L0_2
  L2_2.menu = "government_main_menu"
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_elections_menu"
  L1_2(L2_2)
end
OpenElectionsMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L0_2 = {}
  L1_2 = pairs
  L2_2 = Config
  L2_2 = L2_2.DEFCON
  L2_2 = L2_2.levels
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = table
    L7_2 = L7_2.insert
    L8_2 = L0_2
    L9_2 = {}
    L10_2 = L6_2.label
    L9_2.title = L10_2
    L10_2 = "Set DEFCON level to "
    L11_2 = L5_2
    L10_2 = L10_2 .. L11_2
    L9_2.description = L10_2
    L9_2.icon = "fas fa-shield-alt"
    function L10_2()
      local L0_3, L1_3, L2_3
      L0_3 = TriggerServerEvent
      L1_3 = "fs-government:server:setDefconLevel"
      L2_3 = L5_2
      L0_3(L1_3, L2_3)
    end
    L9_2.onSelect = L10_2
    L7_2(L8_2, L9_2)
  end
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_defcon_menu"
  L2_2.title = "DEFCON System"
  L2_2.options = L0_2
  L2_2.menu = "government_main_menu"
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_defcon_menu"
  L1_2(L2_2)
end
OpenDefconMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Global Announcement"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "input"
  L3_2.label = "Title"
  L3_2.placeholder = "Announcement title..."
  L3_2.required = true
  L4_2 = {}
  L4_2.type = "textarea"
  L4_2.label = "Message"
  L4_2.placeholder = "Announcement message..."
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "select"
  L5_2.label = "Priority"
  L6_2 = {}
  L7_2 = {}
  L7_2.value = "low"
  L7_2.label = "Low"
  L8_2 = {}
  L8_2.value = "normal"
  L8_2.label = "Normal"
  L9_2 = {}
  L9_2.value = "high"
  L9_2.label = "High"
  L10_2 = {}
  L10_2.value = "urgent"
  L10_2.label = "Urgent"
  L6_2[1] = L7_2
  L6_2[2] = L8_2
  L6_2[3] = L9_2
  L6_2[4] = L10_2
  L5_2.options = L6_2
  L5_2.default = "normal"
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = TriggerServerEvent
    L2_2 = "fs-government:server:sendAnnouncement"
    L3_2 = L0_2[1]
    L4_2 = L0_2[2]
    L5_2 = L0_2[3]
    L1_2(L2_2, L3_2, L4_2, L5_2)
  end
end
OpenAnnouncementMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = L0_1
  L0_2, L1_2 = L0_2()
  if not L0_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "Unable to access player data"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L0_2
  L4_2 = L1_2
  L5_2 = "license_management"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "You do not have permission to access license management"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
    return
  end
  L2_2 = {}
  L3_2 = {}
  L3_2.title = "View Player Licenses"
  L3_2.description = "Check nearby player licenses"
  L3_2.icon = "fas fa-search"
  function L4_2()
    local L0_3, L1_3
    L0_3 = CheckPlayerLicenses
    L0_3()
  end
  L3_2.onSelect = L4_2
  L4_2 = {}
  L4_2.title = "Issue License"
  L4_2.description = "Give a license to a player"
  L4_2.icon = "fas fa-plus"
  function L5_2()
    local L0_3, L1_3
    L0_3 = IssueLicense
    L0_3()
  end
  L4_2.onSelect = L5_2
  L5_2 = {}
  L5_2.title = "Revoke License"
  L5_2.description = "Remove a license from a player"
  L5_2.icon = "fas fa-minus"
  function L6_2()
    local L0_3, L1_3
    L0_3 = RevokeLicense
    L0_3()
  end
  L5_2.onSelect = L6_2
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "government_license_menu"
  L4_2.title = "License Management"
  L4_2.options = L2_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "government_license_menu"
  L3_2(L4_2)
end
OpenLicenseMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L0_2 = Framework
  L0_2 = L0_2.GetClosestPlayer
  L0_2, L1_2 = L0_2()
  if not L0_2 or L1_2 > 3.0 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "No player nearby"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
    return
  end
  L2_2 = lib
  L2_2 = L2_2.inputDialog
  L3_2 = "Issue Fine/Bill"
  L4_2 = {}
  L5_2 = {}
  L5_2.type = "input"
  L5_2.label = "Amount"
  L5_2.placeholder = "1000"
  L5_2.required = true
  L6_2 = {}
  L6_2.type = "input"
  L6_2.label = "Reason"
  L6_2.placeholder = "Fine for..."
  L6_2.required = true
  L4_2[1] = L5_2
  L4_2[2] = L6_2
  L2_2 = L2_2(L3_2, L4_2)
  if L2_2 then
    L3_2 = tonumber
    L4_2 = L2_2[1]
    L3_2 = L3_2(L4_2)
    if L3_2 and L3_2 > 0 then
      L4_2 = TriggerServerEvent
      L5_2 = "fs-government:server:billNearestPlayer"
      L6_2 = GetPlayerServerId
      L7_2 = L0_2
      L6_2 = L6_2(L7_2)
      L7_2 = L3_2
      L8_2 = L2_2[2]
      L4_2(L5_2, L6_2, L7_2, L8_2)
    else
      L4_2 = Framework
      L4_2 = L4_2.ShowNotification
      L5_2 = "Invalid amount"
      L6_2 = "error"
      L4_2(L5_2, L6_2)
    end
  end
end
OpenBillingMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = L0_1
  L0_2, L1_2 = L0_2()
  if not L0_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "Unable to access player data"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.TableContains
  L3_2 = Config
  L3_2 = L3_2.Government
  L3_2 = L3_2.jobs
  L4_2 = L0_2
  L2_2 = L2_2(L3_2, L4_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "Access denied - Not a government employee"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
    return
  end
  L2_2 = Config
  L2_2 = L2_2.Debug
  if L2_2 then
    L2_2 = Utils
    L2_2 = L2_2.DebugPrint
    L3_2 = "FieldOperations: job="
    L4_2 = tostring
    L5_2 = L0_2
    L4_2 = L4_2(L5_2)
    L5_2 = ", grade="
    L6_2 = tostring
    L7_2 = L1_2
    L6_2 = L6_2(L7_2)
    L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
    L2_2(L3_2)
  end
  L2_2 = {}
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "search_players"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Search Player"
    L5_2.description = "Search a nearby player for items"
    L5_2.icon = "fas fa-search"
    function L6_2()
      local L0_3, L1_3
      L0_3 = TriggerEvent
      L1_3 = "fs-government:client:searchPlayer"
      L0_3(L1_3)
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "handcuff"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Handcuff/Uncuff"
    L5_2.description = "Handcuff or uncuff a nearby player"
    L5_2.icon = "fas fa-handcuffs"
    function L6_2()
      local L0_3, L1_3
      L0_3 = TriggerEvent
      L1_3 = "fs-government:client:toggleHandcuffs"
      L0_3(L1_3)
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "search_players"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Identity Check"
    L5_2.description = "Check a nearby player's identity"
    L5_2.icon = "fas fa-id-card"
    function L6_2()
      local L0_3, L1_3
      L0_3 = TriggerEvent
      L1_3 = "fs-government:client:checkIdentity"
      L0_3(L1_3)
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "license_management"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "License Management"
    L5_2.description = "Manage player licenses"
    L5_2.icon = "fas fa-certificate"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenLicenseMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = "billing"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "Issue Fine/Bill"
    L5_2.description = "Issue a fine or bill to a player"
    L5_2.icon = "fas fa-receipt"
    function L6_2()
      local L0_3, L1_3
      L0_3 = OpenBillingMenu
      L0_3()
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = #L2_2
  if 0 == L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = "No available actions for your rank"
    L5_2 = "error"
    L3_2(L4_2, L5_2)
    return
  end
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "government_field_operations"
  L4_2.title = "\240\159\154\148 Field Operations"
  L4_2.options = L2_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "government_field_operations"
  L3_2(L4_2)
end
OpenFieldOperationsMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Create Subsidy Program"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "input"
  L3_2.label = "Program Name"
  L3_2.placeholder = "Unemployment Aid"
  L3_2.required = true
  L4_2 = {}
  L4_2.type = "input"
  L4_2.label = "Target ID"
  L4_2.placeholder = "Player ID"
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "number"
  L5_2.label = "Amount"
  L5_2.placeholder = "5000"
  L5_2.required = true
  L6_2 = {}
  L6_2.type = "input"
  L6_2.label = "Duration (days)"
  L6_2.placeholder = "30"
  L6_2.required = true
  L7_2 = {}
  L7_2.type = "input"
  L7_2.label = "Description"
  L7_2.placeholder = "Reason for subsidy"
  L7_2.required = true
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L2_2[4] = L6_2
  L2_2[5] = L7_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = L0_2[1]
    L2_2 = tonumber
    L3_2 = L0_2[2]
    L2_2 = L2_2(L3_2)
    L3_2 = tonumber
    L4_2 = L0_2[3]
    L3_2 = L3_2(L4_2)
    L4_2 = tonumber
    L5_2 = L0_2[4]
    L4_2 = L4_2(L5_2)
    L5_2 = L0_2[5]
    if L2_2 and L3_2 and L3_2 > 0 and L4_2 and L4_2 > 0 then
      L6_2 = TriggerServerEvent
      L7_2 = "fs-government:server:createSubsidy"
      L8_2 = L1_2
      L9_2 = L2_2
      L10_2 = L3_2
      L11_2 = L4_2
      L12_2 = L5_2
      L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
    else
      L6_2 = Framework
      L6_2 = L6_2.ShowNotification
      L7_2 = "Invalid input provided"
      L8_2 = "error"
      L6_2(L7_2, L8_2)
    end
  end
end
OpenSubsidyCreationMenu = L1_1
function L1_1()
  local L0_2, L1_2
  L0_2 = TriggerServerEvent
  L1_2 = "fs-government:server:getSubsidies"
  L0_2(L1_2)
end
OpenSubsidyManagementMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "View Current Budget"
  L1_2.description = "Review department budgets and allocations"
  L1_2.icon = "fas fa-chart-pie"
  function L2_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getBudget"
    L0_3(L1_3)
  end
  L1_2.onSelect = L2_2
  L2_2 = {}
  L2_2.title = "Set Department Budget"
  L2_2.description = "Create or modify department budgets"
  L2_2.icon = "fas fa-edit"
  function L3_2()
    local L0_3, L1_3
    L0_3 = OpenDepartmentBudgetMenu
    L0_3()
  end
  L2_2.onSelect = L3_2
  L3_2 = {}
  L3_2.title = "Allocate Funds"
  L3_2.description = "Distribute budget to departments"
  L3_2.icon = "fas fa-hand-holding-usd"
  function L4_2()
    local L0_3, L1_3
    L0_3 = OpenBudgetAllocationMenu
    L0_3()
  end
  L3_2.onSelect = L4_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_budget_menu"
  L2_2.title = "\240\159\146\176 Budget Management"
  L2_2.options = L0_2
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_budget_menu"
  L1_2(L2_2)
end
OpenBudgetMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L0_2 = {}
  L1_2 = pairs
  L2_2 = Config
  L2_2 = L2_2.Departments
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = table
    L7_2 = L7_2.insert
    L8_2 = L0_2
    L9_2 = {}
    L9_2.value = L5_2
    L9_2.label = L6_2
    L7_2(L8_2, L9_2)
  end
  L1_2 = lib
  L1_2 = L1_2.inputDialog
  L2_2 = "Allocate Department Funds"
  L3_2 = {}
  L4_2 = {}
  L4_2.type = "select"
  L4_2.label = "Department"
  L4_2.options = L0_2
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "number"
  L5_2.label = "Amount"
  L5_2.placeholder = "50000"
  L5_2.required = true
  L6_2 = {}
  L6_2.type = "input"
  L6_2.label = "Purpose"
  L6_2.placeholder = "Equipment purchase"
  L6_2.required = true
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L3_2[3] = L6_2
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L2_2 = L1_2[1]
    L3_2 = tonumber
    L4_2 = L1_2[2]
    L3_2 = L3_2(L4_2)
    L4_2 = L1_2[3]
    if L3_2 and L3_2 > 0 then
      L5_2 = TriggerServerEvent
      L6_2 = "fs-government:server:allocateFunds"
      L7_2 = L2_2
      L8_2 = L3_2
      L9_2 = L4_2
      L5_2(L6_2, L7_2, L8_2, L9_2)
    else
      L5_2 = Framework
      L5_2 = L5_2.ShowNotification
      L6_2 = "Invalid amount"
      L7_2 = "error"
      L5_2(L6_2, L7_2)
    end
  end
end
OpenBudgetAllocationMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L0_2 = {}
  L1_2 = pairs
  L2_2 = Config
  L2_2 = L2_2.Departments
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = table
    L7_2 = L7_2.insert
    L8_2 = L0_2
    L9_2 = {}
    L9_2.value = L5_2
    L9_2.label = L6_2
    L7_2(L8_2, L9_2)
  end
  L1_2 = lib
  L1_2 = L1_2.inputDialog
  L2_2 = "Set Department Budget"
  L3_2 = {}
  L4_2 = {}
  L4_2.type = "select"
  L4_2.label = "Department"
  L4_2.options = L0_2
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "number"
  L5_2.label = "Monthly Budget"
  L5_2.placeholder = "100000"
  L5_2.required = true
  L6_2 = {}
  L6_2.type = "input"
  L6_2.label = "Fiscal Year"
  L6_2.placeholder = "2024"
  L6_2.required = true
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L3_2[3] = L6_2
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L2_2 = L1_2[1]
    L3_2 = tonumber
    L4_2 = L1_2[2]
    L3_2 = L3_2(L4_2)
    L4_2 = L1_2[3]
    if L3_2 and L3_2 > 0 then
      L5_2 = TriggerServerEvent
      L6_2 = "fs-government:server:setDepartmentBudget"
      L7_2 = L2_2
      L8_2 = L3_2
      L9_2 = L4_2
      L5_2(L6_2, L7_2, L8_2, L9_2)
    else
      L5_2 = Framework
      L5_2 = L5_2.ShowNotification
      L6_2 = "Invalid budget amount"
      L7_2 = "error"
      L5_2(L6_2, L7_2)
    end
  end
end
OpenDepartmentBudgetMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "Monthly Revenue Report"
  L1_2.description = "View city income for current month"
  L1_2.icon = "fas fa-chart-line"
  function L2_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getMonthlyReport"
    L0_3(L1_3)
  end
  L1_2.onSelect = L2_2
  L2_2 = {}
  L2_2.title = "Expense Report"
  L2_2.description = "Review government expenditures"
  L2_2.icon = "fas fa-receipt"
  function L3_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getExpenseReport"
    L0_3(L1_3)
  end
  L2_2.onSelect = L3_2
  L3_2 = {}
  L3_2.title = "Tax Collection Report"
  L3_2.description = "View tax revenue breakdown"
  L3_2.icon = "fas fa-coins"
  function L4_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getTaxReport"
    L0_3(L1_3)
  end
  L3_2.onSelect = L4_2
  L4_2 = {}
  L4_2.title = "Annual Summary"
  L4_2.description = "Generate yearly financial summary"
  L4_2.icon = "fas fa-file-alt"
  function L5_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getAnnualReport"
    L0_3(L1_3)
  end
  L4_2.onSelect = L5_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L0_2[4] = L4_2
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_financial_report_menu"
  L2_2.title = "\240\159\147\138 Financial Reports"
  L2_2.options = L0_2
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_financial_report_menu"
  L1_2(L2_2)
end
OpenFinancialReportMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "Initiate New Audit"
  L1_2.description = "Start a new business audit process"
  L1_2.icon = "fas fa-search-dollar"
  function L2_2()
    local L0_3, L1_3
    L0_3 = OpenNewBusinessAuditMenu
    L0_3()
  end
  L1_2.onSelect = L2_2
  L2_2 = {}
  L2_2.title = "Quick Business Search"
  L2_2.description = "Search for businesses by name or owner"
  L2_2.icon = "fas fa-search"
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = lib
    L0_3 = L0_3.inputDialog
    L1_3 = "Search Businesses"
    L2_3 = {}
    L3_3 = {}
    L3_3.type = "input"
    L3_3.label = "Search Term"
    L3_3.placeholder = "Business name, owner, or license..."
    L3_3.required = true
    L2_3[1] = L3_3
    L0_3 = L0_3(L1_3, L2_3)
    if L0_3 then
      L1_3 = L0_3[1]
      if L1_3 then
        L1_3 = TriggerServerEvent
        L2_3 = "fs-government:server:searchBusinesses"
        L3_3 = L0_3[1]
        L1_3(L2_3, L3_3)
      end
    end
  end
  L2_2.onSelect = L3_2
  L3_2 = {}
  L3_2.title = "View All Businesses"
  L3_2.description = "View complete business registry"
  L3_2.icon = "fas fa-building"
  function L4_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getAllBusinesses"
    L0_3(L1_3)
  end
  L3_2.onSelect = L4_2
  L4_2 = {}
  L4_2.title = "Active Audits"
  L4_2.description = "View ongoing business audits"
  L4_2.icon = "fas fa-clock"
  function L5_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getActiveAudits"
    L0_3(L1_3)
  end
  L4_2.onSelect = L5_2
  L5_2 = {}
  L5_2.title = "Audit History"
  L5_2.description = "View completed audit records"
  L5_2.icon = "fas fa-history"
  function L6_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getAuditHistory"
    L0_3(L1_3)
  end
  L5_2.onSelect = L6_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L0_2[4] = L4_2
  L0_2[5] = L5_2
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_business_audit_menu"
  L2_2.title = "\240\159\148\141 Business Audit System"
  L2_2.options = L0_2
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_business_audit_menu"
  L1_2(L2_2)
end
OpenBusinessAuditMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Initiate Business Audit"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "input"
  L3_2.label = "Business Name"
  L3_2.placeholder = "Business to audit"
  L3_2.required = true
  L4_2 = {}
  L4_2.type = "input"
  L4_2.label = "Owner ID"
  L4_2.placeholder = "Player ID of owner"
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "select"
  L5_2.label = "Business Type"
  L6_2 = {}
  L7_2 = {}
  L7_2.value = "restaurant"
  L7_2.label = "Restaurant/Food Service"
  L8_2 = {}
  L8_2.value = "retail"
  L8_2.label = "Retail Store"
  L9_2 = {}
  L9_2.value = "service"
  L9_2.label = "Service Business"
  L10_2 = {}
  L10_2.value = "manufacturing"
  L10_2.label = "Manufacturing"
  L11_2 = {}
  L11_2.value = "technology"
  L11_2.label = "Technology/IT"
  L12_2 = {}
  L12_2.value = "other"
  L12_2.label = "Other"
  L6_2[1] = L7_2
  L6_2[2] = L8_2
  L6_2[3] = L9_2
  L6_2[4] = L10_2
  L6_2[5] = L11_2
  L6_2[6] = L12_2
  L5_2.options = L6_2
  L5_2.required = true
  L6_2 = {}
  L6_2.type = "select"
  L6_2.label = "Audit Type"
  L7_2 = {}
  L8_2 = {}
  L8_2.value = "tax_compliance"
  L8_2.label = "Tax Compliance Review"
  L9_2 = {}
  L9_2.value = "financial_audit"
  L9_2.label = "Financial Records Audit"
  L10_2 = {}
  L10_2.value = "license_check"
  L10_2.label = "License & Permits Check"
  L11_2 = {}
  L11_2.value = "full_audit"
  L11_2.label = "Complete Business Audit"
  L7_2[1] = L8_2
  L7_2[2] = L9_2
  L7_2[3] = L10_2
  L7_2[4] = L11_2
  L6_2.options = L7_2
  L6_2.required = true
  L7_2 = {}
  L7_2.type = "input"
  L7_2.label = "Reason"
  L7_2.placeholder = "Reason for audit"
  L7_2.required = true
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L2_2[4] = L6_2
  L2_2[5] = L7_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = L0_2[1]
    L2_2 = tonumber
    L3_2 = L0_2[2]
    L2_2 = L2_2(L3_2)
    L3_2 = L0_2[3]
    L4_2 = L0_2[4]
    L5_2 = L0_2[5]
    if L2_2 then
      L6_2 = TriggerServerEvent
      L7_2 = "fs-government:server:initiateBusinessAudit"
      L8_2 = L1_2
      L9_2 = L2_2
      L10_2 = L3_2
      L11_2 = L4_2
      L12_2 = L5_2
      L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
    else
      L6_2 = Framework
      L6_2 = L6_2.ShowNotification
      L7_2 = "Invalid owner ID"
      L8_2 = "error"
      L6_2(L7_2, L8_2)
    end
  end
end
OpenNewBusinessAuditMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "View Pending Appointments"
  L1_2.description = "Review citizen appointment requests"
  L1_2.icon = "fas fa-clock"
  function L2_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getAppointments"
    L0_3(L1_3)
  end
  L1_2.onSelect = L2_2
  L2_2 = {}
  L2_2.title = "Schedule New Appointment"
  L2_2.description = "Create appointment slot for citizens"
  L2_2.icon = "fas fa-plus"
  function L3_2()
    local L0_3, L1_3
    L0_3 = OpenAppointmentCreationMenu
    L0_3()
  end
  L2_2.onSelect = L3_2
  L3_2 = {}
  L3_2.title = "Appointment History"
  L3_2.description = "View completed appointments"
  L3_2.icon = "fas fa-history"
  function L4_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getAppointmentHistory"
    L0_3(L1_3)
  end
  L3_2.onSelect = L4_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_appointments_menu"
  L2_2.title = "\240\159\147\133 Appointment Management"
  L2_2.options = L0_2
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_appointments_menu"
  L1_2(L2_2)
end
OpenAppointmentsMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Schedule Appointment"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "input"
  L3_2.label = "Citizen ID"
  L3_2.placeholder = "Player ID"
  L3_2.required = true
  L4_2 = {}
  L4_2.type = "input"
  L4_2.label = "Purpose"
  L4_2.placeholder = "Meeting purpose"
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "date"
  L5_2.label = "Date"
  L5_2.required = true
  L6_2 = {}
  L6_2.type = "input"
  L6_2.label = "Time"
  L6_2.placeholder = "HH:MM"
  L6_2.required = true
  L7_2 = {}
  L7_2.type = "number"
  L7_2.label = "Duration (minutes)"
  L7_2.placeholder = "30"
  L7_2.required = true
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L2_2[4] = L6_2
  L2_2[5] = L7_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = tonumber
    L2_2 = L0_2[1]
    L1_2 = L1_2(L2_2)
    L2_2 = L0_2[2]
    L3_2 = L0_2[3]
    L4_2 = L0_2[4]
    L5_2 = tonumber
    L6_2 = L0_2[5]
    L5_2 = L5_2(L6_2)
    if L1_2 and L5_2 and L5_2 > 0 then
      L6_2 = TriggerServerEvent
      L7_2 = "fs-government:server:scheduleAppointment"
      L8_2 = L1_2
      L9_2 = L2_2
      L10_2 = L3_2
      L11_2 = L4_2
      L12_2 = L5_2
      L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
    else
      L6_2 = Framework
      L6_2 = L6_2.ShowNotification
      L7_2 = "Invalid input provided"
      L8_2 = "error"
      L6_2(L7_2, L8_2)
    end
  end
end
OpenAppointmentCreationMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Register New Business"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "input"
  L3_2.label = "Business Name"
  L3_2.placeholder = "Company Inc."
  L3_2.required = true
  L4_2 = {}
  L4_2.type = "input"
  L4_2.label = "Owner ID"
  L4_2.placeholder = "Player ID"
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "select"
  L5_2.label = "Business Type"
  L6_2 = {}
  L7_2 = {}
  L7_2.value = "restaurant"
  L7_2.label = "Restaurant/Food Service"
  L8_2 = {}
  L8_2.value = "retail"
  L8_2.label = "Retail Store"
  L9_2 = {}
  L9_2.value = "service"
  L9_2.label = "Service Business"
  L10_2 = {}
  L10_2.value = "manufacturing"
  L10_2.label = "Manufacturing"
  L11_2 = {}
  L11_2.value = "technology"
  L11_2.label = "Technology/IT"
  L12_2 = {}
  L12_2.value = "other"
  L12_2.label = "Other"
  L6_2[1] = L7_2
  L6_2[2] = L8_2
  L6_2[3] = L9_2
  L6_2[4] = L10_2
  L6_2[5] = L11_2
  L6_2[6] = L12_2
  L5_2.options = L6_2
  L5_2.required = true
  L6_2 = {}
  L6_2.type = "input"
  L6_2.label = "Address"
  L6_2.placeholder = "Business location"
  L6_2.required = true
  L7_2 = {}
  L7_2.type = "number"
  L7_2.label = "Registration Fee"
  L7_2.placeholder = "5000"
  L7_2.required = true
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L2_2[4] = L6_2
  L2_2[5] = L7_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = L0_2[1]
    L2_2 = tonumber
    L3_2 = L0_2[2]
    L2_2 = L2_2(L3_2)
    L3_2 = L0_2[3]
    L4_2 = L0_2[4]
    L5_2 = tonumber
    L6_2 = L0_2[5]
    L5_2 = L5_2(L6_2)
    if L2_2 and L5_2 and L5_2 > 0 then
      L6_2 = TriggerServerEvent
      L7_2 = "fs-government:server:registerBusiness"
      L8_2 = L1_2
      L9_2 = L2_2
      L10_2 = L3_2
      L11_2 = L4_2
      L12_2 = L5_2
      L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
    else
      L6_2 = Framework
      L6_2 = L6_2.ShowNotification
      L7_2 = "Invalid input provided"
      L8_2 = "error"
      L6_2(L7_2, L8_2)
    end
  end
end
OpenBusinessRegistrationMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "Issue New Permit"
  L1_2.description = "Create permits for citizens/businesses"
  L1_2.icon = "fas fa-certificate"
  function L2_2()
    local L0_3, L1_3
    L0_3 = OpenPermitCreationMenu
    L0_3()
  end
  L1_2.onSelect = L2_2
  L2_2 = {}
  L2_2.title = "View Active Permits"
  L2_2.description = "Review all current permits"
  L2_2.icon = "fas fa-list"
  function L3_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getActivePermits"
    L0_3(L1_3)
  end
  L2_2.onSelect = L3_2
  L3_2 = {}
  L3_2.title = "View All Permits"
  L3_2.description = "View permits of all statuses"
  L3_2.icon = "fas fa-list-alt"
  function L4_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getAllPermits"
    L0_3(L1_3)
  end
  L3_2.onSelect = L4_2
  L4_2 = {}
  L4_2.title = "Search Permits"
  L4_2.description = "Search permits by number/holder/type"
  L4_2.icon = "fas fa-search"
  function L5_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = lib
    L0_3 = L0_3.inputDialog
    L1_3 = "Search Permits"
    L2_3 = {}
    L3_3 = {}
    L3_3.type = "input"
    L3_3.label = "Search Term"
    L3_3.placeholder = "Permit number, holder name, or type..."
    L3_3.required = true
    L2_3[1] = L3_3
    L0_3 = L0_3(L1_3, L2_3)
    if L0_3 then
      L1_3 = L0_3[1]
      if L1_3 then
        L1_3 = TriggerServerEvent
        L2_3 = "fs-government:server:searchPermits"
        L3_3 = L0_3[1]
        L1_3(L2_3, L3_3)
      end
    end
  end
  L4_2.onSelect = L5_2
  L5_2 = {}
  L5_2.title = "Check Permit Status"
  L5_2.description = "Check a specific permit by number"
  L5_2.icon = "fas fa-search-plus"
  function L6_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = lib
    L0_3 = L0_3.inputDialog
    L1_3 = "Check Permit"
    L2_3 = {}
    L3_3 = {}
    L3_3.type = "input"
    L3_3.label = "Permit Number"
    L3_3.placeholder = "PER-XXXXX"
    L3_3.required = true
    L2_3[1] = L3_3
    L0_3 = L0_3(L1_3, L2_3)
    if L0_3 then
      L1_3 = L0_3[1]
      if L1_3 then
        L1_3 = TriggerServerEvent
        L2_3 = "fs-government:server:checkPermit"
        L3_3 = L0_3[1]
        L1_3(L2_3, L3_3)
      end
    end
  end
  L5_2.onSelect = L6_2
  L6_2 = {}
  L6_2.title = "View Expiring Permits"
  L6_2.description = "View permits expiring soon"
  L6_2.icon = "fas fa-exclamation-triangle"
  L6_2.iconColor = "#f39c12"
  function L7_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    L0_3 = lib
    L0_3 = L0_3.inputDialog
    L1_3 = "Expiring Permits"
    L2_3 = {}
    L3_3 = {}
    L3_3.type = "number"
    L3_3.label = "Days ahead to check"
    L3_3.placeholder = "30"
    L3_3.required = true
    L3_3.min = 1
    L3_3.max = 365
    L2_3[1] = L3_3
    L0_3 = L0_3(L1_3, L2_3)
    if L0_3 then
      L1_3 = L0_3[1]
      if L1_3 then
        L1_3 = TriggerServerEvent
        L2_3 = "fs-government:server:getExpiringPermits"
        L3_3 = tonumber
        L4_3 = L0_3[1]
        L3_3, L4_3 = L3_3(L4_3)
        L1_3(L2_3, L3_3, L4_3)
    end
    else
      L1_3 = TriggerServerEvent
      L2_3 = "fs-government:server:getExpiringPermits"
      L3_3 = 30
      L1_3(L2_3, L3_3)
    end
  end
  L6_2.onSelect = L7_2
  L7_2 = {}
  L7_2.title = "View Expired Permits"
  L7_2.description = "View all expired permits"
  L7_2.icon = "fas fa-times-circle"
  L7_2.iconColor = "#e74c3c"
  function L8_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getExpiredPermits"
    L0_3(L1_3)
  end
  L7_2.onSelect = L8_2
  L8_2 = {}
  L8_2.title = "Revoke Permit"
  L8_2.description = "Cancel existing permit"
  L8_2.icon = "fas fa-ban"
  function L9_2()
    local L0_3, L1_3
    L0_3 = OpenPermitRevocationMenu
    L0_3()
  end
  L8_2.onSelect = L9_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L0_2[4] = L4_2
  L0_2[5] = L5_2
  L0_2[6] = L6_2
  L0_2[7] = L7_2
  L0_2[8] = L8_2
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_permit_menu"
  L2_2.title = "\240\159\147\156 Permit Management"
  L2_2.options = L0_2
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_permit_menu"
  L1_2(L2_2)
end
OpenPermitManagementMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Issue New Permit"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "input"
  L3_2.label = "Permit Holder ID"
  L3_2.placeholder = "Player ID"
  L3_2.required = true
  L4_2 = {}
  L4_2.type = "select"
  L4_2.label = "Permit Type"
  L5_2 = {}
  L6_2 = {}
  L6_2.value = "building"
  L6_2.label = "Building Permit"
  L7_2 = {}
  L7_2.value = "event"
  L7_2.label = "Event Permit"
  L8_2 = {}
  L8_2.value = "business_operation"
  L8_2.label = "Business Operation"
  L9_2 = {}
  L9_2.value = "street_vendor"
  L9_2.label = "Street Vendor"
  L10_2 = {}
  L10_2.value = "public_gathering"
  L10_2.label = "Public Gathering"
  L11_2 = {}
  L11_2.value = "special_event"
  L11_2.label = "Special Event"
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  L5_2[3] = L8_2
  L5_2[4] = L9_2
  L5_2[5] = L10_2
  L5_2[6] = L11_2
  L4_2.options = L5_2
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "input"
  L5_2.label = "Description"
  L5_2.placeholder = "Permit details"
  L5_2.required = true
  L6_2 = {}
  L6_2.type = "number"
  L6_2.label = "Validity (days)"
  L6_2.placeholder = "90"
  L6_2.required = true
  L7_2 = {}
  L7_2.type = "number"
  L7_2.label = "Fee"
  L7_2.placeholder = "500"
  L7_2.required = true
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L2_2[4] = L6_2
  L2_2[5] = L7_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = tonumber
    L2_2 = L0_2[1]
    L1_2 = L1_2(L2_2)
    L2_2 = L0_2[2]
    L3_2 = L0_2[3]
    L4_2 = tonumber
    L5_2 = L0_2[4]
    L4_2 = L4_2(L5_2)
    L5_2 = tonumber
    L6_2 = L0_2[5]
    L5_2 = L5_2(L6_2)
    if L1_2 and L4_2 and L4_2 > 0 and L5_2 and L5_2 >= 0 then
      L6_2 = TriggerServerEvent
      L7_2 = "fs-government:server:issuePermit"
      L8_2 = L1_2
      L9_2 = L2_2
      L10_2 = L3_2
      L11_2 = L4_2
      L12_2 = L5_2
      L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
    else
      L6_2 = Framework
      L6_2 = L6_2.ShowNotification
      L7_2 = "Invalid input provided"
      L8_2 = "error"
      L6_2(L7_2, L8_2)
    end
  end
end
OpenPermitCreationMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Revoke Permit"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "input"
  L3_2.label = "Permit Number"
  L3_2.placeholder = "PER-XXXXX"
  L3_2.required = true
  L4_2 = {}
  L4_2.type = "input"
  L4_2.label = "Reason"
  L4_2.placeholder = "Reason for revocation"
  L4_2.required = true
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = L0_2[1]
    L2_2 = L0_2[2]
    L3_2 = TriggerServerEvent
    L4_2 = "fs-government:server:revokePermit"
    L5_2 = L1_2
    L6_2 = L2_2
    L3_2(L4_2, L5_2, L6_2)
  end
end
OpenPermitRevocationMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "Create New Law"
  L1_2.description = "Draft and propose new legislation"
  L1_2.icon = "fas fa-plus"
  function L2_2()
    local L0_3, L1_3
    L0_3 = OpenLawCreationMenu
    L0_3()
  end
  L1_2.onSelect = L2_2
  L2_2 = {}
  L2_2.title = "View Active Laws"
  L2_2.description = "Review current active city laws"
  L2_2.icon = "fas fa-book"
  function L3_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getActiveLaws"
    L0_3(L1_3)
  end
  L2_2.onSelect = L3_2
  L3_2 = {}
  L3_2.title = "Manage All Laws"
  L3_2.description = "View and manage all laws (including drafts)"
  L3_2.icon = "fas fa-cog"
  function L4_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getAllLaws"
    L0_3(L1_3)
  end
  L3_2.onSelect = L4_2
  L4_2 = {}
  L4_2.title = "Activate/Deactivate Law"
  L4_2.description = "Change law status"
  L4_2.icon = "fas fa-toggle-on"
  function L5_2()
    local L0_3, L1_3
    L0_3 = OpenLawStatusMenu
    L0_3()
  end
  L4_2.onSelect = L5_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L0_2[4] = L4_2
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_laws_menu"
  L2_2.title = "\226\154\150\239\184\143 Laws & Legislation"
  L2_2.options = L0_2
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_laws_menu"
  L1_2(L2_2)
end
OpenLawsMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Create New Law"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "input"
  L3_2.label = "Law Title"
  L3_2.placeholder = "Speed Limit Enforcement"
  L3_2.required = true
  L4_2 = {}
  L4_2.type = "textarea"
  L4_2.label = "Description"
  L4_2.placeholder = "Detailed law description"
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "textarea"
  L5_2.label = "Full Content"
  L5_2.placeholder = "Complete law text"
  L5_2.required = true
  L6_2 = {}
  L6_2.type = "number"
  L6_2.label = "Fine Amount"
  L6_2.placeholder = "1000"
  L6_2.required = true
  L7_2 = {}
  L7_2.type = "number"
  L7_2.label = "Jail Time (minutes)"
  L7_2.placeholder = "10"
  L7_2.required = true
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L2_2[4] = L6_2
  L2_2[5] = L7_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = L0_2[1]
    L2_2 = L0_2[2]
    L3_2 = L0_2[3]
    L4_2 = tonumber
    L5_2 = L0_2[4]
    L4_2 = L4_2(L5_2)
    L5_2 = tonumber
    L6_2 = L0_2[5]
    L5_2 = L5_2(L6_2)
    if L4_2 and L4_2 >= 0 and L5_2 and L5_2 >= 0 then
      L6_2 = TriggerServerEvent
      L7_2 = "fs-government:server:createLaw"
      L8_2 = L1_2
      L9_2 = L2_2
      L10_2 = L3_2
      L11_2 = L4_2
      L12_2 = L5_2
      L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
    else
      L6_2 = Framework
      L6_2 = L6_2.ShowNotification
      L7_2 = "Invalid penalty amounts"
      L8_2 = "error"
      L6_2(L7_2, L8_2)
    end
  end
end
OpenLawCreationMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Modify Law Status"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "input"
  L3_2.label = "Law ID"
  L3_2.placeholder = "Enter law ID number"
  L3_2.required = true
  L4_2 = {}
  L4_2.type = "select"
  L4_2.label = "New Status"
  L5_2 = {}
  L6_2 = {}
  L6_2.value = "active"
  L6_2.label = "Activate Law"
  L7_2 = {}
  L7_2.value = "inactive"
  L7_2.label = "Deactivate Law"
  L8_2 = {}
  L8_2.value = "pending"
  L8_2.label = "Set as Pending Review"
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  L5_2[3] = L8_2
  L4_2.options = L5_2
  L4_2.required = true
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = tonumber
    L2_2 = L0_2[1]
    L1_2 = L1_2(L2_2)
    L2_2 = L0_2[2]
    if L1_2 then
      L3_2 = TriggerServerEvent
      L4_2 = "fs-government:server:updateLawStatus"
      L5_2 = L1_2
      L6_2 = L2_2
      L3_2(L4_2, L5_2, L6_2)
    else
      L3_2 = Framework
      L3_2 = L3_2.ShowNotification
      L4_2 = "Invalid law ID"
      L5_2 = "error"
      L3_2(L4_2, L5_2)
    end
  end
end
OpenLawStatusMenu = L1_1
L1_1 = RegisterNetEvent
L2_1 = "fs-government:client:showActiveLaws"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = table
    L8_2 = L8_2.insert
    L9_2 = L1_2
    L10_2 = {}
    L11_2 = L7_2.title
    L10_2.title = L11_2
    L11_2 = "Fine: $"
    L12_2 = L7_2.fine_amount
    L13_2 = " | Jail: "
    L14_2 = L7_2.jail_time
    L15_2 = " min"
    L11_2 = L11_2 .. L12_2 .. L13_2 .. L14_2 .. L15_2
    L10_2.description = L11_2
    L10_2.icon = "fas fa-balance-scale"
    function L11_2()
      local L0_3, L1_3
      L0_3 = ShowLawDetails
      L1_3 = L7_2
      L0_3(L1_3)
    end
    L10_2.onSelect = L11_2
    L8_2(L9_2, L10_2)
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "active_laws_list"
  L4_2 = "\226\154\150\239\184\143 Active Laws ("
  L5_2 = #A0_2
  L6_2 = ")"
  L4_2 = L4_2 .. L5_2 .. L6_2
  L3_2.title = L4_2
  L3_2.menu = "government_laws_menu"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "active_laws_list"
  L2_2(L3_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "fs-government:client:showAllLaws"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = ""
    L9_2 = ""
    L10_2 = L7_2.status
    if "active" == L10_2 then
      L8_2 = "\226\156\133"
      L9_2 = "success"
    else
      L10_2 = L7_2.status
      if "draft" == L10_2 then
        L8_2 = "\240\159\147\157"
        L9_2 = "warning"
      else
        L8_2 = "\226\157\140"
        L9_2 = "error"
      end
    end
    L10_2 = table
    L10_2 = L10_2.insert
    L11_2 = L1_2
    L12_2 = {}
    L13_2 = L8_2
    L14_2 = " ["
    L15_2 = L7_2.id
    L16_2 = "] "
    L17_2 = L7_2.title
    L13_2 = L13_2 .. L14_2 .. L15_2 .. L16_2 .. L17_2
    L12_2.title = L13_2
    L13_2 = "Status: "
    L14_2 = FormatStatusText
    L15_2 = L7_2.status
    L14_2 = L14_2(L15_2)
    L15_2 = " | Fine: $"
    L16_2 = L7_2.fine_amount
    L17_2 = " | Jail: "
    L18_2 = L7_2.jail_time
    L19_2 = " min"
    L13_2 = L13_2 .. L14_2 .. L15_2 .. L16_2 .. L17_2 .. L18_2 .. L19_2
    L12_2.description = L13_2
    L12_2.icon = "fas fa-file-text"
    L12_2.iconColor = L9_2
    function L13_2()
      local L0_3, L1_3
      L0_3 = ShowLawManagementDetails
      L1_3 = L7_2
      L0_3(L1_3)
    end
    L12_2.onSelect = L13_2
    L10_2(L11_2, L12_2)
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "all_laws_list"
  L4_2 = "\240\159\151\130\239\184\143 All Laws - Management ("
  L5_2 = #A0_2
  L6_2 = ")"
  L4_2 = L4_2 .. L5_2 .. L6_2
  L3_2.title = L4_2
  L3_2.menu = "government_laws_menu"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "all_laws_list"
  L2_2(L3_2)
end
L1_1(L2_1, L3_1)
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = {}
  L2_2 = {}
  L2_2.title = "Law Information"
  L2_2.description = "View complete law details"
  L2_2.icon = "fas fa-info-circle"
  L2_2.disabled = true
  L3_2 = {}
  L4_2 = "Title: "
  L5_2 = A0_2.title
  L4_2 = L4_2 .. L5_2
  L3_2.title = L4_2
  L4_2 = A0_2.description
  L3_2.description = L4_2
  L3_2.icon = "fas fa-heading"
  L3_2.disabled = true
  L4_2 = {}
  L4_2.title = "Penalties"
  L5_2 = "Fine: $"
  L6_2 = A0_2.fine_amount
  L7_2 = " | Jail Time: "
  L8_2 = A0_2.jail_time
  L9_2 = " minutes"
  L5_2 = L5_2 .. L6_2 .. L7_2 .. L8_2 .. L9_2
  L4_2.description = L5_2
  L4_2.icon = "fas fa-gavel"
  L4_2.disabled = true
  L5_2 = {}
  L5_2.title = "Created"
  L6_2 = "Date: "
  L7_2 = A0_2.created_at
  L6_2 = L6_2 .. L7_2
  L5_2.description = L6_2
  L5_2.icon = "fas fa-calendar"
  L5_2.disabled = true
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L1_2[3] = L4_2
  L1_2[4] = L5_2
  L2_2 = A0_2.content
  if L2_2 then
    L2_2 = A0_2.content
    if "" ~= L2_2 then
      L2_2 = table
      L2_2 = L2_2.insert
      L3_2 = L1_2
      L4_2 = 2
      L5_2 = {}
      L5_2.title = "Full Law Text"
      L6_2 = A0_2.content
      L5_2.description = L6_2
      L5_2.icon = "fas fa-scroll"
      L5_2.disabled = true
      L2_2(L3_2, L4_2, L5_2)
    end
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L4_2 = "law_details_"
  L5_2 = A0_2.id
  L4_2 = L4_2 .. L5_2
  L3_2.id = L4_2
  L4_2 = "\226\154\150\239\184\143 Law Details - "
  L5_2 = A0_2.title
  L4_2 = L4_2 .. L5_2
  L3_2.title = L4_2
  L3_2.menu = "active_laws_list"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "law_details_"
  L4_2 = A0_2.id
  L3_2 = L3_2 .. L4_2
  L2_2(L3_2)
end
ShowLawDetails = L1_1
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = {}
  L2_2 = {}
  L2_2.title = "Law Information"
  L3_2 = "ID: "
  L4_2 = A0_2.id
  L5_2 = " | Status: "
  L6_2 = FormatStatusText
  L7_2 = A0_2.status
  L6_2 = L6_2(L7_2)
  L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
  L2_2.description = L3_2
  L2_2.icon = "fas fa-info-circle"
  L2_2.disabled = true
  L3_2 = {}
  L4_2 = "Title: "
  L5_2 = A0_2.title
  L4_2 = L4_2 .. L5_2
  L3_2.title = L4_2
  L4_2 = A0_2.description
  L3_2.description = L4_2
  L3_2.icon = "fas fa-heading"
  L3_2.disabled = true
  L4_2 = {}
  L4_2.title = "Penalties"
  L5_2 = "Fine: $"
  L6_2 = A0_2.fine_amount
  L7_2 = " | Jail Time: "
  L8_2 = A0_2.jail_time
  L9_2 = " minutes"
  L5_2 = L5_2 .. L6_2 .. L7_2 .. L8_2 .. L9_2
  L4_2.description = L5_2
  L4_2.icon = "fas fa-gavel"
  L4_2.disabled = true
  L5_2 = {}
  L5_2.title = "Created"
  L6_2 = "Date: "
  L7_2 = A0_2.created_at
  L6_2 = L6_2 .. L7_2
  L5_2.description = L6_2
  L5_2.icon = "fas fa-calendar"
  L5_2.disabled = true
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L1_2[3] = L4_2
  L1_2[4] = L5_2
  L2_2 = A0_2.content
  if L2_2 then
    L2_2 = A0_2.content
    if "" ~= L2_2 then
      L2_2 = table
      L2_2 = L2_2.insert
      L3_2 = L1_2
      L4_2 = 2
      L5_2 = {}
      L5_2.title = "Full Law Text"
      L6_2 = A0_2.content
      L5_2.description = L6_2
      L5_2.icon = "fas fa-scroll"
      L5_2.disabled = true
      L2_2(L3_2, L4_2, L5_2)
    end
  end
  L2_2 = A0_2.status
  if "draft" == L2_2 then
    L2_2 = table
    L2_2 = L2_2.insert
    L3_2 = L1_2
    L4_2 = {}
    L4_2.title = "Activate Law"
    L4_2.description = "Make this law active and notify all players"
    L4_2.icon = "fas fa-check-circle"
    L4_2.iconColor = "success"
    function L5_2()
      local L0_3, L1_3, L2_3, L3_3
      L0_3 = TriggerServerEvent
      L1_3 = "fs-government:server:updateLawStatus"
      L2_3 = A0_2.id
      L3_3 = "active"
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = lib
      L0_3 = L0_3.hideContext
      L0_3()
    end
    L4_2.onSelect = L5_2
    L2_2(L3_2, L4_2)
  else
    L2_2 = A0_2.status
    if "active" == L2_2 then
      L2_2 = table
      L2_2 = L2_2.insert
      L3_2 = L1_2
      L4_2 = {}
      L4_2.title = "Deactivate Law"
      L4_2.description = "Set this law as inactive"
      L4_2.icon = "fas fa-times-circle"
      L4_2.iconColor = "error"
      function L5_2()
        local L0_3, L1_3, L2_3, L3_3
        L0_3 = TriggerServerEvent
        L1_3 = "fs-government:server:updateLawStatus"
        L2_3 = A0_2.id
        L3_3 = "inactive"
        L0_3(L1_3, L2_3, L3_3)
        L0_3 = lib
        L0_3 = L0_3.hideContext
        L0_3()
      end
      L4_2.onSelect = L5_2
      L2_2(L3_2, L4_2)
    else
      L2_2 = table
      L2_2 = L2_2.insert
      L3_2 = L1_2
      L4_2 = {}
      L4_2.title = "Reactivate Law"
      L4_2.description = "Make this law active again"
      L4_2.icon = "fas fa-redo"
      L4_2.iconColor = "warning"
      function L5_2()
        local L0_3, L1_3, L2_3, L3_3
        L0_3 = TriggerServerEvent
        L1_3 = "fs-government:server:updateLawStatus"
        L2_3 = A0_2.id
        L3_3 = "active"
        L0_3(L1_3, L2_3, L3_3)
        L0_3 = lib
        L0_3 = L0_3.hideContext
        L0_3()
      end
      L4_2.onSelect = L5_2
      L2_2(L3_2, L4_2)
    end
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L4_2 = "law_management_"
  L5_2 = A0_2.id
  L4_2 = L4_2 .. L5_2
  L3_2.id = L4_2
  L4_2 = "\240\159\155\160\239\184\143 Manage Law - "
  L5_2 = A0_2.title
  L4_2 = L4_2 .. L5_2
  L3_2.title = L4_2
  L3_2.menu = "all_laws_list"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "law_management_"
  L4_2 = A0_2.id
  L3_2 = L3_2 .. L4_2
  L2_2(L3_2)
end
ShowLawManagementDetails = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "Start New Election"
  L1_2.description = "Begin a new voting process"
  L1_2.icon = "fas fa-vote-yea"
  function L2_2()
    local L0_3, L1_3
    L0_3 = OpenElectionCreationMenu
    L0_3()
  end
  L1_2.onSelect = L2_2
  L2_2 = {}
  L2_2.title = "Register as Candidate"
  L2_2.description = "Apply to run in current election"
  L2_2.icon = "fas fa-user-tie"
  function L3_2()
    local L0_3, L1_3
    L0_3 = OpenCandidateRegistrationMenu
    L0_3()
  end
  L2_2.onSelect = L3_2
  L3_2 = {}
  L3_2.title = "View Election Status"
  L3_2.description = "Check current election progress"
  L3_2.icon = "fas fa-chart-bar"
  function L4_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getElectionStatus"
    L0_3(L1_3)
  end
  L3_2.onSelect = L4_2
  L4_2 = {}
  L4_2.title = "View Candidates"
  L4_2.description = "See all registered candidates"
  L4_2.icon = "fas fa-users"
  function L5_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getCandidates"
    L0_3(L1_3)
  end
  L4_2.onSelect = L5_2
  L5_2 = {}
  L5_2.title = "End Current Election"
  L5_2.description = "Manually end active election"
  L5_2.icon = "fas fa-stop"
  L5_2.iconColor = "#e74c3c"
  function L6_2()
    local L0_3, L1_3
    L0_3 = OpenElectionEndMenu
    L0_3()
  end
  L5_2.onSelect = L6_2
  L6_2 = {}
  L6_2.title = "Election Results"
  L6_2.description = "View past election results"
  L6_2.icon = "fas fa-trophy"
  function L7_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getElectionResults"
    L0_3(L1_3)
  end
  L6_2.onSelect = L7_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L0_2[4] = L4_2
  L0_2[5] = L5_2
  L0_2[6] = L6_2
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_elections_menu"
  L2_2.title = "\240\159\151\179\239\184\143 Election Management"
  L2_2.options = L0_2
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_elections_menu"
  L1_2(L2_2)
end
OpenElectionsMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Start New Election"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "input"
  L3_2.label = "Election Title"
  L3_2.placeholder = "City Mayor Election 2024"
  L3_2.required = true
  L4_2 = {}
  L4_2.type = "input"
  L4_2.label = "Position"
  L4_2.placeholder = "Mayor"
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "number"
  L5_2.label = "Duration Value"
  L5_2.placeholder = "7"
  L5_2.required = true
  L6_2 = {}
  L6_2.type = "select"
  L6_2.label = "Duration Unit"
  L7_2 = {}
  L8_2 = {}
  L8_2.value = "minutes"
  L8_2.label = "Minutes"
  L9_2 = {}
  L9_2.value = "hours"
  L9_2.label = "Hours"
  L10_2 = {}
  L10_2.value = "days"
  L10_2.label = "Days"
  L7_2[1] = L8_2
  L7_2[2] = L9_2
  L7_2[3] = L10_2
  L6_2.options = L7_2
  L6_2.required = true
  L7_2 = {}
  L7_2.type = "number"
  L7_2.label = "Registration Fee"
  L7_2.placeholder = "10000"
  L7_2.required = true
  L8_2 = {}
  L8_2.type = "number"
  L8_2.label = "Min Level Required"
  L8_2.placeholder = "5"
  L8_2.required = true
  L9_2 = {}
  L9_2.type = "number"
  L9_2.label = "Min Playtime (hours)"
  L9_2.placeholder = "168"
  L9_2.required = true
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L2_2[4] = L6_2
  L2_2[5] = L7_2
  L2_2[6] = L8_2
  L2_2[7] = L9_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = L0_2[1]
    L2_2 = L0_2[2]
    L3_2 = tonumber
    L4_2 = L0_2[3]
    L3_2 = L3_2(L4_2)
    L4_2 = L0_2[4]
    L5_2 = tonumber
    L6_2 = L0_2[5]
    L5_2 = L5_2(L6_2)
    L6_2 = tonumber
    L7_2 = L0_2[6]
    L6_2 = L6_2(L7_2)
    L7_2 = tonumber
    L8_2 = L0_2[7]
    L7_2 = L7_2(L8_2)
    if L3_2 and L3_2 > 0 and L5_2 and L5_2 >= 0 then
      L8_2 = TriggerServerEvent
      L9_2 = "fs-government:server:startElection"
      L10_2 = L1_2
      L11_2 = L2_2
      L12_2 = L3_2
      L13_2 = L4_2
      L14_2 = L5_2
      L15_2 = L6_2
      L16_2 = L7_2
      L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
    else
      L8_2 = Framework
      L8_2 = L8_2.ShowNotification
      L9_2 = "Invalid input provided"
      L10_2 = "error"
      L8_2(L9_2, L10_2)
    end
  end
end
OpenElectionCreationMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Register as Candidate"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "input"
  L3_2.label = "Campaign Name"
  L3_2.placeholder = "Your campaign slogan"
  L3_2.required = true
  L4_2 = {}
  L4_2.type = "textarea"
  L4_2.label = "Platform/Agenda"
  L4_2.placeholder = "What you plan to accomplish"
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "input"
  L5_2.label = "Party Affiliation"
  L5_2.placeholder = "Independent, Democratic, etc."
  L6_2 = {}
  L6_2.type = "textarea"
  L6_2.label = "Biography"
  L6_2.placeholder = "Brief background about yourself"
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L2_2[4] = L6_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = L0_2[1]
    L2_2 = L0_2[2]
    L3_2 = L0_2[3]
    if not L3_2 then
      L3_2 = "Independent"
    end
    L4_2 = L0_2[4]
    if not L4_2 then
      L4_2 = ""
    end
    L5_2 = TriggerServerEvent
    L6_2 = "fs-government:server:registerCandidate"
    L7_2 = L1_2
    L8_2 = L2_2
    L9_2 = L3_2
    L10_2 = L4_2
    L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
  end
end
OpenCandidateRegistrationMenu = L1_1
function L1_1()
  local L0_2, L1_2, L2_2
  L0_2 = lib
  L0_2 = L0_2.alertDialog
  L1_2 = {}
  L1_2.header = "End Current Election"
  L1_2.content = "Are you sure you want to manually end the current election? This action cannot be undone and will immediately close voting."
  L1_2.centered = true
  L1_2.cancel = true
  L2_2 = {}
  L2_2.cancel = "Cancel"
  L2_2.confirm = "End Election"
  L1_2.labels = L2_2
  L0_2 = L0_2(L1_2)
  if "confirm" == L0_2 then
    L1_2 = TriggerServerEvent
    L2_2 = "fs-government:server:endElection"
    L1_2(L2_2)
  end
end
OpenElectionEndMenu = L1_1
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = tostring
  L2_2 = math
  L2_2 = L2_2.floor
  L3_2 = A0_2 or L3_2
  if not A0_2 then
    L3_2 = 0
  end
  L2_2, L3_2, L4_2, L5_2, L6_2 = L2_2(L3_2)
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  L2_2 = nil
  while true do
    L3_2 = string
    L3_2 = L3_2.gsub
    L4_2 = L1_2
    L5_2 = "^(-?%d+)(%d%d%d)"
    L6_2 = "%1,%2"
    L3_2, L4_2 = L3_2(L4_2, L5_2, L6_2)
    L2_2 = L4_2
    L1_2 = L3_2
    if 0 == L2_2 then
      break
    end
  end
  L3_2 = "$"
  L4_2 = L1_2
  L3_2 = L3_2 .. L4_2
  return L3_2
end
L2_1 = RegisterNetEvent
L3_1 = "fs-government:client:receiveFundsBalance"
function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = L1_1
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  L2_2 = {}
  L3_2 = {}
  L4_2 = "Available Funds: "
  L5_2 = L1_2
  L4_2 = L4_2 .. L5_2
  L3_2.title = L4_2
  L3_2.description = "Current government treasury balance"
  L3_2.icon = "fas fa-dollar-sign"
  L3_2.iconColor = "#2ecc71"
  L3_2.disabled = true
  L4_2 = {}
  L4_2.title = "Employee Management"
  L4_2.description = "Hire, fire, and promote employees"
  L4_2.icon = "fas fa-users"
  function L5_2()
    local L0_3, L1_3
    L0_3 = OpenEmployeeMenu
    L0_3()
  end
  L4_2.onSelect = L5_2
  L5_2 = {}
  L5_2.title = "View Online Staff"
  L5_2.description = "See who is currently on duty"
  L5_2.icon = "fas fa-user-check"
  function L6_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getOnlineStaff"
    L0_3(L1_3)
  end
  L5_2.onSelect = L6_2
  L6_2 = {}
  L6_2.title = "Government Finances"
  L6_2.description = "View financial information"
  L6_2.icon = "fas fa-chart-line"
  function L7_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getFinances"
    L0_3(L1_3)
  end
  L6_2.onSelect = L7_2
  L7_2 = {}
  L7_2.title = "Withdraw Funds"
  L7_2.description = "Withdraw money from government treasury"
  L7_2.icon = "fas fa-money-bill-wave"
  L7_2.iconColor = "#e74c3c"
  function L8_2()
    local L0_3, L1_3
    L0_3 = OpenWithdrawMenu
    L0_3()
  end
  L7_2.onSelect = L8_2
  L8_2 = {}
  L8_2.title = "Deposit Funds"
  L8_2.description = "Deposit money to government treasury"
  L8_2.icon = "fas fa-piggy-bank"
  L8_2.iconColor = "#27ae60"
  function L9_2()
    local L0_3, L1_3
    L0_3 = OpenDepositMenu
    L0_3()
  end
  L8_2.onSelect = L9_2
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L2_2[4] = L6_2
  L2_2[5] = L7_2
  L2_2[6] = L8_2
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "government_boss_menu"
  L4_2.title = "Boss Actions"
  L4_2.options = L2_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.hideContext
  L4_2 = false
  L3_2(L4_2)
  L3_2 = Wait
  L4_2 = 50
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "government_boss_menu"
  L3_2(L4_2)
end
L2_1(L3_1, L4_1)
L2_1 = RegisterNetEvent
L3_1 = "fs-government:client:showAppointments"
function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L7_2.formatted_preferred
    if not L8_2 then
      L8_2 = "Unknown Date"
    end
    L9_2 = table
    L9_2 = L9_2.insert
    L10_2 = L1_2
    L11_2 = {}
    L12_2 = L7_2.citizen_name
    L13_2 = " - "
    L14_2 = L7_2.appointment_type
    L12_2 = L12_2 .. L13_2 .. L14_2
    L11_2.title = L12_2
    L12_2 = "Reason: "
    L13_2 = L7_2.reason
    L14_2 = [[

Date: ]]
    L15_2 = L8_2
    L16_2 = [[

Status: ]]
    L17_2 = L7_2.status
    L12_2 = L12_2 .. L13_2 .. L14_2 .. L15_2 .. L16_2 .. L17_2
    L11_2.description = L12_2
    L11_2.icon = "fas fa-calendar-alt"
    function L12_2()
      local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
      L0_3 = lib
      L0_3 = L0_3.inputDialog
      L1_3 = "Manage Appointment"
      L2_3 = {}
      L3_3 = {}
      L3_3.type = "select"
      L3_3.label = "Action"
      L4_3 = {}
      L5_3 = {}
      L5_3.value = "approve"
      L5_3.label = "Approve"
      L6_3 = {}
      L6_3.value = "reject"
      L6_3.label = "Reject"
      L7_3 = {}
      L7_3.value = "completed"
      L7_3.label = "Mark Complete"
      L4_3[1] = L5_3
      L4_3[2] = L6_3
      L4_3[3] = L7_3
      L3_3.options = L4_3
      L4_3 = {}
      L4_3.type = "textarea"
      L4_3.label = "Notes (Optional)"
      L2_3[1] = L3_3
      L2_3[2] = L4_3
      L0_3 = L0_3(L1_3, L2_3)
      if L0_3 then
        L1_3 = TriggerServerEvent
        L2_3 = "fs-government:server:manageAppointment"
        L3_3 = L7_2.id
        L4_3 = L0_3[1]
        L5_3 = L0_3[2]
        L1_3(L2_3, L3_3, L4_3, L5_3)
      end
    end
    L11_2.onSelect = L12_2
    L9_2(L10_2, L11_2)
  end
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L4_2.title = "Close"
  L4_2.description = "Close appointments list"
  L4_2.icon = "fas fa-times"
  L4_2.iconColor = "#e74c3c"
  function L5_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L4_2.onSelect = L5_2
  L2_2(L3_2, L4_2)
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "government_appointments_list"
  L4_2 = "Pending Appointments ("
  L5_2 = #A0_2
  L6_2 = ")"
  L4_2 = L4_2 .. L5_2 .. L6_2
  L3_2.title = L4_2
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "government_appointments_list"
  L2_2(L3_2)
end
L2_1(L3_1, L4_1)
L2_1 = RegisterNetEvent
L3_1 = "fs-government:client:showAppointmentHistory"
function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L7_2.formatted_created
    if not L8_2 then
      L8_2 = "Unknown Date"
    end
    L9_2 = L7_2.formatted_updated
    if not L9_2 then
      L9_2 = "Unknown Date"
    end
    L10_2 = L7_2.formatted_preferred
    if not L10_2 then
      L10_2 = "Not specified"
    end
    L11_2 = "#27ae60"
    L12_2 = L7_2.status
    if "approved" == L12_2 then
      L11_2 = "#3498db"
    else
      L12_2 = L7_2.status
      if "rejected" == L12_2 then
        L11_2 = "#e74c3c"
      end
    end
    L12_2 = table
    L12_2 = L12_2.insert
    L13_2 = L1_2
    L14_2 = {}
    L15_2 = L7_2.citizen_name
    L16_2 = " - "
    L17_2 = L7_2.appointment_type
    L15_2 = L15_2 .. L16_2 .. L17_2
    L14_2.title = L15_2
    L15_2 = "Reason: "
    L16_2 = L7_2.reason
    L17_2 = [[

Preferred Date: ]]
    L18_2 = L10_2
    L19_2 = [[

Status: ]]
    L20_2 = FormatStatusText
    L21_2 = L7_2.status
    L20_2 = L20_2(L21_2)
    L21_2 = [[

Created: ]]
    L22_2 = L8_2
    L23_2 = L7_2.notes
    if L23_2 then
      L23_2 = [[

Notes: ]]
      L24_2 = L7_2.notes
      L23_2 = L23_2 .. L24_2
      if L23_2 then
        goto lbl_58
      end
    end
    L23_2 = ""
    ::lbl_58::
    L15_2 = L15_2 .. L16_2 .. L17_2 .. L18_2 .. L19_2 .. L20_2 .. L21_2 .. L22_2 .. L23_2
    L14_2.description = L15_2
    L14_2.icon = "fas fa-history"
    L14_2.iconColor = L11_2
    L15_2 = {}
    L16_2 = {}
    L16_2.label = "ID"
    L17_2 = L7_2.id
    L16_2.value = L17_2
    L17_2 = {}
    L17_2.label = "Status"
    L18_2 = FormatStatusText
    L19_2 = L7_2.status
    L18_2 = L18_2(L19_2)
    L17_2.value = L18_2
    L18_2 = {}
    L18_2.label = "Created"
    L18_2.value = L8_2
    L19_2 = {}
    L19_2.label = "Updated"
    L19_2.value = L9_2
    L15_2[1] = L16_2
    L15_2[2] = L17_2
    L15_2[3] = L18_2
    L15_2[4] = L19_2
    L14_2.metadata = L15_2
    L12_2(L13_2, L14_2)
  end
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L4_2.title = "Close"
  L4_2.description = "Close appointment history"
  L4_2.icon = "fas fa-times"
  L4_2.iconColor = "#e74c3c"
  function L5_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L4_2.onSelect = L5_2
  L2_2(L3_2, L4_2)
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "government_appointment_history"
  L4_2 = "Appointment History ("
  L5_2 = #A0_2
  L6_2 = ")"
  L4_2 = L4_2 .. L5_2 .. L6_2
  L3_2.title = L4_2
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "government_appointment_history"
  L2_2(L3_2)
end
L2_1(L3_1, L4_1)
L2_1 = RegisterNetEvent
L3_1 = "fs-government:client:showPlayerAppointments"
function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L7_2.formatted_created
    if not L8_2 then
      L8_2 = "Unknown Date"
    end
    L9_2 = L7_2.formatted_preferred
    if not L9_2 then
      L9_2 = "Not specified"
    end
    L10_2 = "#f39c12"
    L11_2 = FormatStatusText
    L12_2 = L7_2.status
    L11_2 = L11_2(L12_2)
    L12_2 = L7_2.status
    if "approved" == L12_2 then
      L10_2 = "#3498db"
    else
      L12_2 = L7_2.status
      if "completed" == L12_2 then
        L10_2 = "#27ae60"
      else
        L12_2 = L7_2.status
        if "rejected" == L12_2 then
          L10_2 = "#e74c3c"
        end
      end
    end
    L12_2 = table
    L12_2 = L12_2.insert
    L13_2 = L1_2
    L14_2 = {}
    L15_2 = L7_2.appointment_type
    L16_2 = " - "
    L17_2 = L11_2
    L15_2 = L15_2 .. L16_2 .. L17_2
    L14_2.title = L15_2
    L15_2 = "Reason: "
    L16_2 = L7_2.reason
    L17_2 = [[

Preferred Date: ]]
    L18_2 = L9_2
    L19_2 = [[

Created: ]]
    L20_2 = L8_2
    L21_2 = L7_2.notes
    if L21_2 then
      L21_2 = [[

Notes: ]]
      L22_2 = L7_2.notes
      L21_2 = L21_2 .. L22_2
      if L21_2 then
        goto lbl_58
      end
    end
    L21_2 = ""
    ::lbl_58::
    L15_2 = L15_2 .. L16_2 .. L17_2 .. L18_2 .. L19_2 .. L20_2 .. L21_2
    L14_2.description = L15_2
    L14_2.icon = "fas fa-calendar-check"
    L14_2.iconColor = L10_2
    L15_2 = {}
    L16_2 = {}
    L16_2.label = "Status"
    L16_2.value = L11_2
    L17_2 = {}
    L17_2.label = "Type"
    L18_2 = L7_2.appointment_type
    L17_2.value = L18_2
    L18_2 = {}
    L18_2.label = "Created"
    L18_2.value = L8_2
    L19_2 = {}
    L19_2.label = "Assigned To"
    L20_2 = L7_2.assigned_name
    if not L20_2 then
      L20_2 = "Not assigned"
    end
    L19_2.value = L20_2
    L15_2[1] = L16_2
    L15_2[2] = L17_2
    L15_2[3] = L18_2
    L15_2[4] = L19_2
    L14_2.metadata = L15_2
    L12_2(L13_2, L14_2)
  end
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L4_2.title = "Close"
  L4_2.description = "Close appointments list"
  L4_2.icon = "fas fa-times"
  L4_2.iconColor = "#95a5a6"
  function L5_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L4_2.onSelect = L5_2
  L2_2(L3_2, L4_2)
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "player_appointments_list"
  L4_2 = "My Appointments ("
  L5_2 = #A0_2
  L6_2 = ")"
  L4_2 = L4_2 .. L5_2 .. L6_2
  L3_2.title = L4_2
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "player_appointments_list"
  L2_2(L3_2)
end
L2_1(L3_1, L4_1)
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  if not A0_2 or "" == A0_2 then
    L1_2 = nil
    return L1_2
  end
  L1_2 = type
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if "string" == L1_2 then
    L2_2 = A0_2
    L1_2 = A0_2.gsub
    L3_2 = "T"
    L4_2 = " "
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    L2_2 = L1_2
    L1_2 = L1_2.gsub
    L3_2 = "%.%d+Z?"
    L4_2 = ""
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    L2_2 = L1_2
    L1_2 = L1_2.gsub
    L3_2 = "Z"
    L4_2 = ""
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    L2_2 = L1_2
    L1_2 = L1_2.gsub
    L3_2 = "%+%d%d:%d%d"
    L4_2 = ""
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    L2_2 = L1_2 or L2_2
    if "" == L1_2 or not L1_2 then
      L2_2 = nil
    end
    return L2_2
  end
  L1_2 = nil
  return L1_2
end
L3_1 = RegisterNetEvent
L4_1 = "fs-government:client:showSubsidies"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2
  L1_2 = Config
  L1_2 = L1_2.Debug
  if L1_2 and A0_2 then
    L1_2 = #A0_2
    if L1_2 > 0 then
      L1_2 = Utils
      L1_2 = L1_2.DebugPrint
      L2_2 = "Subsidy date format check:"
      L1_2(L2_2)
      L1_2 = Utils
      L1_2 = L1_2.DebugPrint
      L2_2 = "created_at type:"
      L3_2 = type
      L4_2 = A0_2[1]
      L4_2 = L4_2.created_at
      L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2 = L3_2(L4_2)
      L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2)
      L1_2 = Utils
      L1_2 = L1_2.DebugPrint
      L2_2 = "created_at value:"
      L3_2 = A0_2[1]
      L3_2 = L3_2.created_at
      L1_2(L2_2, L3_2)
    end
  end
  L1_2 = {}
  L2_2 = #A0_2
  if 0 == L2_2 then
    L2_2 = table
    L2_2 = L2_2.insert
    L3_2 = L1_2
    L4_2 = {}
    L4_2.title = "No Subsidies Found"
    L4_2.description = "There are currently no subsidies in the system"
    L4_2.icon = "fas fa-info-circle"
    L4_2.disabled = true
    L2_2(L3_2, L4_2)
  else
    L2_2 = ipairs
    L3_2 = A0_2
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = "\240\159\148\132"
      L9_2 = "#f39c12"
      L10_2 = L7_2.status
      if "paid" == L10_2 then
        L8_2 = "\226\156\133"
        L9_2 = "#27ae60"
      else
        L10_2 = L7_2.status
        if "approved" == L10_2 then
          L8_2 = "\226\143\179"
          L9_2 = "#3498db"
        else
          L10_2 = L7_2.status
          if "rejected" == L10_2 then
            L8_2 = "\226\157\140"
            L9_2 = "#e74c3c"
          else
            L10_2 = L7_2.status
            if "cancelled" == L10_2 then
              L8_2 = "\240\159\154\171"
              L9_2 = "#95a5a6"
            end
          end
        end
      end
      L10_2 = L7_2.formatted_created_at
      if not L10_2 then
        L10_2 = Utils
        L10_2 = L10_2.FormatDate
        L11_2 = L7_2.created_at
        L10_2 = L10_2(L11_2)
        if not L10_2 then
          L10_2 = "Unknown Date"
        end
      end
      L11_2 = table
      L11_2 = L11_2.insert
      L12_2 = L1_2
      L13_2 = {}
      L14_2 = L8_2
      L15_2 = " [ID: "
      L16_2 = L7_2.id
      L17_2 = "] "
      L18_2 = L7_2.subsidy_type
      L14_2 = L14_2 .. L15_2 .. L16_2 .. L17_2 .. L18_2
      L13_2.title = L14_2
      L14_2 = "Recipient: "
      L15_2 = L7_2.recipient_name
      L16_2 = [[

Amount: ]]
      L17_2 = Utils
      L17_2 = L17_2.FormatMoney
      L18_2 = L7_2.amount
      L17_2 = L17_2(L18_2)
      L18_2 = [[

Status: ]]
      L19_2 = FormatStatusText
      L20_2 = L7_2.status
      L19_2 = L19_2(L20_2)
      L20_2 = [[

Date: ]]
      L21_2 = L10_2
      L22_2 = L7_2.description
      if L22_2 then
        L22_2 = [[

Description: ]]
        L23_2 = L7_2.description
        L22_2 = L22_2 .. L23_2
        if L22_2 then
          goto lbl_117
        end
      end
      L22_2 = ""
      ::lbl_117::
      L14_2 = L14_2 .. L15_2 .. L16_2 .. L17_2 .. L18_2 .. L19_2 .. L20_2 .. L21_2 .. L22_2
      L13_2.description = L14_2
      L13_2.icon = "fas fa-hand-holding-usd"
      L13_2.iconColor = L9_2
      L14_2 = {}
      L15_2 = {}
      L15_2.label = "ID"
      L16_2 = L7_2.id
      L15_2.value = L16_2
      L16_2 = {}
      L16_2.label = "Type"
      L17_2 = L7_2.subsidy_type
      L16_2.value = L17_2
      L17_2 = {}
      L17_2.label = "Recipient"
      L18_2 = L7_2.recipient_name
      L17_2.value = L18_2
      L18_2 = {}
      L18_2.label = "Amount"
      L19_2 = Utils
      L19_2 = L19_2.FormatMoney
      L20_2 = L7_2.amount
      L19_2 = L19_2(L20_2)
      L18_2.value = L19_2
      L19_2 = {}
      L19_2.label = "Status"
      L20_2 = FormatStatusText
      L21_2 = L7_2.status
      L20_2 = L20_2(L21_2)
      L19_2.value = L20_2
      L20_2 = {}
      L20_2.label = "Created"
      L20_2.value = L10_2
      L14_2[1] = L15_2
      L14_2[2] = L16_2
      L14_2[3] = L17_2
      L14_2[4] = L18_2
      L14_2[5] = L19_2
      L14_2[6] = L20_2
      L13_2.metadata = L14_2
      function L14_2()
        local L0_3, L1_3
        L0_3 = ShowSubsidyDetails
        L1_3 = L7_2
        L0_3(L1_3)
      end
      L13_2.onSelect = L14_2
      L11_2(L12_2, L13_2)
    end
  end
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L4_2.title = "Close"
  L4_2.description = "Close subsidies list"
  L4_2.icon = "fas fa-times"
  L4_2.iconColor = "#e74c3c"
  function L5_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L4_2.onSelect = L5_2
  L2_2(L3_2, L4_2)
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "government_subsidies_list"
  L4_2 = "\240\159\146\176 Government Subsidies ("
  L5_2 = #A0_2
  L6_2 = ")"
  L4_2 = L4_2 .. L5_2 .. L6_2
  L3_2.title = L4_2
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "government_subsidies_list"
  L2_2(L3_2)
end
L3_1(L4_1, L5_1)
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = {}
  L2_2 = {}
  L2_2.title = "Subsidy Information"
  L3_2 = "ID: "
  L4_2 = A0_2.id
  L5_2 = " | Status: "
  L6_2 = FormatStatusText
  L7_2 = A0_2.status
  L6_2 = L6_2(L7_2)
  L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
  L2_2.description = L3_2
  L2_2.icon = "fas fa-info-circle"
  L2_2.disabled = true
  L3_2 = {}
  L4_2 = "Type: "
  L5_2 = A0_2.subsidy_type
  L4_2 = L4_2 .. L5_2
  L3_2.title = L4_2
  L3_2.description = "Category of financial assistance"
  L3_2.icon = "fas fa-tag"
  L3_2.disabled = true
  L4_2 = {}
  L5_2 = "Recipient: "
  L6_2 = A0_2.recipient_name
  L5_2 = L5_2 .. L6_2
  L4_2.title = L5_2
  L5_2 = "Identifier: "
  L6_2 = A0_2.recipient_identifier
  L5_2 = L5_2 .. L6_2
  L4_2.description = L5_2
  L4_2.icon = "fas fa-user"
  L4_2.disabled = true
  L5_2 = {}
  L6_2 = "Amount: "
  L7_2 = Utils
  L7_2 = L7_2.FormatMoney
  L8_2 = A0_2.amount
  L7_2 = L7_2(L8_2)
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.description = "Financial assistance provided"
  L5_2.icon = "fas fa-dollar-sign"
  L5_2.disabled = true
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L1_2[3] = L4_2
  L1_2[4] = L5_2
  L2_2 = A0_2.description
  if L2_2 then
    L2_2 = A0_2.description
    if "" ~= L2_2 then
      L2_2 = table
      L2_2 = L2_2.insert
      L3_2 = L1_2
      L4_2 = {}
      L4_2.title = "Description"
      L5_2 = A0_2.description
      L4_2.description = L5_2
      L4_2.icon = "fas fa-file-text"
      L4_2.disabled = true
      L2_2(L3_2, L4_2)
    end
  end
  L2_2 = A0_2.duration_days
  if L2_2 then
    L2_2 = table
    L2_2 = L2_2.insert
    L3_2 = L1_2
    L4_2 = {}
    L5_2 = "Duration: "
    L6_2 = A0_2.duration_days
    L7_2 = " days"
    L5_2 = L5_2 .. L6_2 .. L7_2
    L4_2.title = L5_2
    L4_2.description = "Length of subsidy assistance"
    L4_2.icon = "fas fa-calendar-alt"
    L4_2.disabled = true
    L2_2(L3_2, L4_2)
  end
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L5_2 = "Status: "
  L6_2 = FormatStatusText
  L7_2 = A0_2.status
  L6_2 = L6_2(L7_2)
  L5_2 = L5_2 .. L6_2
  L4_2.title = L5_2
  L4_2.description = "Current status of the subsidy"
  L5_2 = A0_2.status
  if "paid" == L5_2 then
    L5_2 = "fas fa-check-circle"
    if L5_2 then
      goto lbl_109
    end
  end
  L5_2 = A0_2.status
  if "approved" == L5_2 then
    L5_2 = "fas fa-clock"
    if L5_2 then
      goto lbl_109
    end
  end
  L5_2 = "fas fa-times-circle"
  ::lbl_109::
  L4_2.icon = L5_2
  L5_2 = A0_2.status
  if "paid" == L5_2 then
    L5_2 = "#27ae60"
    if L5_2 then
      goto lbl_123
    end
  end
  L5_2 = A0_2.status
  if "approved" == L5_2 then
    L5_2 = "#3498db"
    if L5_2 then
      goto lbl_123
    end
  end
  L5_2 = "#e74c3c"
  ::lbl_123::
  L4_2.iconColor = L5_2
  L4_2.disabled = true
  L2_2(L3_2, L4_2)
  L2_2 = A0_2.formatted_created_at
  if not L2_2 then
    L2_2 = Utils
    L2_2 = L2_2.FormatDate
    L3_2 = A0_2.created_at
    L2_2 = L2_2(L3_2)
    if not L2_2 then
      L2_2 = "Unknown Date"
    end
  end
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L1_2
  L5_2 = {}
  L6_2 = "Created: "
  L7_2 = L2_2
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.description = "Date when subsidy was created"
  L5_2.icon = "fas fa-calendar"
  L5_2.disabled = true
  L3_2(L4_2, L5_2)
  L3_2 = A0_2.approved_by
  if L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L1_2
    L5_2 = {}
    L6_2 = "Approved by: "
    L7_2 = A0_2.approved_by
    L6_2 = L6_2 .. L7_2
    L5_2.title = L6_2
    L5_2.description = "Government official who approved this subsidy"
    L5_2.icon = "fas fa-user-check"
    L5_2.disabled = true
    L3_2(L4_2, L5_2)
  end
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L5_2 = "subsidy_details_"
  L6_2 = A0_2.id
  L5_2 = L5_2 .. L6_2
  L4_2.id = L5_2
  L5_2 = "\240\159\147\139 Subsidy Details - "
  L6_2 = A0_2.subsidy_type
  L5_2 = L5_2 .. L6_2
  L4_2.title = L5_2
  L4_2.menu = "government_subsidies_list"
  L4_2.options = L1_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "subsidy_details_"
  L5_2 = A0_2.id
  L4_2 = L4_2 .. L5_2
  L3_2(L4_2)
end
ShowSubsidyDetails = L3_1
L3_1 = RegisterNetEvent
L4_1 = "fs-government:client:showBudgetInfo"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2
  L2_2 = {}
  L3_2 = 0
  L4_2 = 0
  L5_2 = #A0_2
  if 0 == L5_2 then
    L5_2 = table
    L5_2 = L5_2.insert
    L6_2 = L2_2
    L7_2 = {}
    L7_2.title = "No Budget Data"
    L8_2 = "No budget information found for fiscal year "
    L9_2 = A1_2
    L8_2 = L8_2 .. L9_2
    L7_2.description = L8_2
    L7_2.icon = "fas fa-info-circle"
    L7_2.disabled = true
    L5_2(L6_2, L7_2)
  else
    L5_2 = ipairs
    L6_2 = A0_2
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
    for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
      L11_2 = tonumber
      L12_2 = L10_2.allocated_amount
      L11_2 = L11_2(L12_2)
      if not L11_2 then
        L11_2 = 0
      end
      L12_2 = tonumber
      L13_2 = L10_2.spent_amount
      L12_2 = L12_2(L13_2)
      if not L12_2 then
        L12_2 = 0
      end
      L3_2 = L3_2 + L11_2
      L4_2 = L4_2 + L12_2
      L13_2 = L11_2 - L12_2
      if L11_2 > 0 then
        L14_2 = L12_2 / L11_2
        L14_2 = L14_2 * 100
        if L14_2 then
          goto lbl_53
        end
      end
      L14_2 = 0
      ::lbl_53::
      L15_2 = "#27ae60"
      if L14_2 > 90 then
        L15_2 = "#e74c3c"
      elseif L14_2 > 75 then
        L15_2 = "#f39c12"
      end
      L16_2 = table
      L16_2 = L16_2.insert
      L17_2 = L2_2
      L18_2 = {}
      L19_2 = L10_2.department
      L20_2 = L19_2
      L19_2 = L19_2.upper
      L19_2 = L19_2(L20_2)
      L18_2.title = L19_2
      L19_2 = "Allocated: "
      L20_2 = Utils
      L20_2 = L20_2.FormatMoney
      L21_2 = L11_2
      L20_2 = L20_2(L21_2)
      L21_2 = [[

Spent: ]]
      L22_2 = Utils
      L22_2 = L22_2.FormatMoney
      L23_2 = L12_2
      L22_2 = L22_2(L23_2)
      L23_2 = [[

Remaining: ]]
      L24_2 = Utils
      L24_2 = L24_2.FormatMoney
      L25_2 = L13_2
      L24_2 = L24_2(L25_2)
      L25_2 = [[

Utilization: ]]
      L26_2 = string
      L26_2 = L26_2.format
      L27_2 = "%.1f%%"
      L28_2 = L14_2
      L26_2 = L26_2(L27_2, L28_2)
      L19_2 = L19_2 .. L20_2 .. L21_2 .. L22_2 .. L23_2 .. L24_2 .. L25_2 .. L26_2
      L18_2.description = L19_2
      L18_2.icon = "fas fa-building"
      L18_2.iconColor = L15_2
      L19_2 = {}
      L20_2 = {}
      L20_2.label = "Department"
      L21_2 = L10_2.department
      L20_2.value = L21_2
      L21_2 = {}
      L21_2.label = "Fiscal Year"
      L22_2 = L10_2.fiscal_year
      L21_2.value = L22_2
      L22_2 = {}
      L22_2.label = "Allocated"
      L23_2 = Utils
      L23_2 = L23_2.FormatMoney
      L24_2 = L11_2
      L23_2 = L23_2(L24_2)
      L22_2.value = L23_2
      L23_2 = {}
      L23_2.label = "Spent"
      L24_2 = Utils
      L24_2 = L24_2.FormatMoney
      L25_2 = L12_2
      L24_2 = L24_2(L25_2)
      L23_2.value = L24_2
      L24_2 = {}
      L24_2.label = "Remaining"
      L25_2 = Utils
      L25_2 = L25_2.FormatMoney
      L26_2 = L13_2
      L25_2 = L25_2(L26_2)
      L24_2.value = L25_2
      L25_2 = {}
      L25_2.label = "Utilization"
      L26_2 = string
      L26_2 = L26_2.format
      L27_2 = "%.1f%%"
      L28_2 = L14_2
      L26_2 = L26_2(L27_2, L28_2)
      L25_2.value = L26_2
      L19_2[1] = L20_2
      L19_2[2] = L21_2
      L19_2[3] = L22_2
      L19_2[4] = L23_2
      L19_2[5] = L24_2
      L19_2[6] = L25_2
      L18_2.metadata = L19_2
      L16_2(L17_2, L18_2)
    end
    L5_2 = table
    L5_2 = L5_2.insert
    L6_2 = L2_2
    L7_2 = 1
    L8_2 = {}
    L9_2 = "Budget Summary FY"
    L10_2 = A1_2
    L9_2 = L9_2 .. L10_2
    L8_2.title = L9_2
    L9_2 = "Total Allocated: "
    L10_2 = Utils
    L10_2 = L10_2.FormatMoney
    L11_2 = L3_2
    L10_2 = L10_2(L11_2)
    L11_2 = [[

Total Spent: ]]
    L12_2 = Utils
    L12_2 = L12_2.FormatMoney
    L13_2 = L4_2
    L12_2 = L12_2(L13_2)
    L13_2 = [[

Total Remaining: ]]
    L14_2 = Utils
    L14_2 = L14_2.FormatMoney
    L15_2 = L3_2 - L4_2
    L14_2 = L14_2(L15_2)
    L9_2 = L9_2 .. L10_2 .. L11_2 .. L12_2 .. L13_2 .. L14_2
    L8_2.description = L9_2
    L8_2.icon = "fas fa-chart-pie"
    L8_2.iconColor = "#3498db"
    L8_2.disabled = true
    L5_2(L6_2, L7_2, L8_2)
  end
  L5_2 = table
  L5_2 = L5_2.insert
  L6_2 = L2_2
  L7_2 = {}
  L7_2.title = "Close"
  L7_2.description = "Close budget information"
  L7_2.icon = "fas fa-times"
  L7_2.iconColor = "#e74c3c"
  function L8_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L7_2.onSelect = L8_2
  L5_2(L6_2, L7_2)
  L5_2 = lib
  L5_2 = L5_2.registerContext
  L6_2 = {}
  L6_2.id = "government_budget_info"
  L7_2 = "\240\159\146\176 Budget Information FY"
  L8_2 = A1_2
  L7_2 = L7_2 .. L8_2
  L6_2.title = L7_2
  L6_2.options = L2_2
  L5_2(L6_2)
  L5_2 = lib
  L5_2 = L5_2.showContext
  L6_2 = "government_budget_info"
  L5_2(L6_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:client:showMonthlyReport"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L2_2 = {}
  L3_2 = 0
  L4_2 = table
  L4_2 = L4_2.insert
  L5_2 = L2_2
  L6_2 = {}
  L6_2.title = "Monthly Financial Report"
  L7_2 = "Period: "
  L8_2 = A1_2
  L7_2 = L7_2 .. L8_2
  L6_2.description = L7_2
  L6_2.icon = "fas fa-calendar-alt"
  L6_2.iconColor = "#3498db"
  L6_2.disabled = true
  L4_2(L5_2, L6_2)
  L4_2 = #A0_2
  if 0 == L4_2 then
    L4_2 = table
    L4_2 = L4_2.insert
    L5_2 = L2_2
    L6_2 = {}
    L6_2.title = "No Transactions"
    L7_2 = "No financial transactions found for "
    L8_2 = A1_2
    L7_2 = L7_2 .. L8_2
    L6_2.description = L7_2
    L6_2.icon = "fas fa-info-circle"
    L6_2.disabled = true
    L4_2(L5_2, L6_2)
  else
    L4_2 = ipairs
    L5_2 = A0_2
    L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
    for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
      L10_2 = L9_2.total
      L3_2 = L3_2 + L10_2
      L10_2 = "fas fa-dollar-sign"
      L11_2 = "#27ae60"
      L12_2 = L9_2.transaction_type
      if "expense" == L12_2 then
        L10_2 = "fas fa-minus-circle"
        L11_2 = "#e74c3c"
      else
        L12_2 = L9_2.transaction_type
        if "tax" == L12_2 then
          L10_2 = "fas fa-coins"
          L11_2 = "#f39c12"
        else
          L12_2 = L9_2.transaction_type
          if "subsidy" == L12_2 then
            L10_2 = "fas fa-hand-holding-usd"
            L11_2 = "#9b59b6"
          end
        end
      end
      L12_2 = table
      L12_2 = L12_2.insert
      L13_2 = L2_2
      L14_2 = {}
      L15_2 = L9_2.transaction_type
      L16_2 = L15_2
      L15_2 = L15_2.upper
      L15_2 = L15_2(L16_2)
      L14_2.title = L15_2
      L15_2 = "Amount: "
      L16_2 = Utils
      L16_2 = L16_2.FormatMoney
      L17_2 = L9_2.total
      L16_2 = L16_2(L17_2)
      L15_2 = L15_2 .. L16_2
      L14_2.description = L15_2
      L14_2.icon = L10_2
      L14_2.iconColor = L11_2
      L14_2.disabled = true
      L12_2(L13_2, L14_2)
    end
    L4_2 = table
    L4_2 = L4_2.insert
    L5_2 = L2_2
    L6_2 = {}
    L6_2.title = "Total Activity"
    L7_2 = "Combined Amount: "
    L8_2 = Utils
    L8_2 = L8_2.FormatMoney
    L9_2 = L3_2
    L8_2 = L8_2(L9_2)
    L7_2 = L7_2 .. L8_2
    L6_2.description = L7_2
    L6_2.icon = "fas fa-calculator"
    L6_2.iconColor = "#34495e"
    L6_2.disabled = true
    L4_2(L5_2, L6_2)
  end
  L4_2 = table
  L4_2 = L4_2.insert
  L5_2 = L2_2
  L6_2 = {}
  L6_2.title = "Close"
  L6_2.description = "Close monthly report"
  L6_2.icon = "fas fa-times"
  L6_2.iconColor = "#e74c3c"
  function L7_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L6_2.onSelect = L7_2
  L4_2(L5_2, L6_2)
  L4_2 = lib
  L4_2 = L4_2.registerContext
  L5_2 = {}
  L5_2.id = "government_monthly_report"
  L6_2 = "\240\159\147\138 Monthly Report - "
  L7_2 = A1_2
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.options = L2_2
  L4_2(L5_2)
  L4_2 = lib
  L4_2 = L4_2.showContext
  L5_2 = "government_monthly_report"
  L4_2(L5_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:client:showExpenseReport"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L1_2 = {}
  L2_2 = 0
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L1_2
  L5_2 = {}
  L5_2.title = "Government Expenses Report"
  L5_2.description = "Recent expense transactions (last 50)"
  L5_2.icon = "fas fa-receipt"
  L5_2.iconColor = "#e74c3c"
  L5_2.disabled = true
  L3_2(L4_2, L5_2)
  L3_2 = #A0_2
  if 0 == L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L1_2
    L5_2 = {}
    L5_2.title = "No Expenses Found"
    L5_2.description = "No expense records available"
    L5_2.icon = "fas fa-info-circle"
    L5_2.disabled = true
    L3_2(L4_2, L5_2)
  else
    L3_2 = ipairs
    L4_2 = A0_2
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
      L9_2 = L8_2.amount
      L2_2 = L2_2 + L9_2
      L9_2 = Utils
      L9_2 = L9_2.FormatDate
      L10_2 = L8_2.created_at
      L9_2 = L9_2(L10_2)
      if not L9_2 then
        L9_2 = "Unknown Date"
      end
      L10_2 = table
      L10_2 = L10_2.insert
      L11_2 = L1_2
      L12_2 = {}
      L13_2 = Utils
      L13_2 = L13_2.FormatMoney
      L14_2 = L8_2.amount
      L13_2 = L13_2(L14_2)
      L12_2.title = L13_2
      L13_2 = L8_2.description
      L14_2 = [[

Date: ]]
      L15_2 = L9_2
      L13_2 = L13_2 .. L14_2 .. L15_2
      L12_2.description = L13_2
      L12_2.icon = "fas fa-money-bill-wave"
      L12_2.iconColor = "#e74c3c"
      L10_2(L11_2, L12_2)
    end
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L1_2
    L5_2 = 2
    L6_2 = {}
    L7_2 = "Total Expenses: "
    L8_2 = Utils
    L8_2 = L8_2.FormatMoney
    L9_2 = L2_2
    L8_2 = L8_2(L9_2)
    L7_2 = L7_2 .. L8_2
    L6_2.title = L7_2
    L6_2.description = "Sum of all listed expenses"
    L6_2.icon = "fas fa-calculator"
    L6_2.iconColor = "#34495e"
    L6_2.disabled = true
    L3_2(L4_2, L5_2, L6_2)
  end
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L1_2
  L5_2 = {}
  L5_2.title = "Close"
  L5_2.description = "Close expense report"
  L5_2.icon = "fas fa-times"
  L5_2.iconColor = "#e74c3c"
  function L6_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L5_2.onSelect = L6_2
  L3_2(L4_2, L5_2)
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "government_expense_report"
  L5_2 = "\240\159\146\184 Expense Report ("
  L6_2 = #A0_2
  L7_2 = " entries)"
  L5_2 = L5_2 .. L6_2 .. L7_2
  L4_2.title = L5_2
  L4_2.options = L1_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "government_expense_report"
  L3_2(L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:client:showTaxReport"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L1_2 = {}
  L2_2 = 0
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L1_2
  L5_2 = {}
  L5_2.title = "Tax Collection Report"
  L5_2.description = "Last 30 days tax revenue breakdown"
  L5_2.icon = "fas fa-coins"
  L5_2.iconColor = "#f39c12"
  L5_2.disabled = true
  L3_2(L4_2, L5_2)
  L3_2 = #A0_2
  if 0 == L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L1_2
    L5_2 = {}
    L5_2.title = "No Tax Data"
    L5_2.description = "No tax collections found for the last 30 days"
    L5_2.icon = "fas fa-info-circle"
    L5_2.disabled = true
    L3_2(L4_2, L5_2)
  else
    L3_2 = ipairs
    L4_2 = A0_2
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
      L9_2 = L8_2.total
      L2_2 = L2_2 + L9_2
      L9_2 = "fas fa-coins"
      L10_2 = "#f39c12"
      L11_2 = L8_2.tax_type
      if "salary" == L11_2 then
        L9_2 = "fas fa-user-tie"
        L10_2 = "#3498db"
      else
        L11_2 = L8_2.tax_type
        if "business" == L11_2 then
          L9_2 = "fas fa-building"
          L10_2 = "#27ae60"
        else
          L11_2 = L8_2.tax_type
          if "vehicle" == L11_2 then
            L9_2 = "fas fa-car"
            L10_2 = "#9b59b6"
          else
            L11_2 = L8_2.tax_type
            if "property" == L11_2 then
              L9_2 = "fas fa-home"
              L10_2 = "#e67e22"
            end
          end
        end
      end
      L11_2 = table
      L11_2 = L11_2.insert
      L12_2 = L1_2
      L13_2 = {}
      L14_2 = L8_2.tax_type
      L15_2 = L14_2
      L14_2 = L14_2.upper
      L14_2 = L14_2(L15_2)
      L15_2 = " Tax"
      L14_2 = L14_2 .. L15_2
      L13_2.title = L14_2
      L14_2 = "Revenue: "
      L15_2 = Utils
      L15_2 = L15_2.FormatMoney
      L16_2 = L8_2.total
      L15_2 = L15_2(L16_2)
      L14_2 = L14_2 .. L15_2
      L13_2.description = L14_2
      L13_2.icon = L9_2
      L13_2.iconColor = L10_2
      L13_2.disabled = true
      L11_2(L12_2, L13_2)
    end
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L1_2
    L5_2 = 2
    L6_2 = {}
    L7_2 = "Total Tax Revenue: "
    L8_2 = Utils
    L8_2 = L8_2.FormatMoney
    L9_2 = L2_2
    L8_2 = L8_2(L9_2)
    L7_2 = L7_2 .. L8_2
    L6_2.title = L7_2
    L6_2.description = "Combined tax collections for last 30 days"
    L6_2.icon = "fas fa-calculator"
    L6_2.iconColor = "#34495e"
    L6_2.disabled = true
    L3_2(L4_2, L5_2, L6_2)
  end
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L1_2
  L5_2 = {}
  L5_2.title = "Close"
  L5_2.description = "Close tax report"
  L5_2.icon = "fas fa-times"
  L5_2.iconColor = "#e74c3c"
  function L6_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L5_2.onSelect = L6_2
  L3_2(L4_2, L5_2)
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "government_tax_report"
  L4_2.title = "\240\159\143\155\239\184\143 Tax Collection Report"
  L4_2.options = L1_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "government_tax_report"
  L3_2(L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:client:showAnnualReport"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2
  L2_2 = {}
  L3_2 = 0
  L4_2 = 0
  L5_2 = table
  L5_2 = L5_2.insert
  L6_2 = L2_2
  L7_2 = {}
  L7_2.title = "Annual Financial Summary"
  L8_2 = "Fiscal Year: "
  L9_2 = A1_2
  L8_2 = L8_2 .. L9_2
  L7_2.description = L8_2
  L7_2.icon = "fas fa-chart-line"
  L7_2.iconColor = "#3498db"
  L7_2.disabled = true
  L5_2(L6_2, L7_2)
  L5_2 = #A0_2
  if 0 == L5_2 then
    L5_2 = table
    L5_2 = L5_2.insert
    L6_2 = L2_2
    L7_2 = {}
    L7_2.title = "No Financial Data"
    L8_2 = "No transaction records found for "
    L9_2 = A1_2
    L8_2 = L8_2 .. L9_2
    L7_2.description = L8_2
    L7_2.icon = "fas fa-info-circle"
    L7_2.disabled = true
    L5_2(L6_2, L7_2)
  else
    L5_2 = ipairs
    L6_2 = A0_2
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
    for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
      L11_2 = "fas fa-dollar-sign"
      L12_2 = "#27ae60"
      L13_2 = false
      L14_2 = L10_2.transaction_type
      if "income" ~= L14_2 then
        L14_2 = L10_2.transaction_type
        if "tax" ~= L14_2 then
          goto lbl_56
        end
      end
      L14_2 = L10_2.total
      L3_2 = L3_2 + L14_2
      L13_2 = true
      L11_2 = "fas fa-plus-circle"
      L12_2 = "#27ae60"
      goto lbl_61
      ::lbl_56::
      L14_2 = L10_2.total
      L4_2 = L4_2 + L14_2
      L11_2 = "fas fa-minus-circle"
      L12_2 = "#e74c3c"
      ::lbl_61::
      L14_2 = table
      L14_2 = L14_2.insert
      L15_2 = L2_2
      L16_2 = {}
      L17_2 = L10_2.transaction_type
      L18_2 = L17_2
      L17_2 = L17_2.upper
      L17_2 = L17_2(L18_2)
      L16_2.title = L17_2
      if L13_2 then
        L17_2 = "Revenue: "
        if L17_2 then
          goto lbl_76
        end
      end
      L17_2 = "Expenses: "
      ::lbl_76::
      L18_2 = Utils
      L18_2 = L18_2.FormatMoney
      L19_2 = L10_2.total
      L18_2 = L18_2(L19_2)
      L17_2 = L17_2 .. L18_2
      L16_2.description = L17_2
      L16_2.icon = L11_2
      L16_2.iconColor = L12_2
      L16_2.disabled = true
      L14_2(L15_2, L16_2)
    end
    L5_2 = L3_2 - L4_2
    if L5_2 >= 0 then
      L6_2 = "#27ae60"
      if L6_2 then
        goto lbl_97
      end
    end
    L6_2 = "#e74c3c"
    ::lbl_97::
    if L5_2 >= 0 then
      L7_2 = "fas fa-arrow-up"
      if L7_2 then
        goto lbl_103
      end
    end
    L7_2 = "fas fa-arrow-down"
    ::lbl_103::
    L8_2 = table
    L8_2 = L8_2.insert
    L9_2 = L2_2
    L10_2 = {}
    L10_2.title = "Financial Summary"
    L11_2 = "Total Income: "
    L12_2 = Utils
    L12_2 = L12_2.FormatMoney
    L13_2 = L3_2
    L12_2 = L12_2(L13_2)
    L13_2 = [[

Total Expenses: ]]
    L14_2 = Utils
    L14_2 = L14_2.FormatMoney
    L15_2 = L4_2
    L14_2 = L14_2(L15_2)
    L15_2 = [[

Net Profit/Loss: ]]
    L16_2 = Utils
    L16_2 = L16_2.FormatMoney
    L17_2 = L5_2
    L16_2 = L16_2(L17_2)
    L11_2 = L11_2 .. L12_2 .. L13_2 .. L14_2 .. L15_2 .. L16_2
    L10_2.description = L11_2
    L10_2.icon = L7_2
    L10_2.iconColor = L6_2
    L10_2.disabled = true
    L8_2(L9_2, L10_2)
  end
  L5_2 = table
  L5_2 = L5_2.insert
  L6_2 = L2_2
  L7_2 = {}
  L7_2.title = "Close"
  L7_2.description = "Close annual report"
  L7_2.icon = "fas fa-times"
  L7_2.iconColor = "#e74c3c"
  function L8_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L7_2.onSelect = L8_2
  L5_2(L6_2, L7_2)
  L5_2 = lib
  L5_2 = L5_2.registerContext
  L6_2 = {}
  L6_2.id = "government_annual_report"
  L7_2 = "\240\159\147\136 Annual Report "
  L8_2 = A1_2
  L7_2 = L7_2 .. L8_2
  L6_2.title = L7_2
  L6_2.options = L2_2
  L5_2(L6_2)
  L5_2 = lib
  L5_2 = L5_2.showContext
  L6_2 = "government_annual_report"
  L5_2(L6_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:client:showBusinessAuditResult"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = {}
  L2_2 = {}
  L2_2.title = "Business Audit Report"
  L2_2.description = "Complete audit information"
  L2_2.icon = "fas fa-clipboard-check"
  L2_2.iconColor = "#3498db"
  L2_2.disabled = true
  L3_2 = {}
  L4_2 = "Business: "
  L5_2 = A0_2.business_name
  L4_2 = L4_2 .. L5_2
  L3_2.title = L4_2
  L3_2.description = "Registered business name"
  L3_2.icon = "fas fa-building"
  L3_2.disabled = true
  L4_2 = {}
  L5_2 = "Owner: "
  L6_2 = A0_2.owner_name
  L5_2 = L5_2 .. L6_2
  L4_2.title = L5_2
  L4_2.description = "Business owner information"
  L4_2.icon = "fas fa-user-tie"
  L4_2.disabled = true
  L5_2 = {}
  L6_2 = "Type: "
  L7_2 = FormatBusinessType
  L8_2 = A0_2.business_type
  L7_2 = L7_2(L8_2)
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.description = "Business category/classification"
  L5_2.icon = "fas fa-tag"
  L5_2.disabled = true
  L6_2 = {}
  L7_2 = "License: "
  L8_2 = A0_2.license_number
  L7_2 = L7_2 .. L8_2
  L6_2.title = L7_2
  L6_2.description = "Official business license number"
  L6_2.icon = "fas fa-certificate"
  L6_2.disabled = true
  L7_2 = {}
  L8_2 = "Status: "
  L9_2 = FormatStatusText
  L10_2 = A0_2.status
  L9_2 = L9_2(L10_2)
  L8_2 = L8_2 .. L9_2
  L7_2.title = L8_2
  L7_2.description = "Current operational status"
  L7_2.icon = "fas fa-info-circle"
  L8_2 = A0_2.status
  if "active" == L8_2 then
    L8_2 = "#27ae60"
    if L8_2 then
      goto lbl_71
    end
  end
  L8_2 = A0_2.status
  if "suspended" == L8_2 then
    L8_2 = "#f39c12"
    if L8_2 then
      goto lbl_71
    end
  end
  L8_2 = "#e74c3c"
  ::lbl_71::
  L7_2.iconColor = L8_2
  L7_2.disabled = true
  L8_2 = {}
  L9_2 = "Tax Paid: "
  L10_2 = Utils
  L10_2 = L10_2.FormatMoney
  L11_2 = A0_2.total_tax_paid
  if not L11_2 then
    L11_2 = 0
  end
  L10_2 = L10_2(L11_2)
  L9_2 = L9_2 .. L10_2
  L8_2.title = L9_2
  L8_2.description = "Total business taxes paid to date"
  L8_2.icon = "fas fa-coins"
  L8_2.iconColor = "#f39c12"
  L8_2.disabled = true
  L9_2 = {}
  L10_2 = "Tax Rate: "
  L11_2 = A0_2.tax_rate
  L12_2 = "%"
  L10_2 = L10_2 .. L11_2 .. L12_2
  L9_2.title = L10_2
  L9_2.description = "Applied business tax rate"
  L9_2.icon = "fas fa-percentage"
  L9_2.disabled = true
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L1_2[3] = L4_2
  L1_2[4] = L5_2
  L1_2[5] = L6_2
  L1_2[6] = L7_2
  L1_2[7] = L8_2
  L1_2[8] = L9_2
  L2_2 = A0_2.address
  if L2_2 then
    L2_2 = table
    L2_2 = L2_2.insert
    L3_2 = L1_2
    L4_2 = {}
    L5_2 = "Address: "
    L6_2 = A0_2.address
    L5_2 = L5_2 .. L6_2
    L4_2.title = L5_2
    L4_2.description = "Registered business location"
    L4_2.icon = "fas fa-map-marker-alt"
    L4_2.disabled = true
    L2_2(L3_2, L4_2)
  end
  L2_2 = A0_2.registration_fee
  if L2_2 then
    L2_2 = table
    L2_2 = L2_2.insert
    L3_2 = L1_2
    L4_2 = {}
    L5_2 = "Registration Fee: "
    L6_2 = Utils
    L6_2 = L6_2.FormatMoney
    L7_2 = A0_2.registration_fee
    L6_2 = L6_2(L7_2)
    L5_2 = L5_2 .. L6_2
    L4_2.title = L5_2
    L4_2.description = "Initial business registration fee paid"
    L4_2.icon = "fas fa-dollar-sign"
    L4_2.disabled = true
    L2_2(L3_2, L4_2)
  end
  L2_2 = Utils
  L2_2 = L2_2.FormatDate
  L3_2 = A0_2.created_at
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = "Unknown Date"
  end
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L1_2
  L5_2 = {}
  L6_2 = "Registered: "
  L7_2 = L2_2
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.description = "Business registration date"
  L5_2.icon = "fas fa-calendar"
  L5_2.disabled = true
  L3_2(L4_2, L5_2)
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L1_2
  L5_2 = {}
  L5_2.title = "Close"
  L5_2.description = "Close audit report"
  L5_2.icon = "fas fa-times"
  L5_2.iconColor = "#e74c3c"
  function L6_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L5_2.onSelect = L6_2
  L3_2(L4_2, L5_2)
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "business_audit_result"
  L5_2 = "\240\159\148\141 Audit Report - "
  L6_2 = A0_2.business_name
  L5_2 = L5_2 .. L6_2
  L4_2.title = L5_2
  L4_2.options = L1_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "business_audit_result"
  L3_2(L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:client:showBusinessSearch"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2
  L2_2 = {}
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L5_2.title = "Search Results"
  L6_2 = "Found "
  L7_2 = #A0_2
  L8_2 = " businesses for \""
  L9_2 = A1_2
  L10_2 = "\""
  L6_2 = L6_2 .. L7_2 .. L8_2 .. L9_2 .. L10_2
  L5_2.description = L6_2
  L5_2.icon = "fas fa-search"
  L5_2.iconColor = "#3498db"
  L5_2.disabled = true
  L3_2(L4_2, L5_2)
  L3_2 = #A0_2
  if 0 == L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L2_2
    L5_2 = {}
    L5_2.title = "No Results Found"
    L5_2.description = "No businesses match your search criteria"
    L5_2.icon = "fas fa-info-circle"
    L5_2.disabled = true
    L3_2(L4_2, L5_2)
  else
    L3_2 = ipairs
    L4_2 = A0_2
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
      L9_2 = L8_2.status
      if "active" == L9_2 then
        L9_2 = "#27ae60"
        if L9_2 then
          goto lbl_51
        end
      end
      L9_2 = L8_2.status
      if "suspended" == L9_2 then
        L9_2 = "#f39c12"
        if L9_2 then
          goto lbl_51
        end
      end
      L9_2 = "#e74c3c"
      ::lbl_51::
      L10_2 = L8_2.status
      if "active" == L10_2 then
        L10_2 = "fas fa-check-circle"
        if L10_2 then
          goto lbl_64
        end
      end
      L10_2 = L8_2.status
      if "suspended" == L10_2 then
        L10_2 = "fas fa-pause-circle"
        if L10_2 then
          goto lbl_64
        end
      end
      L10_2 = "fas fa-times-circle"
      ::lbl_64::
      L11_2 = table
      L11_2 = L11_2.insert
      L12_2 = L2_2
      L13_2 = {}
      L14_2 = L8_2.business_name
      L13_2.title = L14_2
      L14_2 = "Owner: "
      L15_2 = L8_2.owner_name
      L16_2 = [[

Type: ]]
      L17_2 = FormatBusinessType
      L18_2 = L8_2.business_type
      L17_2 = L17_2(L18_2)
      L18_2 = [[

License: ]]
      L19_2 = L8_2.license_number
      L20_2 = [[

Status: ]]
      L21_2 = FormatStatusText
      L22_2 = L8_2.status
      L21_2 = L21_2(L22_2)
      L14_2 = L14_2 .. L15_2 .. L16_2 .. L17_2 .. L18_2 .. L19_2 .. L20_2 .. L21_2
      L13_2.description = L14_2
      L13_2.icon = L10_2
      L13_2.iconColor = L9_2
      function L14_2()
        local L0_3, L1_3
        L0_3 = ShowBusinessDetails
        L1_3 = L8_2
        L0_3(L1_3)
      end
      L13_2.onSelect = L14_2
      L11_2(L12_2, L13_2)
    end
  end
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L5_2.title = "Close"
  L5_2.description = "Close search results"
  L5_2.icon = "fas fa-times"
  L5_2.iconColor = "#e74c3c"
  function L6_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L5_2.onSelect = L6_2
  L3_2(L4_2, L5_2)
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "business_search_results"
  L5_2 = "\240\159\148\141 Search Results - \""
  L6_2 = A1_2
  L7_2 = "\""
  L5_2 = L5_2 .. L6_2 .. L7_2
  L4_2.title = L5_2
  L4_2.options = L2_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "business_search_results"
  L3_2(L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:client:showAllBusinesses"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2
  L1_2 = {}
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L4_2.title = "Business Registry"
  L5_2 = "Total businesses registered: "
  L6_2 = #A0_2
  L5_2 = L5_2 .. L6_2
  L4_2.description = L5_2
  L4_2.icon = "fas fa-building"
  L4_2.iconColor = "#3498db"
  L4_2.disabled = true
  L2_2(L3_2, L4_2)
  L2_2 = #A0_2
  if 0 == L2_2 then
    L2_2 = table
    L2_2 = L2_2.insert
    L3_2 = L1_2
    L4_2 = {}
    L4_2.title = "No Businesses Found"
    L4_2.description = "No businesses are currently registered"
    L4_2.icon = "fas fa-info-circle"
    L4_2.disabled = true
    L2_2(L3_2, L4_2)
  else
    L2_2 = ipairs
    L3_2 = A0_2
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = L7_2.status
      if "active" == L8_2 then
        L8_2 = "#27ae60"
        if L8_2 then
          goto lbl_48
        end
      end
      L8_2 = L7_2.status
      if "suspended" == L8_2 then
        L8_2 = "#f39c12"
        if L8_2 then
          goto lbl_48
        end
      end
      L8_2 = "#e74c3c"
      ::lbl_48::
      L9_2 = L7_2.status
      if "active" == L9_2 then
        L9_2 = "fas fa-check-circle"
        if L9_2 then
          goto lbl_61
        end
      end
      L9_2 = L7_2.status
      if "suspended" == L9_2 then
        L9_2 = "fas fa-pause-circle"
        if L9_2 then
          goto lbl_61
        end
      end
      L9_2 = "fas fa-times-circle"
      ::lbl_61::
      L10_2 = "Unknown"
      L11_2 = L7_2.created_at
      if not L11_2 then
        L11_2 = L7_2.registered_at
        if not L11_2 then
          goto lbl_78
        end
      end
      L11_2 = Utils
      L11_2 = L11_2.FormatDate
      L12_2 = L7_2.created_at
      if not L12_2 then
        L12_2 = L7_2.registered_at
      end
      L11_2 = L11_2(L12_2)
      L10_2 = L11_2 or L10_2
      if not L11_2 then
        L10_2 = "Unknown"
      end
      ::lbl_78::
      L11_2 = table
      L11_2 = L11_2.insert
      L12_2 = L1_2
      L13_2 = {}
      L14_2 = L7_2.business_name
      L13_2.title = L14_2
      L14_2 = "Owner: "
      L15_2 = L7_2.owner_name
      L16_2 = [[

Type: ]]
      L17_2 = FormatBusinessType
      L18_2 = L7_2.business_type
      L17_2 = L17_2(L18_2)
      L18_2 = [[

License: ]]
      L19_2 = L7_2.license_number
      L20_2 = [[

Status: ]]
      L21_2 = FormatStatusText
      L22_2 = L7_2.status
      L21_2 = L21_2(L22_2)
      L22_2 = [[

Registered: ]]
      L23_2 = L10_2
      L14_2 = L14_2 .. L15_2 .. L16_2 .. L17_2 .. L18_2 .. L19_2 .. L20_2 .. L21_2 .. L22_2 .. L23_2
      L13_2.description = L14_2
      L13_2.icon = L9_2
      L13_2.iconColor = L8_2
      L14_2 = {}
      L15_2 = {}
      L15_2.label = "Business ID"
      L16_2 = L7_2.id
      L15_2.value = L16_2
      L16_2 = {}
      L16_2.label = "Business Name"
      L17_2 = L7_2.business_name
      L16_2.value = L17_2
      L17_2 = {}
      L17_2.label = "Owner"
      L18_2 = L7_2.owner_name
      L17_2.value = L18_2
      L18_2 = {}
      L18_2.label = "Type"
      L19_2 = FormatBusinessType
      L20_2 = L7_2.business_type
      L19_2 = L19_2(L20_2)
      L18_2.value = L19_2
      L19_2 = {}
      L19_2.label = "License Number"
      L20_2 = L7_2.license_number
      L19_2.value = L20_2
      L20_2 = {}
      L20_2.label = "Status"
      L21_2 = FormatStatusText
      L22_2 = L7_2.status
      L21_2 = L21_2(L22_2)
      L20_2.value = L21_2
      L21_2 = {}
      L21_2.label = "Tax Rate"
      L22_2 = L7_2.tax_rate
      if L22_2 then
        L22_2 = L7_2.tax_rate
        L23_2 = "%"
        L22_2 = L22_2 .. L23_2
        if L22_2 then
          goto lbl_151
        end
      end
      L22_2 = "Default"
      ::lbl_151::
      L21_2.value = L22_2
      L22_2 = {}
      L22_2.label = "Registration Fee"
      L23_2 = Utils
      L23_2 = L23_2.FormatMoney
      L24_2 = L7_2.registration_fee
      if not L24_2 then
        L24_2 = 0
      end
      L23_2 = L23_2(L24_2)
      L22_2.value = L23_2
      L23_2 = {}
      L23_2.label = "Address"
      L24_2 = L7_2.address
      if not L24_2 then
        L24_2 = "Not specified"
      end
      L23_2.value = L24_2
      L14_2[1] = L15_2
      L14_2[2] = L16_2
      L14_2[3] = L17_2
      L14_2[4] = L18_2
      L14_2[5] = L19_2
      L14_2[6] = L20_2
      L14_2[7] = L21_2
      L14_2[8] = L22_2
      L14_2[9] = L23_2
      L13_2.metadata = L14_2
      function L14_2()
        local L0_3, L1_3
        L0_3 = ShowBusinessDetails
        L1_3 = L7_2
        L0_3(L1_3)
      end
      L13_2.onSelect = L14_2
      L11_2(L12_2, L13_2)
    end
  end
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L4_2.title = "Close"
  L4_2.description = "Close business registry"
  L4_2.icon = "fas fa-times"
  L4_2.iconColor = "#e74c3c"
  function L5_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L4_2.onSelect = L5_2
  L2_2(L3_2, L4_2)
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "all_businesses_registry"
  L3_2.title = "\240\159\143\162 Business Registry"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "all_businesses_registry"
  L2_2(L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:client:showActiveAudits"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2
  L1_2 = {}
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L4_2.title = "Active Audits"
  L5_2 = "Currently ongoing audits: "
  L6_2 = #A0_2
  L5_2 = L5_2 .. L6_2
  L4_2.description = L5_2
  L4_2.icon = "fas fa-clock"
  L4_2.iconColor = "#f39c12"
  L4_2.disabled = true
  L2_2(L3_2, L4_2)
  L2_2 = #A0_2
  if 0 == L2_2 then
    L2_2 = table
    L2_2 = L2_2.insert
    L3_2 = L1_2
    L4_2 = {}
    L4_2.title = "No Active Audits"
    L4_2.description = "All audits have been completed or there are no ongoing audits"
    L4_2.icon = "fas fa-info-circle"
    L4_2.disabled = true
    L2_2(L3_2, L4_2)
  else
    L2_2 = ipairs
    L3_2 = A0_2
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = Utils
      L8_2 = L8_2.FormatDate
      L9_2 = L7_2.created_at
      L8_2 = L8_2(L9_2)
      if not L8_2 then
        L8_2 = "Unknown"
      end
      L9_2 = table
      L9_2 = L9_2.insert
      L10_2 = L1_2
      L11_2 = {}
      L12_2 = L7_2.business_name
      L13_2 = " ("
      L14_2 = L7_2.audit_type
      L15_2 = ")"
      L12_2 = L12_2 .. L13_2 .. L14_2 .. L15_2
      L11_2.title = L12_2
      L12_2 = "Owner: "
      L13_2 = L7_2.owner_name
      L14_2 = [[

Reason: ]]
      L15_2 = L7_2.reason
      L16_2 = [[

Initiated: ]]
      L17_2 = L8_2
      L18_2 = [[

Status: ]]
      L19_2 = FormatStatusText
      L20_2 = L7_2.status
      L19_2 = L19_2(L20_2)
      L12_2 = L12_2 .. L13_2 .. L14_2 .. L15_2 .. L16_2 .. L17_2 .. L18_2 .. L19_2
      L11_2.description = L12_2
      L11_2.icon = "fas fa-search-dollar"
      L11_2.iconColor = "#3498db"
      L12_2 = {}
      L13_2 = {}
      L13_2.label = "Audit ID"
      L14_2 = L7_2.id
      L13_2.value = L14_2
      L14_2 = {}
      L14_2.label = "Business"
      L15_2 = L7_2.business_name
      L14_2.value = L15_2
      L15_2 = {}
      L15_2.label = "Owner"
      L16_2 = L7_2.owner_name
      L15_2.value = L16_2
      L16_2 = {}
      L16_2.label = "Audit Type"
      L17_2 = L7_2.audit_type
      L16_2.value = L17_2
      L17_2 = {}
      L17_2.label = "Reason"
      L18_2 = L7_2.reason
      L17_2.value = L18_2
      L18_2 = {}
      L18_2.label = "Status"
      L19_2 = FormatStatusText
      L20_2 = L7_2.status
      L19_2 = L19_2(L20_2)
      L18_2.value = L19_2
      L19_2 = {}
      L19_2.label = "Initiated By"
      L20_2 = L7_2.initiated_by_name
      if not L20_2 then
        L20_2 = "Unknown"
      end
      L19_2.value = L20_2
      L20_2 = {}
      L20_2.label = "Date"
      L20_2.value = L8_2
      L12_2[1] = L13_2
      L12_2[2] = L14_2
      L12_2[3] = L15_2
      L12_2[4] = L16_2
      L12_2[5] = L17_2
      L12_2[6] = L18_2
      L12_2[7] = L19_2
      L12_2[8] = L20_2
      L11_2.metadata = L12_2
      function L12_2()
        local L0_3, L1_3, L2_3
        L0_3 = ShowAuditDetails
        L1_3 = L7_2
        L2_3 = "active"
        L0_3(L1_3, L2_3)
      end
      L11_2.onSelect = L12_2
      L9_2(L10_2, L11_2)
    end
  end
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L4_2.title = "Close"
  L4_2.description = "Close active audits view"
  L4_2.icon = "fas fa-times"
  L4_2.iconColor = "#e74c3c"
  function L5_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L4_2.onSelect = L5_2
  L2_2(L3_2, L4_2)
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "active_audits"
  L3_2.title = "\226\143\179 Active Audits"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "active_audits"
  L2_2(L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:client:showAuditHistory"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2
  L1_2 = {}
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L4_2.title = "Audit History"
  L5_2 = "Total completed audits: "
  L6_2 = #A0_2
  L5_2 = L5_2 .. L6_2
  L4_2.description = L5_2
  L4_2.icon = "fas fa-history"
  L4_2.iconColor = "#27ae60"
  L4_2.disabled = true
  L2_2(L3_2, L4_2)
  L2_2 = #A0_2
  if 0 == L2_2 then
    L2_2 = table
    L2_2 = L2_2.insert
    L3_2 = L1_2
    L4_2 = {}
    L4_2.title = "No Audit History"
    L4_2.description = "No audits have been completed yet"
    L4_2.icon = "fas fa-info-circle"
    L4_2.disabled = true
    L2_2(L3_2, L4_2)
  else
    L2_2 = ipairs
    L3_2 = A0_2
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = L7_2.status
      if "completed" == L8_2 then
        L8_2 = "#27ae60"
        if L8_2 then
          goto lbl_48
        end
      end
      L8_2 = L7_2.status
      if "cancelled" == L8_2 then
        L8_2 = "#e74c3c"
        if L8_2 then
          goto lbl_48
        end
      end
      L8_2 = "#f39c12"
      ::lbl_48::
      L9_2 = L7_2.status
      if "completed" == L9_2 then
        L9_2 = "fas fa-check-circle"
        if L9_2 then
          goto lbl_61
        end
      end
      L9_2 = L7_2.status
      if "cancelled" == L9_2 then
        L9_2 = "fas fa-times-circle"
        if L9_2 then
          goto lbl_61
        end
      end
      L9_2 = "fas fa-clock"
      ::lbl_61::
      L10_2 = Utils
      L10_2 = L10_2.FormatDate
      L11_2 = L7_2.created_at
      L10_2 = L10_2(L11_2)
      if not L10_2 then
        L10_2 = "Unknown"
      end
      L11_2 = table
      L11_2 = L11_2.insert
      L12_2 = L1_2
      L13_2 = {}
      L14_2 = L7_2.business_name
      L15_2 = " ("
      L16_2 = L7_2.audit_type
      L17_2 = ")"
      L14_2 = L14_2 .. L15_2 .. L16_2 .. L17_2
      L13_2.title = L14_2
      L14_2 = "Owner: "
      L15_2 = L7_2.owner_name
      L16_2 = [[

Status: ]]
      L17_2 = FormatStatusText
      L18_2 = L7_2.status
      L17_2 = L17_2(L18_2)
      L18_2 = [[

Date: ]]
      L19_2 = L10_2
      L14_2 = L14_2 .. L15_2 .. L16_2 .. L17_2 .. L18_2 .. L19_2
      L13_2.description = L14_2
      L13_2.icon = L9_2
      L13_2.iconColor = L8_2
      L14_2 = {}
      L15_2 = {}
      L15_2.label = "Audit ID"
      L16_2 = L7_2.id
      L15_2.value = L16_2
      L16_2 = {}
      L16_2.label = "Business"
      L17_2 = L7_2.business_name
      L16_2.value = L17_2
      L17_2 = {}
      L17_2.label = "Owner"
      L18_2 = L7_2.owner_name
      L17_2.value = L18_2
      L18_2 = {}
      L18_2.label = "Audit Type"
      L19_2 = L7_2.audit_type
      L18_2.value = L19_2
      L19_2 = {}
      L19_2.label = "Reason"
      L20_2 = L7_2.reason
      L19_2.value = L20_2
      L20_2 = {}
      L20_2.label = "Status"
      L21_2 = FormatStatusText
      L22_2 = L7_2.status
      L21_2 = L21_2(L22_2)
      L20_2.value = L21_2
      L21_2 = {}
      L21_2.label = "Initiated By"
      L22_2 = L7_2.initiated_by_name
      if not L22_2 then
        L22_2 = "Unknown"
      end
      L21_2.value = L22_2
      L22_2 = {}
      L22_2.label = "Completed Date"
      L23_2 = Utils
      L23_2 = L23_2.FormatDate
      L24_2 = L7_2.updated_at
      L23_2 = L23_2(L24_2)
      if not L23_2 then
        L23_2 = L10_2
      end
      L22_2.value = L23_2
      L14_2[1] = L15_2
      L14_2[2] = L16_2
      L14_2[3] = L17_2
      L14_2[4] = L18_2
      L14_2[5] = L19_2
      L14_2[6] = L20_2
      L14_2[7] = L21_2
      L14_2[8] = L22_2
      L13_2.metadata = L14_2
      function L14_2()
        local L0_3, L1_3, L2_3
        L0_3 = ShowAuditDetails
        L1_3 = L7_2
        L2_3 = "history"
        L0_3(L1_3, L2_3)
      end
      L13_2.onSelect = L14_2
      L11_2(L12_2, L13_2)
    end
  end
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L4_2.title = "Close"
  L4_2.description = "Close audit history"
  L4_2.icon = "fas fa-times"
  L4_2.iconColor = "#e74c3c"
  function L5_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L4_2.onSelect = L5_2
  L2_2(L3_2, L4_2)
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "audit_history"
  L3_2.title = "\240\159\147\139 Audit History"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "audit_history"
  L2_2(L3_2)
end
L3_1(L4_1, L5_1)
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  if not A0_2 then
    L1_2 = "Unspecified"
    return L1_2
  end
  L1_2 = {}
  L1_2.restaurant = "Restaurant/Food Service"
  L1_2.retail = "Retail Store"
  L1_2.service = "Service Business"
  L1_2.manufacturing = "Manufacturing"
  L1_2.technology = "Technology/IT"
  L1_2.other = "Other"
  L2_2 = L1_2[A0_2]
  if not L2_2 then
    L3_2 = A0_2
    L2_2 = A0_2.gsub
    L4_2 = "_"
    L5_2 = " "
    L2_2 = L2_2(L3_2, L4_2, L5_2)
    L3_2 = L2_2
    L2_2 = L2_2.gsub
    L4_2 = "^%l"
    L5_2 = string
    L5_2 = L5_2.upper
    L2_2 = L2_2(L3_2, L4_2, L5_2)
  end
  return L2_2
end
FormatBusinessType = L3_1
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  if A0_2 and "" ~= A0_2 then
    L1_2 = tostring
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    L2_2 = L1_2
    L1_2 = L1_2.match
    L3_2 = "^%s*$"
    L1_2 = L1_2(L2_2, L3_2)
    if not L1_2 then
      goto lbl_28
    end
  end
  L1_2 = Config
  L1_2 = L1_2.Debug
  if L1_2 then
    L1_2 = Utils
    L1_2 = L1_2.DebugError
    L2_2 = "FormatStatusText received invalid status: \""
    L3_2 = tostring
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L4_2 = "\" - returning \"Unknown Status\""
    L2_2 = L2_2 .. L3_2 .. L4_2
    L1_2(L2_2)
  end
  L1_2 = "Unknown Status"
  do return L1_2 end
  ::lbl_28::
  L1_2 = tostring
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  L2_2 = L1_2
  L1_2 = L1_2.match
  L3_2 = "^%s*(.-)%s*$"
  L1_2 = L1_2(L2_2, L3_2)
  L2_2 = L1_2
  L1_2 = L1_2.lower
  L1_2 = L1_2(L2_2)
  L2_2 = Config
  L2_2 = L2_2.Debug
  if L2_2 then
    L2_2 = Utils
    L2_2 = L2_2.DebugPrint
    L3_2 = "FormatStatusText received status: \""
    L4_2 = tostring
    L5_2 = A0_2
    L4_2 = L4_2(L5_2)
    L5_2 = "\" -> cleaned: \""
    L6_2 = L1_2
    L7_2 = "\""
    L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2 .. L7_2
    L2_2(L3_2)
    L2_2 = Utils
    L2_2 = L2_2.DebugPrint
    L3_2 = "Status length: "
    L4_2 = string
    L4_2 = L4_2.len
    L5_2 = tostring
    L6_2 = A0_2
    L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = L5_2(L6_2)
    L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
    L5_2 = " | Status type: "
    L6_2 = type
    L7_2 = A0_2
    L6_2 = L6_2(L7_2)
    L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
    L2_2(L3_2)
  end
  L2_2 = {}
  L2_2.in_progress = "In Progress"
  L2_2.completed = "Completed"
  L2_2.cancelled = "Cancelled"
  L2_2.completed_violations = "Completed (Violations Found)"
  L2_2.pending = "Pending"
  L2_2.approved = "Approved"
  L2_2.paid = "Paid"
  L2_2.rejected = "Rejected"
  L2_2.active = "Active"
  L2_2.suspended = "Suspended"
  L2_2.revoked = "Revoked"
  L2_2.closed = "Closed"
  L3_2 = L2_2[L1_2]
  if L3_2 then
    L4_2 = Config
    L4_2 = L4_2.Debug
    if L4_2 then
      L4_2 = Utils
      L4_2 = L4_2.DebugSuccess
      L5_2 = "FormatStatusText mapped \""
      L6_2 = L1_2
      L7_2 = "\" -> \""
      L8_2 = L3_2
      L9_2 = "\""
      L5_2 = L5_2 .. L6_2 .. L7_2 .. L8_2 .. L9_2
      L4_2(L5_2)
    end
    return L3_2
  end
  if L1_2 and "" ~= L1_2 then
    L5_2 = L1_2
    L4_2 = L1_2.gsub
    L6_2 = "_"
    L7_2 = " "
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    L5_2 = L4_2
    L4_2 = L4_2.gsub
    L6_2 = "^%l"
    L7_2 = string
    L7_2 = L7_2.upper
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    L5_2 = Config
    L5_2 = L5_2.Debug
    if L5_2 then
      L5_2 = Utils
      L5_2 = L5_2.DebugSuccess
      L6_2 = "FormatStatusText formatted \""
      L7_2 = L1_2
      L8_2 = "\" -> \""
      L9_2 = L4_2
      L10_2 = "\""
      L6_2 = L6_2 .. L7_2 .. L8_2 .. L9_2 .. L10_2
      L5_2(L6_2)
    end
    return L4_2
  end
  L4_2 = Config
  L4_2 = L4_2.Debug
  if L4_2 then
    L4_2 = Utils
    L4_2 = L4_2.DebugError
    L5_2 = "FormatStatusText falling back to \"Unknown Status\" for: \""
    L6_2 = tostring
    L7_2 = A0_2
    L6_2 = L6_2(L7_2)
    L7_2 = "\""
    L5_2 = L5_2 .. L6_2 .. L7_2
    L4_2(L5_2)
  end
  L4_2 = "Unknown Status"
  return L4_2
end
FormatStatusText = L3_1
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L2_2 = {}
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L5_2.title = "Audit Information"
  L6_2 = "ID: "
  L7_2 = A0_2.id
  L8_2 = " | Status: "
  L9_2 = FormatStatusText
  L10_2 = A0_2.status
  L9_2 = L9_2(L10_2)
  L6_2 = L6_2 .. L7_2 .. L8_2 .. L9_2
  L5_2.description = L6_2
  L5_2.icon = "fas fa-info-circle"
  L5_2.iconColor = "#3498db"
  L5_2.disabled = true
  L3_2(L4_2, L5_2)
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L6_2 = "Business: "
  L7_2 = A0_2.business_name
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.description = "Business being audited"
  L5_2.icon = "fas fa-building"
  L5_2.disabled = true
  L3_2(L4_2, L5_2)
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L6_2 = "Owner: "
  L7_2 = A0_2.owner_name
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.description = "Business owner information"
  L5_2.icon = "fas fa-user-tie"
  L5_2.disabled = true
  L3_2(L4_2, L5_2)
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L6_2 = "Audit Type: "
  L7_2 = A0_2.audit_type
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.description = "Type of audit being conducted"
  L5_2.icon = "fas fa-search-dollar"
  L5_2.disabled = true
  L3_2(L4_2, L5_2)
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L2_2
  L5_2 = {}
  L6_2 = "Reason: "
  L7_2 = A0_2.reason
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.description = "Reason for the audit"
  L5_2.icon = "fas fa-clipboard-list"
  L5_2.disabled = true
  L3_2(L4_2, L5_2)
  L3_2 = A0_2.status
  if "completed" == L3_2 then
    L3_2 = "#27ae60"
    if L3_2 then
      goto lbl_92
    end
  end
  L3_2 = A0_2.status
  if "cancelled" == L3_2 then
    L3_2 = "#e74c3c"
    if L3_2 then
      goto lbl_92
    end
  end
  L3_2 = A0_2.status
  if "in_progress" == L3_2 then
    L3_2 = "#f39c12"
    if L3_2 then
      goto lbl_92
    end
  end
  L3_2 = "#6c757d"
  ::lbl_92::
  L4_2 = A0_2.status
  if "completed" == L4_2 then
    L4_2 = "fas fa-check-circle"
    if L4_2 then
      goto lbl_111
    end
  end
  L4_2 = A0_2.status
  if "cancelled" == L4_2 then
    L4_2 = "fas fa-times-circle"
    if L4_2 then
      goto lbl_111
    end
  end
  L4_2 = A0_2.status
  if "in_progress" == L4_2 then
    L4_2 = "fas fa-clock"
    if L4_2 then
      goto lbl_111
    end
  end
  L4_2 = "fas fa-question-circle"
  ::lbl_111::
  L5_2 = table
  L5_2 = L5_2.insert
  L6_2 = L2_2
  L7_2 = {}
  L8_2 = "Status: "
  L9_2 = FormatStatusText
  L10_2 = A0_2.status
  L9_2 = L9_2(L10_2)
  L8_2 = L8_2 .. L9_2
  L7_2.title = L8_2
  L7_2.description = "Current audit status"
  L7_2.icon = L4_2
  L7_2.iconColor = L3_2
  L7_2.disabled = true
  L5_2(L6_2, L7_2)
  L5_2 = Utils
  L5_2 = L5_2.FormatDate
  L6_2 = A0_2.created_at
  L5_2 = L5_2(L6_2)
  if not L5_2 then
    L5_2 = "Unknown"
  end
  L6_2 = table
  L6_2 = L6_2.insert
  L7_2 = L2_2
  L8_2 = {}
  L9_2 = "Initiated: "
  L10_2 = L5_2
  L9_2 = L9_2 .. L10_2
  L8_2.title = L9_2
  L8_2.description = "When the audit was started"
  L8_2.icon = "fas fa-calendar-plus"
  L8_2.disabled = true
  L6_2(L7_2, L8_2)
  L6_2 = A0_2.updated_at
  if L6_2 then
    L6_2 = A0_2.status
    if "in_progress" ~= L6_2 then
      L6_2 = Utils
      L6_2 = L6_2.FormatDate
      L7_2 = A0_2.updated_at
      L6_2 = L6_2(L7_2)
      if not L6_2 then
        L6_2 = "Unknown"
      end
      L7_2 = table
      L7_2 = L7_2.insert
      L8_2 = L2_2
      L9_2 = {}
      L10_2 = "Completed: "
      L11_2 = L6_2
      L10_2 = L10_2 .. L11_2
      L9_2.title = L10_2
      L9_2.description = "When the audit was completed"
      L9_2.icon = "fas fa-calendar-check"
      L9_2.disabled = true
      L7_2(L8_2, L9_2)
    end
  end
  L6_2 = A0_2.initiated_by_name
  if L6_2 then
    L6_2 = table
    L6_2 = L6_2.insert
    L7_2 = L2_2
    L8_2 = {}
    L9_2 = "Initiated By: "
    L10_2 = A0_2.initiated_by_name
    L9_2 = L9_2 .. L10_2
    L8_2.title = L9_2
    L8_2.description = "Officer who started this audit"
    L8_2.icon = "fas fa-user-shield"
    L8_2.disabled = true
    L6_2(L7_2, L8_2)
  else
    L6_2 = A0_2.initiated_by
    if L6_2 then
      L6_2 = table
      L6_2 = L6_2.insert
      L7_2 = L2_2
      L8_2 = {}
      L9_2 = "Initiated By: "
      L10_2 = A0_2.initiated_by
      L9_2 = L9_2 .. L10_2
      L8_2.title = L9_2
      L8_2.description = "Officer who started this audit (ID)"
      L8_2.icon = "fas fa-user-shield"
      L8_2.disabled = true
      L6_2(L7_2, L8_2)
    end
  end
  L6_2 = A0_2.findings
  if L6_2 then
    L6_2 = A0_2.findings
    if "" ~= L6_2 then
      L6_2 = table
      L6_2 = L6_2.insert
      L7_2 = L2_2
      L8_2 = {}
      L8_2.title = "Findings"
      L9_2 = A0_2.findings
      L8_2.description = L9_2
      L8_2.icon = "fas fa-clipboard-check"
      L8_2.disabled = true
      L6_2(L7_2, L8_2)
    end
  end
  if "active" == A1_2 then
    L6_2 = A0_2.status
    if "in_progress" == L6_2 then
      L6_2 = table
      L6_2 = L6_2.insert
      L7_2 = L2_2
      L8_2 = {}
      L8_2.title = "Complete Audit"
      L8_2.description = "Mark this audit as completed"
      L8_2.icon = "fas fa-check"
      L8_2.iconColor = "#27ae60"
      function L9_2()
        local L0_3, L1_3
        L0_3 = CompleteAuditMenu
        L1_3 = A0_2.id
        L0_3(L1_3)
      end
      L8_2.onSelect = L9_2
      L6_2(L7_2, L8_2)
      L6_2 = table
      L6_2 = L6_2.insert
      L7_2 = L2_2
      L8_2 = {}
      L8_2.title = "Cancel Audit"
      L8_2.description = "Cancel this audit"
      L8_2.icon = "fas fa-times"
      L8_2.iconColor = "#e74c3c"
      function L9_2()
        local L0_3, L1_3
        L0_3 = CancelAuditMenu
        L1_3 = A0_2.id
        L0_3(L1_3)
      end
      L8_2.onSelect = L9_2
      L6_2(L7_2, L8_2)
    end
  end
  L6_2 = table
  L6_2 = L6_2.insert
  L7_2 = L2_2
  L8_2 = {}
  L8_2.title = "Close"
  L8_2.description = "Close audit details"
  L8_2.icon = "fas fa-arrow-left"
  L8_2.iconColor = "#6c757d"
  function L9_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L8_2.onSelect = L9_2
  L6_2(L7_2, L8_2)
  L6_2 = lib
  L6_2 = L6_2.registerContext
  L7_2 = {}
  L8_2 = "audit_details_"
  L9_2 = A0_2.id
  L8_2 = L8_2 .. L9_2
  L7_2.id = L8_2
  L8_2 = "\240\159\147\139 Audit Details - "
  L9_2 = A0_2.business_name
  L8_2 = L8_2 .. L9_2
  L7_2.title = L8_2
  L7_2.options = L2_2
  L6_2(L7_2)
  L6_2 = lib
  L6_2 = L6_2.showContext
  L7_2 = "audit_details_"
  L8_2 = A0_2.id
  L7_2 = L7_2 .. L8_2
  L6_2(L7_2)
end
ShowAuditDetails = L3_1
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = lib
  L1_2 = L1_2.inputDialog
  L2_2 = "Complete Audit"
  L3_2 = {}
  L4_2 = {}
  L4_2.type = "textarea"
  L4_2.label = "Findings"
  L4_2.placeholder = "Describe your audit findings..."
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "select"
  L5_2.label = "Final Status"
  L6_2 = {}
  L7_2 = {}
  L7_2.value = "completed"
  L7_2.label = "Completed Successfully"
  L8_2 = {}
  L8_2.value = "completed_violations"
  L8_2.label = "Completed with Violations Found"
  L6_2[1] = L7_2
  L6_2[2] = L8_2
  L5_2.options = L6_2
  L5_2.required = true
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L2_2 = L1_2[1]
    if L2_2 then
      L2_2 = L1_2[2]
      if L2_2 then
        L2_2 = TriggerServerEvent
        L3_2 = "fs-government:server:completeAudit"
        L4_2 = A0_2
        L5_2 = L1_2[1]
        L6_2 = L1_2[2]
        L2_2(L3_2, L4_2, L5_2, L6_2)
      end
    end
  end
end
CompleteAuditMenu = L3_1
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = lib
  L1_2 = L1_2.inputDialog
  L2_2 = "Cancel Audit"
  L3_2 = {}
  L4_2 = {}
  L4_2.type = "textarea"
  L4_2.label = "Cancellation Reason"
  L4_2.placeholder = "Why is this audit being cancelled?"
  L4_2.required = true
  L3_2[1] = L4_2
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L2_2 = L1_2[1]
    if L2_2 then
      L2_2 = TriggerServerEvent
      L3_2 = "fs-government:server:completeAudit"
      L4_2 = A0_2
      L5_2 = L1_2[1]
      L6_2 = "cancelled"
      L2_2(L3_2, L4_2, L5_2, L6_2)
    end
  end
end
CancelAuditMenu = L3_1
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = Config
  L1_2 = L1_2.Debug
  if L1_2 then
    L1_2 = Utils
    L1_2 = L1_2.DebugPrint
    L2_2 = "ShowBusinessDetails received business data:"
    L1_2(L2_2)
    L1_2 = Utils
    L1_2 = L1_2.DebugPrint
    L2_2 = "Business ID: "
    L3_2 = tostring
    L4_2 = A0_2.id
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
    L1_2 = Utils
    L1_2 = L1_2.DebugPrint
    L2_2 = "Business Name: "
    L3_2 = tostring
    L4_2 = A0_2.business_name
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
    L1_2 = Utils
    L1_2 = L1_2.DebugPrint
    L2_2 = "Business Status: \""
    L3_2 = tostring
    L4_2 = A0_2.status
    L3_2 = L3_2(L4_2)
    L4_2 = "\""
    L2_2 = L2_2 .. L3_2 .. L4_2
    L1_2(L2_2)
    L1_2 = Utils
    L1_2 = L1_2.DebugPrint
    L2_2 = "Business Status Type: "
    L3_2 = type
    L4_2 = A0_2.status
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
    L1_2 = Utils
    L1_2 = L1_2.DebugPrint
    L2_2 = "Business Status Length: "
    L3_2 = string
    L3_2 = L3_2.len
    L4_2 = tostring
    L5_2 = A0_2.status
    L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = L4_2(L5_2)
    L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
    L1_2 = FormatStatusText
    L2_2 = A0_2.status
    L1_2 = L1_2(L2_2)
    L2_2 = Utils
    L2_2 = L2_2.DebugPrint
    L3_2 = "FormatStatusText returned: \""
    L4_2 = L1_2
    L5_2 = "\""
    L3_2 = L3_2 .. L4_2 .. L5_2
    L2_2(L3_2)
  end
  L1_2 = {}
  L2_2 = {}
  L2_2.title = "Business Information"
  L3_2 = "ID: "
  L4_2 = A0_2.id
  L5_2 = " | License: "
  L6_2 = A0_2.license_number
  L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
  L2_2.description = L3_2
  L2_2.icon = "fas fa-info-circle"
  L2_2.disabled = true
  L3_2 = {}
  L4_2 = A0_2.business_name
  L3_2.title = L4_2
  L3_2.description = "Registered business name"
  L3_2.icon = "fas fa-building"
  L3_2.disabled = true
  L4_2 = {}
  L5_2 = "Owner: "
  L6_2 = A0_2.owner_name
  L5_2 = L5_2 .. L6_2
  L4_2.title = L5_2
  L4_2.description = "Business owner details"
  L4_2.icon = "fas fa-user-tie"
  L4_2.disabled = true
  L5_2 = {}
  L6_2 = "Type: "
  L7_2 = FormatBusinessType
  L8_2 = A0_2.business_type
  L7_2 = L7_2(L8_2)
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.description = "Business category"
  L5_2.icon = "fas fa-tag"
  L5_2.disabled = true
  L6_2 = {}
  L7_2 = "Status: "
  L8_2 = FormatStatusText
  L9_2 = A0_2.status
  L8_2 = L8_2(L9_2)
  if not L8_2 then
    L8_2 = "Unknown Status"
  end
  L7_2 = L7_2 .. L8_2
  L6_2.title = L7_2
  L6_2.description = "Current operational status"
  L7_2 = A0_2.status
  if "active" == L7_2 then
    L7_2 = "fas fa-check-circle"
    if L7_2 then
      goto lbl_134
    end
  end
  L7_2 = A0_2.status
  if "suspended" == L7_2 then
    L7_2 = "fas fa-pause-circle"
    if L7_2 then
      goto lbl_134
    end
  end
  L7_2 = A0_2.status
  if "closed" == L7_2 then
    L7_2 = "fas fa-ban"
    if L7_2 then
      goto lbl_134
    end
  end
  L7_2 = "fas fa-times-circle"
  ::lbl_134::
  L6_2.icon = L7_2
  L7_2 = A0_2.status
  if "active" == L7_2 then
    L7_2 = "#27ae60"
    if L7_2 then
      goto lbl_154
    end
  end
  L7_2 = A0_2.status
  if "suspended" == L7_2 then
    L7_2 = "#f39c12"
    if L7_2 then
      goto lbl_154
    end
  end
  L7_2 = A0_2.status
  if "closed" == L7_2 then
    L7_2 = "#e74c3c"
    if L7_2 then
      goto lbl_154
    end
  end
  L7_2 = "#e74c3c"
  ::lbl_154::
  L6_2.iconColor = L7_2
  L6_2.disabled = true
  L7_2 = {}
  L8_2 = "Tax Rate: "
  L9_2 = A0_2.tax_rate
  L10_2 = "%"
  L8_2 = L8_2 .. L9_2 .. L10_2
  L7_2.title = L8_2
  L7_2.description = "Applied business tax rate"
  L7_2.icon = "fas fa-percentage"
  L7_2.disabled = true
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L1_2[3] = L4_2
  L1_2[4] = L5_2
  L1_2[5] = L6_2
  L1_2[6] = L7_2
  L2_2 = A0_2.address
  if L2_2 then
    L2_2 = table
    L2_2 = L2_2.insert
    L3_2 = L1_2
    L4_2 = {}
    L5_2 = "Address: "
    L6_2 = A0_2.address
    L5_2 = L5_2 .. L6_2
    L4_2.title = L5_2
    L4_2.description = "Registered business location"
    L4_2.icon = "fas fa-map-marker-alt"
    L4_2.disabled = true
    L2_2(L3_2, L4_2)
  end
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L5_2 = "Registration Fee: "
  L6_2 = Utils
  L6_2 = L6_2.FormatMoney
  L7_2 = A0_2.registration_fee
  L6_2 = L6_2(L7_2)
  L5_2 = L5_2 .. L6_2
  L4_2.title = L5_2
  L4_2.description = "Initial registration fee paid"
  L4_2.icon = "fas fa-dollar-sign"
  L4_2.disabled = true
  L2_2(L3_2, L4_2)
  L2_2 = Utils
  L2_2 = L2_2.FormatDate
  L3_2 = A0_2.created_at
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = "Unknown Date"
  end
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L1_2
  L5_2 = {}
  L6_2 = "Registered: "
  L7_2 = L2_2
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.description = "Business registration date"
  L5_2.icon = "fas fa-calendar"
  L5_2.disabled = true
  L3_2(L4_2, L5_2)
  L3_2 = A0_2.status
  if "active" == L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L1_2
    L5_2 = {}
    L5_2.title = "Suspend Business"
    L5_2.description = "Temporarily suspend business operations"
    L5_2.icon = "fas fa-pause"
    L5_2.iconColor = "#f39c12"
    function L6_2()
      local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
      L0_3 = lib
      L0_3 = L0_3.inputDialog
      L1_3 = "Suspend Business"
      L2_3 = {}
      L3_3 = {}
      L3_3.type = "textarea"
      L3_3.label = "Reason for Suspension"
      L3_3.placeholder = "Enter reason for suspension..."
      L3_3.required = true
      L2_3[1] = L3_3
      L0_3 = L0_3(L1_3, L2_3)
      if L0_3 then
        L1_3 = L0_3[1]
        if L1_3 then
          L1_3 = TriggerServerEvent
          L2_3 = "fs-government:server:updateBusinessStatus"
          L3_3 = A0_2.id
          L4_3 = "suspended"
          L5_3 = L0_3[1]
          L1_3(L2_3, L3_3, L4_3, L5_3)
          L1_3 = lib
          L1_3 = L1_3.hideContext
          L1_3()
        end
      end
    end
    L5_2.onSelect = L6_2
    L3_2(L4_2, L5_2)
  else
    L3_2 = A0_2.status
    if "suspended" == L3_2 then
      L3_2 = table
      L3_2 = L3_2.insert
      L4_2 = L1_2
      L5_2 = {}
      L5_2.title = "Reactivate Business"
      L5_2.description = "Restore business to active status"
      L5_2.icon = "fas fa-play"
      L5_2.iconColor = "#27ae60"
      function L6_2()
        local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
        L0_3 = lib
        L0_3 = L0_3.inputDialog
        L1_3 = "Reactivate Business"
        L2_3 = {}
        L3_3 = {}
        L3_3.type = "textarea"
        L3_3.label = "Reason for Reactivation"
        L3_3.placeholder = "Enter reason for reactivation..."
        L3_3.required = true
        L2_3[1] = L3_3
        L0_3 = L0_3(L1_3, L2_3)
        if L0_3 then
          L1_3 = L0_3[1]
          if L1_3 then
            L1_3 = TriggerServerEvent
            L2_3 = "fs-government:server:updateBusinessStatus"
            L3_3 = A0_2.id
            L4_3 = "active"
            L5_3 = L0_3[1]
            L1_3(L2_3, L3_3, L4_3, L5_3)
            L1_3 = lib
            L1_3 = L1_3.hideContext
            L1_3()
          end
        end
      end
      L5_2.onSelect = L6_2
      L3_2(L4_2, L5_2)
    end
  end
  L3_2 = A0_2.status
  if "active" ~= L3_2 then
    L3_2 = A0_2.status
    if "suspended" ~= L3_2 then
      goto lbl_268
    end
  end
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L1_2
  L5_2 = {}
  L5_2.title = "Close Business Permanently"
  L5_2.description = "Permanently close this business"
  L5_2.icon = "fas fa-times-circle"
  L5_2.iconColor = "#e74c3c"
  function L6_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L0_3 = lib
    L0_3 = L0_3.alertDialog
    L1_3 = {}
    L1_3.header = "Close Business Permanently"
    L2_3 = "Are you sure you want to permanently close \""
    L3_3 = A0_2.business_name
    L4_3 = "\"? This action cannot be undone."
    L2_3 = L2_3 .. L3_3 .. L4_3
    L1_3.content = L2_3
    L1_3.centered = true
    L1_3.cancel = true
    L2_3 = {}
    L2_3.cancel = "Cancel"
    L2_3.confirm = "Close Business"
    L1_3.labels = L2_3
    L0_3 = L0_3(L1_3)
    if "confirm" == L0_3 then
      L1_3 = lib
      L1_3 = L1_3.inputDialog
      L2_3 = "Close Business"
      L3_3 = {}
      L4_3 = {}
      L4_3.type = "textarea"
      L4_3.label = "Reason for Closure"
      L4_3.placeholder = "Enter reason for permanent closure..."
      L4_3.required = true
      L3_3[1] = L4_3
      L1_3 = L1_3(L2_3, L3_3)
      if L1_3 then
        L2_3 = L1_3[1]
        if L2_3 then
          L2_3 = TriggerServerEvent
          L3_3 = "fs-government:server:updateBusinessStatus"
          L4_3 = A0_2.id
          L5_3 = "closed"
          L6_3 = L1_3[1]
          L2_3(L3_3, L4_3, L5_3, L6_3)
          L2_3 = lib
          L2_3 = L2_3.hideContext
          L2_3()
        end
      end
    end
  end
  L5_2.onSelect = L6_2
  L3_2(L4_2, L5_2)
  ::lbl_268::
  L3_2 = A0_2.status
  if "closed" == L3_2 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L1_2
    L5_2 = {}
    L5_2.title = "Business Closed"
    L5_2.description = "This business has been permanently closed"
    L5_2.icon = "fas fa-ban"
    L5_2.iconColor = "#e74c3c"
    L5_2.disabled = true
    L3_2(L4_2, L5_2)
  end
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L5_2 = "business_details_"
  L6_2 = A0_2.id
  L5_2 = L5_2 .. L6_2
  L4_2.id = L5_2
  L5_2 = "\240\159\143\162 "
  L6_2 = A0_2.business_name
  L5_2 = L5_2 .. L6_2
  L4_2.title = L5_2
  L4_2.menu = "all_businesses_registry"
  L4_2.options = L1_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "business_details_"
  L5_2 = A0_2.id
  L4_2 = L4_2 .. L5_2
  L3_2(L4_2)
end
ShowBusinessDetails = L3_1
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "Seize Player Items"
  L1_2.description = "Seize items from a player"
  L1_2.icon = "fas fa-box"
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L0_3 = lib
    L0_3 = L0_3.inputDialog
    L1_3 = "Seize Items"
    L2_3 = {}
    L3_3 = {}
    L3_3.type = "number"
    L3_3.label = "Player ID"
    L3_3.placeholder = "1"
    L3_3.required = true
    L3_3.min = 1
    L4_3 = {}
    L4_3.type = "input"
    L4_3.label = "Item Name"
    L4_3.placeholder = "weapon_pistol"
    L4_3.required = true
    L5_3 = {}
    L5_3.type = "number"
    L5_3.label = "Amount"
    L5_3.placeholder = "1"
    L5_3.required = true
    L5_3.min = 1
    L6_3 = {}
    L6_3.type = "textarea"
    L6_3.label = "Reason for Seizure"
    L6_3.placeholder = "Enter reason for seizure..."
    L6_3.required = true
    L2_3[1] = L3_3
    L2_3[2] = L4_3
    L2_3[3] = L5_3
    L2_3[4] = L6_3
    L0_3 = L0_3(L1_3, L2_3)
    if L0_3 then
      L1_3 = L0_3[1]
      if L1_3 then
        L1_3 = L0_3[2]
        if L1_3 then
          L1_3 = L0_3[3]
          if L1_3 then
            L1_3 = L0_3[4]
            if L1_3 then
              L1_3 = TriggerServerEvent
              L2_3 = "fs-government:server:seizeItem"
              L3_3 = tonumber
              L4_3 = L0_3[1]
              L3_3 = L3_3(L4_3)
              L4_3 = L0_3[2]
              L5_3 = tonumber
              L6_3 = L0_3[3]
              L5_3 = L5_3(L6_3)
              L6_3 = L0_3[4]
              L1_3(L2_3, L3_3, L4_3, L5_3, L6_3)
            end
          end
        end
      end
    end
  end
  L1_2.onSelect = L2_2
  L2_2 = {}
  L2_2.title = "Seize Money"
  L2_2.description = "Seize money from a player"
  L2_2.icon = "fas fa-dollar-sign"
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L0_3 = lib
    L0_3 = L0_3.inputDialog
    L1_3 = "Seize Money"
    L2_3 = {}
    L3_3 = {}
    L3_3.type = "number"
    L3_3.label = "Player ID"
    L3_3.placeholder = "1"
    L3_3.required = true
    L3_3.min = 1
    L4_3 = {}
    L4_3.type = "select"
    L4_3.label = "Money Type"
    L5_3 = {}
    L6_3 = {}
    L6_3.value = "cash"
    L6_3.label = "Cash"
    L7_3 = {}
    L7_3.value = "bank"
    L7_3.label = "Bank"
    L8_3 = {}
    L8_3.value = "black_money"
    L8_3.label = "Black Money"
    L5_3[1] = L6_3
    L5_3[2] = L7_3
    L5_3[3] = L8_3
    L4_3.options = L5_3
    L4_3.required = true
    L5_3 = {}
    L5_3.type = "number"
    L5_3.label = "Amount"
    L5_3.placeholder = "1000"
    L5_3.required = true
    L5_3.min = 1
    L6_3 = {}
    L6_3.type = "textarea"
    L6_3.label = "Reason for Seizure"
    L6_3.placeholder = "Enter reason for seizure..."
    L6_3.required = true
    L2_3[1] = L3_3
    L2_3[2] = L4_3
    L2_3[3] = L5_3
    L2_3[4] = L6_3
    L0_3 = L0_3(L1_3, L2_3)
    if L0_3 then
      L1_3 = L0_3[1]
      if L1_3 then
        L1_3 = L0_3[2]
        if L1_3 then
          L1_3 = L0_3[3]
          if L1_3 then
            L1_3 = L0_3[4]
            if L1_3 then
              L1_3 = TriggerServerEvent
              L2_3 = "fs-government:server:seizeMoney"
              L3_3 = tonumber
              L4_3 = L0_3[1]
              L3_3 = L3_3(L4_3)
              L4_3 = tonumber
              L5_3 = L0_3[3]
              L4_3 = L4_3(L5_3)
              L5_3 = L0_3[2]
              L6_3 = L0_3[4]
              L1_3(L2_3, L3_3, L4_3, L5_3, L6_3)
            end
          end
        end
      end
    end
  end
  L2_2.onSelect = L3_2
  L3_2 = {}
  L3_2.title = "View Active Seizures"
  L3_2.description = "View all currently seized assets"
  L3_2.icon = "fas fa-list"
  function L4_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getSeizures"
    L0_3(L1_3)
  end
  L3_2.onSelect = L4_2
  L4_2 = {}
  L4_2.title = "Seizure History"
  L4_2.description = "View complete seizure history"
  L4_2.icon = "fas fa-history"
  function L5_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getSeizureHistory"
    L0_3(L1_3)
  end
  L4_2.onSelect = L5_2
  L5_2 = {}
  L5_2.title = "Search Seizures"
  L5_2.description = "Search seizures by name/item/reason"
  L5_2.icon = "fas fa-search"
  function L6_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = lib
    L0_3 = L0_3.inputDialog
    L1_3 = "Search Seizures"
    L2_3 = {}
    L3_3 = {}
    L3_3.type = "input"
    L3_3.label = "Search Term"
    L3_3.placeholder = "Name, item, or reason..."
    L3_3.required = true
    L2_3[1] = L3_3
    L0_3 = L0_3(L1_3, L2_3)
    if L0_3 then
      L1_3 = L0_3[1]
      if L1_3 then
        L1_3 = TriggerServerEvent
        L2_3 = "fs-government:server:searchSeizures"
        L3_3 = L0_3[1]
        L1_3(L2_3, L3_3)
      end
    end
  end
  L5_2.onSelect = L6_2
  L6_2 = {}
  L6_2.title = "Back"
  L6_2.description = "Return to main menu"
  L6_2.icon = "fas fa-arrow-left"
  function L7_2()
    local L0_3, L1_3
    L0_3 = OpenSecurityMenu
    L0_3()
  end
  L6_2.onSelect = L7_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L0_2[4] = L4_2
  L0_2[5] = L5_2
  L0_2[6] = L6_2
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_seizure_menu"
  L2_2.title = "Asset Seizure System"
  L2_2.options = L0_2
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_seizure_menu"
  L1_2(L2_2)
end
OpenSeizureMenu = L3_1
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = {}
  L1_2 = {}
  L1_2.title = "Issue Warrant"
  L1_2.description = "Issue a new arrest warrant"
  L1_2.icon = "fas fa-gavel"
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L0_3 = lib
    L0_3 = L0_3.inputDialog
    L1_3 = "Issue Warrant"
    L2_3 = {}
    L3_3 = {}
    L3_3.type = "input"
    L3_3.label = "Target Name"
    L3_3.placeholder = "John Doe"
    L3_3.required = true
    L4_3 = {}
    L4_3.type = "input"
    L4_3.label = "Offense"
    L4_3.placeholder = "Armed Robbery"
    L4_3.required = true
    L5_3 = {}
    L5_3.type = "textarea"
    L5_3.label = "Details"
    L5_3.placeholder = "Detailed description of the offense..."
    L5_3.required = true
    L6_3 = {}
    L6_3.type = "select"
    L6_3.label = "Priority Level"
    L7_3 = {}
    L8_3 = {}
    L8_3.value = "low"
    L8_3.label = "Low Priority"
    L9_3 = {}
    L9_3.value = "medium"
    L9_3.label = "Medium Priority"
    L10_3 = {}
    L10_3.value = "high"
    L10_3.label = "High Priority"
    L7_3[1] = L8_3
    L7_3[2] = L9_3
    L7_3[3] = L10_3
    L6_3.options = L7_3
    L6_3.default = "medium"
    L2_3[1] = L3_3
    L2_3[2] = L4_3
    L2_3[3] = L5_3
    L2_3[4] = L6_3
    L0_3 = L0_3(L1_3, L2_3)
    if L0_3 then
      L1_3 = L0_3[1]
      if L1_3 then
        L1_3 = L0_3[2]
        if L1_3 then
          L1_3 = L0_3[3]
          if L1_3 then
            L1_3 = L0_3[4]
            if L1_3 then
              L1_3 = TriggerServerEvent
              L2_3 = "fs-government:server:issueWarrant"
              L3_3 = L0_3[1]
              L4_3 = L0_3[2]
              L5_3 = L0_3[3]
              L6_3 = L0_3[4]
              L1_3(L2_3, L3_3, L4_3, L5_3, L6_3)
            end
          end
        end
      end
    end
  end
  L1_2.onSelect = L2_2
  L2_2 = {}
  L2_2.title = "Check Warrants"
  L2_2.description = "Search for active warrants by name"
  L2_2.icon = "fas fa-search"
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = lib
    L0_3 = L0_3.inputDialog
    L1_3 = "Check Warrants"
    L2_3 = {}
    L3_3 = {}
    L3_3.type = "input"
    L3_3.label = "Target Name"
    L3_3.placeholder = "John Doe"
    L3_3.required = true
    L2_3[1] = L3_3
    L0_3 = L0_3(L1_3, L2_3)
    if L0_3 then
      L1_3 = L0_3[1]
      if L1_3 then
        L1_3 = TriggerServerEvent
        L2_3 = "fs-government:server:checkWarrants"
        L3_3 = L0_3[1]
        L1_3(L2_3, L3_3)
      end
    end
  end
  L2_2.onSelect = L3_2
  L3_2 = {}
  L3_2.title = "View All Active Warrants"
  L3_2.description = "View all currently active warrants"
  L3_2.icon = "fas fa-list"
  function L4_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getAllWarrants"
    L0_3(L1_3)
  end
  L3_2.onSelect = L4_2
  L4_2 = {}
  L4_2.title = "Warrant History"
  L4_2.description = "View executed and cancelled warrants"
  L4_2.icon = "fas fa-history"
  function L5_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getWarrantHistory"
    L0_3(L1_3)
  end
  L4_2.onSelect = L5_2
  L5_2 = {}
  L5_2.title = "Back"
  L5_2.description = "Return to main menu"
  L5_2.icon = "fas fa-arrow-left"
  function L6_2()
    local L0_3, L1_3
    L0_3 = OpenSecurityMenu
    L0_3()
  end
  L5_2.onSelect = L6_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L0_2[4] = L4_2
  L0_2[5] = L5_2
  L1_2 = lib
  L1_2 = L1_2.registerContext
  L2_2 = {}
  L2_2.id = "government_warrant_menu"
  L2_2.title = "Warrant System"
  L2_2.options = L0_2
  L1_2(L2_2)
  L1_2 = lib
  L1_2 = L1_2.showContext
  L2_2 = "government_warrant_menu"
  L1_2(L2_2)
end
OpenWarrantMenu = L3_1
