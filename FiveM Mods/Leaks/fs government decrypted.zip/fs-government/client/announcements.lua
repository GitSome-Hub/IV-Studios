local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = false
L1_1 = CreateThread
function L2_1()
  local L0_2, L1_2, L2_2
  L0_2 = Wait
  L1_2 = 1000
  L0_2(L1_2)
  L0_2 = SendNUIMessage
  L1_2 = {}
  L1_2.action = "setDebugMode"
  L2_2 = Config
  L2_2 = L2_2.Debug
  L1_2.debug = L2_2
  L0_2(L1_2)
end
L1_1(L2_1)
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L0_1
  if L1_2 then
    return
  end
  L1_2 = true
  L0_1 = L1_2
  L1_2 = SendNUIMessage
  L2_2 = {}
  L2_2.action = "showAnnouncement"
  L3_2 = {}
  L4_2 = A0_2.title
  if not L4_2 then
    L4_2 = "Government Announcement"
  end
  L3_2.title = L4_2
  L4_2 = A0_2.message
  if not L4_2 then
    L4_2 = ""
  end
  L3_2.message = L4_2
  L4_2 = A0_2.type
  if not L4_2 then
    L4_2 = "primary"
  end
  L3_2.type = L4_2
  L4_2 = A0_2.duration
  if not L4_2 then
    L4_2 = 8000
  end
  L3_2.duration = L4_2
  L4_2 = A0_2.sound
  if not L4_2 then
    L4_2 = true
  end
  L3_2.sound = L4_2
  L4_2 = A0_2.priority
  if not L4_2 then
    L4_2 = "normal"
  end
  L3_2.priority = L4_2
  L4_2 = A0_2.icon
  if not L4_2 then
    L4_2 = "fas fa-bullhorn"
  end
  L3_2.icon = L4_2
  L4_2 = A0_2.background
  if not L4_2 then
    L4_2 = nil
  end
  L3_2.background = L4_2
  L2_2.data = L3_2
  L1_2(L2_2)
  L1_2 = CreateThread
  function L2_2()
    local L0_3, L1_3
    L0_3 = Wait
    L1_3 = A0_2.duration
    if not L1_3 then
      L1_3 = 8000
    end
    L0_3(L1_3)
    L0_3 = HideAdvancedAnnouncement
    L0_3()
  end
  L1_2(L2_2)
end
ShowAdvancedAnnouncement = L1_1
function L1_1()
  local L0_2, L1_2
  L0_2 = L0_1
  if not L0_2 then
    return
  end
  L0_2 = false
  L0_1 = L0_2
  L0_2 = SendNUIMessage
  L1_2 = {}
  L1_2.action = "hideAnnouncement"
  L0_2(L1_2)
end
HideAdvancedAnnouncement = L1_1
L1_1 = RegisterNetEvent
L2_1 = "fs-government:client:electionAnnouncement"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = ShowAdvancedAnnouncement
  L2_2 = {}
  L2_2.title = "ELECTION UPDATE"
  L3_2 = A0_2.message
  L2_2.message = L3_2
  L2_2.type = "election"
  L2_2.duration = 12000
  L2_2.sound = true
  L2_2.priority = "high"
  L2_2.icon = "fas fa-vote-yea"
  L2_2.background = "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
  L1_2(L2_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "fs-government:client:defconAnnouncement"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = {}
  L1_2[1] = "linear-gradient(135deg, #ff0000 0%, #cc0000 100%)"
  L1_2[2] = "linear-gradient(135deg, #ff6600 0%, #cc5200 100%)"
  L1_2[3] = "linear-gradient(135deg, #ffcc00 0%, #cc9900 100%)"
  L1_2[4] = "linear-gradient(135deg, #00ff00 0%, #00cc00 100%)"
  L1_2[5] = "linear-gradient(135deg, #0066ff 0%, #0052cc 100%)"
  L2_2 = ShowAdvancedAnnouncement
  L3_2 = {}
  L3_2.title = "DEFCON ALERT"
  L4_2 = A0_2.message
  L3_2.message = L4_2
  L3_2.type = "defcon"
  L3_2.duration = 15000
  L3_2.sound = true
  L3_2.priority = "critical"
  L3_2.icon = "fas fa-exclamation-triangle"
  L4_2 = A0_2.level
  L4_2 = L1_2[L4_2]
  if not L4_2 then
    L4_2 = L1_2[5]
  end
  L3_2.background = L4_2
  L2_2(L3_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "fs-government:client:governmentAnnouncement"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = {}
  L2_2 = {}
  L2_2.duration = 6000
  L2_2.sound = false
  L2_2.background = "linear-gradient(135deg, #74b9ff 0%, #0984e3 100%)"
  L1_2.low = L2_2
  L2_2 = {}
  L2_2.duration = 8000
  L2_2.sound = true
  L2_2.background = "linear-gradient(135deg, #00b894 0%, #00a085 100%)"
  L1_2.normal = L2_2
  L2_2 = {}
  L2_2.duration = 12000
  L2_2.sound = true
  L2_2.background = "linear-gradient(135deg, #fdcb6e 0%, #e17055 100%)"
  L1_2.high = L2_2
  L2_2 = {}
  L2_2.duration = 15000
  L2_2.sound = true
  L2_2.background = "linear-gradient(135deg, #e17055 0%, #d63031 100%)"
  L1_2.urgent = L2_2
  L2_2 = A0_2.priority
  L2_2 = L1_2[L2_2]
  if not L2_2 then
    L2_2 = L1_2.normal
  end
  L3_2 = ShowAdvancedAnnouncement
  L4_2 = {}
  L5_2 = A0_2.title
  if not L5_2 then
    L5_2 = "GOVERNMENT ANNOUNCEMENT"
  end
  L4_2.title = L5_2
  L5_2 = A0_2.message
  L4_2.message = L5_2
  L4_2.type = "government"
  L5_2 = L2_2.duration
  L4_2.duration = L5_2
  L5_2 = L2_2.sound
  L4_2.sound = L5_2
  L5_2 = A0_2.priority
  L4_2.priority = L5_2
  L4_2.icon = "fas fa-bullhorn"
  L5_2 = L2_2.background
  L4_2.background = L5_2
  L3_2(L4_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "fs-government:client:emergencyAnnouncement"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = ShowAdvancedAnnouncement
  L2_2 = {}
  L2_2.title = "EMERGENCY ALERT"
  L3_2 = A0_2.message
  L2_2.message = L3_2
  L2_2.type = "emergency"
  L2_2.duration = 20000
  L2_2.sound = true
  L2_2.priority = "critical"
  L2_2.icon = "fas fa-exclamation-circle"
  L2_2.background = "linear-gradient(135deg, #d63031 0%, #74b9ff 100%)"
  L1_2(L2_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "fs-government:client:showAdvancedAnnouncement"
function L3_1(A0_2)
  local L1_2, L2_2
  L1_2 = ShowAdvancedAnnouncement
  L2_2 = A0_2
  L1_2(L2_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "fs-government:client:lawEnforcementAnnouncement"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = ShowAdvancedAnnouncement
  L2_2 = {}
  L2_2.title = "LAW ENFORCEMENT NOTICE"
  L3_2 = A0_2.message
  L2_2.message = L3_2
  L2_2.type = "law_enforcement"
  L2_2.duration = 10000
  L2_2.sound = true
  L2_2.priority = "high"
  L2_2.icon = "fas fa-shield-alt"
  L2_2.background = "linear-gradient(135deg, #2d3436 0%, #636e72 100%)"
  L1_2(L2_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "fs-government:client:publicServiceAnnouncement"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = ShowAdvancedAnnouncement
  L2_2 = {}
  L2_2.title = "PUBLIC SERVICE ANNOUNCEMENT"
  L3_2 = A0_2.message
  L2_2.message = L3_2
  L2_2.type = "public_service"
  L2_2.duration = 10000
  L2_2.sound = false
  L2_2.priority = "normal"
  L2_2.icon = "fas fa-info-circle"
  L2_2.background = "linear-gradient(135deg, #00b894 0%, #55a3ff 100%)"
  L1_2(L2_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "fs-government:client:seizureAnnouncement"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = {}
  L2_2 = {}
  L2_2.background = "linear-gradient(135deg, #00b894 0%, #00a085 100%)"
  L2_2.icon = "fas fa-check-circle"
  L2_2.sound = true
  L1_2.success = L2_2
  L2_2 = {}
  L2_2.background = "linear-gradient(135deg, #e17055 0%, #d63031 100%)"
  L2_2.icon = "fas fa-exclamation-circle"
  L2_2.sound = true
  L1_2.error = L2_2
  L2_2 = {}
  L2_2.background = "linear-gradient(135deg, #74b9ff 0%, #0984e3 100%)"
  L2_2.icon = "fas fa-info-circle"
  L2_2.sound = false
  L1_2.primary = L2_2
  L2_2 = A0_2.type
  L2_2 = L1_2[L2_2]
  if not L2_2 then
    L2_2 = L1_2.primary
  end
  L3_2 = ShowAdvancedAnnouncement
  L4_2 = {}
  L4_2.title = "GOVERNMENT SEIZURE"
  L5_2 = A0_2.message
  L4_2.message = L5_2
  L4_2.type = "seizure"
  L5_2 = A0_2.duration
  if not L5_2 then
    L5_2 = 8000
  end
  L4_2.duration = L5_2
  L5_2 = L2_2.sound
  L4_2.sound = L5_2
  L4_2.priority = "high"
  L5_2 = L2_2.icon
  L4_2.icon = L5_2
  L5_2 = L2_2.background
  L4_2.background = L5_2
  L3_2(L4_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "fs-government:client:warrantAnnouncement"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = {}
  L2_2 = {}
  L2_2.background = "linear-gradient(135deg, #00b894 0%, #00a085 100%)"
  L2_2.icon = "fas fa-gavel"
  L2_2.sound = true
  L1_2.success = L2_2
  L2_2 = {}
  L2_2.background = "linear-gradient(135deg, #e17055 0%, #d63031 100%)"
  L2_2.icon = "fas fa-exclamation-triangle"
  L2_2.sound = true
  L1_2.error = L2_2
  L2_2 = {}
  L2_2.background = "linear-gradient(135deg, #6c5ce7 0%, #a29bfe 100%)"
  L2_2.icon = "fas fa-balance-scale"
  L2_2.sound = false
  L1_2.primary = L2_2
  L2_2 = A0_2.type
  L2_2 = L1_2[L2_2]
  if not L2_2 then
    L2_2 = L1_2.primary
  end
  L3_2 = ShowAdvancedAnnouncement
  L4_2 = {}
  L4_2.title = "WARRANT SYSTEM"
  L5_2 = A0_2.message
  L4_2.message = L5_2
  L4_2.type = "warrant"
  L5_2 = A0_2.duration
  if not L5_2 then
    L5_2 = 8000
  end
  L4_2.duration = L5_2
  L5_2 = L2_2.sound
  L4_2.sound = L5_2
  L4_2.priority = "high"
  L5_2 = L2_2.icon
  L4_2.icon = L5_2
  L5_2 = L2_2.background
  L4_2.background = L5_2
  L3_2(L4_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "closeAnnouncement"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = HideAdvancedAnnouncement
  L2_2()
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L1_1(L2_1, L3_1)
L1_1 = Config
L1_1 = L1_1.Debug
if L1_1 then
  L1_1 = RegisterCommand
  L2_1 = "testannouncement"
  function L3_1(A0_2, A1_2, A2_2)
    local L3_2, L4_2, L5_2, L6_2
    L3_2 = A1_2[1]
    if not L3_2 then
      L3_2 = "government"
    end
    if "election" == L3_2 then
      L4_2 = TriggerEvent
      L5_2 = "fs-government:client:electionAnnouncement"
      L6_2 = {}
      L6_2.message = "New election has started! Registration is now open at City Hall."
      L4_2(L5_2, L6_2)
    elseif "defcon" == L3_2 then
      L4_2 = TriggerEvent
      L5_2 = "fs-government:client:defconAnnouncement"
      L6_2 = {}
      L6_2.message = "DEFCON level has been changed to Level 2 - High Alert"
      L6_2.level = 2
      L4_2(L5_2, L6_2)
    elseif "emergency" == L3_2 then
      L4_2 = TriggerEvent
      L5_2 = "fs-government:client:emergencyAnnouncement"
      L6_2 = {}
      L6_2.message = "City-wide emergency declared. All citizens should remain indoors until further notice."
      L4_2(L5_2, L6_2)
    elseif "warrant" == L3_2 then
      L4_2 = TriggerEvent
      L5_2 = "fs-government:client:warrantAnnouncement"
      L6_2 = {}
      L6_2.message = "\226\154\150\239\184\143 WARRANT ISSUED: John Doe - Armed Robbery | Reason: Suspect robbed First National Bank at gunpoint (WAR-12345)"
      L6_2.type = "primary"
      L4_2(L5_2, L6_2)
    elseif "warrant_execute" == L3_2 then
      L4_2 = TriggerEvent
      L5_2 = "fs-government:client:warrantAnnouncement"
      L6_2 = {}
      L6_2.message = "\226\154\150\239\184\143 WARRANT EXECUTED: John Doe - Armed Robbery | Executed by: Officer Smith (WAR-12345)"
      L6_2.type = "success"
      L4_2(L5_2, L6_2)
    elseif "warrant_close" == L3_2 then
      L4_2 = TriggerEvent
      L5_2 = "fs-government:client:warrantAnnouncement"
      L6_2 = {}
      L6_2.message = "\226\154\150\239\184\143 WARRANT CLOSED: John Doe - Armed Robbery | Reason: Case resolved - suspect apprehended"
      L6_2.type = "primary"
      L4_2(L5_2, L6_2)
    elseif "seizure" == L3_2 then
      L4_2 = TriggerEvent
      L5_2 = "fs-government:client:seizureAnnouncement"
      L6_2 = {}
      L6_2.message = "\240\159\154\148 GOVERNMENT SEIZURE: 5x weapon_pistol seized from Jane Smith"
      L6_2.type = "primary"
      L4_2(L5_2, L6_2)
    else
      L4_2 = TriggerEvent
      L5_2 = "fs-government:client:governmentAnnouncement"
      L6_2 = {}
      L6_2.title = "Test Announcement"
      L6_2.message = "This is a test announcement from the government system."
      L6_2.priority = "normal"
      L4_2(L5_2, L6_2)
    end
  end
  L4_1 = false
  L1_1(L2_1, L3_1, L4_1)
end
