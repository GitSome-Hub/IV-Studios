local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1, L18_1, L19_1, L20_1, L21_1, L22_1, L23_1
L0_1 = {}
L1_1 = false
L2_1 = 0
L3_1 = false
L4_1 = nil
L5_1 = {}
L6_1 = {}
L7_1 = {}
L8_1 = false
L9_1 = CreateThread
function L10_1()
  local L0_2, L1_2, L2_2
  while true do
    L0_2 = L0_1
    if L0_2 then
      L0_2 = IsControlJustPressed
      L1_2 = 0
      L2_2 = 167
      L0_2 = L0_2(L1_2, L2_2)
      if L0_2 then
        L0_2 = L1_1
        if L0_2 then
          L0_2 = Config
          L0_2 = L0_2.Debug
          if L0_2 then
            L0_2 = Utils
            L0_2 = L0_2.DebugPrint
            L1_2 = "F6 pressed - Opening field operations menu"
            L0_2(L1_2)
          end
          L0_2 = menuOpen
          if L0_2 then
            L0_2 = Framework
            L0_2 = L0_2.ShowNotification
            L1_2 = "Menu already open"
            L2_2 = "error"
            L0_2(L1_2, L2_2)
          else
            menuOpen = true
            currentMenuContext = "government_field_operations"
            L0_2 = OpenFieldOperationsMenu
            L0_2()
          end
        else
          L0_2 = Config
          L0_2 = L0_2.Debug
          if L0_2 then
            L0_2 = Utils
            L0_2 = L0_2.DebugPrint
            L1_2 = "F6 pressed - Access denied (not government employee)"
            L0_2(L1_2)
          end
          L0_2 = L0_1.job
          if L0_2 then
            L0_2 = Framework
            L0_2 = L0_2.ShowNotification
            L1_2 = "Access denied - Not a government employee"
            L2_2 = "error"
            L0_2(L1_2, L2_2)
          end
        end
      end
      L0_2 = Wait
      L1_2 = 0
      L0_2(L1_2)
    else
      L0_2 = Wait
      L1_2 = 1000
      L0_2(L1_2)
    end
  end
end
L9_1(L10_1)
L9_1 = CreateThread
function L10_1()
  local L0_2, L1_2, L2_2, L3_2
  while true do
    L0_2 = Framework
    L0_2 = L0_2.GetPlayerData
    L0_2 = L0_2()
    L0_1 = L0_2
    L0_2 = L1_1
    L1_2 = L0_1
    if L1_2 then
      L1_2 = L0_1.job
      if L1_2 then
        L1_2 = L0_1.job
        L1_2 = L1_2.name
        if L1_2 then
          L1_2 = Utils
          L1_2 = L1_2.TableContains
          L2_2 = Config
          L2_2 = L2_2.Government
          L2_2 = L2_2.jobs
          L3_2 = L0_1.job
          L3_2 = L3_2.name
          L1_2 = L1_2(L2_2, L3_2)
          L1_1 = L1_2
          L1_2 = L0_1.job
          L1_2 = L1_2.grade
          if L1_2 then
            L1_2 = type
            L2_2 = L0_1.job
            L2_2 = L2_2.grade
            L1_2 = L1_2(L2_2)
            if "table" == L1_2 then
              L1_2 = L0_1.job
              L1_2 = L1_2.grade
              L1_2 = L1_2.level
              if not L1_2 then
                L1_2 = 0
              end
              L2_1 = L1_2
            else
              L1_2 = L0_1.job
              L1_2 = L1_2.grade
              L2_1 = L1_2
            end
          else
            L1_2 = 0
            L2_1 = L1_2
          end
      end
    end
    else
      L1_2 = false
      L1_1 = L1_2
      L1_2 = 0
      L2_1 = L1_2
    end
    L1_2 = L1_1
    if L0_2 ~= L1_2 then
      L1_2 = L1_1
      if L1_2 then
        L1_2 = SetupGovernmentAccess
        L1_2()
      else
        L1_2 = RemoveGovernmentAccess
        L1_2()
      end
    end
    L1_2 = Wait
    L2_2 = 5000
    L1_2(L2_2)
  end
end
L9_1(L10_1)
function L9_1()
  local L0_2, L1_2
  L0_2 = RemoveGovernmentAccess
  L0_2()
  L0_2 = CreateGovernmentBlip
  L0_2()
  L0_2 = SetupTargetZones
  L0_2()
  L0_2 = Utils
  L0_2 = L0_2.DebugPrint
  L1_2 = "Government access granted"
  L0_2(L1_2)
end
SetupGovernmentAccess = L9_1
function L9_1()
  local L0_2, L1_2
  L0_2 = RemoveGovernmentBlip
  L0_2()
  L0_2 = RemoveTargetZones
  L0_2()
  L0_2 = RemoveElectionAccess
  L0_2()
  L0_2 = Utils
  L0_2 = L0_2.DebugPrint
  L1_2 = "Government access removed"
  L0_2(L1_2)
end
RemoveGovernmentAccess = L9_1
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L0_2 = L8_1
  if not L0_2 then
    return
  end
  L0_2 = RemoveElectionAccess
  L0_2()
  L0_2 = ipairs
  L1_2 = Config
  L1_2 = L1_2.Elections
  L1_2 = L1_2.registration_locations
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = L5_2.blip
    L6_2 = L6_2.enabled
    if L6_2 then
      L6_2 = AddBlipForCoord
      L7_2 = L5_2.coords
      L6_2 = L6_2(L7_2)
      L7_2 = SetBlipSprite
      L8_2 = L6_2
      L9_2 = L5_2.blip
      L9_2 = L9_2.sprite
      L7_2(L8_2, L9_2)
      L7_2 = SetBlipDisplay
      L8_2 = L6_2
      L9_2 = 4
      L7_2(L8_2, L9_2)
      L7_2 = SetBlipScale
      L8_2 = L6_2
      L9_2 = L5_2.blip
      L9_2 = L9_2.scale
      L7_2(L8_2, L9_2)
      L7_2 = SetBlipColour
      L8_2 = L6_2
      L9_2 = L5_2.blip
      L9_2 = L9_2.color
      L7_2(L8_2, L9_2)
      L7_2 = SetBlipAsShortRange
      L8_2 = L6_2
      L9_2 = true
      L7_2(L8_2, L9_2)
      L7_2 = BeginTextCommandSetBlipName
      L8_2 = "STRING"
      L7_2(L8_2)
      L7_2 = AddTextComponentSubstringPlayerName
      L8_2 = L5_2.blip
      L8_2 = L8_2.label
      L7_2(L8_2)
      L7_2 = EndTextCommandSetBlipName
      L8_2 = L6_2
      L7_2(L8_2)
      L7_2 = table
      L7_2 = L7_2.insert
      L8_2 = L6_1
      L9_2 = L6_2
      L7_2(L8_2, L9_2)
    end
  end
  L0_2 = ipairs
  L1_2 = Config
  L1_2 = L1_2.Elections
  L1_2 = L1_2.voting_locations
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = L5_2.blip
    L6_2 = L6_2.enabled
    if L6_2 then
      L6_2 = AddBlipForCoord
      L7_2 = L5_2.coords
      L6_2 = L6_2(L7_2)
      L7_2 = SetBlipSprite
      L8_2 = L6_2
      L9_2 = L5_2.blip
      L9_2 = L9_2.sprite
      L7_2(L8_2, L9_2)
      L7_2 = SetBlipDisplay
      L8_2 = L6_2
      L9_2 = 4
      L7_2(L8_2, L9_2)
      L7_2 = SetBlipScale
      L8_2 = L6_2
      L9_2 = L5_2.blip
      L9_2 = L9_2.scale
      L7_2(L8_2, L9_2)
      L7_2 = SetBlipColour
      L8_2 = L6_2
      L9_2 = L5_2.blip
      L9_2 = L9_2.color
      L7_2(L8_2, L9_2)
      L7_2 = SetBlipAsShortRange
      L8_2 = L6_2
      L9_2 = true
      L7_2(L8_2, L9_2)
      L7_2 = BeginTextCommandSetBlipName
      L8_2 = "STRING"
      L7_2(L8_2)
      L7_2 = AddTextComponentSubstringPlayerName
      L8_2 = L5_2.blip
      L8_2 = L8_2.label
      L7_2(L8_2)
      L7_2 = EndTextCommandSetBlipName
      L8_2 = L6_2
      L7_2(L8_2)
      L7_2 = table
      L7_2 = L7_2.insert
      L8_2 = L6_1
      L9_2 = L6_2
      L7_2(L8_2, L9_2)
    end
  end
  L0_2 = SetupElectionTargetZones
  L0_2()
end
SetupElectionAccess = L9_1
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = ipairs
  L1_2 = L6_1
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = DoesBlipExist
    L7_2 = L5_2
    L6_2 = L6_2(L7_2)
    if L6_2 then
      L6_2 = RemoveBlip
      L7_2 = L5_2
      L6_2(L7_2)
    end
  end
  L0_2 = {}
  L6_1 = L0_2
  L0_2 = RemoveElectionTargetZones
  L0_2()
end
RemoveElectionAccess = L9_1
function L9_1()
  local L0_2, L1_2, L2_2
  L0_2 = L4_1
  if L0_2 then
    return
  end
  L0_2 = AddBlipForCoord
  L1_2 = Config
  L1_2 = L1_2.Locations
  L1_2 = L1_2.government
  L1_2 = L1_2.coords
  L0_2 = L0_2(L1_2)
  L4_1 = L0_2
  L0_2 = SetBlipSprite
  L1_2 = L4_1
  L2_2 = Config
  L2_2 = L2_2.Locations
  L2_2 = L2_2.government
  L2_2 = L2_2.blip
  L2_2 = L2_2.sprite
  L0_2(L1_2, L2_2)
  L0_2 = SetBlipDisplay
  L1_2 = L4_1
  L2_2 = 4
  L0_2(L1_2, L2_2)
  L0_2 = SetBlipScale
  L1_2 = L4_1
  L2_2 = Config
  L2_2 = L2_2.Locations
  L2_2 = L2_2.government
  L2_2 = L2_2.blip
  L2_2 = L2_2.scale
  L0_2(L1_2, L2_2)
  L0_2 = SetBlipColour
  L1_2 = L4_1
  L2_2 = Config
  L2_2 = L2_2.Locations
  L2_2 = L2_2.government
  L2_2 = L2_2.blip
  L2_2 = L2_2.color
  L0_2(L1_2, L2_2)
  L0_2 = SetBlipAsShortRange
  L1_2 = L4_1
  L2_2 = true
  L0_2(L1_2, L2_2)
  L0_2 = BeginTextCommandSetBlipName
  L1_2 = "STRING"
  L0_2(L1_2)
  L0_2 = AddTextComponentSubstringPlayerName
  L1_2 = Config
  L1_2 = L1_2.Locations
  L1_2 = L1_2.government
  L1_2 = L1_2.blip
  L1_2 = L1_2.label
  L0_2(L1_2)
  L0_2 = EndTextCommandSetBlipName
  L1_2 = L4_1
  L0_2(L1_2)
end
CreateGovernmentBlip = L9_1
function L9_1()
  local L0_2, L1_2
  L0_2 = L4_1
  if L0_2 then
    L0_2 = RemoveBlip
    L1_2 = L4_1
    L0_2(L1_2)
    L0_2 = nil
    L4_1 = L0_2
  end
end
RemoveGovernmentBlip = L9_1
function L9_1()
  local L0_2, L1_2
  L0_2 = GetResourceState
  L1_2 = "ox_target"
  L0_2 = L0_2(L1_2)
  if "started" == L0_2 then
    L0_2 = SetupOxTargetZones
    L0_2()
  else
    L0_2 = GetResourceState
    L1_2 = "qb-target"
    L0_2 = L0_2(L1_2)
    if "started" == L0_2 then
      L0_2 = SetupQBTargetZones
      L0_2()
    else
      L0_2 = CreateThread
      L1_2 = CheckMarkerDistance
      L0_2(L1_2)
    end
  end
end
SetupTargetZones = L9_1
function L9_1()
  local L0_2, L1_2
  L0_2 = GetResourceState
  L1_2 = "ox_target"
  L0_2 = L0_2(L1_2)
  if "started" == L0_2 then
    L0_2 = SetupOxElectionTargetZones
    L0_2()
  else
    L0_2 = GetResourceState
    L1_2 = "qb-target"
    L0_2 = L0_2(L1_2)
    if "started" == L0_2 then
      L0_2 = SetupQBElectionTargetZones
      L0_2()
    else
      L0_2 = CreateThread
      L1_2 = CheckElectionMarkerDistance
      L0_2(L1_2)
    end
  end
end
SetupElectionTargetZones = L9_1
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L0_2 = {}
  L5_1 = L0_2
  L0_2 = exports
  L0_2 = L0_2.ox_target
  L1_2 = L0_2
  L0_2 = L0_2.addBoxZone
  L2_2 = {}
  L3_2 = Config
  L3_2 = L3_2.Locations
  L3_2 = L3_2.armory
  L3_2 = L3_2.coords
  L2_2.coords = L3_2
  L3_2 = vector3
  L4_2 = 2
  L5_2 = 2
  L6_2 = 2
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L2_2.size = L3_2
  L2_2.rotation = 45
  L3_2 = {}
  L4_2 = {}
  L4_2.name = "government_armory"
  L4_2.icon = "fas fa-gun"
  L4_2.label = "Access Armory"
  function L5_2()
    local L0_3, L1_3
    L0_3 = OpenArmoryMenu
    L0_3()
  end
  L4_2.onSelect = L5_2
  function L5_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = L1_1
    if L0_3 then
      L0_3 = Utils
      L0_3 = L0_3.HasPermission
      L1_3 = L0_1.job
      L1_3 = L1_3.name
      L2_3 = L2_1
      L3_3 = "armory_access"
      L0_3 = L0_3(L1_3, L2_3, L3_3)
    end
    return L0_3
  end
  L4_2.canInteract = L5_2
  L3_2[1] = L4_2
  L2_2.options = L3_2
  L0_2 = L0_2(L1_2, L2_2)
  L1_2 = table
  L1_2 = L1_2.insert
  L2_2 = L5_1
  L3_2 = L0_2
  L1_2(L2_2, L3_2)
  L1_2 = exports
  L1_2 = L1_2.ox_target
  L2_2 = L1_2
  L1_2 = L1_2.addBoxZone
  L3_2 = {}
  L4_2 = Config
  L4_2 = L4_2.Locations
  L4_2 = L4_2.stash
  L4_2 = L4_2.coords
  L3_2.coords = L4_2
  L4_2 = vector3
  L5_2 = 2
  L6_2 = 2
  L7_2 = 2
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  L3_2.size = L4_2
  L3_2.rotation = 45
  L4_2 = {}
  L5_2 = {}
  L5_2.name = "government_stash"
  L5_2.icon = "fas fa-box"
  L5_2.label = "Access Storage"
  function L6_2()
    local L0_3, L1_3
    L0_3 = Inventory
    L0_3 = L0_3.OpenStash
    L1_3 = "government_storage"
    L0_3(L1_3)
  end
  L5_2.onSelect = L6_2
  function L6_2()
    local L0_3, L1_3
    L0_3 = L1_1
    return L0_3
  end
  L5_2.canInteract = L6_2
  L4_2[1] = L5_2
  L3_2.options = L4_2
  L1_2 = L1_2(L2_2, L3_2)
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L5_1
  L4_2 = L1_2
  L2_2(L3_2, L4_2)
  L2_2 = exports
  L2_2 = L2_2.ox_target
  L3_2 = L2_2
  L2_2 = L2_2.addBoxZone
  L4_2 = {}
  L5_2 = Config
  L5_2 = L5_2.Locations
  L5_2 = L5_2.garage
  L5_2 = L5_2.coords
  L4_2.coords = L5_2
  L5_2 = vector3
  L6_2 = 6
  L7_2 = 6
  L8_2 = 3
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  L4_2.size = L5_2
  L4_2.rotation = 0
  L5_2 = {}
  L6_2 = {}
  L6_2.name = "government_garage"
  L6_2.icon = "fas fa-car"
  L6_2.label = "Access Vehicle Garage"
  function L7_2()
    local L0_3, L1_3
    L0_3 = OpenGarageMenu
    L0_3()
  end
  L6_2.onSelect = L7_2
  function L7_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
    L0_3 = L1_1
    if not L0_3 then
      L0_3 = false
      return L0_3
    end
    L0_3 = Framework
    L0_3 = L0_3.GetPlayerData
    L0_3 = L0_3()
    if L0_3 then
      L1_3 = L0_3.job
      if L1_3 then
        goto lbl_16
      end
    end
    L1_3 = false
    do return L1_3 end
    ::lbl_16::
    L1_3 = type
    L2_3 = L0_3.job
    L2_3 = L2_3.grade
    L1_3 = L1_3(L2_3)
    if "table" == L1_3 then
      L1_3 = L0_3.job
      L1_3 = L1_3.grade
      L1_3 = L1_3.level
      if L1_3 then
        goto lbl_32
      end
    end
    L1_3 = L0_3.job
    L1_3 = L1_3.grade
    if not L1_3 then
      L1_3 = 0
    end
    ::lbl_32::
    L2_3 = Utils
    L2_3 = L2_3.HasPermission
    L3_3 = L0_3.job
    L3_3 = L3_3.name
    L4_3 = L1_3
    L5_3 = "garage_access"
    return L2_3(L3_3, L4_3, L5_3)
  end
  L6_2.canInteract = L7_2
  L5_2[1] = L6_2
  L4_2.options = L5_2
  L2_2 = L2_2(L3_2, L4_2)
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = L5_1
  L5_2 = L2_2
  L3_2(L4_2, L5_2)
  L3_2 = exports
  L3_2 = L3_2.ox_target
  L4_2 = L3_2
  L3_2 = L3_2.addBoxZone
  L5_2 = {}
  L6_2 = Config
  L6_2 = L6_2.Locations
  L6_2 = L6_2.boss_actions
  L6_2 = L6_2.coords
  L5_2.coords = L6_2
  L6_2 = vector3
  L7_2 = 2
  L8_2 = 2
  L9_2 = 2
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  L5_2.size = L6_2
  L5_2.rotation = 45
  L6_2 = {}
  L7_2 = {}
  L7_2.name = "government_boss"
  L7_2.icon = "fas fa-crown"
  L7_2.label = "Boss Actions"
  function L8_2()
    local L0_3, L1_3
    L0_3 = OpenBossMenu
    L0_3()
  end
  L7_2.onSelect = L8_2
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = L1_1
    if L0_3 then
      L0_3 = Utils
      L0_3 = L0_3.HasPermission
      L1_3 = L0_1.job
      L1_3 = L1_3.name
      L2_3 = L2_1
      L3_3 = "employee_management"
      L0_3 = L0_3(L1_3, L2_3, L3_3)
    end
    return L0_3
  end
  L7_2.canInteract = L8_2
  L6_2[1] = L7_2
  L5_2.options = L6_2
  L3_2 = L3_2(L4_2, L5_2)
  L4_2 = table
  L4_2 = L4_2.insert
  L5_2 = L5_1
  L6_2 = L3_2
  L4_2(L5_2, L6_2)
  L4_2 = exports
  L4_2 = L4_2.ox_target
  L5_2 = L4_2
  L4_2 = L4_2.addBoxZone
  L6_2 = {}
  L7_2 = Config
  L7_2 = L7_2.Locations
  L7_2 = L7_2.surveillance
  L7_2 = L7_2.coords
  L6_2.coords = L7_2
  L7_2 = vector3
  L8_2 = 2
  L9_2 = 2
  L10_2 = 2
  L7_2 = L7_2(L8_2, L9_2, L10_2)
  L6_2.size = L7_2
  L6_2.rotation = 45
  L7_2 = {}
  L8_2 = {}
  L8_2.name = "government_surveillance"
  L8_2.icon = "fas fa-video"
  L8_2.label = "Surveillance System"
  function L9_2()
    local L0_3, L1_3
    L0_3 = OpenSurveillanceMenu
    L0_3()
  end
  L8_2.onSelect = L9_2
  function L9_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = L1_1
    if L0_3 then
      L0_3 = Utils
      L0_3 = L0_3.HasPermission
      L1_3 = L0_1.job
      L1_3 = L1_3.name
      L2_3 = L2_1
      L3_3 = "surveillance"
      L0_3 = L0_3(L1_3, L2_3, L3_3)
    end
    return L0_3
  end
  L8_2.canInteract = L9_2
  L7_2[1] = L8_2
  L6_2.options = L7_2
  L4_2 = L4_2(L5_2, L6_2)
  L5_2 = table
  L5_2 = L5_2.insert
  L6_2 = L5_1
  L7_2 = L4_2
  L5_2(L6_2, L7_2)
end
SetupOxTargetZones = L9_1
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L0_2 = exports
  L0_2 = L0_2["qb-target"]
  L1_2 = L0_2
  L0_2 = L0_2.AddBoxZone
  L2_2 = "government_armory"
  L3_2 = Config
  L3_2 = L3_2.Locations
  L3_2 = L3_2.armory
  L3_2 = L3_2.coords
  L4_2 = 2.0
  L5_2 = 2.0
  L6_2 = {}
  L6_2.name = "government_armory"
  L6_2.heading = 0
  L6_2.debugPoly = false
  L7_2 = Config
  L7_2 = L7_2.Locations
  L7_2 = L7_2.armory
  L7_2 = L7_2.coords
  L7_2 = L7_2.z
  L7_2 = L7_2 - 1
  L6_2.minZ = L7_2
  L7_2 = Config
  L7_2 = L7_2.Locations
  L7_2 = L7_2.armory
  L7_2 = L7_2.coords
  L7_2 = L7_2.z
  L7_2 = L7_2 + 1
  L6_2.maxZ = L7_2
  L7_2 = {}
  L8_2 = {}
  L9_2 = {}
  L9_2.type = "client"
  L9_2.event = "fs-government:client:openArmoryMenu"
  L9_2.icon = "fas fa-gun"
  L9_2.label = "Access Armory"
  function L10_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = L1_1
    if L0_3 then
      L0_3 = Utils
      L0_3 = L0_3.HasPermission
      L1_3 = L0_1.job
      L1_3 = L1_3.name
      L2_3 = L2_1
      L3_3 = "armory_access"
      L0_3 = L0_3(L1_3, L2_3, L3_3)
    end
    return L0_3
  end
  L9_2.canInteract = L10_2
  L8_2[1] = L9_2
  L7_2.options = L8_2
  L7_2.distance = 2.5
  L0_2(L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
  L0_2 = exports
  L0_2 = L0_2["qb-target"]
  L1_2 = L0_2
  L0_2 = L0_2.AddBoxZone
  L2_2 = "government_stash"
  L3_2 = Config
  L3_2 = L3_2.Locations
  L3_2 = L3_2.stash
  L3_2 = L3_2.coords
  L4_2 = 2.0
  L5_2 = 2.0
  L6_2 = {}
  L6_2.name = "government_stash"
  L6_2.heading = 0
  L6_2.debugPoly = false
  L7_2 = Config
  L7_2 = L7_2.Locations
  L7_2 = L7_2.stash
  L7_2 = L7_2.coords
  L7_2 = L7_2.z
  L7_2 = L7_2 - 1
  L6_2.minZ = L7_2
  L7_2 = Config
  L7_2 = L7_2.Locations
  L7_2 = L7_2.stash
  L7_2 = L7_2.coords
  L7_2 = L7_2.z
  L7_2 = L7_2 + 1
  L6_2.maxZ = L7_2
  L7_2 = {}
  L8_2 = {}
  L9_2 = {}
  L9_2.type = "client"
  L9_2.event = "fs-government:client:openStash"
  L9_2.icon = "fas fa-box"
  L9_2.label = "Access Storage"
  function L10_2()
    local L0_3, L1_3
    L0_3 = L1_1
    return L0_3
  end
  L9_2.canInteract = L10_2
  L8_2[1] = L9_2
  L7_2.options = L8_2
  L7_2.distance = 2.5
  L0_2(L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
  L0_2 = exports
  L0_2 = L0_2["qb-target"]
  L1_2 = L0_2
  L0_2 = L0_2.AddBoxZone
  L2_2 = "government_garage"
  L3_2 = Config
  L3_2 = L3_2.Locations
  L3_2 = L3_2.garage
  L3_2 = L3_2.coords
  L4_2 = 4.0
  L5_2 = 4.0
  L6_2 = {}
  L6_2.name = "government_garage"
  L6_2.heading = 0
  L6_2.debugPoly = false
  L7_2 = Config
  L7_2 = L7_2.Locations
  L7_2 = L7_2.garage
  L7_2 = L7_2.coords
  L7_2 = L7_2.z
  L7_2 = L7_2 - 1
  L6_2.minZ = L7_2
  L7_2 = Config
  L7_2 = L7_2.Locations
  L7_2 = L7_2.garage
  L7_2 = L7_2.coords
  L7_2 = L7_2.z
  L7_2 = L7_2 + 1
  L6_2.maxZ = L7_2
  L7_2 = {}
  L8_2 = {}
  L9_2 = {}
  L9_2.type = "client"
  L9_2.event = "fs-government:client:openGarageMenu"
  L9_2.icon = "fas fa-car"
  L9_2.label = "Access Vehicle Garage"
  function L10_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
    L0_3 = L1_1
    if not L0_3 then
      L0_3 = false
      return L0_3
    end
    L0_3 = Framework
    L0_3 = L0_3.GetPlayerData
    L0_3 = L0_3()
    if L0_3 then
      L1_3 = L0_3.job
      if L1_3 then
        goto lbl_16
      end
    end
    L1_3 = false
    do return L1_3 end
    ::lbl_16::
    L1_3 = type
    L2_3 = L0_3.job
    L2_3 = L2_3.grade
    L1_3 = L1_3(L2_3)
    if "table" == L1_3 then
      L1_3 = L0_3.job
      L1_3 = L1_3.grade
      L1_3 = L1_3.level
      if L1_3 then
        goto lbl_32
      end
    end
    L1_3 = L0_3.job
    L1_3 = L1_3.grade
    if not L1_3 then
      L1_3 = 0
    end
    ::lbl_32::
    L2_3 = Utils
    L2_3 = L2_3.HasPermission
    L3_3 = L0_3.job
    L3_3 = L3_3.name
    L4_3 = L1_3
    L5_3 = "garage_access"
    return L2_3(L3_3, L4_3, L5_3)
  end
  L9_2.canInteract = L10_2
  L8_2[1] = L9_2
  L7_2.options = L8_2
  L7_2.distance = 2.5
  L0_2(L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
  L0_2 = exports
  L0_2 = L0_2["qb-target"]
  L1_2 = L0_2
  L0_2 = L0_2.AddBoxZone
  L2_2 = "government_boss"
  L3_2 = Config
  L3_2 = L3_2.Locations
  L3_2 = L3_2.boss_actions
  L3_2 = L3_2.coords
  L4_2 = 2.0
  L5_2 = 2.0
  L6_2 = {}
  L6_2.name = "government_boss"
  L6_2.heading = 0
  L6_2.debugPoly = false
  L7_2 = Config
  L7_2 = L7_2.Locations
  L7_2 = L7_2.boss_actions
  L7_2 = L7_2.coords
  L7_2 = L7_2.z
  L7_2 = L7_2 - 1
  L6_2.minZ = L7_2
  L7_2 = Config
  L7_2 = L7_2.Locations
  L7_2 = L7_2.boss_actions
  L7_2 = L7_2.coords
  L7_2 = L7_2.z
  L7_2 = L7_2 + 1
  L6_2.maxZ = L7_2
  L7_2 = {}
  L8_2 = {}
  L9_2 = {}
  L9_2.type = "client"
  L9_2.event = "fs-government:client:openBossMenu"
  L9_2.icon = "fas fa-crown"
  L9_2.label = "Boss Actions"
  function L10_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = L1_1
    if L0_3 then
      L0_3 = Utils
      L0_3 = L0_3.HasPermission
      L1_3 = L0_1.job
      L1_3 = L1_3.name
      L2_3 = L2_1
      L3_3 = "employee_management"
      L0_3 = L0_3(L1_3, L2_3, L3_3)
    end
    return L0_3
  end
  L9_2.canInteract = L10_2
  L8_2[1] = L9_2
  L7_2.options = L8_2
  L7_2.distance = 2.5
  L0_2(L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
  L0_2 = exports
  L0_2 = L0_2["qb-target"]
  L1_2 = L0_2
  L0_2 = L0_2.AddBoxZone
  L2_2 = "government_surveillance"
  L3_2 = Config
  L3_2 = L3_2.Locations
  L3_2 = L3_2.surveillance
  L3_2 = L3_2.coords
  L4_2 = 2.0
  L5_2 = 2.0
  L6_2 = {}
  L6_2.name = "government_surveillance"
  L6_2.heading = 0
  L6_2.debugPoly = false
  L7_2 = Config
  L7_2 = L7_2.Locations
  L7_2 = L7_2.surveillance
  L7_2 = L7_2.coords
  L7_2 = L7_2.z
  L7_2 = L7_2 - 1
  L6_2.minZ = L7_2
  L7_2 = Config
  L7_2 = L7_2.Locations
  L7_2 = L7_2.surveillance
  L7_2 = L7_2.coords
  L7_2 = L7_2.z
  L7_2 = L7_2 + 1
  L6_2.maxZ = L7_2
  L7_2 = {}
  L8_2 = {}
  L9_2 = {}
  L9_2.type = "client"
  L9_2.event = "fs-government:client:openSurveillanceMenu"
  L9_2.icon = "fas fa-video"
  L9_2.label = "Surveillance System"
  function L10_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = L1_1
    if L0_3 then
      L0_3 = Utils
      L0_3 = L0_3.HasPermission
      L1_3 = L0_1.job
      L1_3 = L1_3.name
      L2_3 = L2_1
      L3_3 = "surveillance"
      L0_3 = L0_3(L1_3, L2_3, L3_3)
    end
    return L0_3
  end
  L9_2.canInteract = L10_2
  L8_2[1] = L9_2
  L7_2.options = L8_2
  L7_2.distance = 2.5
  L0_2(L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
  L0_2 = table
  L0_2 = L0_2.insert
  L1_2 = L5_1
  L2_2 = "government_armory"
  L0_2(L1_2, L2_2)
  L0_2 = table
  L0_2 = L0_2.insert
  L1_2 = L5_1
  L2_2 = "government_stash"
  L0_2(L1_2, L2_2)
  L0_2 = table
  L0_2 = L0_2.insert
  L1_2 = L5_1
  L2_2 = "government_garage"
  L0_2(L1_2, L2_2)
  L0_2 = table
  L0_2 = L0_2.insert
  L1_2 = L5_1
  L2_2 = "government_boss"
  L0_2(L1_2, L2_2)
  L0_2 = table
  L0_2 = L0_2.insert
  L1_2 = L5_1
  L2_2 = "government_surveillance"
  L0_2(L1_2, L2_2)
end
SetupQBTargetZones = L9_1
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L0_2 = {}
  L7_1 = L0_2
  L0_2 = ipairs
  L1_2 = Config
  L1_2 = L1_2.Elections
  L1_2 = L1_2.registration_locations
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = exports
    L6_2 = L6_2.ox_target
    L7_2 = L6_2
    L6_2 = L6_2.addBoxZone
    L8_2 = {}
    L9_2 = L5_2.coords
    L8_2.coords = L9_2
    L9_2 = vector3
    L10_2 = 2
    L11_2 = 2
    L12_2 = 2
    L9_2 = L9_2(L10_2, L11_2, L12_2)
    L8_2.size = L9_2
    L9_2 = L5_2.heading
    L8_2.rotation = L9_2
    L9_2 = {}
    L10_2 = {}
    L11_2 = "election_register_"
    L12_2 = L4_2
    L11_2 = L11_2 .. L12_2
    L10_2.name = L11_2
    L10_2.icon = "fas fa-user-tie"
    L10_2.label = "Register as Candidate"
    function L11_2()
      local L0_3, L1_3
      L0_3 = OpenCandidateRegistrationMenu
      L0_3()
    end
    L10_2.onSelect = L11_2
    function L11_2()
      local L0_3, L1_3
      L0_3 = L8_1
      return L0_3
    end
    L10_2.canInteract = L11_2
    L9_2[1] = L10_2
    L8_2.options = L9_2
    L6_2 = L6_2(L7_2, L8_2)
    L7_2 = table
    L7_2 = L7_2.insert
    L8_2 = L7_1
    L9_2 = L6_2
    L7_2(L8_2, L9_2)
  end
  L0_2 = ipairs
  L1_2 = Config
  L1_2 = L1_2.Elections
  L1_2 = L1_2.voting_locations
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = exports
    L6_2 = L6_2.ox_target
    L7_2 = L6_2
    L6_2 = L6_2.addBoxZone
    L8_2 = {}
    L9_2 = L5_2.coords
    L8_2.coords = L9_2
    L9_2 = vector3
    L10_2 = 2
    L11_2 = 2
    L12_2 = 2
    L9_2 = L9_2(L10_2, L11_2, L12_2)
    L8_2.size = L9_2
    L9_2 = L5_2.heading
    L8_2.rotation = L9_2
    L9_2 = {}
    L10_2 = {}
    L11_2 = "election_vote_"
    L12_2 = L4_2
    L11_2 = L11_2 .. L12_2
    L10_2.name = L11_2
    L10_2.icon = "fas fa-vote-yea"
    L10_2.label = "Cast Vote"
    function L11_2()
      local L0_3, L1_3
      L0_3 = OpenVotingMenu
      L0_3()
    end
    L10_2.onSelect = L11_2
    function L11_2()
      local L0_3, L1_3
      L0_3 = L8_1
      return L0_3
    end
    L10_2.canInteract = L11_2
    L9_2[1] = L10_2
    L8_2.options = L9_2
    L6_2 = L6_2(L7_2, L8_2)
    L7_2 = table
    L7_2 = L7_2.insert
    L8_2 = L7_1
    L9_2 = L6_2
    L7_2(L8_2, L9_2)
  end
end
SetupOxElectionTargetZones = L9_1
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L0_2 = ipairs
  L1_2 = Config
  L1_2 = L1_2.Elections
  L1_2 = L1_2.registration_locations
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = "election_register_"
    L7_2 = L4_2
    L6_2 = L6_2 .. L7_2
    L7_2 = exports
    L7_2 = L7_2["qb-target"]
    L8_2 = L7_2
    L7_2 = L7_2.AddBoxZone
    L9_2 = L6_2
    L10_2 = L5_2.coords
    L11_2 = 2.0
    L12_2 = 2.0
    L13_2 = {}
    L13_2.name = L6_2
    L14_2 = L5_2.heading
    L13_2.heading = L14_2
    L13_2.debugPoly = false
    L14_2 = L5_2.coords
    L14_2 = L14_2.z
    L14_2 = L14_2 - 1
    L13_2.minZ = L14_2
    L14_2 = L5_2.coords
    L14_2 = L14_2.z
    L14_2 = L14_2 + 1
    L13_2.maxZ = L14_2
    L14_2 = {}
    L15_2 = {}
    L16_2 = {}
    L16_2.type = "client"
    L16_2.event = "fs-government:client:openCandidateRegistration"
    L16_2.icon = "fas fa-user-tie"
    L16_2.label = "Register as Candidate"
    function L17_2()
      local L0_3, L1_3
      L0_3 = L8_1
      return L0_3
    end
    L16_2.canInteract = L17_2
    L15_2[1] = L16_2
    L14_2.options = L15_2
    L14_2.distance = 2.5
    L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
    L7_2 = table
    L7_2 = L7_2.insert
    L8_2 = L7_1
    L9_2 = L6_2
    L7_2(L8_2, L9_2)
  end
  L0_2 = ipairs
  L1_2 = Config
  L1_2 = L1_2.Elections
  L1_2 = L1_2.voting_locations
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = "election_vote_"
    L7_2 = L4_2
    L6_2 = L6_2 .. L7_2
    L7_2 = exports
    L7_2 = L7_2["qb-target"]
    L8_2 = L7_2
    L7_2 = L7_2.AddBoxZone
    L9_2 = L6_2
    L10_2 = L5_2.coords
    L11_2 = 2.0
    L12_2 = 2.0
    L13_2 = {}
    L13_2.name = L6_2
    L14_2 = L5_2.heading
    L13_2.heading = L14_2
    L13_2.debugPoly = false
    L14_2 = L5_2.coords
    L14_2 = L14_2.z
    L14_2 = L14_2 - 1
    L13_2.minZ = L14_2
    L14_2 = L5_2.coords
    L14_2 = L14_2.z
    L14_2 = L14_2 + 1
    L13_2.maxZ = L14_2
    L14_2 = {}
    L15_2 = {}
    L16_2 = {}
    L16_2.type = "client"
    L16_2.event = "fs-government:client:openVotingMenu"
    L16_2.icon = "fas fa-vote-yea"
    L16_2.label = "Cast Vote"
    function L17_2()
      local L0_3, L1_3
      L0_3 = L8_1
      return L0_3
    end
    L16_2.canInteract = L17_2
    L15_2[1] = L16_2
    L14_2.options = L15_2
    L14_2.distance = 2.5
    L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
    L7_2 = table
    L7_2 = L7_2.insert
    L8_2 = L7_1
    L9_2 = L6_2
    L7_2(L8_2, L9_2)
  end
end
SetupQBElectionTargetZones = L9_1
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  while true do
    L0_2 = L8_1
    if not L0_2 then
      break
    end
    L0_2 = PlayerPedId
    L0_2 = L0_2()
    L1_2 = GetEntityCoords
    L2_2 = L0_2
    L1_2 = L1_2(L2_2)
    L2_2 = {}
    L3_2 = ipairs
    L4_2 = Config
    L4_2 = L4_2.Elections
    L4_2 = L4_2.registration_locations
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
      L9_2 = table
      L9_2 = L9_2.insert
      L10_2 = L2_2
      L11_2 = {}
      L12_2 = L8_2.coords
      L11_2.pos = L12_2
      L11_2.action = "register"
      L11_2.label = "~g~E~w~ - Register as Candidate"
      L9_2(L10_2, L11_2)
    end
    L3_2 = ipairs
    L4_2 = Config
    L4_2 = L4_2.Elections
    L4_2 = L4_2.voting_locations
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
      L9_2 = table
      L9_2 = L9_2.insert
      L10_2 = L2_2
      L11_2 = {}
      L12_2 = L8_2.coords
      L11_2.pos = L12_2
      L11_2.action = "vote"
      L11_2.label = "~g~E~w~ - Cast Vote"
      L9_2(L10_2, L11_2)
    end
    L3_2 = false
    L4_2 = pairs
    L5_2 = L2_2
    L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
    for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
      L10_2 = Utils
      L10_2 = L10_2.GetDistance
      L11_2 = L1_2
      L12_2 = L9_2.pos
      L10_2 = L10_2(L11_2, L12_2)
      if L10_2 < 2.0 then
        L3_2 = true
        L11_2 = lib
        L11_2 = L11_2.showTextUI
        L12_2 = L9_2.label
        L11_2(L12_2)
        L11_2 = IsControlJustReleased
        L12_2 = 0
        L13_2 = 38
        L11_2 = L11_2(L12_2, L13_2)
        if L11_2 then
          L11_2 = lib
          L11_2 = L11_2.hideTextUI
          L11_2()
          L11_2 = L9_2.action
          if "register" == L11_2 then
            L11_2 = OpenCandidateRegistrationMenu
            L11_2()
            break
          end
          L11_2 = L9_2.action
          if "vote" == L11_2 then
            L11_2 = OpenVotingMenu
            L11_2()
          end
        end
        break
      end
    end
    if not L3_2 then
      L4_2 = lib
      L4_2 = L4_2.hideTextUI
      L4_2()
    end
    L4_2 = Wait
    L5_2 = 0
    L4_2(L5_2)
  end
end
CheckElectionMarkerDistance = L9_1
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L0_2 = pairs
  L1_2 = L7_1
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    if L5_2 then
      L6_2 = GetResourceState
      L7_2 = "ox_target"
      L6_2 = L6_2(L7_2)
      if "started" == L6_2 then
        L6_2 = exports
        L6_2 = L6_2.ox_target
        L7_2 = L6_2
        L6_2 = L6_2.removeZone
        L8_2 = L5_2
        L6_2(L7_2, L8_2)
      else
        L6_2 = GetResourceState
        L7_2 = "qb-target"
        L6_2 = L6_2(L7_2)
        if "started" == L6_2 then
          L6_2 = exports
          L6_2 = L6_2["qb-target"]
          L7_2 = L6_2
          L6_2 = L6_2.RemoveZone
          L8_2 = L5_2
          L6_2(L7_2, L8_2)
        end
      end
    end
  end
  L0_2 = {}
  L7_1 = L0_2
end
RemoveElectionTargetZones = L9_1
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  while true do
    L0_2 = L1_1
    if not L0_2 then
      break
    end
    L0_2 = PlayerPedId
    L0_2 = L0_2()
    L1_2 = GetEntityCoords
    L2_2 = L0_2
    L1_2 = L1_2(L2_2)
    L2_2 = {}
    L3_2 = {}
    L4_2 = Config
    L4_2 = L4_2.Locations
    L4_2 = L4_2.armory
    L4_2 = L4_2.coords
    L3_2.pos = L4_2
    L3_2.action = "armory"
    L3_2.label = "~g~E~w~ - Armory"
    L3_2.permission = "armory_access"
    L4_2 = {}
    L5_2 = Config
    L5_2 = L5_2.Locations
    L5_2 = L5_2.stash
    L5_2 = L5_2.coords
    L4_2.pos = L5_2
    L4_2.action = "stash"
    L4_2.label = "~g~E~w~ - Storage"
    L5_2 = {}
    L6_2 = Config
    L6_2 = L6_2.Locations
    L6_2 = L6_2.garage
    L6_2 = L6_2.coords
    L5_2.pos = L6_2
    L5_2.action = "garage"
    L5_2.label = "~g~E~w~ - Garage"
    L5_2.permission = "garage_access"
    L6_2 = {}
    L7_2 = Config
    L7_2 = L7_2.Locations
    L7_2 = L7_2.boss_actions
    L7_2 = L7_2.coords
    L6_2.pos = L7_2
    L6_2.action = "boss"
    L6_2.label = "~g~E~w~ - Boss Actions"
    L6_2.permission = "employee_management"
    L7_2 = {}
    L8_2 = Config
    L8_2 = L8_2.Locations
    L8_2 = L8_2.surveillance
    L8_2 = L8_2.coords
    L7_2.pos = L8_2
    L7_2.action = "surveillance"
    L7_2.label = "~g~E~w~ - Surveillance"
    L7_2.permission = "surveillance"
    L2_2[1] = L3_2
    L2_2[2] = L4_2
    L2_2[3] = L5_2
    L2_2[4] = L6_2
    L2_2[5] = L7_2
    L3_2 = false
    L4_2 = pairs
    L5_2 = L2_2
    L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
    for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
      L10_2 = Utils
      L10_2 = L10_2.GetDistance
      L11_2 = L1_2
      L12_2 = L9_2.pos
      L10_2 = L10_2(L11_2, L12_2)
      if L10_2 < 2.0 then
        L3_2 = true
        L11_2 = true
        L12_2 = L9_2.permission
        if L12_2 then
          L12_2 = Framework
          L12_2 = L12_2.GetPlayerData
          L12_2 = L12_2()
          if L12_2 then
            L13_2 = L12_2.job
            if L13_2 then
              goto lbl_88
            end
          end
          L11_2 = false
          goto lbl_117
          ::lbl_88::
          L13_2 = L12_2.job
          L13_2 = L13_2.name
          L14_2 = 0
          L15_2 = L12_2.job
          L15_2 = L15_2.grade
          if L15_2 then
            L15_2 = type
            L16_2 = L12_2.job
            L16_2 = L16_2.grade
            L15_2 = L15_2(L16_2)
            if "table" == L15_2 then
              L15_2 = L12_2.job
              L15_2 = L15_2.grade
              L15_2 = L15_2.level
              L14_2 = L15_2 or L14_2
              if not L15_2 then
                L14_2 = 0
              end
            else
              L15_2 = L12_2.job
              L14_2 = L15_2.grade
            end
          end
          L15_2 = Utils
          L15_2 = L15_2.HasPermission
          L16_2 = L13_2
          L17_2 = L14_2
          L18_2 = L9_2.permission
          L15_2 = L15_2(L16_2, L17_2, L18_2)
          L11_2 = L15_2
        end
        ::lbl_117::
        if L11_2 then
          L12_2 = lib
          L12_2 = L12_2.showTextUI
          L13_2 = L9_2.label
          L12_2(L13_2)
          L12_2 = IsControlJustReleased
          L13_2 = 0
          L14_2 = 38
          L12_2 = L12_2(L13_2, L14_2)
          if L12_2 then
            L12_2 = lib
            L12_2 = L12_2.hideTextUI
            L12_2()
            L12_2 = L9_2.action
            if "armory" == L12_2 then
              L12_2 = OpenArmoryMenu
              L12_2()
              break
            end
            L12_2 = L9_2.action
            if "stash" == L12_2 then
              L12_2 = Inventory
              L12_2 = L12_2.OpenStash
              L13_2 = "government_storage"
              L12_2(L13_2)
              break
            end
            L12_2 = L9_2.action
            if "garage" == L12_2 then
              L12_2 = OpenGarageMenu
              L12_2()
              break
            end
            L12_2 = L9_2.action
            if "boss" == L12_2 then
              L12_2 = OpenBossMenu
              L12_2()
              break
            end
            L12_2 = L9_2.action
            if "surveillance" == L12_2 then
              L12_2 = OpenSurveillanceMenu
              L12_2()
            end
          end
        end
        break
      end
    end
    if not L3_2 then
      L4_2 = lib
      L4_2 = L4_2.hideTextUI
      L4_2()
    end
    L4_2 = Wait
    L5_2 = 0
    L4_2(L5_2)
  end
end
CheckMarkerDistance = L9_1
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L0_2 = pairs
  L1_2 = L5_1
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    if L5_2 then
      L6_2 = GetResourceState
      L7_2 = "ox_target"
      L6_2 = L6_2(L7_2)
      if "started" == L6_2 then
        L6_2 = exports
        L6_2 = L6_2.ox_target
        L7_2 = L6_2
        L6_2 = L6_2.removeZone
        L8_2 = L5_2
        L6_2(L7_2, L8_2)
      else
        L6_2 = GetResourceState
        L7_2 = "qb-target"
        L6_2 = L6_2(L7_2)
        if "started" == L6_2 then
          L6_2 = exports
          L6_2 = L6_2["qb-target"]
          L7_2 = L6_2
          L6_2 = L6_2.RemoveZone
          L8_2 = L5_2
          L6_2(L7_2, L8_2)
        end
      end
    end
  end
  L0_2 = {}
  L5_1 = L0_2
end
RemoveTargetZones = L9_1
L9_1 = RegisterNetEvent
L10_1 = "fs-government:client:openMainMenu"
function L11_1()
  local L0_2, L1_2
  L0_2 = OpenGovernmentMenu
  L0_2()
end
L9_1(L10_1, L11_1)
L9_1 = RegisterNetEvent
L10_1 = "fs-government:client:openArmoryMenu"
function L11_1()
  local L0_2, L1_2
  L0_2 = OpenArmoryMenu
  L0_2()
end
L9_1(L10_1, L11_1)
L9_1 = RegisterCommand
L10_1 = "govfield"
function L11_1()
  local L0_2, L1_2, L2_2
  L0_2 = L1_1
  if L0_2 then
    L0_2 = OpenFieldOperationsMenu
    L0_2()
  else
    L0_2 = Framework
    L0_2 = L0_2.ShowNotification
    L1_2 = "Access denied - Not a government employee"
    L2_2 = "error"
    L0_2(L1_2, L2_2)
  end
end
L12_1 = false
L9_1(L10_1, L11_1, L12_1)
L9_1 = TriggerEvent
L10_1 = "chat:addSuggestion"
L11_1 = "/govfield"
L12_1 = "Open government field operations menu"
L9_1(L10_1, L11_1, L12_1)
L9_1 = RegisterNetEvent
L10_1 = "fs-government:client:openStash"
function L11_1()
  local L0_2, L1_2
  L0_2 = Inventory
  L0_2 = L0_2.OpenStash
  L1_2 = "government_storage"
  L0_2(L1_2)
end
L9_1(L10_1, L11_1)
L9_1 = false
L10_1 = nil
L11_1 = "amb@world_human_seat_wall_tablet@female@base"
L12_1 = "base"
L13_1 = -1585232418
L14_1 = false
L15_1 = nil
L16_1 = RegisterNetEvent
L17_1 = "fs-government:client:useTablet"
function L18_1()
  local L0_2, L1_2, L2_2
  L0_2 = L9_1
  if L0_2 then
    L0_2 = L14_1
    if not L0_2 then
      L0_2 = Utils
      L0_2 = L0_2.DebugPrint
      L1_2 = "Tablet stuck in use state, cleaning up..."
      L0_2(L1_2)
      L0_2 = StopTabletAnimation
      L0_2()
      L0_2 = Wait
      L1_2 = 500
      L0_2(L1_2)
    else
      L0_2 = Framework
      L0_2 = L0_2.ShowNotification
      L1_2 = "Menu already open"
      L2_2 = "error"
      L0_2(L1_2, L2_2)
      return
    end
  end
  L0_2 = StartTabletAnimation
  L0_2()
  L0_2 = Wait
  L1_2 = 1000
  L0_2(L1_2)
  L0_2 = true
  L14_1 = L0_2
  L0_2 = "government_main_menu"
  L15_1 = L0_2
  L0_2 = OpenGovernmentMenu
  L0_2()
end
L16_1(L17_1, L18_1)
function L16_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L0_2 = L9_1
  if L0_2 then
    return
  end
  L0_2 = true
  L9_1 = L0_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = RequestAnimDict
  L2_2 = L11_1
  L1_2(L2_2)
  while true do
    L1_2 = HasAnimDictLoaded
    L2_2 = L11_1
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = Wait
    L2_2 = 100
    L1_2(L2_2)
  end
  L1_2 = RequestModel
  L2_2 = L13_1
  L1_2(L2_2)
  while true do
    L1_2 = HasModelLoaded
    L2_2 = L13_1
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = Wait
    L2_2 = 100
    L1_2(L2_2)
  end
  L1_2 = CreateObject
  L2_2 = L13_1
  L3_2 = 0.0
  L4_2 = 0.0
  L5_2 = 0.0
  L6_2 = true
  L7_2 = true
  L8_2 = false
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
  L10_1 = L1_2
  L1_2 = SetEntityCollision
  L2_2 = L10_1
  L3_2 = false
  L4_2 = false
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = AttachEntityToEntity
  L2_2 = L10_1
  L3_2 = L0_2
  L4_2 = GetPedBoneIndex
  L5_2 = L0_2
  L6_2 = 28422
  L4_2 = L4_2(L5_2, L6_2)
  L5_2 = 0.0
  L6_2 = 0.0
  L7_2 = 0.03
  L8_2 = 0.0
  L9_2 = 0.0
  L10_2 = 0.0
  L11_2 = true
  L12_2 = true
  L13_2 = false
  L14_2 = true
  L15_2 = 1
  L16_2 = true
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
  L1_2 = TaskPlayAnim
  L2_2 = L0_2
  L3_2 = L11_1
  L4_2 = L12_1
  L5_2 = 8.0
  L6_2 = -8.0
  L7_2 = -1
  L8_2 = 50
  L9_2 = 0
  L10_2 = false
  L11_2 = false
  L12_2 = false
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L1_2 = Utils
  L1_2 = L1_2.DebugPrint
  L2_2 = "Started tablet animation and attached prop"
  L1_2(L2_2)
end
StartTabletAnimation = L16_1
function L16_1()
  local L0_2, L1_2, L2_2
  L0_2 = L9_1
  if not L0_2 then
    return
  end
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = ClearPedTasks
  L2_2 = L0_2
  L1_2(L2_2)
  L1_2 = L10_1
  if L1_2 then
    L1_2 = DoesEntityExist
    L2_2 = L10_1
    L1_2 = L1_2(L2_2)
    if L1_2 then
      L1_2 = DeleteEntity
      L2_2 = L10_1
      L1_2(L2_2)
      L1_2 = nil
      L10_1 = L1_2
    end
  end
  L1_2 = false
  L9_1 = L1_2
  L1_2 = false
  L14_1 = L1_2
  L1_2 = nil
  L15_1 = L1_2
  L1_2 = Utils
  L1_2 = L1_2.DebugPrint
  L2_2 = "Stopped tablet animation and removed prop"
  L1_2(L2_2)
end
StopTabletAnimation = L16_1
L16_1 = RegisterNetEvent
L17_1 = "fs-government:client:stopTabletAnimation"
function L18_1()
  local L0_2, L1_2
  L0_2 = StopTabletAnimation
  L0_2()
end
L16_1(L17_1, L18_1)
L16_1 = AddEventHandler
L17_1 = "onResourceStop"
function L18_1(A0_2)
  local L1_2
  L1_2 = GetCurrentResourceName
  L1_2 = L1_2()
  if A0_2 == L1_2 then
    L1_2 = StopTabletAnimation
    L1_2()
  end
end
L16_1(L17_1, L18_1)
L16_1 = 0
L17_1 = 0
L18_1 = false
L19_1 = CreateThread
function L20_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2, L34_2, L35_2, L36_2, L37_2, L38_2, L39_2, L40_2, L41_2, L42_2, L43_2, L44_2, L45_2, L46_2
  while true do
    L0_2 = L14_1
    if L0_2 then
      L0_2 = GetGameTimer
      L0_2 = L0_2()
      L1_2 = false
      L2_2 = lib
      if L2_2 then
        L2_2 = lib
        L2_2 = L2_2.getOpenContextMenu
        if L2_2 then
          L2_2 = lib
          L2_2 = L2_2.getOpenContextMenu
          L2_2 = L2_2()
          if L2_2 then
            L3_2 = {}
            L4_2 = "government_main_menu"
            L5_2 = "government_core_menu"
            L6_2 = "government_strategic_menu"
            L7_2 = "government_admin_menu"
            L8_2 = "government_security_menu"
            L9_2 = "government_economic_menu"
            L10_2 = "government_armory_menu"
            L11_2 = "government_boss_menu"
            L12_2 = "government_employee_menu"
            L13_2 = "government_surveillance_menu"
            L14_2 = "government_taxation_menu"
            L15_2 = "government_elections_menu"
            L16_2 = "government_defcon_menu"
            L17_2 = "government_license_menu"
            L18_2 = "government_field_operations"
            L19_2 = "government_budget_menu"
            L20_2 = "government_financial_report_menu"
            L21_2 = "government_business_audit_menu"
            L22_2 = "government_appointments_menu"
            L23_2 = "government_permit_menu"
            L24_2 = "government_garage_menu"
            L25_2 = "government_online_staff"
            L26_2 = "government_employee_list"
            L27_2 = "government_employee_actions"
            L28_2 = "search_results"
            L29_2 = "player_licenses"
            L30_2 = "player_licenses_display"
            L31_2 = "license_actions"
            L32_2 = "player_fines"
            L33_2 = "seizures_list"
            L34_2 = "seizure_details"
            L35_2 = "seizure_history"
            L36_2 = "warrants_search_results"
            L37_2 = "all_warrants"
            L38_2 = "warrant_details"
            L39_2 = "warrant_history"
            L40_2 = "active_permits"
            L41_2 = "all_permits"
            L42_2 = "expired_permits"
            L43_2 = "expiring_permits"
            L44_2 = "permit_details"
            L45_2 = "player_permits_list"
            L46_2 = "player_permit_options"
            L3_2[1] = L4_2
            L3_2[2] = L5_2
            L3_2[3] = L6_2
            L3_2[4] = L7_2
            L3_2[5] = L8_2
            L3_2[6] = L9_2
            L3_2[7] = L10_2
            L3_2[8] = L11_2
            L3_2[9] = L12_2
            L3_2[10] = L13_2
            L3_2[11] = L14_2
            L3_2[12] = L15_2
            L3_2[13] = L16_2
            L3_2[14] = L17_2
            L3_2[15] = L18_2
            L3_2[16] = L19_2
            L3_2[17] = L20_2
            L3_2[18] = L21_2
            L3_2[19] = L22_2
            L3_2[20] = L23_2
            L3_2[21] = L24_2
            L3_2[22] = L25_2
            L3_2[23] = L26_2
            L3_2[24] = L27_2
            L3_2[25] = L28_2
            L3_2[26] = L29_2
            L3_2[27] = L30_2
            L3_2[28] = L31_2
            L3_2[29] = L32_2
            L3_2[30] = L33_2
            L3_2[31] = L34_2
            L3_2[32] = L35_2
            L3_2[33] = L36_2
            L3_2[34] = L37_2
            L3_2[35] = L38_2
            L3_2[36] = L39_2
            L3_2[37] = L40_2
            L3_2[38] = L41_2
            L3_2[39] = L42_2
            L3_2[40] = L43_2
            L3_2[41] = L44_2
            L3_2[42] = L45_2
            L3_2[43] = L46_2
            L4_2 = ipairs
            L5_2 = L3_2
            L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
            for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
              if L2_2 == L9_2 then
                L1_2 = true
                L16_1 = L0_2
                L10_2 = false
                L18_1 = L10_2
                break
              end
            end
          end
        end
      end
      if not L1_2 then
        L2_2 = L18_1
        if not L2_2 then
          L2_2 = true
          L18_1 = L2_2
          L2_2 = L0_2 + 2000
          L17_1 = L2_2
          L2_2 = Utils
          L2_2 = L2_2.DebugPrint
          L3_2 = "No government menu detected, starting 2s transition timer..."
          L2_2(L3_2)
        else
          L2_2 = L17_1
          if L0_2 > L2_2 then
            L2_2 = Utils
            L2_2 = L2_2.DebugPrint
            L3_2 = "Menu transition timeout expired, cleaning up tablet..."
            L2_2(L3_2)
            L2_2 = StopTabletAnimation
            L2_2()
          end
        end
      else
        L2_2 = L18_1
        if L2_2 then
          L2_2 = Utils
          L2_2 = L2_2.DebugPrint
          L3_2 = "Government menu detected again, canceling transition timer"
          L2_2(L3_2)
          L2_2 = false
          L18_1 = L2_2
        end
      end
    end
    L0_2 = L14_1
    if L0_2 then
      L0_2 = IsControlJustPressed
      L1_2 = 0
      L2_2 = 322
      L0_2 = L0_2(L1_2, L2_2)
      if L0_2 then
        L0_2 = Utils
        L0_2 = L0_2.DebugPrint
        L1_2 = "ESC pressed, cleaning up tablet..."
        L0_2(L1_2)
        L0_2 = StopTabletAnimation
        L0_2()
      end
    end
    L0_2 = Wait
    L1_2 = 100
    L0_2(L1_2)
  end
end
L19_1(L20_1)
L19_1 = Config
L19_1 = L19_1.Debug
if L19_1 then
  L19_1 = RegisterCommand
  L20_1 = "testtablet"
  function L21_1()
    local L0_2, L1_2
    L0_2 = TriggerEvent
    L1_2 = "fs-government:client:useTablet"
    L0_2(L1_2)
  end
  L22_1 = false
  L19_1(L20_1, L21_1, L22_1)
end
L19_1 = RegisterCommand
L20_1 = "resettablet"
function L21_1()
  local L0_2, L1_2, L2_2
  L0_2 = L9_1
  if not L0_2 then
    L0_2 = L14_1
    if not L0_2 then
      goto lbl_19
    end
  end
  L0_2 = Utils
  L0_2 = L0_2.DebugPrint
  L1_2 = "Manual tablet reset requested"
  L0_2(L1_2)
  L0_2 = StopTabletAnimation
  L0_2()
  L0_2 = Framework
  L0_2 = L0_2.ShowNotification
  L1_2 = "Tablet state reset"
  L2_2 = "success"
  L0_2(L1_2, L2_2)
  goto lbl_24
  ::lbl_19::
  L0_2 = Framework
  L0_2 = L0_2.ShowNotification
  L1_2 = "Tablet is not active"
  L2_2 = "error"
  L0_2(L1_2, L2_2)
  ::lbl_24::
end
L22_1 = false
L19_1(L20_1, L21_1, L22_1)
L19_1 = Config
L19_1 = L19_1.Debug
if L19_1 then
  L19_1 = RegisterCommand
  L20_1 = "menustate"
  function L21_1()
    local L0_2, L1_2, L2_2, L3_2, L4_2
    L0_2 = lib
    L0_2 = L0_2.getOpenContextMenu
    if L0_2 then
      L0_2 = lib
      L0_2 = L0_2.getOpenContextMenu
      L0_2 = L0_2()
      if L0_2 then
        goto lbl_11
      end
    end
    L0_2 = "none"
    ::lbl_11::
    L1_2 = print
    L2_2 = "=== GOVERNMENT MENU DEBUG ==="
    L1_2(L2_2)
    L1_2 = print
    L2_2 = "Tablet Active: "
    L3_2 = tostring
    L4_2 = L9_1
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
    L1_2 = print
    L2_2 = "Menu Open: "
    L3_2 = tostring
    L4_2 = L14_1
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
    L1_2 = print
    L2_2 = "Current Context: "
    L3_2 = tostring
    L4_2 = L15_1
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
    L1_2 = print
    L2_2 = "Active OX Menu: "
    L3_2 = tostring
    L4_2 = L0_2
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
    L1_2 = print
    L2_2 = "In Transition: "
    L3_2 = tostring
    L4_2 = L18_1
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
    L1_2 = Framework
    L1_2 = L1_2.ShowNotification
    L2_2 = "Check console for debug info"
    L3_2 = "primary"
    L1_2(L2_2, L3_2)
  end
  L22_1 = false
  L19_1(L20_1, L21_1, L22_1)
end
L19_1 = Config
L19_1 = L19_1.Debug
if L19_1 then
  L19_1 = RegisterCommand
  L20_1 = "test_ox_shop"
  function L21_1(A0_2, A1_2, A2_2)
    local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
    L3_2 = A1_2[1]
    if not L3_2 then
      L3_2 = "government_armory_shop"
    end
    L4_2 = Utils
    L4_2 = L4_2.DebugPrint
    L5_2 = "Testing shop access..."
    L4_2(L5_2)
    L4_2 = Utils
    L4_2 = L4_2.DebugPrint
    L5_2 = "Shop name: "
    L6_2 = L3_2
    L5_2 = L5_2 .. L6_2
    L4_2(L5_2)
    L4_2 = Utils
    L4_2 = L4_2.DebugPrint
    L5_2 = "ox_inventory available: "
    L6_2 = tostring
    L7_2 = exports
    L7_2 = L7_2.ox_inventory
    L7_2 = nil ~= L7_2
    L6_2 = L6_2(L7_2)
    L5_2 = L5_2 .. L6_2
    L4_2(L5_2)
    L4_2 = exports
    L4_2 = L4_2.ox_inventory
    if L4_2 then
      L4_2 = pcall
      function L5_2()
        local L0_3, L1_3, L2_3
        L0_3 = exports
        L0_3 = L0_3.ox_inventory
        L1_3 = L0_3
        L0_3 = L0_3.GetShop
        L2_3 = L3_2
        return L0_3(L1_3, L2_3)
      end
      L4_2, L5_2 = L4_2(L5_2)
      if L4_2 and L5_2 then
        L6_2 = Utils
        L6_2 = L6_2.DebugPrint
        L7_2 = "Shop exists in ox_inventory"
        L6_2(L7_2)
        L6_2 = Utils
        L6_2 = L6_2.DebugPrint
        L7_2 = "Shop info: "
        L8_2 = json
        L8_2 = L8_2.encode
        L9_2 = L5_2
        L8_2 = L8_2(L9_2)
        L7_2 = L7_2 .. L8_2
        L6_2(L7_2)
      else
        L6_2 = Utils
        L6_2 = L6_2.DebugWarn
        L7_2 = "Shop not found in ox_inventory: "
        L8_2 = tostring
        L9_2 = L5_2
        L8_2 = L8_2(L9_2)
        L7_2 = L7_2 .. L8_2
        L6_2(L7_2)
      end
      L6_2 = pcall
      function L7_2()
        local L0_3, L1_3, L2_3, L3_3, L4_3
        L0_3 = exports
        L0_3 = L0_3.ox_inventory
        L1_3 = L0_3
        L0_3 = L0_3.openInventory
        L2_3 = "shop"
        L3_3 = {}
        L4_3 = L3_2
        L3_3.type = L4_3
        L3_3.id = 1
        L0_3(L1_3, L2_3, L3_3)
      end
      L6_2, L7_2 = L6_2(L7_2)
      if not L6_2 then
        L8_2 = Utils
        L8_2 = L8_2.DebugError
        L9_2 = "Failed to open shop with type format: "
        L10_2 = tostring
        L11_2 = L7_2
        L10_2 = L10_2(L11_2)
        L9_2 = L9_2 .. L10_2
        L8_2(L9_2)
        L8_2 = pcall
        function L9_2()
          local L0_3, L1_3, L2_3, L3_3, L4_3
          L0_3 = exports
          L0_3 = L0_3.ox_inventory
          L1_3 = L0_3
          L0_3 = L0_3.openInventory
          L2_3 = "shop"
          L3_3 = {}
          L4_3 = L3_2
          L3_3.id = L4_3
          L0_3(L1_3, L2_3, L3_3)
        end
        L8_2, L9_2 = L8_2(L9_2)
        if not L8_2 then
          L10_2 = Utils
          L10_2 = L10_2.DebugError
          L11_2 = "Failed to open shop with legacy format: "
          L12_2 = tostring
          L13_2 = L9_2
          L12_2 = L12_2(L13_2)
          L11_2 = L11_2 .. L12_2
          L10_2(L11_2)
          L10_2 = Framework
          L10_2 = L10_2.ShowNotification
          L11_2 = "Shop open failed: "
          L12_2 = tostring
          L13_2 = L7_2
          L12_2 = L12_2(L13_2)
          L11_2 = L11_2 .. L12_2
          L12_2 = "error"
          L10_2(L11_2, L12_2)
        else
          L10_2 = Utils
          L10_2 = L10_2.DebugSuccess
          L11_2 = "Shop opened with legacy format"
          L10_2(L11_2)
          L10_2 = Framework
          L10_2 = L10_2.ShowNotification
          L11_2 = "Shop opened (legacy)"
          L12_2 = "success"
          L10_2(L11_2, L12_2)
        end
      else
        L8_2 = Utils
        L8_2 = L8_2.DebugSuccess
        L9_2 = "Shop opened successfully with type format"
        L8_2(L9_2)
        L8_2 = Framework
        L8_2 = L8_2.ShowNotification
        L9_2 = "Shop opened"
        L10_2 = "success"
        L8_2(L9_2, L10_2)
      end
    else
      L4_2 = Utils
      L4_2 = L4_2.DebugError
      L5_2 = "ox_inventory not available"
      L4_2(L5_2)
      L4_2 = Framework
      L4_2 = L4_2.ShowNotification
      L5_2 = "ox_inventory not available"
      L6_2 = "error"
      L4_2(L5_2, L6_2)
    end
  end
  L22_1 = false
  L19_1(L20_1, L21_1, L22_1)
end
L19_1 = RegisterNetEvent
L20_1 = "fs-government:client:openGarageMenu"
function L21_1()
  local L0_2, L1_2
  L0_2 = OpenGarageMenu
  L0_2()
end
L19_1(L20_1, L21_1)
L19_1 = RegisterNetEvent
L20_1 = "fs-government:client:openBossMenu"
function L21_1()
  local L0_2, L1_2
  L0_2 = OpenBossMenu
  L0_2()
end
L19_1(L20_1, L21_1)
L19_1 = RegisterNetEvent
L20_1 = "fs-government:client:openSurveillanceMenu"
function L21_1()
  local L0_2, L1_2
  L0_2 = OpenSurveillanceMenu
  L0_2()
end
L19_1(L20_1, L21_1)
L19_1 = RegisterNetEvent
L20_1 = "esx:setJob"
function L21_1(A0_2)
  local L1_2
  L1_2 = UpdateJobStatus
  L1_2()
end
L19_1(L20_1, L21_1)
L19_1 = RegisterNetEvent
L20_1 = "QBCore:Client:OnJobUpdate"
function L21_1(A0_2)
  local L1_2
  L1_2 = UpdateJobStatus
  L1_2()
end
L19_1(L20_1, L21_1)
L19_1 = RegisterNetEvent
L20_1 = "qb-core:client:onJobUpdate"
function L21_1(A0_2)
  local L1_2
  L1_2 = UpdateJobStatus
  L1_2()
end
L19_1(L20_1, L21_1)
function L19_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = Framework
  L0_2 = L0_2.GetPlayerData
  L0_2 = L0_2()
  L0_1 = L0_2
  L0_2 = L1_1
  L1_2 = L0_1
  if L1_2 then
    L1_2 = L0_1.job
    if L1_2 then
      L1_2 = L0_1.job
      L1_2 = L1_2.name
      if L1_2 then
        L1_2 = Utils
        L1_2 = L1_2.TableContains
        L2_2 = Config
        L2_2 = L2_2.Government
        L2_2 = L2_2.jobs
        L3_2 = L0_1.job
        L3_2 = L3_2.name
        L1_2 = L1_2(L2_2, L3_2)
        L1_1 = L1_2
        L1_2 = L0_1.job
        L1_2 = L1_2.grade
        if L1_2 then
          L1_2 = type
          L2_2 = L0_1.job
          L2_2 = L2_2.grade
          L1_2 = L1_2(L2_2)
          if "table" == L1_2 then
            L1_2 = L0_1.job
            L1_2 = L1_2.grade
            L1_2 = L1_2.level
            if not L1_2 then
              L1_2 = 0
            end
            L2_1 = L1_2
          else
            L1_2 = L0_1.job
            L1_2 = L1_2.grade
            L2_1 = L1_2
          end
        else
          L1_2 = 0
          L2_1 = L1_2
        end
    end
  end
  else
    L1_2 = false
    L1_1 = L1_2
    L1_2 = 0
    L2_1 = L1_2
  end
  L1_2 = L1_1
  if L0_2 ~= L1_2 then
    L1_2 = L1_1
    if L1_2 then
      L1_2 = SetupGovernmentAccess
      L1_2()
    else
      L1_2 = RemoveGovernmentAccess
      L1_2()
    end
  end
end
UpdateJobStatus = L19_1
L19_1 = RegisterNetEvent
L20_1 = "fs-government:client:electionStarted"
function L21_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = true
  L8_1 = L1_2
  L1_2 = SetupElectionAccess
  L1_2()
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "New election started: "
  L3_2 = A0_2.title
  L4_2 = "! Registration is now open."
  L2_2 = L2_2 .. L3_2 .. L4_2
  L3_2 = "success"
  L1_2(L2_2, L3_2)
end
L19_1(L20_1, L21_1)
L19_1 = RegisterNetEvent
L20_1 = "fs-government:client:electionEnded"
function L21_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = false
  L8_1 = L1_2
  L1_2 = RemoveElectionAccess
  L1_2()
  L1_2 = A0_2.winner
  if L1_2 then
    L1_2 = Framework
    L1_2 = L1_2.ShowNotification
    L2_2 = "Election ended! Winner: "
    L3_2 = A0_2.winner
    L3_2 = L3_2.name
    L4_2 = " with "
    L5_2 = A0_2.winner
    L5_2 = L5_2.votes
    L6_2 = " votes."
    L2_2 = L2_2 .. L3_2 .. L4_2 .. L5_2 .. L6_2
    L3_2 = "success"
    L1_2(L2_2, L3_2)
  else
    L1_2 = Framework
    L1_2 = L1_2.ShowNotification
    L2_2 = "Election ended with no winner."
    L3_2 = "primary"
    L1_2(L2_2, L3_2)
  end
end
L19_1(L20_1, L21_1)
L19_1 = RegisterNetEvent
L20_1 = "fs-government:client:openCandidateRegistration"
function L21_1()
  local L0_2, L1_2
  L0_2 = OpenCandidateRegistrationMenu
  L0_2()
end
L19_1(L20_1, L21_1)
L19_1 = RegisterNetEvent
L20_1 = "fs-government:client:openVotingMenu"
function L21_1()
  local L0_2, L1_2
  L0_2 = OpenVotingMenu
  L0_2()
end
L19_1(L20_1, L21_1)
function L19_1()
  local L0_2, L1_2, L2_2
  L0_2 = L8_1
  if not L0_2 then
    L0_2 = Framework
    L0_2 = L0_2.ShowNotification
    L1_2 = "No active election"
    L2_2 = "error"
    L0_2(L1_2, L2_2)
    return
  end
  L0_2 = TriggerServerEvent
  L1_2 = "fs-government:server:getVotingCandidates"
  L0_2(L1_2)
end
OpenVotingMenu = L19_1
L19_1 = RegisterNetEvent
L20_1 = "fs-government:client:showVotingMenu"
function L21_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  if A0_2 then
    L1_2 = #A0_2
    if 0 ~= L1_2 then
      goto lbl_12
    end
  end
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "No candidates available to vote for"
  L3_2 = "error"
  L1_2(L2_2, L3_2)
  do return end
  ::lbl_12::
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L7_2.name
    L9_2 = L7_2.campaign_message
    if L9_2 then
      L9_2 = L7_2.campaign_message
      if "" ~= L9_2 then
        L9_2 = L8_2
        L10_2 = " - "
        L11_2 = L7_2.campaign_message
        L12_2 = L11_2
        L11_2 = L11_2.sub
        L13_2 = 1
        L14_2 = 50
        L11_2 = L11_2(L12_2, L13_2, L14_2)
        L12_2 = L7_2.campaign_message
        L13_2 = L12_2
        L12_2 = L12_2.len
        L12_2 = L12_2(L13_2)
        if L12_2 > 50 then
          L12_2 = "..."
          if L12_2 then
            goto lbl_41
          end
        end
        L12_2 = ""
        ::lbl_41::
        L9_2 = L9_2 .. L10_2 .. L11_2 .. L12_2
        L8_2 = L9_2
      end
    end
    L9_2 = table
    L9_2 = L9_2.insert
    L10_2 = L1_2
    L11_2 = {}
    L12_2 = L7_2.id
    L11_2.value = L12_2
    L11_2.label = L8_2
    L9_2(L10_2, L11_2)
  end
  L2_2 = lib
  L2_2 = L2_2.inputDialog
  L3_2 = "Cast Your Vote"
  L4_2 = {}
  L5_2 = {}
  L5_2.type = "select"
  L5_2.label = "Select Candidate"
  L5_2.options = L1_2
  L5_2.required = true
  L4_2[1] = L5_2
  L2_2 = L2_2(L3_2, L4_2)
  if L2_2 then
    L3_2 = TriggerServerEvent
    L4_2 = "fs-government:server:vote"
    L5_2 = L2_2[1]
    L3_2(L4_2, L5_2)
  end
end
L19_1(L20_1, L21_1)
L19_1 = false
L20_1 = nil
L21_1 = RegisterNetEvent
L22_1 = "fs-government:client:setHandcuffState"
function L23_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L1_2 = L19_1
  if L1_2 == A0_2 then
    return
  end
  L19_1 = A0_2
  if A0_2 then
    L1_2 = PlayerPedId
    L1_2 = L1_2()
    L2_2 = SetEnableHandcuffs
    L3_2 = L1_2
    L4_2 = true
    L2_2(L3_2, L4_2)
    L2_2 = SetPedCanPlayGestureAnims
    L3_2 = L1_2
    L4_2 = false
    L2_2(L3_2, L4_2)
    L2_2 = SetPedCanPlayAmbientAnims
    L3_2 = L1_2
    L4_2 = false
    L2_2(L3_2, L4_2)
    L2_2 = SetPedCanPlayAmbientBaseAnims
    L3_2 = L1_2
    L4_2 = false
    L2_2(L3_2, L4_2)
    L2_2 = FreezeEntityPosition
    L3_2 = L1_2
    L4_2 = false
    L2_2(L3_2, L4_2)
    L2_2 = DoesEntityExist
    L3_2 = L1_2
    L2_2 = L2_2(L3_2)
    if L2_2 then
      L2_2 = IsEntityDead
      L3_2 = L1_2
      L2_2 = L2_2(L3_2)
      if not L2_2 then
        L2_2 = RequestAnimDict
        L3_2 = "mp_arresting"
        L2_2(L3_2)
        while true do
          L2_2 = HasAnimDictLoaded
          L3_2 = "mp_arresting"
          L2_2 = L2_2(L3_2)
          if L2_2 then
            break
          end
          L2_2 = Wait
          L3_2 = 100
          L2_2(L3_2)
        end
        L2_2 = TaskPlayAnim
        L3_2 = L1_2
        L4_2 = "mp_arresting"
        L5_2 = "idle"
        L6_2 = 8.0
        L7_2 = -8
        L8_2 = -1
        L9_2 = 49
        L10_2 = 0
        L11_2 = false
        L12_2 = false
        L13_2 = false
        L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
      end
    end
    L2_2 = L20_1
    if not L2_2 then
      L2_2 = CreateThread
      function L3_2()
        local L0_3, L1_3, L2_3, L3_3
        while true do
          L0_3 = L19_1
          if not L0_3 then
            break
          end
          L0_3 = DisableAllControlActions
          L1_3 = 0
          L0_3(L1_3)
          L0_3 = EnableControlAction
          L1_3 = 0
          L2_3 = 1
          L3_3 = true
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = EnableControlAction
          L1_3 = 0
          L2_3 = 2
          L3_3 = true
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = EnableControlAction
          L1_3 = 0
          L2_3 = 245
          L3_3 = true
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = EnableControlAction
          L1_3 = 0
          L2_3 = 322
          L3_3 = true
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = EnableControlAction
          L1_3 = 0
          L2_3 = 288
          L3_3 = true
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = EnableControlAction
          L1_3 = 0
          L2_3 = 289
          L3_3 = true
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = EnableControlAction
          L1_3 = 0
          L2_3 = 170
          L3_3 = true
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = EnableControlAction
          L1_3 = 0
          L2_3 = 167
          L3_3 = true
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = EnableControlAction
          L1_3 = 0
          L2_3 = 0
          L3_3 = true
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = EnableControlAction
          L1_3 = 0
          L2_3 = 26
          L3_3 = true
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = Wait
          L1_3 = 0
          L0_3(L1_3)
        end
        L0_3 = nil
        L20_1 = L0_3
      end
      L2_2 = L2_2(L3_2)
      L20_1 = L2_2
    end
  else
    L1_2 = false
    L19_1 = L1_2
    L1_2 = PlayerPedId
    L1_2 = L1_2()
    L2_2 = SetEnableHandcuffs
    L3_2 = L1_2
    L4_2 = false
    L2_2(L3_2, L4_2)
    L2_2 = SetPedCanPlayGestureAnims
    L3_2 = L1_2
    L4_2 = true
    L2_2(L3_2, L4_2)
    L2_2 = SetPedCanPlayAmbientAnims
    L3_2 = L1_2
    L4_2 = true
    L2_2(L3_2, L4_2)
    L2_2 = SetPedCanPlayAmbientBaseAnims
    L3_2 = L1_2
    L4_2 = true
    L2_2(L3_2, L4_2)
    L2_2 = ClearPedTasks
    L3_2 = L1_2
    L2_2(L3_2)
  end
end
L21_1(L22_1, L23_1)
function L21_1()
  local L0_2, L1_2
  L0_2 = L19_1
  return L0_2
end
IsPlayerHandcuffed = L21_1
L21_1 = AddEventHandler
L22_1 = "onResourceStop"
function L23_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = GetCurrentResourceName
  L1_2 = L1_2()
  if A0_2 == L1_2 then
    L1_2 = L19_1
    if L1_2 then
      L1_2 = false
      L19_1 = L1_2
      L1_2 = PlayerPedId
      L1_2 = L1_2()
      L2_2 = SetEnableHandcuffs
      L3_2 = L1_2
      L4_2 = false
      L2_2(L3_2, L4_2)
      L2_2 = SetPedCanPlayGestureAnims
      L3_2 = L1_2
      L4_2 = true
      L2_2(L3_2, L4_2)
      L2_2 = SetPedCanPlayAmbientAnims
      L3_2 = L1_2
      L4_2 = true
      L2_2(L3_2, L4_2)
      L2_2 = SetPedCanPlayAmbientBaseAnims
      L3_2 = L1_2
      L4_2 = true
      L2_2(L3_2, L4_2)
      L2_2 = ClearPedTasks
      L3_2 = L1_2
      L2_2(L3_2)
    end
    L1_2 = RemoveGovernmentBlip
    L1_2()
    L1_2 = RemoveTargetZones
    L1_2()
    L1_2 = RemoveElectionAccess
    L1_2()
    L1_2 = StopTabletAnimation
    L1_2()
    L1_2 = lib
    L1_2 = L1_2.hideTextUI
    L1_2()
  end
end
L21_1(L22_1, L23_1)
L21_1 = exports
L22_1 = "ForceCleanupTablet"
function L23_1()
  local L0_2, L1_2
  L0_2 = Utils
  L0_2 = L0_2.DebugPrint
  L1_2 = "External cleanup requested"
  L0_2(L1_2)
  L0_2 = StopTabletAnimation
  L0_2()
end
L21_1(L22_1, L23_1)
L21_1 = exports
L22_1 = "IsTabletActive"
function L23_1()
  local L0_2, L1_2
  L0_2 = L9_1
  return L0_2
end
L21_1(L22_1, L23_1)
L21_1 = exports
L22_1 = "IsMenuOpen"
function L23_1()
  local L0_2, L1_2
  L0_2 = L14_1
  return L0_2
end
L21_1(L22_1, L23_1)
L21_1 = AddEventHandler
L22_1 = "playerSpawned"
function L23_1()
  local L0_2, L1_2
  L0_2 = L9_1
  if L0_2 then
    L0_2 = Utils
    L0_2 = L0_2.DebugPrint
    L1_2 = "Player spawned with tablet active, cleaning up..."
    L0_2(L1_2)
    L0_2 = StopTabletAnimation
    L0_2()
  end
end
L21_1(L22_1, L23_1)
L21_1 = AddEventHandler
L22_1 = "ox_lib:hideContext"
function L23_1()
  local L0_2, L1_2
  L0_2 = L14_1
  if L0_2 then
    L0_2 = L9_1
    if L0_2 then
      L0_2 = Utils
      L0_2 = L0_2.DebugPrint
      L1_2 = "Context menu hidden, transition handler will manage cleanup..."
      L0_2(L1_2)
    end
  end
end
L21_1(L22_1, L23_1)
