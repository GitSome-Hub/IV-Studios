local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1
L0_1 = nil
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  if not A0_2 then
    L1_2 = "Unknown"
    return L1_2
  end
  L1_2 = {}
  L1_2.in_progress = "In Progress"
  L1_2.IN_PROGRESS = "In Progress"
  L1_2.completed = "Completed"
  L1_2.COMPLETED = "Completed"
  L1_2.cancelled = "Cancelled"
  L1_2.CANCELLED = "Cancelled"
  L1_2.completed_violations = "Completed (Violations Found)"
  L1_2.COMPLETED_VIOLATIONS = "Completed (Violations Found)"
  L1_2.pending = "Pending"
  L1_2.PENDING = "Pending"
  L1_2.approved = "Approved"
  L1_2.APPROVED = "Approved"
  L1_2.paid = "Paid"
  L1_2.PAID = "Paid"
  L1_2.rejected = "Rejected"
  L1_2.REJECTED = "Rejected"
  L1_2.active = "Active"
  L1_2.ACTIVE = "Active"
  L1_2.suspended = "Suspended"
  L1_2.SUSPENDED = "Suspended"
  L1_2.revoked = "Revoked"
  L1_2.REVOKED = "Revoked"
  L1_2.closed = "Closed"
  L1_2.CLOSED = "Closed"
  L1_2.expired = "Expired"
  L1_2.EXPIRED = "Expired"
  L1_2.seized = "Seized"
  L1_2.SEIZED = "Seized"
  L1_2.released = "Released"
  L1_2.RELEASED = "Released"
  L2_2 = L1_2[A0_2]
  if not L2_2 then
    L3_2 = A0_2
    L2_2 = A0_2.gsub
    L4_2 = "_"
    L5_2 = " "
    L2_2 = L2_2(L3_2, L4_2, L5_2)
    L3_2 = L2_2
    L2_2 = L2_2.gsub
    L4_2 = "^%l"
    L5_2 = string
    L5_2 = L5_2.upper
    L2_2 = L2_2(L3_2, L4_2, L5_2)
  end
  return L2_2
end
FormatStatusText = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = Framework
  L0_2 = L0_2.GetClosestPlayer
  L0_2, L1_2 = L0_2()
  if L0_2 and L1_2 < 3.0 then
    L2_2 = TriggerServerEvent
    L3_2 = "fs-government:server:searchPlayer"
    L4_2 = GetPlayerServerId
    L5_2 = L0_2
    L4_2, L5_2 = L4_2(L5_2)
    L2_2(L3_2, L4_2, L5_2)
  else
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "No player nearby"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
  end
end
SearchNearbyPlayer = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = Framework
  L0_2 = L0_2.GetClosestPlayer
  L0_2, L1_2 = L0_2()
  if L0_2 and L1_2 < 3.0 then
    L2_2 = TriggerServerEvent
    L3_2 = "fs-government:server:toggleHandcuffs"
    L4_2 = GetPlayerServerId
    L5_2 = L0_2
    L4_2, L5_2 = L4_2(L5_2)
    L2_2(L3_2, L4_2, L5_2)
  else
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "No player nearby"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
  end
end
ToggleHandcuffs = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = Framework
  L0_2 = L0_2.GetClosestPlayer
  L0_2, L1_2 = L0_2()
  if L0_2 and L1_2 < 3.0 then
    L2_2 = TriggerServerEvent
    L3_2 = "fs-government:server:checkIdentity"
    L4_2 = GetPlayerServerId
    L5_2 = L0_2
    L4_2, L5_2 = L4_2(L5_2)
    L2_2(L3_2, L4_2, L5_2)
  else
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "No player nearby"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
  end
end
CheckPlayerIdentity = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = onDuty
  L0_2 = not L0_2
  onDuty = L0_2
  L0_2 = TriggerServerEvent
  L1_2 = "fs-government:server:toggleDuty"
  L2_2 = onDuty
  L0_2(L1_2, L2_2)
  L0_2 = onDuty
  if L0_2 then
    L0_2 = "on duty"
    if L0_2 then
      goto lbl_15
    end
  end
  L0_2 = "off duty"
  ::lbl_15::
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "You are now "
  L3_2 = L0_2
  L2_2 = L2_2 .. L3_2
  L3_2 = "success"
  L1_2(L2_2, L3_2)
end
ToggleDuty = L1_1
function L1_1()
  local L0_2, L1_2
  L0_2 = TriggerServerEvent
  L1_2 = "fs-government:server:getFrameworkJobs"
  L0_2(L1_2)
end
HireEmployee = L1_1
L1_1 = {}
L2_1 = {}
L3_1 = nil
L4_1 = nil
L5_1 = RegisterNetEvent
L6_1 = "fs-government:client:receiveFrameworkJobs"
function L7_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = {}
  L1_1 = L1_2
  L1_2 = ipairs
  L2_2 = A0_2
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = table
    L7_2 = L7_2.insert
    L8_2 = L1_1
    L9_2 = {}
    L10_2 = L6_2.name
    L9_2.value = L10_2
    L10_2 = L6_2.label
    L9_2.label = L10_2
    L7_2(L8_2, L9_2)
  end
  L1_2 = L1_1
  L1_2 = #L1_2
  if 0 == L1_2 then
    L1_2 = Framework
    L1_2 = L1_2.ShowNotification
    L2_2 = "No government jobs available"
    L3_2 = "error"
    L1_2(L2_2, L3_2)
    return
  end
  L1_2 = lib
  L1_2 = L1_2.inputDialog
  L2_2 = "Hire Employee - Step 1"
  L3_2 = {}
  L4_2 = {}
  L4_2.type = "number"
  L4_2.label = "Player Server ID"
  L4_2.placeholder = "1"
  L4_2.min = 1
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "select"
  L5_2.label = "Job"
  L6_2 = L1_1
  L5_2.options = L6_2
  L5_2.required = true
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L2_2 = L1_2[1]
    L3_1 = L2_2
    L2_2 = L1_2[2]
    L4_1 = L2_2
    L2_2 = TriggerServerEvent
    L3_2 = "fs-government:server:getJobGrades"
    L4_2 = L4_1
    L2_2(L3_2, L4_2)
  end
end
L5_1(L6_1, L7_1)
L5_1 = RegisterNetEvent
L6_1 = "fs-government:client:receiveJobGrades"
function L7_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L1_2 = {}
  L2_1 = L1_2
  L1_2 = ipairs
  L2_2 = A0_2
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = table
    L7_2 = L7_2.insert
    L8_2 = L2_1
    L9_2 = {}
    L10_2 = L6_2.grade
    L9_2.value = L10_2
    L10_2 = string
    L10_2 = L10_2.format
    L11_2 = "Grade %d - %s ($%d)"
    L12_2 = L6_2.grade
    L13_2 = L6_2.label
    L14_2 = L6_2.salary
    L10_2 = L10_2(L11_2, L12_2, L13_2, L14_2)
    L9_2.label = L10_2
    L7_2(L8_2, L9_2)
  end
  L1_2 = L2_1
  L1_2 = #L1_2
  if 0 == L1_2 then
    L1_2 = Framework
    L1_2 = L1_2.ShowNotification
    L2_2 = "No grades available for this job"
    L3_2 = "error"
    L1_2(L2_2, L3_2)
    return
  end
  L1_2 = lib
  L1_2 = L1_2.inputDialog
  L2_2 = "Hire Employee - Step 2"
  L3_2 = {}
  L4_2 = {}
  L4_2.type = "select"
  L4_2.label = "Grade"
  L5_2 = L2_1
  L4_2.options = L5_2
  L4_2.required = true
  L3_2[1] = L4_2
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L2_2 = TriggerServerEvent
    L3_2 = "fs-government:server:hireEmployee"
    L4_2 = L3_1
    L5_2 = L4_1
    L6_2 = L1_2[1]
    L2_2(L3_2, L4_2, L5_2, L6_2)
  end
end
L5_1(L6_1, L7_1)
function L5_1()
  local L0_2, L1_2
  L0_2 = TriggerServerEvent
  L1_2 = "fs-government:server:getEmployeeList"
  L0_2(L1_2)
end
OpenEmployeeListMenu = L5_1
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = Framework
  L0_2 = L0_2.GetClosestPlayer
  L0_2, L1_2 = L0_2()
  if L0_2 and L1_2 < 3.0 then
    L2_2 = lib
    L2_2 = L2_2.alertDialog
    L3_2 = {}
    L3_2.header = "Fire Employee"
    L3_2.content = "Are you sure you want to fire this employee?"
    L3_2.centered = true
    L3_2.cancel = true
    L2_2 = L2_2(L3_2)
    if "confirm" == L2_2 then
      L3_2 = TriggerServerEvent
      L4_2 = "fs-government:server:fireEmployee"
      L5_2 = GetPlayerServerId
      L6_2 = L0_2
      L5_2, L6_2 = L5_2(L6_2)
      L3_2(L4_2, L5_2, L6_2)
    end
  else
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "No player nearby"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
  end
end
FireEmployee = L5_1
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = Framework
  L0_2 = L0_2.GetClosestPlayer
  L0_2, L1_2 = L0_2()
  if L0_2 and L1_2 < 3.0 then
    L2_2 = lib
    L2_2 = L2_2.inputDialog
    L3_2 = "Promote/Demote Employee"
    L4_2 = {}
    L5_2 = {}
    L5_2.type = "number"
    L5_2.label = "New Grade"
    L5_2.placeholder = "1"
    L5_2.min = 0
    L5_2.max = 7
    L5_2.required = true
    L4_2[1] = L5_2
    L2_2 = L2_2(L3_2, L4_2)
    if L2_2 then
      L3_2 = TriggerServerEvent
      L4_2 = "fs-government:server:setEmployeeGrade"
      L5_2 = GetPlayerServerId
      L6_2 = L0_2
      L5_2 = L5_2(L6_2)
      L6_2 = L2_2[1]
      L3_2(L4_2, L5_2, L6_2)
    end
  else
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "No player nearby"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
  end
end
PromoteEmployee = L5_1
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L1_2 = nil
  L2_2 = ipairs
  L3_2 = Config
  L3_2 = L3_2.Locations
  L3_2 = L3_2.surveillance
  L3_2 = L3_2.cameras
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L7_2.id
    if L8_2 == A0_2 then
      L1_2 = L7_2
      break
    end
  end
  if not L1_2 then
    return
  end
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = GetEntityCoords
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  L4_2 = DoScreenFadeOut
  L5_2 = 1000
  L4_2(L5_2)
  L4_2 = Wait
  L5_2 = 1000
  L4_2(L5_2)
  L4_2 = SetEntityCoords
  L5_2 = L2_2
  L6_2 = L1_2.coords
  L6_2 = L6_2.x
  L7_2 = L1_2.coords
  L7_2 = L7_2.y
  L8_2 = L1_2.coords
  L8_2 = L8_2.z
  L8_2 = L8_2 + 50.0
  L4_2(L5_2, L6_2, L7_2, L8_2)
  L4_2 = SetEntityVisible
  L5_2 = L2_2
  L6_2 = false
  L7_2 = false
  L4_2(L5_2, L6_2, L7_2)
  L4_2 = FreezeEntityPosition
  L5_2 = L2_2
  L6_2 = true
  L4_2(L5_2, L6_2)
  L4_2 = CreateCam
  L5_2 = "DEFAULT_SCRIPTED_CAMERA"
  L6_2 = true
  L4_2 = L4_2(L5_2, L6_2)
  L5_2 = SetCamCoord
  L6_2 = L4_2
  L7_2 = L1_2.coords
  L7_2 = L7_2.x
  L8_2 = L1_2.coords
  L8_2 = L8_2.y
  L9_2 = L1_2.coords
  L9_2 = L9_2.z
  L9_2 = L9_2 + 10.0
  L5_2(L6_2, L7_2, L8_2, L9_2)
  L5_2 = PointCamAtCoord
  L6_2 = L4_2
  L7_2 = L1_2.coords
  L7_2 = L7_2.x
  L8_2 = L1_2.coords
  L8_2 = L8_2.y
  L9_2 = L1_2.coords
  L9_2 = L9_2.z
  L5_2(L6_2, L7_2, L8_2, L9_2)
  L5_2 = SetCamActive
  L6_2 = L4_2
  L7_2 = true
  L5_2(L6_2, L7_2)
  L5_2 = RenderScriptCams
  L6_2 = true
  L7_2 = true
  L8_2 = 1000
  L9_2 = true
  L10_2 = true
  L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
  L5_2 = DoScreenFadeIn
  L6_2 = 1000
  L5_2(L6_2)
  L5_2 = GetGameTimer
  L5_2 = L5_2()
  L6_2 = lib
  L6_2 = L6_2.showTextUI
  L7_2 = "Press [BACKSPACE] to exit camera view"
  L6_2(L7_2)
  L6_2 = true
  L7_2 = CreateThread
  function L8_2()
    local L0_3, L1_3, L2_3
    while true do
      L0_3 = L6_2
      if not L0_3 then
        break
      end
      L0_3 = IsControlJustReleased
      L1_3 = 0
      L2_3 = 322
      L0_3 = L0_3(L1_3, L2_3)
      if not L0_3 then
        L0_3 = IsControlJustReleased
        L1_3 = 0
        L2_3 = 194
        L0_3 = L0_3(L1_3, L2_3)
        if not L0_3 then
          L0_3 = IsControlJustReleased
          L1_3 = 0
          L2_3 = 177
          L0_3 = L0_3(L1_3, L2_3)
          if not L0_3 then
            goto lbl_25
          end
        end
      end
      L0_3 = false
      L6_2 = L0_3
      do break end
      ::lbl_25::
      L0_3 = Wait
      L1_3 = 0
      L0_3(L1_3)
    end
  end
  L7_2(L8_2)
  while L6_2 do
    L7_2 = DisableControlAction
    L8_2 = 0
    L9_2 = 1
    L10_2 = true
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = DisableControlAction
    L8_2 = 0
    L9_2 = 2
    L10_2 = true
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = DisableControlAction
    L8_2 = 0
    L9_2 = 24
    L10_2 = true
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = DisableControlAction
    L8_2 = 0
    L9_2 = 25
    L10_2 = true
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = DisableControlAction
    L8_2 = 0
    L9_2 = 47
    L10_2 = true
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = DisableControlAction
    L8_2 = 0
    L9_2 = 58
    L10_2 = true
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = DisableControlAction
    L8_2 = 0
    L9_2 = 263
    L10_2 = true
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = DisableControlAction
    L8_2 = 0
    L9_2 = 264
    L10_2 = true
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = DisableControlAction
    L8_2 = 0
    L9_2 = 257
    L10_2 = true
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = DisableControlAction
    L8_2 = 0
    L9_2 = 140
    L10_2 = true
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = DisableControlAction
    L8_2 = 0
    L9_2 = 141
    L10_2 = true
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = DisableControlAction
    L8_2 = 0
    L9_2 = 142
    L10_2 = true
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = GetDisabledControlNormal
    L8_2 = 0
    L9_2 = 1
    L7_2 = L7_2(L8_2, L9_2)
    L7_2 = L7_2 * 2.0
    L8_2 = GetDisabledControlNormal
    L9_2 = 0
    L10_2 = 2
    L8_2 = L8_2(L9_2, L10_2)
    L8_2 = L8_2 * 2.0
    L9_2 = math
    L9_2 = L9_2.abs
    L10_2 = L7_2
    L9_2 = L9_2(L10_2)
    if not (L9_2 > 0.0) then
      L9_2 = math
      L9_2 = L9_2.abs
      L10_2 = L8_2
      L9_2 = L9_2(L10_2)
      if not (L9_2 > 0.0) then
        goto lbl_200
      end
    end
    L9_2 = GetCamRot
    L10_2 = L4_2
    L11_2 = 2
    L9_2 = L9_2(L10_2, L11_2)
    L10_2 = SetCamRot
    L11_2 = L4_2
    L12_2 = L9_2.x
    L12_2 = L12_2 - L8_2
    L13_2 = 0.0
    L14_2 = L9_2.z
    L14_2 = L14_2 - L7_2
    L15_2 = 2
    L10_2(L11_2, L12_2, L13_2, L14_2, L15_2)
    ::lbl_200::
    L9_2 = Wait
    L10_2 = 0
    L9_2(L10_2)
  end
  L7_2 = GetGameTimer
  L7_2 = L7_2()
  L8_2 = math
  L8_2 = L8_2.floor
  L9_2 = L7_2 - L5_2
  L9_2 = L9_2 / 1000
  L8_2 = L8_2(L9_2)
  L9_2 = lib
  L9_2 = L9_2.hideTextUI
  L9_2()
  L9_2 = DoScreenFadeOut
  L10_2 = 1000
  L9_2(L10_2)
  L9_2 = Wait
  L10_2 = 1000
  L9_2(L10_2)
  L9_2 = RenderScriptCams
  L10_2 = false
  L11_2 = true
  L12_2 = 1000
  L13_2 = true
  L14_2 = true
  L9_2(L10_2, L11_2, L12_2, L13_2, L14_2)
  L9_2 = DestroyCam
  L10_2 = L4_2
  L11_2 = false
  L9_2(L10_2, L11_2)
  L9_2 = SetEntityCoords
  L10_2 = L2_2
  L11_2 = L3_2.x
  L12_2 = L3_2.y
  L13_2 = L3_2.z
  L9_2(L10_2, L11_2, L12_2, L13_2)
  L9_2 = SetEntityVisible
  L10_2 = L2_2
  L11_2 = true
  L12_2 = false
  L9_2(L10_2, L11_2, L12_2)
  L9_2 = FreezeEntityPosition
  L10_2 = L2_2
  L11_2 = false
  L9_2(L10_2, L11_2)
  L9_2 = DoScreenFadeIn
  L10_2 = 1000
  L9_2(L10_2)
  L9_2 = TriggerServerEvent
  L10_2 = "fs-government:server:logSurveillance"
  L11_2 = A0_2
  L12_2 = L8_2
  L9_2(L10_2, L11_2, L12_2)
end
ViewCamera = L5_1
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Update Tax Rates"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "number"
  L3_2.label = "Salary Tax (%)"
  L3_2.placeholder = "15"
  L3_2.min = 0
  L3_2.max = 100
  L3_2.step = 0.1
  L4_2 = {}
  L4_2.type = "number"
  L4_2.label = "Business Tax (%)"
  L4_2.placeholder = "12"
  L4_2.min = 0
  L4_2.max = 100
  L4_2.step = 0.1
  L5_2 = {}
  L5_2.type = "number"
  L5_2.label = "Vehicle Tax (%)"
  L5_2.placeholder = "8"
  L5_2.min = 0
  L5_2.max = 100
  L5_2.step = 0.1
  L6_2 = {}
  L6_2.type = "number"
  L6_2.label = "Property Tax (%)"
  L6_2.placeholder = "10"
  L6_2.min = 0
  L6_2.max = 100
  L6_2.step = 0.1
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L2_2[4] = L6_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = {}
    L2_2 = L0_2[1]
    L2_2 = L2_2 / 100
    L1_2.salary = L2_2
    L2_2 = L0_2[2]
    L2_2 = L2_2 / 100
    L1_2.business = L2_2
    L2_2 = L0_2[3]
    L2_2 = L2_2 / 100
    L1_2.vehicle = L2_2
    L2_2 = L0_2[4]
    L2_2 = L2_2 / 100
    L1_2.property = L2_2
    L2_2 = TriggerServerEvent
    L3_2 = "fs-government:server:updateTaxRates"
    L4_2 = L1_2
    L2_2(L3_2, L4_2)
  end
end
UpdateTaxRates = L5_1
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = lib
  L0_2 = L0_2.inputDialog
  L1_2 = "Start New Election"
  L2_2 = {}
  L3_2 = {}
  L3_2.type = "input"
  L3_2.label = "Election Title"
  L3_2.placeholder = "Mayoral Election 2024"
  L3_2.required = true
  L4_2 = {}
  L4_2.type = "textarea"
  L4_2.label = "Description"
  L4_2.placeholder = "Election description..."
  L5_2 = {}
  L5_2.type = "number"
  L5_2.label = "Duration (days)"
  L5_2.placeholder = "7"
  L5_2.min = 1
  L5_2.max = 30
  L5_2.required = true
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = TriggerServerEvent
    L2_2 = "fs-government:server:startElection"
    L3_2 = L0_2[1]
    L4_2 = L0_2[2]
    L5_2 = L0_2[3]
    L1_2(L2_2, L3_2, L4_2, L5_2)
  end
end
StartNewElection = L5_1
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = Framework
  L0_2 = L0_2.GetClosestPlayer
  L0_2, L1_2 = L0_2()
  if L0_2 and L1_2 < 3.0 then
    L2_2 = TriggerServerEvent
    L3_2 = "fs-government:server:checkLicenses"
    L4_2 = GetPlayerServerId
    L5_2 = L0_2
    L4_2, L5_2 = L4_2(L5_2)
    L2_2(L3_2, L4_2, L5_2)
  else
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "No player nearby"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
  end
end
CheckPlayerLicenses = L5_1
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L0_2 = Framework
  L0_2 = L0_2.GetClosestPlayer
  L0_2, L1_2 = L0_2()
  if L0_2 and L1_2 < 3.0 then
    L2_2 = lib
    L2_2 = L2_2.inputDialog
    L3_2 = "Issue License"
    L4_2 = {}
    L5_2 = {}
    L5_2.type = "select"
    L5_2.label = "License Type"
    L6_2 = {}
    L7_2 = {}
    L7_2.value = "driving"
    L7_2.label = "Driving License"
    L8_2 = {}
    L8_2.value = "weapon"
    L8_2.label = "Weapon License"
    L9_2 = {}
    L9_2.value = "business"
    L9_2.label = "Business License"
    L10_2 = {}
    L10_2.value = "fishing"
    L10_2.label = "Fishing License"
    L11_2 = {}
    L11_2.value = "hunting"
    L11_2.label = "Hunting License"
    L6_2[1] = L7_2
    L6_2[2] = L8_2
    L6_2[3] = L9_2
    L6_2[4] = L10_2
    L6_2[5] = L11_2
    L5_2.options = L6_2
    L5_2.required = true
    L6_2 = {}
    L6_2.type = "textarea"
    L6_2.label = "Notes"
    L6_2.placeholder = "Additional notes..."
    L4_2[1] = L5_2
    L4_2[2] = L6_2
    L2_2 = L2_2(L3_2, L4_2)
    if L2_2 then
      L3_2 = TriggerServerEvent
      L4_2 = "fs-government:server:issueLicense"
      L5_2 = GetPlayerServerId
      L6_2 = L0_2
      L5_2 = L5_2(L6_2)
      L6_2 = L2_2[1]
      L7_2 = L2_2[2]
      L3_2(L4_2, L5_2, L6_2, L7_2)
    end
  else
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "No player nearby"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
  end
end
IssueLicense = L5_1
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L0_2 = GetActivePlayers
  L0_2 = L0_2()
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = GetEntityCoords
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = nil
  L4_2 = math
  L4_2 = L4_2.huge
  L5_2 = ipairs
  L6_2 = L0_2
  L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
  for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
    L11_2 = PlayerId
    L11_2 = L11_2()
    if L10_2 ~= L11_2 then
      L11_2 = GetPlayerPed
      L12_2 = L10_2
      L11_2 = L11_2(L12_2)
      L12_2 = DoesEntityExist
      L13_2 = L11_2
      L12_2 = L12_2(L13_2)
      if L12_2 then
        L12_2 = GetEntityCoords
        L13_2 = L11_2
        L12_2 = L12_2(L13_2)
        L13_2 = L2_2 - L12_2
        L13_2 = #L13_2
        if L4_2 > L13_2 then
          L4_2 = L13_2
          L3_2 = L11_2
        end
      end
    end
  end
  L5_2 = L3_2
  L6_2 = L4_2
  return L5_2, L6_2
end
function L6_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = Utils
  L0_2 = L0_2.DebugPrint
  L1_2 = "RevokeLicense: Starting function"
  L0_2(L1_2)
  L0_2 = Framework
  L0_2 = L0_2.GetClosestPlayer
  L0_2, L1_2 = L0_2()
  L2_2 = Utils
  L2_2 = L2_2.DebugPrint
  L3_2 = "RevokeLicense: Framework.GetClosestPlayer returned - Player:"
  L4_2 = L0_2
  L5_2 = "Distance:"
  L6_2 = L1_2
  L2_2(L3_2, L4_2, L5_2, L6_2)
  if not L0_2 or L1_2 < 0 or L1_2 > 3.0 then
    L2_2 = Utils
    L2_2 = L2_2.DebugPrint
    L3_2 = "RevokeLicense: Framework method failed, trying alternative method"
    L2_2(L3_2)
    L2_2 = L5_1
    L2_2, L3_2 = L2_2()
    L1_2 = L3_2
    L0_2 = L2_2
    L2_2 = Utils
    L2_2 = L2_2.DebugPrint
    L3_2 = "RevokeLicense: Alternative method returned - Player:"
    L4_2 = L0_2
    L5_2 = "Distance:"
    L6_2 = L1_2
    L2_2(L3_2, L4_2, L5_2, L6_2)
  end
  if L0_2 then
    L2_2 = DoesEntityExist
    L3_2 = L0_2
    L2_2 = L2_2(L3_2)
    if L2_2 and L1_2 < 3.0 then
      L2_2 = Utils
      L2_2 = L2_2.DebugPrint
      L3_2 = "RevokeLicense: Valid player entity found"
      L2_2(L3_2)
      L2_2 = GetPlayerServerId
      L3_2 = L0_2
      L2_2 = L2_2(L3_2)
      L0_1 = L2_2
      L2_2 = Utils
      L2_2 = L2_2.DebugPrint
      L3_2 = "RevokeLicense: Target ID:"
      L4_2 = L0_1
      L2_2(L3_2, L4_2)
      L2_2 = L0_1
      if L2_2 then
        L2_2 = L0_1
        if L2_2 > 0 then
          L2_2 = Utils
          L2_2 = L2_2.DebugPrint
          L3_2 = "RevokeLicense: Valid server ID, sending request"
          L2_2(L3_2)
          L2_2 = TriggerServerEvent
          L3_2 = "fs-government:server:getPlayerLicensesForRevoke"
          L4_2 = L0_1
          L2_2(L3_2, L4_2)
          L2_2 = Utils
          L2_2 = L2_2.DebugPrint
          L3_2 = "RevokeLicense: Sent request to server"
          L2_2(L3_2)
      end
      else
        L2_2 = Framework
        L2_2 = L2_2.ShowNotification
        L3_2 = "Invalid player ID detected"
        L4_2 = "error"
        L2_2(L3_2, L4_2)
        L2_2 = Utils
        L2_2 = L2_2.DebugError
        L3_2 = "RevokeLicense: Invalid server ID:"
        L4_2 = L0_1
        L2_2(L3_2, L4_2)
      end
  end
  else
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = "No player nearby (within 3 meters)"
    L4_2 = "error"
    L2_2(L3_2, L4_2)
    L2_2 = Utils
    L2_2 = L2_2.DebugWarn
    L3_2 = "RevokeLicense: No valid player nearby - Entity exists:"
    L4_2 = L0_2 or L4_2
    if L0_2 then
      L4_2 = DoesEntityExist
      L5_2 = L0_2
      L4_2 = L4_2(L5_2)
    end
    L5_2 = "Distance:"
    L6_2 = L1_2
    L2_2(L3_2, L4_2, L5_2, L6_2)
  end
end
RevokeLicense = L6_1
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showLicensesForRevoke"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L1_2 = Utils
  L1_2 = L1_2.DebugPrint
  L2_2 = "Client received showLicensesForRevoke event"
  L1_2(L2_2)
  L1_2 = Utils
  L1_2 = L1_2.DebugPrint
  L2_2 = "Licenses received:"
  L3_2 = json
  L3_2 = L3_2.encode
  L4_2 = A0_2
  L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2 = L3_2(L4_2)
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2)
  if A0_2 then
    L1_2 = #A0_2
    if 0 ~= L1_2 then
      goto lbl_28
    end
  end
  L1_2 = Utils
  L1_2 = L1_2.DebugPrint
  L2_2 = "No licenses found for player"
  L1_2(L2_2)
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "Player has no licenses to revoke"
  L3_2 = "error"
  L1_2(L2_2, L3_2)
  do return end
  ::lbl_28::
  L1_2 = Utils
  L1_2 = L1_2.DebugPrint
  L2_2 = "Found"
  L3_2 = #A0_2
  L4_2 = "licenses to revoke"
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = table
    L8_2 = L8_2.insert
    L9_2 = L1_2
    L10_2 = {}
    L11_2 = L7_2.type
    L10_2.value = L11_2
    L11_2 = L7_2.label
    L10_2.label = L11_2
    L8_2(L9_2, L10_2)
    L8_2 = Utils
    L8_2 = L8_2.DebugPrint
    L9_2 = "Added license option:"
    L10_2 = L7_2.type
    L11_2 = L7_2.label
    L8_2(L9_2, L10_2, L11_2)
  end
  L2_2 = Utils
  L2_2 = L2_2.DebugPrint
  L3_2 = "Opening revoke license dialog"
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.inputDialog
  L3_2 = "Revoke License"
  L4_2 = {}
  L5_2 = {}
  L5_2.type = "select"
  L5_2.label = "License to Revoke"
  L5_2.options = L1_2
  L5_2.required = true
  L6_2 = {}
  L6_2.type = "input"
  L6_2.label = "Reason"
  L6_2.placeholder = "Reason for revocation..."
  L6_2.required = true
  L4_2[1] = L5_2
  L4_2[2] = L6_2
  L2_2 = L2_2(L3_2, L4_2)
  if L2_2 then
    L3_2 = L0_1
    if L3_2 then
      L3_2 = Utils
      L3_2 = L3_2.DebugPrint
      L4_2 = "Revoking license:"
      L5_2 = L2_2[1]
      L6_2 = "Reason:"
      L7_2 = L2_2[2]
      L3_2(L4_2, L5_2, L6_2, L7_2)
      L3_2 = TriggerServerEvent
      L4_2 = "fs-government:server:revokeLicense"
      L5_2 = L0_1
      L6_2 = L2_2[1]
      L7_2 = L2_2[2]
      L3_2(L4_2, L5_2, L6_2, L7_2)
      L3_2 = nil
      L0_1 = L3_2
  end
  else
    L3_2 = Utils
    L3_2 = L3_2.DebugPrint
    L4_2 = "Revoke license dialog cancelled or no target ID"
    L3_2(L4_2)
  end
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showVehicleMenu"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = Config
  L3_2 = L3_2.Locations
  L3_2 = L3_2.garage
  L3_2 = L3_2.vehicles
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = table
    L8_2 = L8_2.insert
    L9_2 = L1_2
    L10_2 = {}
    L11_2 = L7_2.label
    L10_2.title = L11_2
    L11_2 = "Spawn "
    L12_2 = L7_2.label
    L11_2 = L11_2 .. L12_2
    L10_2.description = L11_2
    L10_2.icon = "fas fa-car"
    function L11_2()
      local L0_3, L1_3, L2_3
      L0_3 = TriggerServerEvent
      L1_3 = "fs-government:server:spawnVehicle"
      L2_3 = L7_2.model
      L0_3(L1_3, L2_3)
    end
    L10_2.onSelect = L11_2
    L8_2(L9_2, L10_2)
  end
  L2_2 = #A0_2
  if L2_2 > 0 then
    L2_2 = table
    L2_2 = L2_2.insert
    L3_2 = L1_2
    L4_2 = {}
    L4_2.title = "\226\148\128\226\148\128\226\148\128\226\148\128\226\148\128\226\148\128\226\148\128\226\148\128\226\148\128\226\148\128\226\148\128\226\148\128\226\148\128"
    L4_2.disabled = true
    L2_2(L3_2, L4_2)
    L2_2 = ipairs
    L3_2 = A0_2
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = table
      L8_2 = L8_2.insert
      L9_2 = L1_2
      L10_2 = {}
      L11_2 = "Return "
      L12_2 = L7_2.model
      L11_2 = L11_2 .. L12_2
      L10_2.title = L11_2
      L10_2.description = "Store this vehicle"
      L10_2.icon = "fas fa-parking"
      function L11_2()
        local L0_3, L1_3, L2_3
        L0_3 = TriggerServerEvent
        L1_3 = "fs-government:server:storeVehicle"
        L2_3 = L7_2.plate
        L0_3(L1_3, L2_3)
      end
      L10_2.onSelect = L11_2
      L8_2(L9_2, L10_2)
    end
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "government_garage_menu"
  L3_2.title = "Government Garage"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "government_garage_menu"
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showIdentity"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = string
  L1_2 = L1_2.format
  L2_2 = [[
Name: %s

Date of Birth: %s

Gender: %s

Nationality: %s

Job: %s

Rank: %s]]
  L3_2 = A0_2.name
  if not L3_2 then
    L3_2 = "Unknown"
  end
  L4_2 = A0_2.dateofbirth
  if not L4_2 then
    L4_2 = "Unknown"
  end
  L5_2 = A0_2.sex
  if not L5_2 then
    L5_2 = "Unknown"
  end
  L6_2 = A0_2.nationality
  if not L6_2 then
    L6_2 = "Unknown"
  end
  L7_2 = A0_2.job
  if not L7_2 then
    L7_2 = "Unemployed"
  end
  L8_2 = A0_2.rank
  if not L8_2 then
    L8_2 = "Unknown"
  end
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
  L2_2 = lib
  L2_2 = L2_2.alertDialog
  L3_2 = {}
  L3_2.header = "Player Identity"
  L3_2.content = L1_2
  L3_2.centered = true
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showOnlineStaff"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L1_2 = #A0_2
  if 0 == L1_2 then
    L1_2 = Framework
    L1_2 = L1_2.ShowNotification
    L2_2 = "No government staff currently online"
    L3_2 = "primary"
    L1_2(L2_2, L3_2)
    return
  end
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = table
    L8_2 = L8_2.insert
    L9_2 = L1_2
    L10_2 = {}
    L11_2 = L7_2.name
    L10_2.title = L11_2
    L11_2 = string
    L11_2 = L11_2.format
    L12_2 = "Job: %s | Grade: %d | ID: %d"
    L13_2 = L7_2.job
    L14_2 = L7_2.grade
    L15_2 = L7_2.serverId
    L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2)
    L10_2.description = L11_2
    L10_2.icon = "fas fa-user"
    L8_2(L9_2, L10_2)
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "government_online_staff"
  L4_2 = "\240\159\145\165 Online Government Staff ("
  L5_2 = #A0_2
  L6_2 = ")"
  L4_2 = L4_2 .. L5_2 .. L6_2
  L3_2.title = L4_2
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "government_online_staff"
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showEmployeeList"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L1_2 = #A0_2
  if 0 == L1_2 then
    L1_2 = Framework
    L1_2 = L1_2.ShowNotification
    L2_2 = "No employees found"
    L3_2 = "primary"
    L1_2(L2_2, L3_2)
    return
  end
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = "Grade "
    L9_2 = L7_2.grade
    L8_2 = L8_2 .. L9_2
    L9_2 = table
    L9_2 = L9_2.insert
    L10_2 = L1_2
    L11_2 = {}
    L12_2 = L7_2.name
    L11_2.title = L12_2
    L12_2 = string
    L12_2 = L12_2.format
    L13_2 = "%s - %s | Salary: $%d"
    L14_2 = L7_2.job
    L15_2 = L8_2
    L16_2 = L7_2.salary
    if not L16_2 then
      L16_2 = 0
    end
    L12_2 = L12_2(L13_2, L14_2, L15_2, L16_2)
    L11_2.description = L12_2
    L11_2.icon = "fas fa-user"
    function L12_2()
      local L0_3, L1_3
      L0_3 = OpenEmployeeActionsMenu
      L1_3 = L7_2
      L0_3(L1_3)
    end
    L11_2.onSelect = L12_2
    L9_2(L10_2, L11_2)
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "government_employee_list"
  L4_2 = "\240\159\147\139 Employee List ("
  L5_2 = #A0_2
  L6_2 = ")"
  L4_2 = L4_2 .. L5_2 .. L6_2
  L3_2.title = L4_2
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "government_employee_list"
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = "Grade "
  L2_2 = A0_2.grade
  L1_2 = L1_2 .. L2_2
  L2_2 = {}
  L3_2 = {}
  L3_2.title = "Promote Employee"
  L3_2.description = "Increase employee grade"
  L3_2.icon = "fas fa-arrow-up"
  L3_2.iconColor = "#27ae60"
  function L4_2()
    local L0_3, L1_3
    L0_3 = PromoteEmployeeById
    L1_3 = A0_2
    L0_3(L1_3)
  end
  L3_2.onSelect = L4_2
  L4_2 = {}
  L4_2.title = "Demote Employee"
  L4_2.description = "Decrease employee grade"
  L4_2.icon = "fas fa-arrow-down"
  L4_2.iconColor = "#f39c12"
  function L5_2()
    local L0_3, L1_3
    L0_3 = DemoteEmployeeById
    L1_3 = A0_2
    L0_3(L1_3)
  end
  L4_2.onSelect = L5_2
  L5_2 = {}
  L5_2.title = "Fire Employee"
  L5_2.description = "Remove employee from job"
  L5_2.icon = "fas fa-user-times"
  L5_2.iconColor = "#e74c3c"
  function L6_2()
    local L0_3, L1_3
    L0_3 = FireEmployeeById
    L1_3 = A0_2
    L0_3(L1_3)
  end
  L5_2.onSelect = L6_2
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "government_employee_actions"
  L5_2 = "\226\154\153\239\184\143 "
  L6_2 = A0_2.name
  L7_2 = " Actions"
  L5_2 = L5_2 .. L6_2 .. L7_2
  L4_2.title = L5_2
  L4_2.menu = "government_employee_list"
  L4_2.options = L2_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "government_employee_actions"
  L3_2(L4_2)
end
OpenEmployeeActionsMenu = L6_1
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = A0_2.grade
  if L1_2 >= 7 then
    L1_2 = Framework
    L1_2 = L1_2.ShowNotification
    L2_2 = "Employee is already at maximum grade"
    L3_2 = "error"
    L1_2(L2_2, L3_2)
    return
  end
  L1_2 = lib
  L1_2 = L1_2.alertDialog
  L2_2 = {}
  L2_2.header = "Promote Employee"
  L3_2 = string
  L3_2 = L3_2.format
  L4_2 = "Promote %s to grade %d?"
  L5_2 = A0_2.name
  L6_2 = A0_2.grade
  L6_2 = L6_2 + 1
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L2_2.content = L3_2
  L2_2.centered = true
  L2_2.cancel = true
  L1_2 = L1_2(L2_2)
  if "confirm" == L1_2 then
    L2_2 = TriggerServerEvent
    L3_2 = "fs-government:server:promoteEmployee"
    L4_2 = A0_2.identifier
    L5_2 = A0_2.grade
    L5_2 = L5_2 + 1
    L2_2(L3_2, L4_2, L5_2)
  end
end
PromoteEmployeeById = L6_1
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = A0_2.grade
  if L1_2 <= 0 then
    L1_2 = Framework
    L1_2 = L1_2.ShowNotification
    L2_2 = "Employee is already at minimum grade"
    L3_2 = "error"
    L1_2(L2_2, L3_2)
    return
  end
  L1_2 = lib
  L1_2 = L1_2.alertDialog
  L2_2 = {}
  L2_2.header = "Demote Employee"
  L3_2 = string
  L3_2 = L3_2.format
  L4_2 = "Demote %s to grade %d?"
  L5_2 = A0_2.name
  L6_2 = A0_2.grade
  L6_2 = L6_2 - 1
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L2_2.content = L3_2
  L2_2.centered = true
  L2_2.cancel = true
  L1_2 = L1_2(L2_2)
  if "confirm" == L1_2 then
    L2_2 = TriggerServerEvent
    L3_2 = "fs-government:server:demoteEmployee"
    L4_2 = A0_2.identifier
    L5_2 = A0_2.grade
    L5_2 = L5_2 - 1
    L2_2(L3_2, L4_2, L5_2)
  end
end
DemoteEmployeeById = L6_1
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = lib
  L1_2 = L1_2.alertDialog
  L2_2 = {}
  L2_2.header = "Fire Employee"
  L3_2 = string
  L3_2 = L3_2.format
  L4_2 = "Are you sure you want to fire %s?"
  L5_2 = A0_2.name
  L3_2 = L3_2(L4_2, L5_2)
  L2_2.content = L3_2
  L2_2.centered = true
  L2_2.cancel = true
  L1_2 = L1_2(L2_2)
  if "confirm" == L1_2 then
    L2_2 = TriggerServerEvent
    L3_2 = "fs-government:server:fireEmployeeById"
    L4_2 = A0_2.identifier
    L2_2(L3_2, L4_2)
  end
end
FireEmployeeById = L6_1
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:searchPlayer"
function L8_1()
  local L0_2, L1_2
  L0_2 = SearchNearbyPlayer
  L0_2()
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:toggleHandcuffs"
function L8_1()
  local L0_2, L1_2
  L0_2 = ToggleHandcuffs
  L0_2()
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:checkIdentity"
function L8_1()
  local L0_2, L1_2
  L0_2 = CheckPlayerIdentity
  L0_2()
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showSearchResults"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  if not A0_2 then
    return
  end
  L1_2 = {}
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L5_2 = "\240\159\145\164 "
  L6_2 = A0_2.targetName
  L5_2 = L5_2 .. L6_2
  L4_2.title = L5_2
  L5_2 = "Items found: "
  L6_2 = A0_2.itemCount
  L5_2 = L5_2 .. L6_2
  L4_2.description = L5_2
  L4_2.disabled = true
  L2_2(L3_2, L4_2)
  L2_2 = A0_2.licenses
  if L2_2 then
    L2_2 = A0_2.licenses
    L2_2 = #L2_2
    if L2_2 > 0 then
      L2_2 = table
      L2_2 = L2_2.insert
      L3_2 = L1_2
      L4_2 = {}
      L4_2.title = "\240\159\147\132 View Licenses"
      L5_2 = "View player licenses ("
      L6_2 = A0_2.licenses
      L6_2 = #L6_2
      L7_2 = " found)"
      L5_2 = L5_2 .. L6_2 .. L7_2
      L4_2.description = L5_2
      L4_2.icon = "fas fa-certificate"
      function L5_2()
        local L0_3, L1_3
        L0_3 = ShowPlayerLicenses
        L1_3 = A0_2.licenses
        L0_3(L1_3)
      end
      L4_2.onSelect = L5_2
      L2_2(L3_2, L4_2)
  end
  else
    L2_2 = table
    L2_2 = L2_2.insert
    L3_2 = L1_2
    L4_2 = {}
    L4_2.title = "\240\159\147\132 No Licenses Found"
    L4_2.description = "This player has no licenses"
    L4_2.disabled = true
    L2_2(L3_2, L4_2)
  end
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L4_2.title = "\240\159\142\146 Open Inventory"
  L4_2.description = "Open and confiscate from player inventory"
  L4_2.icon = "fas fa-box-open"
  function L5_2()
    local L0_3, L1_3, L2_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:openPlayerInventory"
    L2_3 = A0_2.targetId
    L0_3(L1_3, L2_3)
  end
  L4_2.onSelect = L5_2
  L2_2(L3_2, L4_2)
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "search_results"
  L3_2.title = "\240\159\148\141 Search Results"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "search_results"
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = table
    L8_2 = L8_2.insert
    L9_2 = L1_2
    L10_2 = {}
    L11_2 = "\226\156\133 "
    L12_2 = L7_2.label
    L11_2 = L11_2 .. L12_2
    L10_2.title = L11_2
    L11_2 = "License Type: "
    L12_2 = L7_2.type
    L11_2 = L11_2 .. L12_2
    L10_2.description = L11_2
    L10_2.icon = "fas fa-check-circle"
    L8_2(L9_2, L10_2)
  end
  L2_2 = #L1_2
  if 0 == L2_2 then
    L2_2 = table
    L2_2 = L2_2.insert
    L3_2 = L1_2
    L4_2 = {}
    L4_2.title = "No Licenses"
    L4_2.description = "This player has no licenses"
    L4_2.disabled = true
    L2_2(L3_2, L4_2)
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "player_licenses"
  L3_2.title = "\240\159\147\132 Player Licenses"
  L3_2.menu = "search_results"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "player_licenses"
  L2_2(L3_2)
end
ShowPlayerLicenses = L6_1
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showPlayerLicenses"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  if A0_2 then
    L1_2 = A0_2.licenses
    if L1_2 then
      goto lbl_7
    end
  end
  do return end
  ::lbl_7::
  L1_2 = {}
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L5_2 = "\240\159\145\164 "
  L6_2 = A0_2.playerName
  L5_2 = L5_2 .. L6_2
  L4_2.title = L5_2
  L4_2.description = "License information for this player"
  L4_2.disabled = true
  L2_2(L3_2, L4_2)
  L2_2 = A0_2.licenses
  L2_2 = #L2_2
  if L2_2 > 0 then
    L2_2 = ipairs
    L3_2 = A0_2.licenses
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = table
      L8_2 = L8_2.insert
      L9_2 = L1_2
      L10_2 = {}
      L11_2 = "\226\156\133 "
      L12_2 = L7_2.label
      L11_2 = L11_2 .. L12_2
      L10_2.title = L11_2
      L11_2 = "License Type: "
      L12_2 = L7_2.type
      L11_2 = L11_2 .. L12_2
      L10_2.description = L11_2
      L10_2.icon = "fas fa-certificate"
      function L11_2()
        local L0_3, L1_3, L2_3, L3_3
        L0_3 = ShowLicenseActions
        L1_3 = A0_2.playerId
        L2_3 = L7_2.type
        L3_3 = L7_2.label
        L0_3(L1_3, L2_3, L3_3)
      end
      L10_2.onSelect = L11_2
      L8_2(L9_2, L10_2)
    end
  else
    L2_2 = table
    L2_2 = L2_2.insert
    L3_2 = L1_2
    L4_2 = {}
    L4_2.title = "\226\157\140 No Licenses Found"
    L4_2.description = "This player has no licenses"
    L4_2.disabled = true
    L2_2(L3_2, L4_2)
  end
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L4_2.title = "\226\158\149 Issue New License"
  L4_2.description = "Issue a new license to this player"
  L4_2.icon = "fas fa-plus"
  function L5_2()
    local L0_3, L1_3
    L0_3 = IssueLicenseToPlayer
    L1_3 = A0_2.playerId
    L0_3(L1_3)
  end
  L4_2.onSelect = L5_2
  L2_2(L3_2, L4_2)
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "player_licenses_display"
  L3_2.title = "\240\159\147\132 Player Licenses"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "player_licenses_display"
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
function L6_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = {}
  L4_2 = {}
  L4_2.title = "\240\159\151\145\239\184\143 Revoke License"
  L4_2.description = "Revoke this license from the player"
  L4_2.icon = "fas fa-times"
  function L5_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    L0_3 = lib
    L0_3 = L0_3.alertDialog
    L1_3 = {}
    L1_3.header = "Revoke License"
    L2_3 = "Are you sure you want to revoke the "
    L3_3 = A2_2
    L4_3 = " license?"
    L2_3 = L2_3 .. L3_3 .. L4_3
    L1_3.content = L2_3
    L1_3.centered = true
    L1_3.cancel = true
    L0_3 = L0_3(L1_3)
    if "confirm" == L0_3 then
      L1_3 = TriggerServerEvent
      L2_3 = "fs-government:server:revokeLicense"
      L3_3 = A0_2
      L4_3 = A1_2
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L4_2.onSelect = L5_2
  L5_2 = {}
  L5_2.title = "\240\159\147\139 Back to Licenses"
  L5_2.description = "Return to license list"
  L5_2.icon = "fas fa-arrow-left"
  function L6_2()
    local L0_3, L1_3, L2_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:checkLicenses"
    L2_3 = A0_2
    L0_3(L1_3, L2_3)
  end
  L5_2.onSelect = L6_2
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L4_2 = lib
  L4_2 = L4_2.registerContext
  L5_2 = {}
  L5_2.id = "license_actions"
  L6_2 = "\240\159\148\167 License Actions - "
  L7_2 = A2_2
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.menu = "player_licenses_display"
  L5_2.options = L3_2
  L4_2(L5_2)
  L4_2 = lib
  L4_2 = L4_2.showContext
  L5_2 = "license_actions"
  L4_2(L5_2)
end
ShowLicenseActions = L6_1
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L1_2 = lib
  L1_2 = L1_2.inputDialog
  L2_2 = "Issue License"
  L3_2 = {}
  L4_2 = {}
  L4_2.type = "select"
  L4_2.label = "License Type"
  L5_2 = {}
  L6_2 = {}
  L6_2.value = "dmv"
  L6_2.label = "Driving License"
  L7_2 = {}
  L7_2.value = "weapon"
  L7_2.label = "Weapon License"
  L8_2 = {}
  L8_2.value = "business"
  L8_2.label = "Business License"
  L9_2 = {}
  L9_2.value = "fishing"
  L9_2.label = "Fishing License"
  L10_2 = {}
  L10_2.value = "hunting"
  L10_2.label = "Hunting License"
  L11_2 = {}
  L11_2.value = "pilot"
  L11_2.label = "Pilot License"
  L12_2 = {}
  L12_2.value = "bike"
  L12_2.label = "Motorcycle License"
  L13_2 = {}
  L13_2.value = "truck"
  L13_2.label = "Truck License"
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  L5_2[3] = L8_2
  L5_2[4] = L9_2
  L5_2[5] = L10_2
  L5_2[6] = L11_2
  L5_2[7] = L12_2
  L5_2[8] = L13_2
  L4_2.options = L5_2
  L4_2.required = true
  L5_2 = {}
  L5_2.type = "textarea"
  L5_2.label = "Notes"
  L5_2.placeholder = "Additional notes..."
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L2_2 = TriggerServerEvent
    L3_2 = "fs-government:server:issueLicense"
    L4_2 = A0_2
    L5_2 = L1_2[1]
    L6_2 = L1_2[2]
    L2_2(L3_2, L4_2, L5_2, L6_2)
  end
end
IssueLicenseToPlayer = L6_1
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showPlayerFines"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  if A0_2 then
    L1_2 = #A0_2
    if 0 ~= L1_2 then
      goto lbl_12
    end
  end
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "You have no outstanding fines"
  L3_2 = "success"
  L1_2(L2_2, L3_2)
  do return end
  ::lbl_12::
  L1_2 = {}
  L2_2 = 0
  L3_2 = ipairs
  L4_2 = A0_2
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
    L9_2 = "\240\159\148\180"
    L10_2 = "UNPAID"
    L11_2 = L8_2.status
    if "paid" == L11_2 then
      L9_2 = "\240\159\159\162"
      L10_2 = "PAID"
    else
      L11_2 = L8_2.status
      if "cancelled" == L11_2 then
        L9_2 = "\226\154\171"
        L10_2 = "CANCELLED"
      else
        L11_2 = L8_2.amount
        L2_2 = L2_2 + L11_2
      end
    end
    L11_2 = L9_2
    L12_2 = " $"
    L13_2 = L8_2.amount
    L14_2 = " - "
    L15_2 = L10_2
    L11_2 = L11_2 .. L12_2 .. L13_2 .. L14_2 .. L15_2
    L12_2 = "Reason: "
    L13_2 = L8_2.reason
    L14_2 = " | Issued by: "
    L15_2 = L8_2.issued_by_name
    L12_2 = L12_2 .. L13_2 .. L14_2 .. L15_2
    L13_2 = {}
    L13_2.title = L11_2
    L13_2.description = L12_2
    L14_2 = {}
    L15_2 = {}
    L15_2.label = "Fine ID"
    L16_2 = "#"
    L17_2 = L8_2.id
    L16_2 = L16_2 .. L17_2
    L15_2.value = L16_2
    L16_2 = {}
    L16_2.label = "Date"
    L17_2 = L8_2.created_at
    L16_2.value = L17_2
    L14_2[1] = L15_2
    L14_2[2] = L16_2
    L13_2.metadata = L14_2
    L14_2 = L8_2.status
    if "unpaid" == L14_2 then
      function L14_2()
        local L0_3, L1_3
        L0_3 = ShowFinePaymentDialog
        L1_3 = L8_2
        L0_3(L1_3)
      end
      L13_2.onSelect = L14_2
    else
      L13_2.disabled = true
    end
    L14_2 = table
    L14_2 = L14_2.insert
    L15_2 = L1_2
    L16_2 = L13_2
    L14_2(L15_2, L16_2)
  end
  if L2_2 > 0 then
    L3_2 = table
    L3_2 = L3_2.insert
    L4_2 = L1_2
    L5_2 = 1
    L6_2 = {}
    L7_2 = "\240\159\146\176 Total Unpaid: $"
    L8_2 = L2_2
    L7_2 = L7_2 .. L8_2
    L6_2.title = L7_2
    L6_2.description = "Total amount of unpaid fines"
    L6_2.disabled = true
    L3_2(L4_2, L5_2, L6_2)
  end
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "player_fines"
  L4_2.title = "\240\159\146\184 My Fines"
  L4_2.options = L1_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "player_fines"
  L3_2(L4_2)
end
L6_1(L7_1, L8_1)
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = lib
  L1_2 = L1_2.alertDialog
  L2_2 = {}
  L2_2.header = "Pay Fine"
  L3_2 = [[
Are you sure you want to pay this fine?

Amount: $]]
  L4_2 = A0_2.amount
  L5_2 = [[

Reason: ]]
  L6_2 = A0_2.reason
  L7_2 = [[


This will be deducted from your bank account.]]
  L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2 .. L7_2
  L2_2.content = L3_2
  L2_2.centered = true
  L2_2.cancel = true
  L1_2 = L1_2(L2_2)
  if "confirm" == L1_2 then
    L2_2 = TriggerServerEvent
    L3_2 = "fs-government:server:payFine"
    L4_2 = A0_2.id
    L2_2(L3_2, L4_2)
  end
end
ShowFinePaymentDialog = L6_1
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showSeizures"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  if A0_2 then
    L1_2 = #A0_2
    if 0 ~= L1_2 then
      goto lbl_12
    end
  end
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "No seizures found"
  L3_2 = "primary"
  L1_2(L2_2, L3_2)
  do return end
  ::lbl_12::
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = "\240\159\148\180"
    L9_2 = L7_2.status
    if "returned" == L9_2 then
      L8_2 = "\240\159\159\162"
    else
      L9_2 = L7_2.status
      if "deleted" == L9_2 then
        L8_2 = "\226\154\171"
      end
    end
    L9_2 = L8_2
    L10_2 = " "
    L11_2 = L7_2.item_description
    L9_2 = L9_2 .. L10_2 .. L11_2
    L10_2 = "Target: "
    L11_2 = L7_2.target_name
    L12_2 = " | Reason: "
    L13_2 = L7_2.reason
    L14_2 = " | Status: "
    L15_2 = FormatStatusText
    L16_2 = L7_2.status
    L15_2 = L15_2(L16_2)
    L10_2 = L10_2 .. L11_2 .. L12_2 .. L13_2 .. L14_2 .. L15_2
    L11_2 = table
    L11_2 = L11_2.insert
    L12_2 = L1_2
    L13_2 = {}
    L13_2.title = L9_2
    L13_2.description = L10_2
    L14_2 = {}
    L15_2 = {}
    L15_2.label = "Seized By"
    L16_2 = L7_2.seized_by
    L15_2.value = L16_2
    L16_2 = {}
    L16_2.label = "Date"
    L17_2 = L7_2.formatted_date
    if not L17_2 then
      L17_2 = L7_2.created_at
    end
    L16_2.value = L17_2
    L14_2[1] = L15_2
    L14_2[2] = L16_2
    L13_2.metadata = L14_2
    function L14_2()
      local L0_3, L1_3
      L0_3 = ShowSeizureDetails
      L1_3 = L7_2
      L0_3(L1_3)
    end
    L13_2.onSelect = L14_2
    L11_2(L12_2, L13_2)
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "seizures_list"
  L3_2.title = "\240\159\148\146 Asset Seizures"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "seizures_list"
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showSeizureHistory"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  if A0_2 then
    L1_2 = #A0_2
    if 0 ~= L1_2 then
      goto lbl_12
    end
  end
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "No seizure history found"
  L3_2 = "primary"
  L1_2(L2_2, L3_2)
  do return end
  ::lbl_12::
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = "\240\159\148\180"
    L9_2 = L7_2.status
    if "returned" == L9_2 then
      L8_2 = "\240\159\159\162"
    else
      L9_2 = L7_2.status
      if "deleted" == L9_2 then
        L8_2 = "\226\154\171"
      else
        L9_2 = L7_2.status
        if "destroyed" == L9_2 then
          L8_2 = "\240\159\146\165"
        end
      end
    end
    L9_2 = L8_2
    L10_2 = " "
    L11_2 = L7_2.item_description
    L9_2 = L9_2 .. L10_2 .. L11_2
    L10_2 = "Target: "
    L11_2 = L7_2.target_name
    L12_2 = " | Status: "
    L13_2 = FormatStatusText
    L14_2 = L7_2.status
    L13_2 = L13_2(L14_2)
    L10_2 = L10_2 .. L11_2 .. L12_2 .. L13_2
    L11_2 = table
    L11_2 = L11_2.insert
    L12_2 = L1_2
    L13_2 = {}
    L13_2.title = L9_2
    L13_2.description = L10_2
    L14_2 = {}
    L15_2 = {}
    L15_2.label = "Date"
    L16_2 = L7_2.formatted_date
    if not L16_2 then
      L16_2 = L7_2.created_at
    end
    L15_2.value = L16_2
    L16_2 = {}
    L16_2.label = "Seized By"
    L17_2 = L7_2.seized_by
    L16_2.value = L17_2
    L14_2[1] = L15_2
    L14_2[2] = L16_2
    L13_2.metadata = L14_2
    function L14_2()
      local L0_3, L1_3
      L0_3 = ShowSeizureDetails
      L1_3 = L7_2
      L0_3(L1_3)
    end
    L13_2.onSelect = L14_2
    L11_2(L12_2, L13_2)
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "seizure_history"
  L3_2.title = "\240\159\147\154 Seizure History"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "seizure_history"
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = GetCurrentPlayerJobData
  L1_2, L2_2 = L1_2()
  if not L1_2 then
    return
  end
  L3_2 = {}
  L4_2 = table
  L4_2 = L4_2.insert
  L5_2 = L3_2
  L6_2 = {}
  L6_2.title = "View Details"
  L6_2.description = "Show complete seizure information"
  L6_2.icon = "fas fa-info-circle"
  function L7_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L0_3 = {}
    L1_3 = {}
    L1_3.label = "Item Type"
    L2_3 = A0_2.item_type
    L3_3 = L2_3
    L2_3 = L2_3.upper
    L2_3 = L2_3(L3_3)
    L1_3.value = L2_3
    L2_3 = {}
    L2_3.label = "Item ID"
    L3_3 = A0_2.item_identifier
    L2_3.value = L3_3
    L3_3 = {}
    L3_3.label = "Description"
    L4_3 = A0_2.item_description
    L3_3.value = L4_3
    L4_3 = {}
    L4_3.label = "Target"
    L5_3 = A0_2.target_name
    L4_3.value = L5_3
    L5_3 = {}
    L5_3.label = "Reason"
    L6_3 = A0_2.reason
    L5_3.value = L6_3
    L6_3 = {}
    L6_3.label = "Status"
    L7_3 = FormatStatusText
    L8_3 = A0_2.status
    L7_3 = L7_3(L8_3)
    L6_3.value = L7_3
    L7_3 = {}
    L7_3.label = "Seized By"
    L8_3 = A0_2.seized_by
    L7_3.value = L8_3
    L8_3 = {}
    L8_3.label = "Date Seized"
    L9_3 = A0_2.formatted_date
    if not L9_3 then
      L9_3 = A0_2.created_at
    end
    L8_3.value = L9_3
    L0_3[1] = L1_3
    L0_3[2] = L2_3
    L0_3[3] = L3_3
    L0_3[4] = L4_3
    L0_3[5] = L5_3
    L0_3[6] = L6_3
    L0_3[7] = L7_3
    L0_3[8] = L8_3
    L1_3 = A0_2.returned_by
    if L1_3 then
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Returned By"
      L4_3 = A0_2.returned_by
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Return Date"
      L4_3 = A0_2.formatted_returned_date
      if not L4_3 then
        L4_3 = A0_2.returned_at
      end
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
    end
    L1_3 = A0_2.deleted_by
    if L1_3 then
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Deleted By"
      L4_3 = A0_2.deleted_by
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Deletion Reason"
      L4_3 = A0_2.deletion_reason
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Delete Date"
      L4_3 = A0_2.formatted_deleted_date
      if not L4_3 then
        L4_3 = A0_2.deleted_at
      end
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
    end
    L1_3 = lib
    L1_3 = L1_3.alertDialog
    L2_3 = {}
    L3_3 = "Seizure Details - ID: "
    L4_3 = A0_2.id
    L3_3 = L3_3 .. L4_3
    L2_3.header = L3_3
    L2_3.content = "Complete information about this seizure:"
    L2_3.metadata = L0_3
    L2_3.centered = true
    L2_3.cancel = true
    L1_3(L2_3)
  end
  L6_2.onSelect = L7_2
  L4_2(L5_2, L6_2)
  L4_2 = A0_2.status
  if "seized" == L4_2 then
    L4_2 = Utils
    L4_2 = L4_2.HasPermission
    L5_2 = L1_2
    L6_2 = L2_2
    L7_2 = "seizure"
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    if L4_2 then
      L4_2 = table
      L4_2 = L4_2.insert
      L5_2 = L3_2
      L6_2 = {}
      L6_2.title = "Return Seizure"
      L6_2.description = "Return this seized property to the owner"
      L6_2.icon = "fas fa-undo"
      function L7_2()
        local L0_3, L1_3, L2_3, L3_3
        L0_3 = lib
        L0_3 = L0_3.alertDialog
        L1_3 = {}
        L1_3.header = "Confirm Return"
        L1_3.content = "Are you sure you want to return this seized property?"
        L1_3.centered = true
        L1_3.cancel = true
        L0_3 = L0_3(L1_3)
        if "confirm" == L0_3 then
          L1_3 = TriggerServerEvent
          L2_3 = "fs-government:server:returnSeizure"
          L3_3 = A0_2.id
          L1_3(L2_3, L3_3)
        end
      end
      L6_2.onSelect = L7_2
      L4_2(L5_2, L6_2)
      L4_2 = Utils
      L4_2 = L4_2.HasPermission
      L5_2 = L1_2
      L6_2 = L2_2
      L7_2 = "all"
      L4_2 = L4_2(L5_2, L6_2, L7_2)
      if L4_2 then
        L4_2 = table
        L4_2 = L4_2.insert
        L5_2 = L3_2
        L6_2 = {}
        L6_2.title = "Delete Seizure Record"
        L6_2.description = "Permanently delete this seizure record"
        L6_2.icon = "fas fa-trash"
        function L7_2()
          local L0_3, L1_3, L2_3, L3_3, L4_3
          L0_3 = lib
          L0_3 = L0_3.inputDialog
          L1_3 = "Delete Seizure Record"
          L2_3 = {}
          L3_3 = {}
          L3_3.type = "input"
          L3_3.label = "Deletion Reason"
          L3_3.required = true
          L3_3.min = 5
          L2_3[1] = L3_3
          L0_3 = L0_3(L1_3, L2_3)
          if L0_3 then
            L1_3 = L0_3[1]
            if L1_3 then
              L1_3 = TriggerServerEvent
              L2_3 = "fs-government:server:deleteSeizure"
              L3_3 = A0_2.id
              L4_3 = L0_3[1]
              L1_3(L2_3, L3_3, L4_3)
            end
          end
        end
        L6_2.onSelect = L7_2
        L4_2(L5_2, L6_2)
      end
    end
  end
  L4_2 = lib
  L4_2 = L4_2.registerContext
  L5_2 = {}
  L5_2.id = "seizure_details"
  L6_2 = "\240\159\148\141 Seizure: "
  L7_2 = A0_2.id
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.menu = "seizures_list"
  L5_2.options = L3_2
  L4_2(L5_2)
  L4_2 = lib
  L4_2 = L4_2.showContext
  L5_2 = "seizure_details"
  L4_2(L5_2)
end
ShowSeizureDetails = L6_1
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showWarrants"
function L8_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  if A0_2 then
    L2_2 = #A0_2
    if 0 ~= L2_2 then
      goto lbl_16
    end
  end
  L2_2 = Framework
  L2_2 = L2_2.ShowNotification
  L3_2 = "No warrants found for "
  L4_2 = A1_2 or L4_2
  if not A1_2 then
    L4_2 = "search"
  end
  L3_2 = L3_2 .. L4_2
  L4_2 = "primary"
  L2_2(L3_2, L4_2)
  do return end
  ::lbl_16::
  L2_2 = {}
  L3_2 = ipairs
  L4_2 = A0_2
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
    L9_2 = "\240\159\159\161"
    L10_2 = L8_2.urgency
    if "high" == L10_2 then
      L9_2 = "\240\159\148\180"
    else
      L10_2 = L8_2.urgency
      if "low" == L10_2 then
        L9_2 = "\240\159\159\162"
      end
    end
    L10_2 = L9_2
    L11_2 = " "
    L12_2 = L8_2.warrant_number
    L10_2 = L10_2 .. L11_2 .. L12_2
    L11_2 = "Target: "
    L12_2 = L8_2.target_name
    L13_2 = " | Offense: "
    L14_2 = L8_2.offense
    L11_2 = L11_2 .. L12_2 .. L13_2 .. L14_2
    L12_2 = table
    L12_2 = L12_2.insert
    L13_2 = L2_2
    L14_2 = {}
    L14_2.title = L10_2
    L14_2.description = L11_2
    L15_2 = {}
    L16_2 = {}
    L16_2.label = "Urgency"
    L17_2 = L8_2.urgency
    L18_2 = L17_2
    L17_2 = L17_2.upper
    L17_2 = L17_2(L18_2)
    L16_2.value = L17_2
    L17_2 = {}
    L17_2.label = "Issued"
    L18_2 = L8_2.formatted_date
    if not L18_2 then
      L18_2 = L8_2.created_at
    end
    L17_2.value = L18_2
    L15_2[1] = L16_2
    L15_2[2] = L17_2
    L14_2.metadata = L15_2
    function L15_2()
      local L0_3, L1_3
      L0_3 = ShowWarrantDetails
      L1_3 = L8_2
      L0_3(L1_3)
    end
    L14_2.onSelect = L15_2
    L12_2(L13_2, L14_2)
  end
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "warrants_search_results"
  L5_2 = "\240\159\142\175 Warrants: "
  L6_2 = A1_2 or L6_2
  if not A1_2 then
    L6_2 = "Results"
  end
  L5_2 = L5_2 .. L6_2
  L4_2.title = L5_2
  L4_2.options = L2_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "warrants_search_results"
  L3_2(L4_2)
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showAllWarrants"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  if A0_2 then
    L1_2 = #A0_2
    if 0 ~= L1_2 then
      goto lbl_12
    end
  end
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "No active warrants found"
  L3_2 = "primary"
  L1_2(L2_2, L3_2)
  do return end
  ::lbl_12::
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = "\240\159\159\161"
    L9_2 = L7_2.urgency
    if "high" == L9_2 then
      L8_2 = "\240\159\148\180"
    else
      L9_2 = L7_2.urgency
      if "low" == L9_2 then
        L8_2 = "\240\159\159\162"
      end
    end
    L9_2 = L8_2
    L10_2 = " "
    L11_2 = L7_2.warrant_number
    L9_2 = L9_2 .. L10_2 .. L11_2
    L10_2 = "Target: "
    L11_2 = L7_2.target_name
    L12_2 = " | Offense: "
    L13_2 = L7_2.offense
    L10_2 = L10_2 .. L11_2 .. L12_2 .. L13_2
    L11_2 = table
    L11_2 = L11_2.insert
    L12_2 = L1_2
    L13_2 = {}
    L13_2.title = L9_2
    L13_2.description = L10_2
    L14_2 = {}
    L15_2 = {}
    L15_2.label = "Urgency"
    L16_2 = L7_2.urgency
    L17_2 = L16_2
    L16_2 = L16_2.upper
    L16_2 = L16_2(L17_2)
    L15_2.value = L16_2
    L16_2 = {}
    L16_2.label = "Issued"
    L17_2 = L7_2.formatted_date
    if not L17_2 then
      L17_2 = L7_2.created_at
    end
    L16_2.value = L17_2
    L14_2[1] = L15_2
    L14_2[2] = L16_2
    L13_2.metadata = L14_2
    function L14_2()
      local L0_3, L1_3
      L0_3 = ShowWarrantDetails
      L1_3 = L7_2
      L0_3(L1_3)
    end
    L13_2.onSelect = L14_2
    L11_2(L12_2, L13_2)
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "all_warrants"
  L3_2.title = "\226\154\150\239\184\143 Active Warrants"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "all_warrants"
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showWarrantHistory"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  if A0_2 then
    L1_2 = #A0_2
    if 0 ~= L1_2 then
      goto lbl_12
    end
  end
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "No warrant history found"
  L3_2 = "primary"
  L1_2(L2_2, L3_2)
  do return end
  ::lbl_12::
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = "\240\159\148\180"
    L9_2 = L7_2.status
    if "executed" == L9_2 then
      L8_2 = "\226\156\133"
    else
      L9_2 = L7_2.status
      if "cancelled" == L9_2 then
        L8_2 = "\226\157\140"
      end
    end
    L9_2 = "\240\159\159\161"
    L10_2 = L7_2.urgency
    if "high" == L10_2 then
      L9_2 = "\240\159\148\180"
    else
      L10_2 = L7_2.urgency
      if "low" == L10_2 then
        L9_2 = "\240\159\159\162"
      end
    end
    L10_2 = L8_2
    L11_2 = " "
    L12_2 = L7_2.warrant_number
    L10_2 = L10_2 .. L11_2 .. L12_2
    L11_2 = "Target: "
    L12_2 = L7_2.target_name
    L13_2 = " | Status: "
    L14_2 = FormatStatusText
    L15_2 = L7_2.status
    L14_2 = L14_2(L15_2)
    L11_2 = L11_2 .. L12_2 .. L13_2 .. L14_2
    L12_2 = table
    L12_2 = L12_2.insert
    L13_2 = L1_2
    L14_2 = {}
    L14_2.title = L10_2
    L14_2.description = L11_2
    L15_2 = {}
    L16_2 = {}
    L16_2.label = "Urgency"
    L17_2 = L7_2.urgency
    L18_2 = L17_2
    L17_2 = L17_2.upper
    L17_2 = L17_2(L18_2)
    L16_2.value = L17_2
    L17_2 = {}
    L17_2.label = "Issued"
    L18_2 = L7_2.formatted_date
    if not L18_2 then
      L18_2 = L7_2.created_at
    end
    L17_2.value = L18_2
    L15_2[1] = L16_2
    L15_2[2] = L17_2
    L14_2.metadata = L15_2
    function L15_2()
      local L0_3, L1_3
      L0_3 = ShowWarrantDetails
      L1_3 = L7_2
      L0_3(L1_3)
    end
    L14_2.onSelect = L15_2
    L12_2(L13_2, L14_2)
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "warrant_history"
  L3_2.title = "\240\159\147\156 Warrant History"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "warrant_history"
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = GetCurrentPlayerJobData
  L1_2, L2_2 = L1_2()
  if not L1_2 then
    return
  end
  L3_2 = {}
  L4_2 = table
  L4_2 = L4_2.insert
  L5_2 = L3_2
  L6_2 = {}
  L6_2.title = "View Details"
  L6_2.description = "Show complete warrant information"
  L6_2.icon = "fas fa-info-circle"
  function L7_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L0_3 = {}
    L1_3 = {}
    L1_3.label = "Warrant Number"
    L2_3 = A0_2.warrant_number
    L1_3.value = L2_3
    L2_3 = {}
    L2_3.label = "Target"
    L3_3 = A0_2.target_name
    L2_3.value = L3_3
    L3_3 = {}
    L3_3.label = "Offense"
    L4_3 = A0_2.offense
    L3_3.value = L4_3
    L4_3 = {}
    L4_3.label = "Details"
    L5_3 = A0_2.details
    if not L5_3 then
      L5_3 = "No details provided"
    end
    L4_3.value = L5_3
    L5_3 = {}
    L5_3.label = "Urgency"
    L6_3 = A0_2.urgency
    L7_3 = L6_3
    L6_3 = L6_3.upper
    L6_3 = L6_3(L7_3)
    L5_3.value = L6_3
    L6_3 = {}
    L6_3.label = "Status"
    L7_3 = FormatStatusText
    L8_3 = A0_2.status
    L7_3 = L7_3(L8_3)
    L6_3.value = L7_3
    L7_3 = {}
    L7_3.label = "Issued By"
    L8_3 = A0_2.issued_by
    L7_3.value = L8_3
    L8_3 = {}
    L8_3.label = "Date Issued"
    L9_3 = A0_2.formatted_date
    if not L9_3 then
      L9_3 = A0_2.created_at
    end
    L8_3.value = L9_3
    L0_3[1] = L1_3
    L0_3[2] = L2_3
    L0_3[3] = L3_3
    L0_3[4] = L4_3
    L0_3[5] = L5_3
    L0_3[6] = L6_3
    L0_3[7] = L7_3
    L0_3[8] = L8_3
    L1_3 = A0_2.executed_by
    if L1_3 then
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Executed By"
      L4_3 = A0_2.executed_by
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Execution Date"
      L4_3 = A0_2.formatted_executed_date
      if not L4_3 then
        L4_3 = A0_2.executed_at
      end
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
    end
    L1_3 = A0_2.cancelled_by
    if L1_3 then
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Cancelled By"
      L4_3 = A0_2.cancelled_by
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Cancellation Reason"
      L4_3 = A0_2.cancellation_reason
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Cancel Date"
      L4_3 = A0_2.formatted_cancelled_date
      if not L4_3 then
        L4_3 = A0_2.cancelled_at
      end
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
    end
    L1_3 = lib
    L1_3 = L1_3.alertDialog
    L2_3 = {}
    L2_3.header = "Warrant Details"
    L2_3.content = "Complete information about this warrant:"
    L2_3.metadata = L0_3
    L2_3.centered = true
    L2_3.cancel = true
    L1_3(L2_3)
  end
  L6_2.onSelect = L7_2
  L4_2(L5_2, L6_2)
  L4_2 = A0_2.status
  if "active" == L4_2 then
    L4_2 = Utils
    L4_2 = L4_2.HasPermission
    L5_2 = L1_2
    L6_2 = L2_2
    L7_2 = "warrant_issue"
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    if L4_2 then
      L4_2 = table
      L4_2 = L4_2.insert
      L5_2 = L3_2
      L6_2 = {}
      L6_2.title = "Execute Warrant"
      L6_2.description = "Mark this warrant as executed"
      L6_2.icon = "fas fa-check"
      function L7_2()
        local L0_3, L1_3, L2_3, L3_3
        L0_3 = lib
        L0_3 = L0_3.alertDialog
        L1_3 = {}
        L1_3.header = "Execute Warrant"
        L1_3.content = "Are you sure you want to execute this warrant?"
        L1_3.centered = true
        L1_3.cancel = true
        L0_3 = L0_3(L1_3)
        if "confirm" == L0_3 then
          L1_3 = TriggerServerEvent
          L2_3 = "fs-government:server:executeWarrant"
          L3_3 = A0_2.id
          L1_3(L2_3, L3_3)
        end
      end
      L6_2.onSelect = L7_2
      L4_2(L5_2, L6_2)
      L4_2 = table
      L4_2 = L4_2.insert
      L5_2 = L3_2
      L6_2 = {}
      L6_2.title = "Cancel Warrant"
      L6_2.description = "Cancel this active warrant"
      L6_2.icon = "fas fa-times"
      function L7_2()
        local L0_3, L1_3, L2_3, L3_3, L4_3
        L0_3 = lib
        L0_3 = L0_3.inputDialog
        L1_3 = "Cancel Warrant"
        L2_3 = {}
        L3_3 = {}
        L3_3.type = "input"
        L3_3.label = "Cancellation Reason"
        L3_3.required = true
        L3_3.min = 5
        L2_3[1] = L3_3
        L0_3 = L0_3(L1_3, L2_3)
        if L0_3 then
          L1_3 = L0_3[1]
          if L1_3 then
            L1_3 = TriggerServerEvent
            L2_3 = "fs-government:server:cancelWarrant"
            L3_3 = A0_2.id
            L4_3 = L0_3[1]
            L1_3(L2_3, L3_3, L4_3)
          end
        end
      end
      L6_2.onSelect = L7_2
      L4_2(L5_2, L6_2)
    end
  end
  L4_2 = lib
  L4_2 = L4_2.registerContext
  L5_2 = {}
  L5_2.id = "warrant_details"
  L6_2 = "\240\159\142\175 Warrant: "
  L7_2 = A0_2.warrant_number
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L6_2 = A0_2.status
  if "active" == L6_2 then
    L6_2 = "all_warrants"
    if L6_2 then
      goto lbl_68
    end
  end
  L6_2 = "warrant_history"
  ::lbl_68::
  L5_2.menu = L6_2
  L5_2.options = L3_2
  L4_2(L5_2)
  L4_2 = lib
  L4_2 = L4_2.showContext
  L5_2 = "warrant_details"
  L4_2(L5_2)
end
ShowWarrantDetails = L6_1
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showActivePermits"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  if A0_2 then
    L1_2 = #A0_2
    if 0 ~= L1_2 then
      goto lbl_12
    end
  end
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "No active permits found"
  L3_2 = "primary"
  L1_2(L2_2, L3_2)
  do return end
  ::lbl_12::
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = "\240\159\147\132 "
    L9_2 = L7_2.permit_number
    L8_2 = L8_2 .. L9_2
    L9_2 = "Type: "
    L10_2 = L7_2.permit_type
    L11_2 = " | Holder: "
    L12_2 = L7_2.holder_name
    L9_2 = L9_2 .. L10_2 .. L11_2 .. L12_2
    L10_2 = table
    L10_2 = L10_2.insert
    L11_2 = L1_2
    L12_2 = {}
    L12_2.title = L8_2
    L12_2.description = L9_2
    L13_2 = {}
    L14_2 = {}
    L14_2.label = "Expires"
    L15_2 = L7_2.expiry_date
    L14_2.value = L15_2
    L15_2 = {}
    L15_2.label = "Status"
    L16_2 = FormatStatusText
    L17_2 = L7_2.status
    L16_2 = L16_2(L17_2)
    L15_2.value = L16_2
    L13_2[1] = L14_2
    L13_2[2] = L15_2
    L12_2.metadata = L13_2
    function L13_2()
      local L0_3, L1_3
      L0_3 = ShowPermitDetails
      L1_3 = L7_2
      L0_3(L1_3)
    end
    L12_2.onSelect = L13_2
    L10_2(L11_2, L12_2)
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "active_permits"
  L3_2.title = "\240\159\147\139 Active Permits"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "active_permits"
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showAllPermits"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  if A0_2 then
    L1_2 = #A0_2
    if 0 ~= L1_2 then
      goto lbl_12
    end
  end
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "No permits found"
  L3_2 = "primary"
  L1_2(L2_2, L3_2)
  do return end
  ::lbl_12::
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = "\240\159\159\162"
    L9_2 = L7_2.status
    if "expired" == L9_2 then
      L8_2 = "\240\159\159\161"
    else
      L9_2 = L7_2.status
      if "revoked" == L9_2 then
        L8_2 = "\240\159\148\180"
      else
        L9_2 = L7_2.status
        if "suspended" == L9_2 then
          L8_2 = "\240\159\159\160"
        end
      end
    end
    L9_2 = L8_2
    L10_2 = " "
    L11_2 = L7_2.permit_number
    L9_2 = L9_2 .. L10_2 .. L11_2
    L10_2 = "Type: "
    L11_2 = L7_2.permit_type
    L12_2 = " | Holder: "
    L13_2 = L7_2.holder_name
    L10_2 = L10_2 .. L11_2 .. L12_2 .. L13_2
    L11_2 = table
    L11_2 = L11_2.insert
    L12_2 = L1_2
    L13_2 = {}
    L13_2.title = L9_2
    L13_2.description = L10_2
    L14_2 = {}
    L15_2 = {}
    L15_2.label = "Status"
    L16_2 = FormatStatusText
    L17_2 = L7_2.status
    L16_2 = L16_2(L17_2)
    L15_2.value = L16_2
    L16_2 = {}
    L16_2.label = "Issued"
    L17_2 = L7_2.issued_at
    L16_2.value = L17_2
    L14_2[1] = L15_2
    L14_2[2] = L16_2
    L13_2.metadata = L14_2
    function L14_2()
      local L0_3, L1_3
      L0_3 = ShowPermitDetails
      L1_3 = L7_2
      L0_3(L1_3)
    end
    L13_2.onSelect = L14_2
    L11_2(L12_2, L13_2)
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "all_permits"
  L3_2.title = "\240\159\147\139 All Permits"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "all_permits"
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showExpiredPermits"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  if A0_2 then
    L1_2 = #A0_2
    if 0 ~= L1_2 then
      goto lbl_12
    end
  end
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "No expired permits found"
  L3_2 = "primary"
  L1_2(L2_2, L3_2)
  do return end
  ::lbl_12::
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = "\240\159\159\161 "
    L9_2 = L7_2.permit_number
    L8_2 = L8_2 .. L9_2
    L9_2 = "Type: "
    L10_2 = L7_2.permit_type
    L11_2 = " | Holder: "
    L12_2 = L7_2.holder_name
    L9_2 = L9_2 .. L10_2 .. L11_2 .. L12_2
    L10_2 = table
    L10_2 = L10_2.insert
    L11_2 = L1_2
    L12_2 = {}
    L12_2.title = L8_2
    L12_2.description = L9_2
    L13_2 = {}
    L14_2 = {}
    L14_2.label = "Expired"
    L15_2 = L7_2.expiry_date
    L14_2.value = L15_2
    L15_2 = {}
    L15_2.label = "Type"
    L16_2 = L7_2.permit_type
    L15_2.value = L16_2
    L13_2[1] = L14_2
    L13_2[2] = L15_2
    L12_2.metadata = L13_2
    function L13_2()
      local L0_3, L1_3
      L0_3 = ShowPermitDetails
      L1_3 = L7_2
      L0_3(L1_3)
    end
    L12_2.onSelect = L13_2
    L10_2(L11_2, L12_2)
  end
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "expired_permits"
  L3_2.title = "\226\143\176 Expired Permits"
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "expired_permits"
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showExpiringPermits"
function L8_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2
  if A0_2 then
    L2_2 = #A0_2
    if 0 ~= L2_2 then
      goto lbl_17
    end
  end
  L2_2 = Framework
  L2_2 = L2_2.ShowNotification
  L3_2 = "No permits expiring in the next "
  L4_2 = A1_2 or L4_2
  if not A1_2 then
    L4_2 = 30
  end
  L5_2 = " days"
  L3_2 = L3_2 .. L4_2 .. L5_2
  L4_2 = "primary"
  L2_2(L3_2, L4_2)
  do return end
  ::lbl_17::
  L2_2 = {}
  L3_2 = ipairs
  L4_2 = A0_2
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
    L9_2 = "\226\154\160\239\184\143 "
    L10_2 = L8_2.permit_number
    L9_2 = L9_2 .. L10_2
    L10_2 = "Type: "
    L11_2 = L8_2.permit_type
    L12_2 = " | Holder: "
    L13_2 = L8_2.holder_name
    L10_2 = L10_2 .. L11_2 .. L12_2 .. L13_2
    L11_2 = table
    L11_2 = L11_2.insert
    L12_2 = L2_2
    L13_2 = {}
    L13_2.title = L9_2
    L13_2.description = L10_2
    L14_2 = {}
    L15_2 = {}
    L15_2.label = "Expires"
    L16_2 = L8_2.expiry_date
    L15_2.value = L16_2
    L16_2 = {}
    L16_2.label = "Days Left"
    L17_2 = math
    L17_2 = L17_2.ceil
    L18_2 = os
    L18_2 = L18_2.time
    L19_2 = {}
    L19_2.year = 2000
    L19_2.month = 1
    L19_2.day = 1
    L19_2.hour = 0
    L19_2.min = 0
    L19_2.sec = 0
    L18_2 = L18_2(L19_2)
    L19_2 = os
    L19_2 = L19_2.time
    L19_2 = L19_2()
    L18_2 = L18_2 - L19_2
    L18_2 = L18_2 / 86400
    L17_2 = L17_2(L18_2)
    L16_2.value = L17_2
    L14_2[1] = L15_2
    L14_2[2] = L16_2
    L13_2.metadata = L14_2
    function L14_2()
      local L0_3, L1_3
      L0_3 = ShowPermitDetails
      L1_3 = L8_2
      L0_3(L1_3)
    end
    L13_2.onSelect = L14_2
    L11_2(L12_2, L13_2)
  end
  L3_2 = lib
  L3_2 = L3_2.registerContext
  L4_2 = {}
  L4_2.id = "expiring_permits"
  L5_2 = "\226\154\160\239\184\143 Expiring Permits ("
  L6_2 = A1_2 or L6_2
  if not A1_2 then
    L6_2 = 30
  end
  L7_2 = " days)"
  L5_2 = L5_2 .. L6_2 .. L7_2
  L4_2.title = L5_2
  L4_2.options = L2_2
  L3_2(L4_2)
  L3_2 = lib
  L3_2 = L3_2.showContext
  L4_2 = "expiring_permits"
  L3_2(L4_2)
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showPermitDetails"
function L8_1(A0_2)
  local L1_2, L2_2
  L1_2 = ShowPermitDetails
  L2_2 = A0_2
  L1_2(L2_2)
end
L6_1(L7_1, L8_1)
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = GetCurrentPlayerJobData
  L1_2, L2_2 = L1_2()
  if not L1_2 then
    return
  end
  L3_2 = {}
  L4_2 = table
  L4_2 = L4_2.insert
  L5_2 = L3_2
  L6_2 = {}
  L6_2.title = "View Details"
  L6_2.description = "Show complete permit information"
  L6_2.icon = "fas fa-info-circle"
  function L7_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L0_3 = {}
    L1_3 = {}
    L1_3.label = "Permit Number"
    L2_3 = A0_2.permit_number
    L1_3.value = L2_3
    L2_3 = {}
    L2_3.label = "Type"
    L3_3 = A0_2.permit_type
    L2_3.value = L3_3
    L3_3 = {}
    L3_3.label = "Holder"
    L4_3 = A0_2.holder_name
    L3_3.value = L4_3
    L4_3 = {}
    L4_3.label = "Description"
    L5_3 = A0_2.description
    if not L5_3 then
      L5_3 = "No description"
    end
    L4_3.value = L5_3
    L5_3 = {}
    L5_3.label = "Status"
    L6_3 = FormatStatusText
    L7_3 = A0_2.status
    L6_3 = L6_3(L7_3)
    L5_3.value = L6_3
    L6_3 = {}
    L6_3.label = "Issued By"
    L7_3 = A0_2.issued_by
    L6_3.value = L7_3
    L7_3 = {}
    L7_3.label = "Issue Date"
    L8_3 = A0_2.issued_at
    L7_3.value = L8_3
    L8_3 = {}
    L8_3.label = "Expiry Date"
    L9_3 = A0_2.expiry_date
    L8_3.value = L9_3
    L9_3 = {}
    L9_3.label = "Fee Paid"
    L10_3 = A0_2.fee
    if L10_3 then
      L10_3 = "$"
      L11_3 = A0_2.fee
      L10_3 = L10_3 .. L11_3
      if L10_3 then
        goto lbl_60
      end
    end
    L10_3 = "No fee"
    ::lbl_60::
    L9_3.value = L10_3
    L0_3[1] = L1_3
    L0_3[2] = L2_3
    L0_3[3] = L3_3
    L0_3[4] = L4_3
    L0_3[5] = L5_3
    L0_3[6] = L6_3
    L0_3[7] = L7_3
    L0_3[8] = L8_3
    L0_3[9] = L9_3
    L1_3 = A0_2.renewed_by
    if L1_3 then
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Last Renewed By"
      L4_3 = A0_2.renewed_by
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Renewal Date"
      L4_3 = A0_2.renewed_at
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
    end
    L1_3 = A0_2.suspended_by
    if L1_3 then
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Suspended By"
      L4_3 = A0_2.suspended_by
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Suspension Reason"
      L4_3 = A0_2.suspension_reason
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = L0_3
      L3_3 = {}
      L3_3.label = "Suspended Date"
      L4_3 = A0_2.suspended_at
      L3_3.value = L4_3
      L1_3(L2_3, L3_3)
      L1_3 = A0_2.unsuspend_date
      if L1_3 then
        L1_3 = table
        L1_3 = L1_3.insert
        L2_3 = L0_3
        L3_3 = {}
        L3_3.label = "Unsuspend Date"
        L4_3 = A0_2.unsuspend_date
        L3_3.value = L4_3
        L1_3(L2_3, L3_3)
      end
    end
    L1_3 = lib
    L1_3 = L1_3.alertDialog
    L2_3 = {}
    L2_3.header = "Permit Details"
    L2_3.content = "Complete information about this permit:"
    L2_3.metadata = L0_3
    L2_3.centered = true
    L2_3.cancel = true
    L1_3(L2_3)
  end
  L6_2.onSelect = L7_2
  L4_2(L5_2, L6_2)
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L1_2
  L6_2 = L2_2
  L7_2 = "license_management"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if L4_2 then
    L4_2 = A0_2.status
    if "active" ~= L4_2 then
      L4_2 = A0_2.status
      if "expired" ~= L4_2 then
        goto lbl_44
      end
    end
    L4_2 = table
    L4_2 = L4_2.insert
    L5_2 = L3_2
    L6_2 = {}
    L6_2.title = "Renew Permit"
    L6_2.description = "Extend the expiry date of this permit"
    L6_2.icon = "fas fa-calendar-plus"
    function L7_2()
      local L0_3, L1_3, L2_3, L3_3, L4_3
      L0_3 = lib
      L0_3 = L0_3.inputDialog
      L1_3 = "Renew Permit"
      L2_3 = {}
      L3_3 = {}
      L3_3.type = "number"
      L3_3.label = "Extension Days"
      L3_3.required = true
      L3_3.min = 1
      L3_3.max = 365
      L2_3[1] = L3_3
      L0_3 = L0_3(L1_3, L2_3)
      if L0_3 then
        L1_3 = L0_3[1]
        if L1_3 then
          L1_3 = TriggerServerEvent
          L2_3 = "fs-government:server:renewPermit"
          L3_3 = A0_2.id
          L4_3 = L0_3[1]
          L1_3(L2_3, L3_3, L4_3)
        end
      end
    end
    L6_2.onSelect = L7_2
    L4_2(L5_2, L6_2)
    ::lbl_44::
    L4_2 = A0_2.status
    if "active" == L4_2 then
      L4_2 = table
      L4_2 = L4_2.insert
      L5_2 = L3_2
      L6_2 = {}
      L6_2.title = "Suspend Permit"
      L6_2.description = "Temporarily suspend this permit"
      L6_2.icon = "fas fa-pause"
      function L7_2()
        local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
        L0_3 = lib
        L0_3 = L0_3.inputDialog
        L1_3 = "Suspend Permit"
        L2_3 = {}
        L3_3 = {}
        L3_3.type = "input"
        L3_3.label = "Suspension Reason"
        L3_3.required = true
        L3_3.min = 5
        L4_3 = {}
        L4_3.type = "number"
        L4_3.label = "Suspension Days (0 = indefinite)"
        L4_3.min = 0
        L4_3.max = 365
        L2_3[1] = L3_3
        L2_3[2] = L4_3
        L0_3 = L0_3(L1_3, L2_3)
        if L0_3 then
          L1_3 = L0_3[1]
          if L1_3 then
            L1_3 = L0_3[2]
            if L1_3 then
              L1_3 = L0_3[2]
              if L1_3 > 0 then
                L1_3 = L0_3[2]
                if L1_3 then
                  goto lbl_35
                end
              end
            end
            L1_3 = nil
            ::lbl_35::
            L2_3 = TriggerServerEvent
            L3_3 = "fs-government:server:suspendPermit"
            L4_3 = A0_2.id
            L5_3 = L0_3[1]
            L6_3 = L1_3
            L2_3(L3_3, L4_3, L5_3, L6_3)
          end
        end
      end
      L6_2.onSelect = L7_2
      L4_2(L5_2, L6_2)
    end
  end
  L4_2 = lib
  L4_2 = L4_2.registerContext
  L5_2 = {}
  L5_2.id = "permit_details"
  L6_2 = "\240\159\147\132 Permit: "
  L7_2 = A0_2.permit_number
  L6_2 = L6_2 .. L7_2
  L5_2.title = L6_2
  L5_2.menu = "all_permits"
  L5_2.options = L3_2
  L4_2(L5_2)
  L4_2 = lib
  L4_2 = L4_2.showContext
  L5_2 = "permit_details"
  L4_2(L5_2)
end
ShowPermitDetails = L6_1
function L6_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = Framework
  L0_2 = L0_2.GetPlayerData
  L0_2 = L0_2()
  if L0_2 then
    L1_2 = L0_2.job
    if L1_2 then
      goto lbl_11
    end
  end
  L1_2 = nil
  L2_2 = nil
  do return L1_2, L2_2 end
  ::lbl_11::
  L1_2 = L0_2.job
  L1_2 = L1_2.name
  L2_2 = 0
  L3_2 = L0_2.job
  L3_2 = L3_2.grade
  if L3_2 then
    L3_2 = type
    L4_2 = L0_2.job
    L4_2 = L4_2.grade
    L3_2 = L3_2(L4_2)
    if "table" == L3_2 then
      L3_2 = L0_2.job
      L3_2 = L3_2.grade
      L3_2 = L3_2.level
      L2_2 = L3_2 or L2_2
      if not L3_2 then
        L2_2 = 0
      end
    else
      L3_2 = L0_2.job
      L2_2 = L3_2.grade
    end
  end
  L3_2 = L1_2
  L4_2 = L2_2
  return L3_2, L4_2
end
GetCurrentPlayerJobData = L6_1
L6_1 = RegisterCommand
L7_1 = "mypermits"
function L8_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2
  L3_2 = TriggerServerEvent
  L4_2 = "fs-government:server:getPlayerPermits"
  L3_2(L4_2)
end
L9_1 = false
L6_1(L7_1, L8_1, L9_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showPlayerPermits"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2
  if A0_2 then
    L1_2 = #A0_2
    if 0 ~= L1_2 then
      goto lbl_12
    end
  end
  L1_2 = Framework
  L1_2 = L1_2.ShowNotification
  L2_2 = "You have no permits on record"
  L3_2 = "primary"
  L1_2(L2_2, L3_2)
  do return end
  ::lbl_12::
  L1_2 = {}
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = "\240\159\159\162"
    L9_2 = "#27ae60"
    L10_2 = L7_2.status
    if "expired" == L10_2 then
      L8_2 = "\240\159\148\180"
      L9_2 = "#e74c3c"
    else
      L10_2 = L7_2.status
      if "suspended" == L10_2 then
        L8_2 = "\240\159\159\161"
        L9_2 = "#f39c12"
      else
        L10_2 = L7_2.status
        if "revoked" == L10_2 then
          L8_2 = "\226\157\140"
          L9_2 = "#e74c3c"
        end
      end
    end
    L10_2 = L8_2
    L11_2 = " "
    L12_2 = L7_2.permit_type
    L13_2 = L12_2
    L12_2 = L12_2.gsub
    L14_2 = "_"
    L15_2 = " "
    L12_2 = L12_2(L13_2, L14_2, L15_2)
    L13_2 = L12_2
    L12_2 = L12_2.upper
    L12_2 = L12_2(L13_2)
    L10_2 = L10_2 .. L11_2 .. L12_2
    L11_2 = "Status: "
    L12_2 = FormatStatusText
    L13_2 = L7_2.status
    L12_2 = L12_2(L13_2)
    L13_2 = " | Expires: "
    L14_2 = L7_2.formatted_expiry_date
    if not L14_2 then
      L14_2 = "Never"
    end
    L11_2 = L11_2 .. L12_2 .. L13_2 .. L14_2
    L12_2 = table
    L12_2 = L12_2.insert
    L13_2 = L1_2
    L14_2 = {}
    L14_2.title = L10_2
    L14_2.description = L11_2
    L15_2 = {}
    L16_2 = {}
    L16_2.label = "Permit Number"
    L17_2 = L7_2.permit_number
    L16_2.value = L17_2
    L17_2 = {}
    L17_2.label = "Issued"
    L18_2 = L7_2.formatted_issued_date
    if not L18_2 then
      L18_2 = L7_2.issued_at
    end
    L17_2.value = L18_2
    L18_2 = {}
    L18_2.label = "Status"
    L19_2 = FormatStatusText
    L20_2 = L7_2.status
    L19_2 = L19_2(L20_2)
    L18_2.value = L19_2
    L15_2[1] = L16_2
    L15_2[2] = L17_2
    L15_2[3] = L18_2
    L14_2.metadata = L15_2
    L14_2.iconColor = L9_2
    function L15_2()
      local L0_3, L1_3
      L0_3 = ShowPlayerPermitOptions
      L1_3 = L7_2
      L0_3(L1_3)
    end
    L14_2.onSelect = L15_2
    L12_2(L13_2, L14_2)
  end
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = L1_2
  L4_2 = {}
  L4_2.title = "Close"
  L4_2.description = "Close permit list"
  L4_2.icon = "fas fa-times"
  L4_2.iconColor = "#95a5a6"
  function L5_2()
    local L0_3, L1_3
    L0_3 = lib
    L0_3 = L0_3.hideContext
    L0_3()
  end
  L4_2.onSelect = L5_2
  L2_2(L3_2, L4_2)
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "player_permits_list"
  L4_2 = "\240\159\147\156 My Permits ("
  L5_2 = #A0_2
  L6_2 = ")"
  L4_2 = L4_2 .. L5_2 .. L6_2
  L3_2.title = L4_2
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "player_permits_list"
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = {}
  L2_2 = {}
  L2_2.title = "View Document"
  L2_2.description = "View professional permit document"
  L2_2.icon = "fas fa-file-alt"
  function L3_2()
    local L0_3, L1_3, L2_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getPermitDocument"
    L2_3 = A0_2.id
    L0_3(L1_3, L2_3)
  end
  L2_2.onSelect = L3_2
  L3_2 = {}
  L3_2.title = "Show to Nearby Players"
  L3_2.description = "Display permit to players within 5m"
  L3_2.icon = "fas fa-share"
  function L4_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L0_3 = lib
    L0_3 = L0_3.alertDialog
    L1_3 = {}
    L1_3.header = "Show Permit"
    L2_3 = "Are you sure you want to show your "
    L3_3 = A0_2.permit_type
    L4_3 = L3_3
    L3_3 = L3_3.gsub
    L5_3 = "_"
    L6_3 = " "
    L3_3 = L3_3(L4_3, L5_3, L6_3)
    L4_3 = " permit to nearby players?"
    L2_3 = L2_3 .. L3_3 .. L4_3
    L1_3.content = L2_3
    L1_3.centered = true
    L1_3.cancel = true
    L2_3 = {}
    L2_3.cancel = "Cancel"
    L2_3.confirm = "Show Permit"
    L1_3.labels = L2_3
    L0_3 = L0_3(L1_3)
    if "confirm" == L0_3 then
      L1_3 = TriggerServerEvent
      L2_3 = "fs-government:server:showPermitToNearby"
      L3_3 = A0_2.id
      L1_3(L2_3, L3_3)
    end
  end
  L3_2.onSelect = L4_2
  L4_2 = {}
  L4_2.title = "Back"
  L4_2.description = "Return to permit list"
  L4_2.icon = "fas fa-arrow-left"
  function L5_2()
    local L0_3, L1_3
    L0_3 = TriggerServerEvent
    L1_3 = "fs-government:server:getPlayerPermits"
    L0_3(L1_3)
  end
  L4_2.onSelect = L5_2
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L1_2[3] = L4_2
  L2_2 = lib
  L2_2 = L2_2.registerContext
  L3_2 = {}
  L3_2.id = "player_permit_options"
  L4_2 = "\240\159\147\156 "
  L5_2 = A0_2.permit_type
  L6_2 = L5_2
  L5_2 = L5_2.gsub
  L7_2 = "_"
  L8_2 = " "
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  L6_2 = L5_2
  L5_2 = L5_2.upper
  L5_2 = L5_2(L6_2)
  L4_2 = L4_2 .. L5_2
  L3_2.title = L4_2
  L3_2.options = L1_2
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.showContext
  L3_2 = "player_permit_options"
  L2_2(L3_2)
end
ShowPlayerPermitOptions = L6_1
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:showPermitDocument"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = SetNuiFocus
  L2_2 = false
  L3_2 = false
  L1_2(L2_2, L3_2)
  L1_2 = Citizen
  L1_2 = L1_2.Wait
  L2_2 = 50
  L1_2(L2_2)
  L1_2 = SetNuiFocus
  L2_2 = true
  L3_2 = true
  L1_2(L2_2, L3_2)
  L1_2 = SendNUIMessage
  L2_2 = {}
  L2_2.action = "showPermitDocument"
  L2_2.permit = A0_2
  L2_2.isOwner = true
  L1_2(L2_2)
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "fs-government:client:viewNearbyPermit"
function L8_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = SetNuiFocus
  L3_2 = false
  L4_2 = false
  L2_2(L3_2, L4_2)
  L2_2 = Citizen
  L2_2 = L2_2.Wait
  L3_2 = 50
  L2_2(L3_2)
  L2_2 = SetNuiFocus
  L3_2 = true
  L4_2 = true
  L2_2(L3_2, L4_2)
  L2_2 = SendNUIMessage
  L3_2 = {}
  L3_2.action = "showPermitDocument"
  L3_2.permit = A0_2
  L3_2.isOwner = false
  L3_2.shownBy = A1_2
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNUICallback
L7_1 = "closePermitDocument"
function L8_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
  L2_2 = SetNuiFocus
  L3_2 = false
  L4_2 = false
  L2_2(L3_2, L4_2)
  L2_2 = SetNuiFocusKeepInput
  L3_2 = false
  L2_2(L3_2)
  L2_2 = Citizen
  L2_2 = L2_2.CreateThread
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L0_3 = 1
    L1_3 = 5
    L2_3 = 1
    for L3_3 = L0_3, L1_3, L2_3 do
      L4_3 = Citizen
      L4_3 = L4_3.Wait
      L5_3 = 50
      L4_3(L5_3)
      L4_3 = SetNuiFocus
      L5_3 = false
      L6_3 = false
      L4_3(L5_3, L6_3)
      L4_3 = SetNuiFocusKeepInput
      L5_3 = false
      L4_3(L5_3)
      if 5 == L3_3 then
        L4_3 = DisplayHud
        L5_3 = true
        L4_3(L5_3)
        L4_3 = DisplayRadar
        L5_3 = true
        L4_3(L5_3)
      end
    end
  end
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)
