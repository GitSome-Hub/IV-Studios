local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
L0_1 = 5
L1_1 = nil
L2_1 = nil
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:setDefconLevel"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L2_2.job
  L4_2 = L4_2.name
  L5_2 = L2_2.job
  L5_2 = L5_2.grade
  L6_2 = "defcon"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if not L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = L1_2
    L5_2 = "You do not have permission to change DEFCON level"
    L6_2 = "error"
    L3_2(L4_2, L5_2, L6_2)
    return
  end
  L0_1 = A0_2
  L3_2 = Config
  L3_2 = L3_2.DEFCON
  L3_2.current_level = A0_2
  L3_2 = MySQL
  L3_2 = L3_2.execute
  L4_2 = "UPDATE government_settings SET setting_value = ?, updated_by = ? WHERE setting_key = ?"
  L5_2 = {}
  L6_2 = tostring
  L7_2 = A0_2
  L6_2 = L6_2(L7_2)
  L7_2 = L2_2.identifier
  L8_2 = "defcon_level"
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  L5_2[3] = L8_2
  L3_2(L4_2, L5_2)
  L3_2 = Config
  L3_2 = L3_2.DEFCON
  L3_2 = L3_2.levels
  L3_2 = L3_2[A0_2]
  L4_2 = GetPlayers
  L4_2 = L4_2()
  L5_2 = ipairs
  L6_2 = L4_2
  L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
  for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
    L11_2 = tonumber
    L12_2 = L10_2
    L11_2 = L11_2(L12_2)
    L12_2 = Framework
    L12_2 = L12_2.ShowNotification
    L13_2 = L11_2
    L14_2 = "DEFCON ALERT: "
    L15_2 = L3_2.label
    L16_2 = " has been activated!"
    L14_2 = L14_2 .. L15_2 .. L16_2
    L15_2 = "error"
    L12_2(L13_2, L14_2, L15_2)
    L12_2 = {}
    L12_2[1] = "MAXIMUM READINESS - Exercise of non-nuclear war is imminent or underway. All available resources mobilized."
    L12_2[2] = "FAST PACE - Next step to nuclear war. Armed forces ready to deploy and engage in less than 6 hours."
    L12_2[3] = "ROUND HOUSE - Increase in force readiness. Air Force ready to mobilize in 15 minutes."
    L12_2[4] = "DOUBLE TAKE - Increased intelligence and strengthened security measures."
    L12_2[5] = "FADE OUT - Lowest state of readiness. Normal peacetime conditions."
    L13_2 = TriggerClientEvent
    L14_2 = "fs-government:client:defconAnnouncement"
    L15_2 = L11_2
    L16_2 = {}
    L17_2 = "DEFCON LEVEL "
    L18_2 = A0_2
    L19_2 = " - "
    L20_2 = L12_2[A0_2]
    if not L20_2 then
      L20_2 = "Status changed by government official."
    end
    L17_2 = L17_2 .. L18_2 .. L19_2 .. L20_2
    L16_2.message = L17_2
    L16_2.level = A0_2
    L13_2(L14_2, L15_2, L16_2)
  end
  L5_2 = TriggerEvent
  L6_2 = "fs-government:defconChanged"
  L7_2 = A0_2
  L8_2 = L3_2
  L5_2(L6_2, L7_2, L8_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:getTaxSettings"
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = source
  L1_2 = MySQL
  L1_2 = L1_2.query
  L2_2 = "SELECT setting_value FROM government_settings WHERE setting_key = ?"
  L3_2 = {}
  L4_2 = "tax_rates"
  L3_2[1] = L4_2
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = A0_3[1]
    if L1_3 then
      L1_3 = json
      L1_3 = L1_3.decode
      L2_3 = A0_3[1]
      L2_3 = L2_3.setting_value
      L1_3 = L1_3(L2_3)
      L2_3 = string
      L2_3 = L2_3.format
      L3_3 = "Tax Rates - Salary: %.1f%% | Business: %.1f%% | Vehicle: %.1f%% | Property: %.1f%%"
      L4_3 = L1_3.salary
      L4_3 = L4_3 * 100
      L5_3 = L1_3.business
      L5_3 = L5_3 * 100
      L6_3 = L1_3.vehicle
      L6_3 = L6_3 * 100
      L7_3 = L1_3.property
      L7_3 = L7_3 * 100
      L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3)
      L3_3 = Framework
      L3_3 = L3_3.ShowNotification
      L4_3 = L0_2
      L5_3 = L2_3
      L6_3 = "success"
      L3_3(L4_3, L5_3, L6_3)
    end
  end
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:updateTaxRates"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L2_2.job
  L4_2 = L4_2.name
  L5_2 = L2_2.job
  L5_2 = L5_2.grade
  L6_2 = "taxation"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if not L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = L1_2
    L5_2 = "You do not have permission to update tax rates"
    L6_2 = "error"
    L3_2(L4_2, L5_2, L6_2)
    return
  end
  L3_2 = Config
  L3_2 = L3_2.Taxation
  L3_2.rates = A0_2
  L3_2 = MySQL
  L3_2 = L3_2.execute
  L4_2 = "UPDATE government_settings SET setting_value = ?, updated_by = ? WHERE setting_key = ?"
  L5_2 = {}
  L6_2 = json
  L6_2 = L6_2.encode
  L7_2 = A0_2
  L6_2 = L6_2(L7_2)
  L7_2 = L2_2.identifier
  L8_2 = "tax_rates"
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  L5_2[3] = L8_2
  L3_2(L4_2, L5_2)
  L3_2 = Framework
  L3_2 = L3_2.ShowNotification
  L4_2 = L1_2
  L5_2 = "Tax rates updated successfully"
  L6_2 = "success"
  L3_2(L4_2, L5_2, L6_2)
  L3_2 = GetPlayers
  L3_2 = L3_2()
  L4_2 = ipairs
  L5_2 = L3_2
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
  for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
    L10_2 = tonumber
    L11_2 = L9_2
    L10_2 = L10_2(L11_2)
    if L10_2 ~= L1_2 then
      L10_2 = Framework
      L10_2 = L10_2.ShowNotification
      L11_2 = tonumber
      L12_2 = L9_2
      L11_2 = L11_2(L12_2)
      L12_2 = "Tax rates have been updated by the government"
      L13_2 = "primary"
      L10_2(L11_2, L12_2, L13_2)
    end
  end
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:getTaxRevenue"
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = source
  L1_2 = MySQL
  L1_2 = L1_2.query
  L2_2 = "SELECT tax_type, SUM(amount) as total FROM government_taxation WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY tax_type"
  L3_2 = {}
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
    L1_3 = 0
    L2_3 = {}
    L3_3 = ipairs
    L4_3 = A0_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = L8_3.total
      L1_3 = L1_3 + L9_3
      L9_3 = L8_3.tax_type
      L10_3 = L8_3.total
      L2_3[L9_3] = L10_3
    end
    L3_3 = "Tax Revenue (Last 30 Days): Total: "
    L4_3 = Utils
    L4_3 = L4_3.FormatMoney
    L5_3 = L1_3
    L4_3 = L4_3(L5_3)
    L3_3 = L3_3 .. L4_3
    L4_3 = pairs
    L5_3 = L2_3
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      L10_3 = L3_3
      L11_3 = " | "
      L12_3 = L8_3
      L13_3 = ": "
      L14_3 = Utils
      L14_3 = L14_3.FormatMoney
      L15_3 = L9_3
      L14_3 = L14_3(L15_3)
      L10_3 = L10_3 .. L11_3 .. L12_3 .. L13_3 .. L14_3
      L3_3 = L10_3
    end
    L4_3 = Framework
    L4_3 = L4_3.ShowNotification
    L5_3 = L0_2
    L6_3 = L3_3
    L7_3 = "success"
    L4_3(L5_3, L6_3, L7_3)
  end
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:startElection"
function L5_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2)
  local L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2
  L7_2 = source
  L8_2 = Framework
  L8_2 = L8_2.GetPlayerData
  L9_2 = L7_2
  L8_2 = L8_2(L9_2)
  if not L8_2 then
    return
  end
  L9_2 = Utils
  L9_2 = L9_2.HasPermission
  L10_2 = L8_2.job
  L10_2 = L10_2.name
  L11_2 = L8_2.job
  L11_2 = L11_2.grade
  L12_2 = "elections"
  L9_2 = L9_2(L10_2, L11_2, L12_2)
  if not L9_2 then
    L9_2 = Framework
    L9_2 = L9_2.ShowNotification
    L10_2 = L7_2
    L11_2 = "You do not have permission to start elections"
    L12_2 = "error"
    L9_2(L10_2, L11_2, L12_2)
    return
  end
  L9_2 = L1_1
  if L9_2 then
    L9_2 = Framework
    L9_2 = L9_2.ShowNotification
    L10_2 = L7_2
    L11_2 = "An election is already in progress"
    L12_2 = "error"
    L9_2(L10_2, L11_2, L12_2)
    return
  end
  L9_2 = A2_2
  if "minutes" == A3_2 then
    L9_2 = A2_2 * 60
  elseif "hours" == A3_2 then
    L9_2 = A2_2 * 3600
  elseif "days" == A3_2 then
    L10_2 = A2_2 * 24
    L9_2 = L10_2 * 3600
  end
  L10_2 = Config
  L10_2 = L10_2.Elections
  L10_2 = L10_2.candidate_requirements
  L11_2 = A4_2 or L11_2
  if not A4_2 then
    L11_2 = 10000
  end
  L10_2.registration_fee = L11_2
  L10_2 = Config
  L10_2 = L10_2.Elections
  L10_2 = L10_2.candidate_requirements
  L11_2 = A5_2 or L11_2
  if not A5_2 then
    L11_2 = 5
  end
  L10_2.min_level = L11_2
  L10_2 = Config
  L10_2 = L10_2.Elections
  L10_2 = L10_2.candidate_requirements
  L11_2 = A6_2 or L11_2
  if not A6_2 then
    L11_2 = 168
  end
  L10_2.min_playtime = L11_2
  L10_2 = os
  L10_2 = L10_2.date
  L11_2 = "%Y-%m-%d %H:%M:%S"
  L10_2 = L10_2(L11_2)
  L11_2 = os
  L11_2 = L11_2.date
  L12_2 = "%Y-%m-%d %H:%M:%S"
  L13_2 = os
  L13_2 = L13_2.time
  L13_2 = L13_2()
  L13_2 = L13_2 + L9_2
  L11_2 = L11_2(L12_2, L13_2)
  L12_2 = MySQL
  L12_2 = L12_2.insert
  L13_2 = "INSERT INTO government_elections (title, description, start_date, end_date, status, created_by) VALUES (?, ?, ?, ?, ?, ?)"
  L14_2 = {}
  L15_2 = A0_2
  L16_2 = " - "
  L17_2 = A1_2
  L15_2 = L15_2 .. L16_2 .. L17_2
  L16_2 = "Election for "
  L17_2 = A1_2
  L18_2 = " | Registration Fee: $"
  L19_2 = A4_2
  L20_2 = " | Min Level: "
  L21_2 = A5_2
  L22_2 = " | Min Playtime: "
  L23_2 = A6_2
  L24_2 = "h"
  L16_2 = L16_2 .. L17_2 .. L18_2 .. L19_2 .. L20_2 .. L21_2 .. L22_2 .. L23_2 .. L24_2
  L17_2 = L10_2
  L18_2 = L11_2
  L19_2 = "active"
  L20_2 = L8_2.identifier
  L14_2[1] = L15_2
  L14_2[2] = L16_2
  L14_2[3] = L17_2
  L14_2[4] = L18_2
  L14_2[5] = L19_2
  L14_2[6] = L20_2
  function L15_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3
    L1_3 = {}
    L1_3.id = A0_3
    L2_3 = A0_2
    L1_3.title = L2_3
    L2_3 = "Election for "
    L3_3 = A1_2
    L2_3 = L2_3 .. L3_3
    L1_3.description = L2_3
    L2_3 = L10_2
    L1_3.start_date = L2_3
    L2_3 = L11_2
    L1_3.end_date = L2_3
    L1_3.status = "active"
    L2_3 = A1_2
    L1_3.position = L2_3
    L1_1 = L1_3
    L1_3 = GetPlayers
    L1_3 = L1_3()
    L2_3 = ipairs
    L3_3 = L1_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = tonumber
      L9_3 = L7_3
      L8_3 = L8_3(L9_3)
      L9_3 = Framework
      L9_3 = L9_3.ShowNotification
      L10_3 = L8_3
      L11_3 = "New election started: "
      L12_3 = A0_2
      L13_3 = " | Duration: "
      L14_3 = A2_2
      L15_3 = " "
      L16_3 = A3_2
      L11_3 = L11_3 .. L12_3 .. L13_3 .. L14_3 .. L15_3 .. L16_3
      L12_3 = "success"
      L9_3(L10_3, L11_3, L12_3)
      L9_3 = TriggerClientEvent
      L10_3 = "fs-government:client:electionStarted"
      L11_3 = L8_3
      L12_3 = L1_1
      L9_3(L10_3, L11_3, L12_3)
      L9_3 = TriggerClientEvent
      L10_3 = "fs-government:client:electionAnnouncement"
      L11_3 = L8_3
      L12_3 = {}
      L13_3 = "New election has started: "
      L14_3 = A0_2
      L15_3 = " for "
      L16_3 = A1_2
      L17_3 = ". Registration is open for "
      L18_3 = A2_2
      L19_3 = " "
      L20_3 = A3_2
      L21_3 = " at designated locations. Registration fee: $"
      L22_3 = A4_2
      L13_3 = L13_3 .. L14_3 .. L15_3 .. L16_3 .. L17_3 .. L18_3 .. L19_3 .. L20_3 .. L21_3 .. L22_3
      L12_3.message = L13_3
      L9_3(L10_3, L11_3, L12_3)
    end
    L2_3 = Framework
    L2_3 = L2_3.ShowNotification
    L3_3 = L7_2
    L4_3 = "Election created successfully! Registration fee: $"
    L5_3 = A4_2
    L4_3 = L4_3 .. L5_3
    L5_3 = "success"
    L2_3(L3_3, L4_3, L5_3)
    L2_3 = CreateThread
    function L3_3()
      local L0_4, L1_4
      L0_4 = Wait
      L1_4 = L9_2
      L1_4 = L1_4 * 1000
      L0_4(L1_4)
      L0_4 = EndElection
      L1_4 = A0_3
      L0_4(L1_4)
    end
    L2_3(L3_3)
  end
  L12_2(L13_2, L14_2, L15_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:getCurrentElection"
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = source
  L1_2 = L1_1
  if not L1_2 then
    L1_2 = Framework
    L1_2 = L1_2.ShowNotification
    L2_2 = L0_2
    L3_2 = "No active election"
    L4_2 = "error"
    L1_2(L2_2, L3_2, L4_2)
    return
  end
  L1_2 = MySQL
  L1_2 = L1_2.query
  L2_2 = "SELECT c.*, COUNT(v.id) as votes FROM government_candidates c LEFT JOIN government_votes v ON c.id = v.candidate_id WHERE c.election_id = ? GROUP BY c.id ORDER BY votes DESC"
  L3_2 = {}
  L4_2 = L1_1.id
  L3_2[1] = L4_2
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    L1_3 = "Current Election: "
    L2_3 = L1_1.title
    L3_3 = " - Candidates: "
    L1_3 = L1_3 .. L2_3 .. L3_3
    L2_3 = ipairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = L1_3
      L9_3 = L7_3.name
      L10_3 = " ("
      L11_3 = L7_3.votes
      L12_3 = " votes) "
      L8_3 = L8_3 .. L9_3 .. L10_3 .. L11_3 .. L12_3
      L1_3 = L8_3
    end
    L2_3 = Framework
    L2_3 = L2_3.ShowNotification
    L3_3 = L0_2
    L4_3 = L1_3
    L5_3 = "success"
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:getCandidates"
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = source
  L1_2 = L1_1
  if not L1_2 then
    L1_2 = Framework
    L1_2 = L1_2.ShowNotification
    L2_2 = L0_2
    L3_2 = "No active election"
    L4_2 = "error"
    L1_2(L2_2, L3_2, L4_2)
    return
  end
  L1_2 = MySQL
  L1_2 = L1_2.query
  L2_2 = "SELECT c.*, COUNT(v.id) as vote_count FROM government_candidates c LEFT JOIN government_votes v ON c.id = v.candidate_id WHERE c.election_id = ? GROUP BY c.id ORDER BY vote_count DESC"
  L3_2 = {}
  L4_2 = L1_1.id
  L3_2[1] = L4_2
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L0_2
      L3_3 = "No candidates registered yet"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = "Registered Candidates for "
    L2_3 = L1_1.title
    L3_3 = ":\n"
    L1_3 = L1_3 .. L2_3 .. L3_3
    L2_3 = ipairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = L1_3
      L9_3 = L6_3
      L10_3 = ". "
      L11_3 = L7_3.name
      L12_3 = " - "
      L13_3 = L7_3.vote_count
      L14_3 = " votes\n"
      L8_3 = L8_3 .. L9_3 .. L10_3 .. L11_3 .. L12_3 .. L13_3 .. L14_3
      L1_3 = L8_3
      L8_3 = L7_3.campaign_message
      if L8_3 then
        L8_3 = L7_3.campaign_message
        if "" ~= L8_3 then
          L8_3 = L1_3
          L9_3 = "   Details: "
          L10_3 = L7_3.campaign_message
          L11_3 = "\n"
          L8_3 = L8_3 .. L9_3 .. L10_3 .. L11_3
          L1_3 = L8_3
        end
      end
    end
    L2_3 = Framework
    L2_3 = L2_3.ShowNotification
    L3_3 = L0_2
    L4_3 = L1_3
    L5_3 = "success"
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:getElectionStatus"
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L0_2 = source
  L1_2 = L1_1
  if not L1_2 then
    L1_2 = Framework
    L1_2 = L1_2.ShowNotification
    L2_2 = L0_2
    L3_2 = "No active election"
    L4_2 = "error"
    L1_2(L2_2, L3_2, L4_2)
    return
  end
  L1_2 = os
  L1_2 = L1_2.time
  L2_2 = {}
  L3_2 = tonumber
  L4_2 = string
  L4_2 = L4_2.sub
  L5_2 = L1_1.end_date
  L6_2 = 1
  L7_2 = 4
  L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L4_2(L5_2, L6_2, L7_2)
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L2_2.year = L3_2
  L3_2 = tonumber
  L4_2 = string
  L4_2 = L4_2.sub
  L5_2 = L1_1.end_date
  L6_2 = 6
  L7_2 = 7
  L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L4_2(L5_2, L6_2, L7_2)
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L2_2.month = L3_2
  L3_2 = tonumber
  L4_2 = string
  L4_2 = L4_2.sub
  L5_2 = L1_1.end_date
  L6_2 = 9
  L7_2 = 10
  L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L4_2(L5_2, L6_2, L7_2)
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L2_2.day = L3_2
  L3_2 = tonumber
  L4_2 = string
  L4_2 = L4_2.sub
  L5_2 = L1_1.end_date
  L6_2 = 12
  L7_2 = 13
  L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L4_2(L5_2, L6_2, L7_2)
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L2_2.hour = L3_2
  L3_2 = tonumber
  L4_2 = string
  L4_2 = L4_2.sub
  L5_2 = L1_1.end_date
  L6_2 = 15
  L7_2 = 16
  L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L4_2(L5_2, L6_2, L7_2)
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L2_2.min = L3_2
  L3_2 = tonumber
  L4_2 = string
  L4_2 = L4_2.sub
  L5_2 = L1_1.end_date
  L6_2 = 18
  L7_2 = 19
  L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L4_2(L5_2, L6_2, L7_2)
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L2_2.sec = L3_2
  L1_2 = L1_2(L2_2)
  L2_2 = os
  L2_2 = L2_2.time
  L2_2 = L2_2()
  L2_2 = L1_2 - L2_2
  L3_2 = ""
  if L2_2 > 0 then
    L4_2 = math
    L4_2 = L4_2.floor
    L5_2 = L2_2 / 86400
    L4_2 = L4_2(L5_2)
    L5_2 = math
    L5_2 = L5_2.floor
    L6_2 = L2_2 % 86400
    L6_2 = L6_2 / 3600
    L5_2 = L5_2(L6_2)
    L6_2 = math
    L6_2 = L6_2.floor
    L7_2 = L2_2 % 3600
    L7_2 = L7_2 / 60
    L6_2 = L6_2(L7_2)
    if L4_2 > 0 then
      L7_2 = L4_2
      L8_2 = " days, "
      L9_2 = L5_2
      L10_2 = " hours, "
      L11_2 = L6_2
      L12_2 = " minutes"
      L7_2 = L7_2 .. L8_2 .. L9_2 .. L10_2 .. L11_2 .. L12_2
      L3_2 = L7_2
    elseif L5_2 > 0 then
      L7_2 = L5_2
      L8_2 = " hours, "
      L9_2 = L6_2
      L10_2 = " minutes"
      L7_2 = L7_2 .. L8_2 .. L9_2 .. L10_2
      L3_2 = L7_2
    else
      L7_2 = L6_2
      L8_2 = " minutes"
      L7_2 = L7_2 .. L8_2
      L3_2 = L7_2
    end
  else
    L3_2 = "Election ended"
  end
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT COUNT(*) as candidate_count FROM government_candidates WHERE election_id = ?"
  L6_2 = {}
  L7_2 = L1_1.id
  L6_2[1] = L7_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = MySQL
    L1_3 = L1_3.query
    L2_3 = "SELECT COUNT(*) as vote_count FROM government_votes WHERE election_id = ?"
    L3_3 = {}
    L4_3 = L1_1.id
    L3_3[1] = L4_3
    function L4_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4
      L1_4 = "Election Status:\n"
      L2_4 = "Title: "
      L3_4 = L1_1.title
      L4_4 = "\n"
      L5_4 = "Status: "
      L6_4 = L1_1.status
      L7_4 = "\n"
      L8_4 = "Time Left: "
      L9_4 = L3_2
      L10_4 = "\n"
      L11_4 = "Candidates: "
      L12_4 = A0_3
      L12_4 = L12_4[1]
      L12_4 = L12_4.candidate_count
      L13_4 = "\n"
      L14_4 = "Total Votes: "
      L15_4 = A0_4[1]
      L15_4 = L15_4.vote_count
      L1_4 = L1_4 .. L2_4 .. L3_4 .. L4_4 .. L5_4 .. L6_4 .. L7_4 .. L8_4 .. L9_4 .. L10_4 .. L11_4 .. L12_4 .. L13_4 .. L14_4 .. L15_4
      L2_4 = Framework
      L2_4 = L2_4.ShowNotification
      L3_4 = L0_2
      L4_4 = L1_4
      L5_4 = "success"
      L2_4(L3_4, L4_4, L5_4)
    end
    L1_3(L2_3, L3_3, L4_3)
  end
  L4_2(L5_2, L6_2, L7_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:getElectionResults"
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = source
  L1_2 = MySQL
  L1_2 = L1_2.query
  L2_2 = "SELECT * FROM government_elections WHERE status = ? ORDER BY end_date DESC LIMIT 5"
  L3_2 = {}
  L4_2 = "completed"
  L3_2[1] = L4_2
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L0_2
      L3_3 = "No completed elections found"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = "Recent Election Results:\n"
    L2_3 = ipairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = MySQL
      L8_3 = L8_3.query
      L9_3 = "SELECT c.name, c.campaign_message, COUNT(v.id) as vote_count FROM government_candidates c LEFT JOIN government_votes v ON c.id = v.candidate_id WHERE c.election_id = ? GROUP BY c.id ORDER BY vote_count DESC LIMIT 1"
      L10_3 = {}
      L11_3 = L7_3.id
      L10_3[1] = L11_3
      function L11_3(A0_4)
        local L1_4, L2_4, L3_4, L4_4
        L1_4 = MySQL
        L1_4 = L1_4.query
        L2_4 = "SELECT COUNT(*) as total_votes FROM government_votes WHERE election_id = ?"
        L3_4 = {}
        L4_4 = L7_3.id
        L3_4[1] = L4_4
        function L4_4(A0_5)
          local L1_5, L2_5, L3_5, L4_5, L5_5, L6_5, L7_5, L8_5, L9_5, L10_5, L11_5, L12_5
          L1_5 = ""
          L2_5 = A0_4
          L2_5 = L2_5[1]
          if L2_5 then
            L2_5 = "Winner: "
            L3_5 = A0_4
            L3_5 = L3_5[1]
            L3_5 = L3_5.name
            L4_5 = " ("
            L5_5 = A0_4
            L5_5 = L5_5[1]
            L5_5 = L5_5.vote_count
            L6_5 = " votes)"
            L2_5 = L2_5 .. L3_5 .. L4_5 .. L5_5 .. L6_5
            L1_5 = L2_5
          else
            L1_5 = "No votes cast"
          end
          L2_5 = L6_3
          L3_5 = ". "
          L4_5 = L7_3.title
          L5_5 = " (Ended: "
          L6_5 = L7_3.end_date
          L7_5 = ")\n"
          L8_5 = "   "
          L9_5 = L1_5
          L10_5 = " | Total Votes: "
          L11_5 = A0_5[1]
          L11_5 = L11_5.total_votes
          L12_5 = "\n"
          L2_5 = L2_5 .. L3_5 .. L4_5 .. L5_5 .. L6_5 .. L7_5 .. L8_5 .. L9_5 .. L10_5 .. L11_5 .. L12_5
          L3_5 = L6_3
          if 1 == L3_5 then
            L3_5 = "Recent Election Results:\n"
            L4_5 = L2_5
            L3_5 = L3_5 .. L4_5
            L1_3 = L3_5
          end
          L3_5 = L6_3
          L4_5 = A0_3
          L4_5 = #L4_5
          if L3_5 == L4_5 then
            L3_5 = Framework
            L3_5 = L3_5.ShowNotification
            L4_5 = L0_2
            L5_5 = L1_3
            L6_5 = "success"
            L3_5(L4_5, L5_5, L6_5)
          end
        end
        L1_4(L2_4, L3_4, L4_4)
      end
      L8_3(L9_3, L10_3, L11_3)
    end
  end
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:registerCandidate"
function L5_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L4_2 = source
  L5_2 = Framework
  L5_2 = L5_2.GetPlayerData
  L6_2 = L4_2
  L5_2 = L5_2(L6_2)
  if not L5_2 then
    return
  end
  L6_2 = L1_1
  if not L6_2 then
    L6_2 = Framework
    L6_2 = L6_2.ShowNotification
    L7_2 = L4_2
    L8_2 = "No active election to register for"
    L9_2 = "error"
    L6_2(L7_2, L8_2, L9_2)
    return
  end
  L6_2 = MySQL
  L6_2 = L6_2.query
  L7_2 = "SELECT COUNT(*) as count FROM government_candidates WHERE election_id = ? AND identifier = ?"
  L8_2 = {}
  L9_2 = L1_1.id
  L10_2 = L5_2.identifier
  L8_2[1] = L9_2
  L8_2[2] = L10_2
  function L9_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
    L1_3 = A0_3[1]
    L1_3 = L1_3.count
    if L1_3 > 0 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L4_2
      L3_3 = "You are already registered as a candidate"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = L5_2.bank
    if not L1_3 then
      L1_3 = 0
    end
    L2_3 = Config
    L2_3 = L2_3.Elections
    L2_3 = L2_3.candidate_requirements
    L2_3 = L2_3.registration_fee
    L3_3 = Config
    L3_3 = L3_3.Debug
    if L3_3 then
      L3_3 = Utils
      L3_3 = L3_3.DebugPrint
      L4_3 = "Registration fee check - Required: $"
      L5_3 = L2_3
      L6_3 = ", Player bank: $"
      L7_3 = L1_3
      L4_3 = L4_3 .. L5_3 .. L6_3 .. L7_3
      L3_3(L4_3)
    end
    if L1_3 < L2_3 then
      L3_3 = Framework
      L3_3 = L3_3.ShowNotification
      L4_3 = L4_2
      L5_3 = "Insufficient bank funds for registration fee. Required: $"
      L6_3 = L2_3
      L7_3 = ", Available: $"
      L8_3 = L1_3
      L5_3 = L5_3 .. L6_3 .. L7_3 .. L8_3
      L6_3 = "error"
      L3_3(L4_3, L5_3, L6_3)
      return
    end
    L3_3 = Framework
    L3_3 = L3_3.RemoveMoney
    L4_3 = L4_2
    L5_3 = L2_3
    L6_3 = "bank"
    L3_3 = L3_3(L4_3, L5_3, L6_3)
    if not L3_3 then
      L3_3 = Framework
      L3_3 = L3_3.ShowNotification
      L4_3 = L4_2
      L5_3 = "Failed to process registration fee payment. Please try again."
      L6_3 = "error"
      L3_3(L4_3, L5_3, L6_3)
      return
    end
    L3_3 = MySQL
    L3_3 = L3_3.insert
    L4_3 = "INSERT INTO government_candidates (election_id, identifier, name, campaign_message) VALUES (?, ?, ?, ?)"
    L5_3 = {}
    L6_3 = L1_1.id
    L7_3 = L5_2.identifier
    L8_3 = L5_2.name
    L9_3 = A0_2
    L10_3 = " | Platform: "
    L11_3 = A1_2
    L12_3 = " | Party: "
    L13_3 = A2_2
    if not L13_3 then
      L13_3 = "Independent"
    end
    L14_3 = A3_2
    if L14_3 then
      L14_3 = A3_2
      if "" ~= L14_3 then
        L14_3 = " | Bio: "
        L15_3 = A3_2
        L14_3 = L14_3 .. L15_3
        if L14_3 then
          goto lbl_88
        end
      end
    end
    L14_3 = ""
    ::lbl_88::
    L9_3 = L9_3 .. L10_3 .. L11_3 .. L12_3 .. L13_3 .. L14_3
    L5_3[1] = L6_3
    L5_3[2] = L7_3
    L5_3[3] = L8_3
    L5_3[4] = L9_3
    function L6_3()
      local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4
      L0_4 = Framework
      L0_4 = L0_4.ShowNotification
      L1_4 = L4_2
      L2_4 = "Successfully registered as candidate! Registration fee: $"
      L3_4 = L2_3
      L2_4 = L2_4 .. L3_4
      L3_4 = "success"
      L0_4(L1_4, L2_4, L3_4)
      L0_4 = GetPlayers
      L0_4 = L0_4()
      L1_4 = ipairs
      L2_4 = L0_4
      L1_4, L2_4, L3_4, L4_4 = L1_4(L2_4)
      for L5_4, L6_4 in L1_4, L2_4, L3_4, L4_4 do
        L7_4 = tonumber
        L8_4 = L6_4
        L7_4 = L7_4(L8_4)
        L8_4 = L4_2
        if L7_4 ~= L8_4 then
          L7_4 = Framework
          L7_4 = L7_4.ShowNotification
          L8_4 = tonumber
          L9_4 = L6_4
          L8_4 = L8_4(L9_4)
          L9_4 = L5_2.name
          L10_4 = " has registered as a candidate for "
          L11_4 = L1_1.title
          L9_4 = L9_4 .. L10_4 .. L11_4
          L10_4 = "primary"
          L7_4(L8_4, L9_4, L10_4)
        end
      end
    end
    L3_3(L4_3, L5_3, L6_3)
  end
  L6_2(L7_2, L8_2, L9_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:getVotingCandidates"
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = source
  L1_2 = L1_1
  if not L1_2 then
    L1_2 = Framework
    L1_2 = L1_2.ShowNotification
    L2_2 = L0_2
    L3_2 = "No active election"
    L4_2 = "error"
    L1_2(L2_2, L3_2, L4_2)
    return
  end
  L1_2 = MySQL
  L1_2 = L1_2.query
  L2_2 = "SELECT * FROM government_candidates WHERE election_id = ? ORDER BY name ASC"
  L3_2 = {}
  L4_2 = L1_1.id
  L3_2[1] = L4_2
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showVotingMenu"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:vote"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = L1_1
  if not L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = L1_2
    L5_2 = "No active election"
    L6_2 = "error"
    L3_2(L4_2, L5_2, L6_2)
    return
  end
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT COUNT(*) as count FROM government_votes WHERE election_id = ? AND voter_identifier = ?"
  L5_2 = {}
  L6_2 = L1_1.id
  L7_2 = L2_2.identifier
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = A0_3[1]
    L1_3 = L1_3.count
    if L1_3 > 0 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L1_2
      L3_3 = "You have already voted in this election"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = MySQL
    L1_3 = L1_3.insert
    L2_3 = "INSERT INTO government_votes (election_id, candidate_id, voter_identifier) VALUES (?, ?, ?)"
    L3_3 = {}
    L4_3 = L1_1.id
    L5_3 = A0_2
    L6_3 = L2_2.identifier
    L3_3[1] = L4_3
    L3_3[2] = L5_3
    L3_3[3] = L6_3
    function L4_3()
      local L0_4, L1_4, L2_4, L3_4
      L0_4 = MySQL
      L0_4 = L0_4.execute
      L1_4 = "UPDATE government_candidates SET votes = votes + 1 WHERE id = ?"
      L2_4 = {}
      L3_4 = A0_2
      L2_4[1] = L3_4
      L0_4(L1_4, L2_4)
      L0_4 = Framework
      L0_4 = L0_4.ShowNotification
      L1_4 = L1_2
      L2_4 = "Vote cast successfully! Thank you for participating."
      L3_4 = "success"
      L0_4(L1_4, L2_4, L3_4)
    end
    L1_3(L2_3, L3_3, L4_3)
  end
  L3_2(L4_2, L5_2, L6_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:sendAnnouncement"
function L5_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  if not L4_2 then
    return
  end
  L5_2 = Utils
  L5_2 = L5_2.HasPermission
  L6_2 = L4_2.job
  L6_2 = L6_2.name
  L7_2 = L4_2.job
  L7_2 = L7_2.grade
  L8_2 = "announcements"
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  if not L5_2 then
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L3_2
    L7_2 = "You do not have permission to send announcements"
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
    return
  end
  L5_2 = MySQL
  L5_2 = L5_2.insert
  L6_2 = "INSERT INTO government_announcements (title, message, sender, priority) VALUES (?, ?, ?, ?)"
  L7_2 = {}
  L8_2 = A0_2
  L9_2 = A1_2
  L10_2 = L4_2.name
  L11_2 = A2_2
  L7_2[1] = L8_2
  L7_2[2] = L9_2
  L7_2[3] = L10_2
  L7_2[4] = L11_2
  L5_2(L6_2, L7_2)
  L5_2 = GetPlayers
  L5_2 = L5_2()
  L6_2 = ipairs
  L7_2 = L5_2
  L6_2, L7_2, L8_2, L9_2 = L6_2(L7_2)
  for L10_2, L11_2 in L6_2, L7_2, L8_2, L9_2 do
    L12_2 = TriggerClientEvent
    L13_2 = "fs-government:client:governmentAnnouncement"
    L14_2 = tonumber
    L15_2 = L11_2
    L14_2 = L14_2(L15_2)
    L15_2 = {}
    L15_2.title = A0_2
    L16_2 = A1_2
    L17_2 = [[


- ]]
    L18_2 = L4_2.name
    L16_2 = L16_2 .. L17_2 .. L18_2
    L15_2.message = L16_2
    L15_2.priority = A2_2
    L12_2(L13_2, L14_2, L15_2)
  end
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "fs-government:server:endElection"
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "elections"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to end elections."
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = L1_1
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "There is no active election to end."
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.DebugPrint
  L3_2 = "Election manually ended by "
  L4_2 = L1_2.name
  if not L4_2 then
    L4_2 = "Unknown"
  end
  L5_2 = " (ID: "
  L6_2 = L0_2
  L7_2 = ")"
  L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2 .. L7_2
  L2_2(L3_2)
  L2_2 = EndElection
  L3_2 = L1_1.id
  L2_2(L3_2)
  L2_2 = nil
  L1_1 = L2_2
end
L3_1(L4_1, L5_1)
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = MySQL
  L1_2 = L1_2.execute
  L2_2 = "UPDATE government_elections SET status = ? WHERE id = ?"
  L3_2 = {}
  L4_2 = "completed"
  L5_2 = A0_2
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L1_2(L2_2, L3_2)
  L1_2 = MySQL
  L1_2 = L1_2.query
  L2_2 = "SELECT c.*, COUNT(v.id) as vote_count FROM government_candidates c LEFT JOIN government_votes v ON c.id = v.candidate_id WHERE c.election_id = ? GROUP BY c.id ORDER BY vote_count DESC LIMIT 1"
  L3_2 = {}
  L4_2 = A0_2
  L3_2[1] = L4_2
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3
    L1_3 = {}
    L2_3 = A0_2
    L1_3.id = L2_3
    L2_3 = L1_1
    if L2_3 then
      L2_3 = L1_1.title
      if L2_3 then
        goto lbl_12
      end
    end
    L2_3 = "Unknown Election"
    ::lbl_12::
    L1_3.title = L2_3
    L2_3 = A0_3[1]
    if L2_3 then
      L2_3 = A0_3[1]
      L2_3 = L2_3.vote_count
      if L2_3 > 0 then
        L2_3 = A0_3[1]
        L2_1 = L2_3
        L2_3 = {}
        L3_3 = A0_3[1]
        L3_3 = L3_3.name
        L2_3.name = L3_3
        L3_3 = A0_3[1]
        L3_3 = L3_3.vote_count
        L2_3.votes = L3_3
        L3_3 = A0_3[1]
        L3_3 = L3_3.campaign_message
        L2_3.campaign_message = L3_3
        L1_3.winner = L2_3
        L2_3 = MySQL
        L2_3 = L2_3.execute
        L3_3 = "UPDATE government_settings SET setting_value = ?, updated_by = ? WHERE setting_key = ?"
        L4_3 = {}
        L5_3 = A0_3[1]
        L5_3 = L5_3.identifier
        L6_3 = "system"
        L7_3 = "current_mayor"
        L4_3[1] = L5_3
        L4_3[2] = L6_3
        L4_3[3] = L7_3
        L2_3(L3_3, L4_3)
        L2_3 = GetPlayers
        L2_3 = L2_3()
        L3_3 = ipairs
        L4_3 = L2_3
        L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
        for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
          L9_3 = tonumber
          L10_3 = L8_3
          L9_3 = L9_3(L10_3)
          L10_3 = Framework
          L10_3 = L10_3.ShowNotification
          L11_3 = L9_3
          L12_3 = A0_3[1]
          L12_3 = L12_3.name
          L13_3 = " has won the election with "
          L14_3 = A0_3[1]
          L14_3 = L14_3.vote_count
          L15_3 = " votes!"
          L12_3 = L12_3 .. L13_3 .. L14_3 .. L15_3
          L13_3 = "success"
          L10_3(L11_3, L12_3, L13_3)
          L10_3 = TriggerClientEvent
          L11_3 = "fs-government:client:electionEnded"
          L12_3 = L9_3
          L13_3 = L1_3
          L10_3(L11_3, L12_3, L13_3)
          L10_3 = TriggerClientEvent
          L11_3 = "fs-government:client:electionAnnouncement"
          L12_3 = L9_3
          L13_3 = {}
          L14_3 = "ELECTION RESULTS: "
          L15_3 = A0_3[1]
          L15_3 = L15_3.name
          L16_3 = " has been elected with "
          L17_3 = A0_3[1]
          L17_3 = L17_3.vote_count
          L18_3 = " votes! Congratulations to our new leader."
          L14_3 = L14_3 .. L15_3 .. L16_3 .. L17_3 .. L18_3
          L13_3.message = L14_3
          L10_3(L11_3, L12_3, L13_3)
        end
    end
    else
      L2_3 = GetPlayers
      L2_3 = L2_3()
      L3_3 = ipairs
      L4_3 = L2_3
      L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
      for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
        L9_3 = tonumber
        L10_3 = L8_3
        L9_3 = L9_3(L10_3)
        L10_3 = Framework
        L10_3 = L10_3.ShowNotification
        L11_3 = L9_3
        L12_3 = "Election ended with no votes cast."
        L13_3 = "primary"
        L10_3(L11_3, L12_3, L13_3)
        L10_3 = TriggerClientEvent
        L11_3 = "fs-government:client:electionEnded"
        L12_3 = L9_3
        L13_3 = L1_3
        L10_3(L11_3, L12_3, L13_3)
        L10_3 = TriggerClientEvent
        L11_3 = "fs-government:client:electionAnnouncement"
        L12_3 = L9_3
        L13_3 = {}
        L13_3.message = "ELECTION ENDED: The election has concluded with no votes cast. No candidate has been elected at this time."
        L10_3(L11_3, L12_3, L13_3)
      end
    end
  end
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = nil
  L1_1 = L1_2
end
EndElection = L3_1
L3_1 = CreateThread
function L4_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = Wait
  L1_2 = 5000
  L0_2(L1_2)
  L0_2 = MySQL
  L0_2 = L0_2.query
  L1_2 = "SELECT setting_value FROM government_settings WHERE setting_key = ?"
  L2_2 = {}
  L3_2 = "defcon_level"
  L2_2[1] = L3_2
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = A0_3[1]
    if L1_3 then
      L1_3 = tonumber
      L2_3 = A0_3[1]
      L2_3 = L2_3.setting_value
      L1_3 = L1_3(L2_3)
      if not L1_3 then
        L1_3 = 5
      end
      L0_1 = L1_3
      L1_3 = Config
      L1_3 = L1_3.DEFCON
      L2_3 = L0_1
      L1_3.current_level = L2_3
    end
  end
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = MySQL
  L0_2 = L0_2.query
  L1_2 = "SELECT setting_value FROM government_settings WHERE setting_key = ?"
  L2_2 = {}
  L3_2 = "current_mayor"
  L2_2[1] = L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = A0_3[1]
    if L1_3 then
      L1_3 = A0_3[1]
      L1_3 = L1_3.setting_value
      if "" ~= L1_3 then
        L1_3 = MySQL
        L1_3 = L1_3.query
        L2_3 = "SELECT * FROM government_candidates WHERE identifier = ? ORDER BY registered_at DESC LIMIT 1"
        L3_3 = {}
        L4_3 = A0_3[1]
        L4_3 = L4_3.setting_value
        L3_3[1] = L4_3
        function L4_3(A0_4)
          local L1_4
          L1_4 = A0_4[1]
          if L1_4 then
            L1_4 = A0_4[1]
            L2_1 = L1_4
          end
        end
        L1_3(L2_3, L3_3, L4_3)
      end
    end
  end
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = MySQL
  L0_2 = L0_2.query
  L1_2 = "SELECT * FROM government_elections WHERE status = ?"
  L2_2 = {}
  L3_2 = "active"
  L2_2[1] = L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    L1_3 = A0_3[1]
    if L1_3 then
      L1_3 = A0_3[1]
      L1_1 = L1_3
      L1_3 = CreateThread
      function L2_3()
        local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4
        L0_4 = Wait
        L1_4 = 5000
        L0_4(L1_4)
        L0_4 = GetPlayers
        L0_4 = L0_4()
        L1_4 = ipairs
        L2_4 = L0_4
        L1_4, L2_4, L3_4, L4_4 = L1_4(L2_4)
        for L5_4, L6_4 in L1_4, L2_4, L3_4, L4_4 do
          L7_4 = TriggerClientEvent
          L8_4 = "fs-government:client:electionStarted"
          L9_4 = tonumber
          L10_4 = L6_4
          L9_4 = L9_4(L10_4)
          L10_4 = L1_1
          L7_4(L8_4, L9_4, L10_4)
        end
      end
      L1_3(L2_3)
      L1_3 = A0_3[1]
      L1_3 = L1_3.end_date
      if not L1_3 or "" == L1_3 then
        L2_3 = Utils
        L2_3 = L2_3.DebugError
        L3_3 = "Invalid end_date for election "
        L4_3 = A0_3[1]
        L4_3 = L4_3.id
        L5_3 = ", ending election"
        L3_3 = L3_3 .. L4_3 .. L5_3
        L2_3(L3_3)
        L2_3 = EndElection
        L3_3 = A0_3[1]
        L3_3 = L3_3.id
        L2_3(L3_3)
        return
      end
      L2_3 = tonumber
      L3_3 = string
      L3_3 = L3_3.sub
      L4_3 = L1_3
      L5_3 = 1
      L6_3 = 4
      L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3 = L3_3(L4_3, L5_3, L6_3)
      L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      L3_3 = tonumber
      L4_3 = string
      L4_3 = L4_3.sub
      L5_3 = L1_3
      L6_3 = 6
      L7_3 = 7
      L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3 = L4_3(L5_3, L6_3, L7_3)
      L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      L4_3 = tonumber
      L5_3 = string
      L5_3 = L5_3.sub
      L6_3 = L1_3
      L7_3 = 9
      L8_3 = 10
      L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3 = L5_3(L6_3, L7_3, L8_3)
      L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      L5_3 = tonumber
      L6_3 = string
      L6_3 = L6_3.sub
      L7_3 = L1_3
      L8_3 = 12
      L9_3 = 13
      L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3 = L6_3(L7_3, L8_3, L9_3)
      L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      L6_3 = tonumber
      L7_3 = string
      L7_3 = L7_3.sub
      L8_3 = L1_3
      L9_3 = 15
      L10_3 = 16
      L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3 = L7_3(L8_3, L9_3, L10_3)
      L6_3 = L6_3(L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      L7_3 = tonumber
      L8_3 = string
      L8_3 = L8_3.sub
      L9_3 = L1_3
      L10_3 = 18
      L11_3 = 19
      L8_3, L9_3, L10_3, L11_3, L12_3, L13_3 = L8_3(L9_3, L10_3, L11_3)
      L7_3 = L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      if not (L2_3 and L3_3 and L4_3 and L5_3 and L6_3) or not L7_3 then
        L8_3 = Utils
        L8_3 = L8_3.DebugError
        L9_3 = "Could not parse end_date \""
        L10_3 = L1_3
        L11_3 = "\" for election "
        L12_3 = A0_3[1]
        L12_3 = L12_3.id
        L13_3 = ", ending election"
        L9_3 = L9_3 .. L10_3 .. L11_3 .. L12_3 .. L13_3
        L8_3(L9_3)
        L8_3 = EndElection
        L9_3 = A0_3[1]
        L9_3 = L9_3.id
        L8_3(L9_3)
        return
      end
      L8_3 = os
      L8_3 = L8_3.time
      L9_3 = {}
      L9_3.year = L2_3
      L9_3.month = L3_3
      L9_3.day = L4_3
      L9_3.hour = L5_3
      L9_3.min = L6_3
      L9_3.sec = L7_3
      L8_3 = L8_3(L9_3)
      if not L8_3 then
        L9_3 = Utils
        L9_3 = L9_3.DebugError
        L10_3 = "Failed to create timestamp for election "
        L11_3 = A0_3[1]
        L11_3 = L11_3.id
        L12_3 = ", ending election"
        L10_3 = L10_3 .. L11_3 .. L12_3
        L9_3(L10_3)
        L9_3 = EndElection
        L10_3 = A0_3[1]
        L10_3 = L10_3.id
        L9_3(L10_3)
        return
      end
      L9_3 = os
      L9_3 = L9_3.time
      L9_3 = L9_3()
      L9_3 = L8_3 - L9_3
      if L9_3 > 0 then
        L10_3 = CreateThread
        function L11_3()
          local L0_4, L1_4
          L0_4 = Wait
          L1_4 = L9_3
          L1_4 = L1_4 * 1000
          L0_4(L1_4)
          L0_4 = EndElection
          L1_4 = A0_3
          L1_4 = L1_4[1]
          L1_4 = L1_4.id
          L0_4(L1_4)
        end
        L10_3(L11_3)
      else
        L10_3 = EndElection
        L11_3 = A0_3[1]
        L11_3 = L11_3.id
        L10_3(L11_3)
      end
    end
  end
  L0_2(L1_2, L2_2, L3_2)
end
L3_1(L4_1)
