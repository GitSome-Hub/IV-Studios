local L0_1, L1_1, L2_1, L3_1
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getBudgetInfo"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "budget_management"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view budget information"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_budget WHERE fiscal_year = ? ORDER BY department"
  L4_2 = {}
  L5_2 = os
  L5_2 = L5_2.date
  L6_2 = "%Y"
  L5_2, L6_2 = L5_2(L6_2)
  L4_2[1] = L5_2
  L4_2[2] = L6_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showBudgetInfo"
    L3_3 = L0_2
    L4_3 = A0_3
    L5_3 = os
    L5_3 = L5_3.date
    L6_3 = "%Y"
    L5_3, L6_3 = L5_3(L6_3)
    L1_3(L2_3, L3_3, L4_3, L5_3, L6_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:setDepartmentBudget"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  if not L4_2 then
    return
  end
  L5_2 = Utils
  L5_2 = L5_2.HasPermission
  L6_2 = L4_2.job
  L6_2 = L6_2.name
  L7_2 = L4_2.job
  L7_2 = L7_2.grade
  L8_2 = "budget_management"
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  if not L5_2 then
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L3_2
    L7_2 = "You do not have permission to set department budgets"
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
    return
  end
  L5_2 = MySQL
  L5_2 = L5_2.query
  L6_2 = "SELECT * FROM government_budget WHERE department = ? AND fiscal_year = ?"
  L7_2 = {}
  L8_2 = A0_2
  L9_2 = A2_2
  L7_2[1] = L8_2
  L7_2[2] = L9_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = A0_3[1]
    if L1_3 then
      L1_3 = MySQL
      L1_3 = L1_3.execute
      L2_3 = "UPDATE government_budget SET allocated_amount = ? WHERE department = ? AND fiscal_year = ?"
      L3_3 = {}
      L4_3 = A1_2
      L5_3 = A0_2
      L6_3 = A2_2
      L3_3[1] = L4_3
      L3_3[2] = L5_3
      L3_3[3] = L6_3
      L1_3(L2_3, L3_3)
    else
      L1_3 = MySQL
      L1_3 = L1_3.insert
      L2_3 = "INSERT INTO government_budget (department, fiscal_year, allocated_amount, spent_amount, created_by) VALUES (?, ?, ?, ?, ?)"
      L3_3 = {}
      L4_3 = A0_2
      L5_3 = A2_2
      L6_3 = A1_2
      L7_3 = 0
      L8_3 = L4_2.identifier
      L3_3[1] = L4_3
      L3_3[2] = L5_3
      L3_3[3] = L6_3
      L3_3[4] = L7_3
      L3_3[5] = L8_3
      L1_3(L2_3, L3_3)
    end
    L1_3 = Framework
    L1_3 = L1_3.ShowNotification
    L2_3 = L3_2
    L3_3 = "Budget set for "
    L4_3 = A0_2
    L5_3 = ": $"
    L6_3 = A1_2
    L3_3 = L3_3 .. L4_3 .. L5_3 .. L6_3
    L4_3 = "success"
    L1_3(L2_3, L3_3, L4_3)
  end
  L5_2(L6_2, L7_2, L8_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getMonthlyReport"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "financial_reporting"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view financial reports"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = os
  L2_2 = L2_2.date
  L3_2 = "%Y-%m"
  L2_2 = L2_2(L3_2)
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT transaction_type, SUM(amount) as total FROM government_transactions WHERE DATE_FORMAT(created_at, \"%Y-%m\") = ? GROUP BY transaction_type"
  L5_2 = {}
  L6_2 = L2_2
  L5_2[1] = L6_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showMonthlyReport"
    L3_3 = L0_2
    L4_3 = A0_3
    L5_3 = L2_2
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L3_2(L4_2, L5_2, L6_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getExpenseReport"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "financial_reporting"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view expense reports"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT description, amount, created_at FROM government_transactions WHERE transaction_type IN (?, ?, ?) ORDER BY created_at DESC LIMIT 50"
  L4_2 = {}
  L5_2 = "expense"
  L6_2 = "subsidy"
  L7_2 = "allocation"
  L4_2[1] = L5_2
  L4_2[2] = L6_2
  L4_2[3] = L7_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showExpenseReport"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getTaxReport"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "financial_reporting"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view tax reports"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT tax_type, SUM(amount) as total FROM government_taxation WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY tax_type"
  L4_2 = {}
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showTaxReport"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getAnnualReport"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "financial_reporting"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view annual reports"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = os
  L2_2 = L2_2.date
  L3_2 = "%Y"
  L2_2 = L2_2(L3_2)
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT transaction_type, SUM(amount) as total FROM government_transactions WHERE YEAR(created_at) = ? GROUP BY transaction_type"
  L5_2 = {}
  L6_2 = L2_2
  L5_2[1] = L6_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showAnnualReport"
    L3_3 = L0_2
    L4_3 = A0_3
    L5_3 = L2_2
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L3_2(L4_2, L5_2, L6_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:initiateBusinessAudit"
function L2_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L5_2 = source
  L6_2 = Framework
  L6_2 = L6_2.GetPlayerData
  L7_2 = L5_2
  L6_2 = L6_2(L7_2)
  if not L6_2 then
    return
  end
  L7_2 = Utils
  L7_2 = L7_2.HasPermission
  L8_2 = L6_2.job
  L8_2 = L8_2.name
  L9_2 = L6_2.job
  L9_2 = L9_2.grade
  L10_2 = "business_audit"
  L7_2 = L7_2(L8_2, L9_2, L10_2)
  if not L7_2 then
    L7_2 = Framework
    L7_2 = L7_2.ShowNotification
    L8_2 = L5_2
    L9_2 = "You do not have permission to initiate business audits"
    L10_2 = "error"
    L7_2(L8_2, L9_2, L10_2)
    return
  end
  L7_2 = Framework
  L7_2 = L7_2.GetPlayerData
  L8_2 = A1_2
  L7_2 = L7_2(L8_2)
  if not L7_2 then
    L8_2 = Framework
    L8_2 = L8_2.ShowNotification
    L9_2 = L5_2
    L10_2 = "Business owner not found or not online"
    L11_2 = "error"
    L8_2(L9_2, L10_2, L11_2)
    return
  end
  function L8_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L0_3 = MySQL
    L0_3 = L0_3.insert
    L1_3 = "INSERT INTO government_audits (business_name, owner_identifier, owner_name, business_type, audit_type, reason, status, initiated_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    L2_3 = {}
    L3_3 = A0_2
    L4_3 = L7_2.identifier
    L5_3 = L7_2.name
    L6_3 = A2_2
    L7_3 = A3_2
    L8_3 = A4_2
    L9_3 = "in_progress"
    L10_3 = L6_2.identifier
    L2_3[1] = L3_3
    L2_3[2] = L4_3
    L2_3[3] = L5_3
    L2_3[4] = L6_3
    L2_3[5] = L7_3
    L2_3[6] = L8_3
    L2_3[7] = L9_3
    L2_3[8] = L10_3
    function L3_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4
      L1_4 = Framework
      L1_4 = L1_4.ShowNotification
      L2_4 = L5_2
      L3_4 = "Business audit initiated for "
      L4_4 = A0_2
      L5_4 = " (ID: "
      L6_4 = A0_4
      L7_4 = ")"
      L3_4 = L3_4 .. L4_4 .. L5_4 .. L6_4 .. L7_4
      L4_4 = "success"
      L1_4(L2_4, L3_4, L4_4)
      L1_4 = Framework
      L1_4 = L1_4.ShowNotification
      L2_4 = A1_2
      L3_4 = "Your business \""
      L4_4 = A0_2
      L5_4 = "\" is being audited. Type: "
      L6_4 = A3_2
      L7_4 = " | Reason: "
      L8_4 = A4_2
      L3_4 = L3_4 .. L4_4 .. L5_4 .. L6_4 .. L7_4 .. L8_4
      L4_4 = "warning"
      L1_4(L2_4, L3_4, L4_4)
      L1_4 = MySQL
      L1_4 = L1_4.insert
      L2_4 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
      L3_4 = {}
      L4_4 = "expense"
      L5_4 = 0
      L6_4 = "Business audit initiated: "
      L7_4 = A0_2
      L8_4 = " ("
      L9_4 = A3_2
      L10_4 = ")"
      L6_4 = L6_4 .. L7_4 .. L8_4 .. L9_4 .. L10_4
      L7_4 = L7_2.identifier
      L8_4 = L6_2.identifier
      L3_4[1] = L4_4
      L3_4[2] = L5_4
      L3_4[3] = L6_4
      L3_4[4] = L7_4
      L3_4[5] = L8_4
      L1_4(L2_4, L3_4)
    end
    L0_3(L1_3, L2_3, L3_3)
  end
  L9_2 = MySQL
  L9_2 = L9_2.query
  L10_2 = "SELECT id FROM government_businesses WHERE business_name = ? AND owner_identifier = ?"
  L11_2 = {}
  L12_2 = A0_2
  L13_2 = L7_2.identifier
  L11_2[1] = L12_2
  L11_2[2] = L13_2
  function L12_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L1_3 = Config
    L1_3 = L1_3.Debug
    if L1_3 then
      L1_3 = Utils
      L1_3 = L1_3.DebugPrint
      L2_3 = "Checking for existing business: "
      L3_3 = A0_2
      L4_3 = " owned by "
      L5_3 = L7_2.identifier
      L2_3 = L2_3 .. L3_3 .. L4_3 .. L5_3
      L1_3(L2_3)
      L1_3 = Utils
      L1_3 = L1_3.DebugPrint
      L2_3 = "Existing business query returned: "
      L3_3 = #A0_3
      L4_3 = " records"
      L2_3 = L2_3 .. L3_3 .. L4_3
      L1_3(L2_3)
    end
    if A0_3 then
      L1_3 = #A0_3
      if 0 ~= L1_3 then
        goto lbl_58
      end
    end
    L1_3 = "AUD-"
    L2_3 = Utils
    L2_3 = L2_3.GenerateId
    L2_3 = L2_3()
    L1_3 = L1_3 .. L2_3
    L2_3 = Config
    L2_3 = L2_3.Debug
    if L2_3 then
      L2_3 = Utils
      L2_3 = L2_3.DebugPrint
      L3_3 = "Creating new business record for audit: "
      L4_3 = A0_2
      L5_3 = " with license: "
      L6_3 = L1_3
      L3_3 = L3_3 .. L4_3 .. L5_3 .. L6_3
      L2_3(L3_3)
    end
    L2_3 = MySQL
    L2_3 = L2_3.insert
    L3_3 = "INSERT INTO government_businesses (business_name, owner_identifier, owner_name, business_type, license_number, registration_fee, status) VALUES (?, ?, ?, ?, ?, ?, ?)"
    L4_3 = {}
    L5_3 = A0_2
    L6_3 = L7_2.identifier
    L7_3 = L7_2.name
    L8_3 = A2_2
    L9_3 = L1_3
    L10_3 = 0
    L11_3 = "active"
    L4_3[1] = L5_3
    L4_3[2] = L6_3
    L4_3[3] = L7_3
    L4_3[4] = L8_3
    L4_3[5] = L9_3
    L4_3[6] = L10_3
    L4_3[7] = L11_3
    function L5_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4
      if A1_4 then
        L2_4 = Config
        L2_4 = L2_4.Debug
        if L2_4 then
          L2_4 = Utils
          L2_4 = L2_4.DebugError
          L3_4 = "Failed to create business record: "
          L4_4 = tostring
          L5_4 = A1_4
          L4_4 = L4_4(L5_4)
          L3_4 = L3_4 .. L4_4
          L2_4(L3_4)
        end
        L2_4 = Framework
        L2_4 = L2_4.ShowNotification
        L3_4 = L5_2
        L4_4 = "Failed to create business record. Check server console for details."
        L5_4 = "error"
        L2_4(L3_4, L4_4, L5_4)
        return
      end
      L2_4 = Config
      L2_4 = L2_4.Debug
      if L2_4 then
        L2_4 = Utils
        L2_4 = L2_4.DebugSuccess
        L3_4 = "Business created successfully with ID: "
        L4_4 = tostring
        L5_4 = A0_4
        L4_4 = L4_4(L5_4)
        L3_4 = L3_4 .. L4_4
        L2_4(L3_4)
      end
      L2_4 = L8_2
      L2_4()
    end
    L2_3(L3_3, L4_3, L5_3)
    goto lbl_68
    ::lbl_58::
    L1_3 = Config
    L1_3 = L1_3.Debug
    if L1_3 then
      L1_3 = Utils
      L1_3 = L1_3.DebugPrint
      L2_3 = "Business already exists, proceeding with audit"
      L1_3(L2_3)
    end
    L1_3 = L8_2
    L1_3()
    ::lbl_68::
  end
  L9_2(L10_2, L11_2, L12_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:createSubsidy"
function L2_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L5_2 = source
  L6_2 = Framework
  L6_2 = L6_2.GetPlayerData
  L7_2 = L5_2
  L6_2 = L6_2(L7_2)
  if not L6_2 then
    return
  end
  L7_2 = Utils
  L7_2 = L7_2.HasPermission
  L8_2 = L6_2.job
  L8_2 = L8_2.name
  L9_2 = L6_2.job
  L9_2 = L9_2.grade
  L10_2 = "subsidy_management"
  L7_2 = L7_2(L8_2, L9_2, L10_2)
  if not L7_2 then
    L7_2 = Framework
    L7_2 = L7_2.ShowNotification
    L8_2 = L5_2
    L9_2 = "You do not have permission to create subsidies"
    L10_2 = "error"
    L7_2(L8_2, L9_2, L10_2)
    return
  end
  L7_2 = MySQL
  L7_2 = L7_2.query
  L8_2 = "SELECT SUM(CASE WHEN transaction_type IN (\"income\", \"tax\", \"deposit\") THEN amount ELSE -amount END) as total_funds FROM government_transactions"
  L9_2 = {}
  function L10_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    L1_3 = tonumber
    L2_3 = A0_3[1]
    if L2_3 then
      L2_3 = A0_3[1]
      L2_3 = L2_3.total_funds
      if L2_3 then
        goto lbl_10
      end
    end
    L2_3 = 0
    ::lbl_10::
    L1_3 = L1_3(L2_3)
    L2_3 = A2_2
    if L1_3 < L2_3 then
      L2_3 = Framework
      L2_3 = L2_3.ShowNotification
      L3_3 = L5_2
      L4_3 = "Insufficient government treasury funds. Available: "
      L5_3 = Utils
      L5_3 = L5_3.FormatMoney
      L6_3 = L1_3
      L5_3 = L5_3(L6_3)
      L6_3 = ", Required: "
      L7_3 = Utils
      L7_3 = L7_3.FormatMoney
      L8_3 = A2_2
      L7_3 = L7_3(L8_3)
      L4_3 = L4_3 .. L5_3 .. L6_3 .. L7_3
      L5_3 = "error"
      L2_3(L3_3, L4_3, L5_3)
      return
    end
    L2_3 = Framework
    L2_3 = L2_3.GetPlayerData
    L3_3 = A1_2
    L2_3 = L2_3(L3_3)
    if not L2_3 then
      L3_3 = Framework
      L3_3 = L3_3.ShowNotification
      L4_3 = L5_2
      L5_3 = "Target player not found or not online"
      L6_3 = "error"
      L3_3(L4_3, L5_3, L6_3)
      return
    end
    L3_3 = MySQL
    L3_3 = L3_3.insert
    L4_3 = "INSERT INTO government_subsidies (recipient_identifier, recipient_name, subsidy_type, amount, description, duration_days, status, approved_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    L5_3 = {}
    L6_3 = L2_3.identifier
    L7_3 = L2_3.name
    L8_3 = A0_2
    L9_3 = A2_2
    L10_3 = A4_2
    L11_3 = A3_2
    L12_3 = "approved"
    L13_3 = L6_2.identifier
    L5_3[1] = L6_3
    L5_3[2] = L7_3
    L5_3[3] = L8_3
    L5_3[4] = L9_3
    L5_3[5] = L10_3
    L5_3[6] = L11_3
    L5_3[7] = L12_3
    L5_3[8] = L13_3
    function L6_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4
      L1_4 = Framework
      L1_4 = L1_4.AddMoney
      L2_4 = A1_2
      L3_4 = A2_2
      L4_4 = "bank"
      L1_4 = L1_4(L2_4, L3_4, L4_4)
      if L1_4 then
        L1_4 = MySQL
        L1_4 = L1_4.execute
        L2_4 = "UPDATE government_subsidies SET status = ?, paid_by = ? WHERE id = ?"
        L3_4 = {}
        L4_4 = "paid"
        L5_4 = L6_2.identifier
        L6_4 = A0_4
        L3_4[1] = L4_4
        L3_4[2] = L5_4
        L3_4[3] = L6_4
        L1_4(L2_4, L3_4)
        L1_4 = MySQL
        L1_4 = L1_4.insert
        L2_4 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
        L3_4 = {}
        L4_4 = "subsidy"
        L5_4 = A2_2
        L6_4 = A0_2
        L7_4 = " subsidy for "
        L8_4 = L2_3.name
        L9_4 = ": "
        L10_4 = A4_2
        L6_4 = L6_4 .. L7_4 .. L8_4 .. L9_4 .. L10_4
        L7_4 = L2_3.identifier
        L8_4 = L6_2.identifier
        L3_4[1] = L4_4
        L3_4[2] = L5_4
        L3_4[3] = L6_4
        L3_4[4] = L7_4
        L3_4[5] = L8_4
        L1_4(L2_4, L3_4)
        L1_4 = Framework
        L1_4 = L1_4.ShowNotification
        L2_4 = L5_2
        L3_4 = "Subsidy created and paid successfully"
        L4_4 = "success"
        L1_4(L2_4, L3_4, L4_4)
        L1_4 = Framework
        L1_4 = L1_4.ShowNotification
        L2_4 = A1_2
        L3_4 = "You have received a "
        L4_4 = A0_2
        L5_4 = " subsidy of "
        L6_4 = Utils
        L6_4 = L6_4.FormatMoney
        L7_4 = A2_2
        L6_4 = L6_4(L7_4)
        L7_4 = ". Description: "
        L8_4 = A4_2
        L3_4 = L3_4 .. L4_4 .. L5_4 .. L6_4 .. L7_4 .. L8_4
        L4_4 = "success"
        L1_4(L2_4, L3_4, L4_4)
      else
        L1_4 = Framework
        L1_4 = L1_4.ShowNotification
        L2_4 = L5_2
        L3_4 = "Failed to pay subsidy - system error"
        L4_4 = "error"
        L1_4(L2_4, L3_4, L4_4)
      end
    end
    L3_3(L4_3, L5_3, L6_3)
  end
  L7_2(L8_2, L9_2, L10_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getSubsidies"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "subsidy_management"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view subsidies"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_subsidies ORDER BY created_at DESC LIMIT 50"
  L4_2 = {}
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = TriggerClientEvent
      L2_3 = "fs-government:client:showSubsidies"
      L3_3 = L0_2
      L4_3 = {}
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = Config
    L1_3 = L1_3.Debug
    if L1_3 then
      L1_3 = A0_3[1]
      if L1_3 then
        L1_3 = Utils
        L1_3 = L1_3.DebugPrint
        L2_3 = "Subsidy database check:"
        L1_3(L2_3)
        L1_3 = Utils
        L1_3 = L1_3.DebugPrint
        L2_3 = "created_at type:"
        L3_3 = type
        L4_3 = A0_3[1]
        L4_3 = L4_3.created_at
        L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L3_3(L4_3)
        L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
        L1_3 = Utils
        L1_3 = L1_3.DebugPrint
        L2_3 = "created_at value:"
        L3_3 = A0_3[1]
        L3_3 = L3_3.created_at
        L1_3(L2_3, L3_3)
        L1_3 = Utils
        L1_3 = L1_3.DebugPrint
        L2_3 = "updated_at type:"
        L3_3 = type
        L4_3 = A0_3[1]
        L4_3 = L4_3.updated_at
        L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L3_3(L4_3)
        L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
        L1_3 = Utils
        L1_3 = L1_3.DebugPrint
        L2_3 = "updated_at value:"
        L3_3 = A0_3[1]
        L3_3 = L3_3.updated_at
        L1_3(L2_3, L3_3)
      end
    end
    function L1_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4, L16_4, L17_4
      if not A0_4 or "" == A0_4 or "NULL" == A0_4 then
        L1_4 = "Unknown Date"
        return L1_4
      end
      L1_4 = {}
      L2_4 = "Jan"
      L3_4 = "Feb"
      L4_4 = "Mar"
      L5_4 = "Apr"
      L6_4 = "May"
      L7_4 = "Jun"
      L8_4 = "Jul"
      L9_4 = "Aug"
      L10_4 = "Sep"
      L11_4 = "Oct"
      L12_4 = "Nov"
      L13_4 = "Dec"
      L1_4[1] = L2_4
      L1_4[2] = L3_4
      L1_4[3] = L4_4
      L1_4[4] = L5_4
      L1_4[5] = L6_4
      L1_4[6] = L7_4
      L1_4[7] = L8_4
      L1_4[8] = L9_4
      L1_4[9] = L10_4
      L1_4[10] = L11_4
      L1_4[11] = L12_4
      L1_4[12] = L13_4
      L2_4 = tonumber
      L3_4 = A0_4
      L2_4 = L2_4(L3_4)
      if L2_4 then
        L3_4 = 1000000000
        if L2_4 > L3_4 then
          L3_4 = 10000000000
          if L2_4 > L3_4 then
            L2_4 = L2_4 / 1000
          end
          L3_4 = os
          L3_4 = L3_4.date
          L4_4 = "*t"
          L5_4 = L2_4
          L3_4 = L3_4(L4_4, L5_4)
          if L3_4 then
            L4_4 = L3_4.year
            L5_4 = 1970
            if L4_4 > L5_4 then
              L4_4 = string
              L4_4 = L4_4.format
              L5_4 = "%s %d, %d at %02d:%02d"
              L6_4 = L3_4.month
              L6_4 = L1_4[L6_4]
              if not L6_4 then
                L6_4 = "Unknown"
              end
              L7_4 = L3_4.day
              L8_4 = L3_4.year
              L9_4 = L3_4.hour
              L10_4 = L3_4.min
              return L4_4(L5_4, L6_4, L7_4, L8_4, L9_4, L10_4)
            end
          end
        end
      end
      L3_4 = tostring
      L4_4 = A0_4
      L3_4 = L3_4(L4_4)
      L5_4 = L3_4
      L4_4 = L3_4.match
      L6_4 = "(%d%d%d%d)-(%d%d)-(%d%d) (%d%d):(%d%d)"
      L4_4, L5_4, L6_4, L7_4, L8_4 = L4_4(L5_4, L6_4)
      if L4_4 and L5_4 and L6_4 and L7_4 and L8_4 then
        L9_4 = tonumber
        L10_4 = L4_4
        L9_4 = L9_4(L10_4)
        L10_4 = tonumber
        L11_4 = L5_4
        L10_4 = L10_4(L11_4)
        L11_4 = tonumber
        L12_4 = L6_4
        L11_4 = L11_4(L12_4)
        L12_4 = tonumber
        L13_4 = L7_4
        L12_4 = L12_4(L13_4)
        L13_4 = tonumber
        L14_4 = L8_4
        L13_4 = L13_4(L14_4)
        L8_4 = L13_4
        L7_4 = L12_4
        L6_4 = L11_4
        L5_4 = L10_4
        L4_4 = L9_4
        L9_4 = 1970
        if L4_4 > L9_4 and L5_4 >= 1 and L5_4 <= 12 and L6_4 >= 1 and L6_4 <= 31 then
          L9_4 = string
          L9_4 = L9_4.format
          L10_4 = "%s %d, %d at %02d:%02d"
          L11_4 = L1_4[L5_4]
          if not L11_4 then
            L11_4 = "Unknown"
          end
          L12_4 = L6_4
          L13_4 = L4_4
          L14_4 = L7_4
          L15_4 = L8_4
          return L9_4(L10_4, L11_4, L12_4, L13_4, L14_4, L15_4)
        end
      end
      L10_4 = L3_4
      L9_4 = L3_4.match
      L11_4 = "(%d%d%d%d)-(%d%d)-(%d%d)"
      L9_4, L10_4, L11_4 = L9_4(L10_4, L11_4)
      L6_4 = L11_4
      L5_4 = L10_4
      L4_4 = L9_4
      if L4_4 and L5_4 and L6_4 then
        L9_4 = tonumber
        L10_4 = L4_4
        L9_4 = L9_4(L10_4)
        L10_4 = tonumber
        L11_4 = L5_4
        L10_4 = L10_4(L11_4)
        L11_4 = tonumber
        L12_4 = L6_4
        L11_4 = L11_4(L12_4)
        L6_4 = L11_4
        L5_4 = L10_4
        L4_4 = L9_4
        L9_4 = 1970
        if L4_4 > L9_4 and L5_4 >= 1 and L5_4 <= 12 and L6_4 >= 1 and L6_4 <= 31 then
          L9_4 = string
          L9_4 = L9_4.format
          L10_4 = "%s %d, %d"
          L11_4 = L1_4[L5_4]
          if not L11_4 then
            L11_4 = "Unknown"
          end
          L12_4 = L6_4
          L13_4 = L4_4
          return L9_4(L10_4, L11_4, L12_4, L13_4)
        end
      end
      L10_4 = L3_4
      L9_4 = L3_4.match
      L11_4 = "(%d%d%d%d)-(%d%d)-(%d%d)T(%d%d):(%d%d)"
      L9_4, L10_4, L11_4, L12_4, L13_4 = L9_4(L10_4, L11_4)
      L8_4 = L13_4
      L7_4 = L12_4
      L6_4 = L11_4
      L5_4 = L10_4
      L4_4 = L9_4
      if L4_4 and L5_4 and L6_4 then
        L9_4 = tonumber
        L10_4 = L4_4
        L9_4 = L9_4(L10_4)
        L10_4 = tonumber
        L11_4 = L5_4
        L10_4 = L10_4(L11_4)
        L11_4 = tonumber
        L12_4 = L6_4
        L11_4 = L11_4(L12_4)
        L6_4 = L11_4
        L5_4 = L10_4
        L4_4 = L9_4
        L9_4 = tonumber
        L10_4 = L7_4
        L9_4 = L9_4(L10_4)
        if not L9_4 then
          L9_4 = 0
        end
        L10_4 = tonumber
        L11_4 = L8_4
        L10_4 = L10_4(L11_4)
        L8_4 = L10_4 or L8_4
        if not L10_4 then
          L8_4 = 0
        end
        L7_4 = L9_4
        L9_4 = 1970
        if L4_4 > L9_4 and L5_4 >= 1 and L5_4 <= 12 and L6_4 >= 1 and L6_4 <= 31 then
          L9_4 = string
          L9_4 = L9_4.format
          L10_4 = "%s %d, %d at %02d:%02d"
          L11_4 = L1_4[L5_4]
          if not L11_4 then
            L11_4 = "Unknown"
          end
          L12_4 = L6_4
          L13_4 = L4_4
          L14_4 = L7_4
          L15_4 = L8_4
          return L9_4(L10_4, L11_4, L12_4, L13_4, L14_4, L15_4)
        end
      end
      L10_4 = L3_4
      L9_4 = L3_4.match
      L11_4 = "^%d+$"
      L9_4 = L9_4(L10_4, L11_4)
      if L9_4 then
        L9_4 = tonumber
        L10_4 = L3_4
        L9_4 = L9_4(L10_4)
        if L9_4 then
          L10_4 = 1000000000
          if L9_4 > L10_4 then
            L10_4 = 10000000000
            if L9_4 > L10_4 then
              L9_4 = L9_4 / 1000
            end
            L10_4 = os
            L10_4 = L10_4.date
            L11_4 = "*t"
            L12_4 = L9_4
            L10_4 = L10_4(L11_4, L12_4)
            if L10_4 then
              L11_4 = L10_4.year
              L12_4 = 1970
              if L11_4 > L12_4 then
                L11_4 = string
                L11_4 = L11_4.format
                L12_4 = "%s %d, %d at %02d:%02d"
                L13_4 = L10_4.month
                L13_4 = L1_4[L13_4]
                if not L13_4 then
                  L13_4 = "Unknown"
                end
                L14_4 = L10_4.day
                L15_4 = L10_4.year
                L16_4 = L10_4.hour
                L17_4 = L10_4.min
                return L11_4(L12_4, L13_4, L14_4, L15_4, L16_4, L17_4)
              end
            end
          end
        end
      end
      L10_4 = L3_4
      L9_4 = L3_4.gsub
      L11_4 = "T"
      L12_4 = " "
      L9_4 = L9_4(L10_4, L11_4, L12_4)
      L10_4 = L9_4
      L9_4 = L9_4.gsub
      L11_4 = "%.%d+Z?"
      L12_4 = ""
      L9_4 = L9_4(L10_4, L11_4, L12_4)
      L10_4 = L9_4
      L9_4 = L9_4.gsub
      L11_4 = "Z"
      L12_4 = ""
      L9_4 = L9_4(L10_4, L11_4, L12_4)
      L10_4 = L9_4 or L10_4
      if "" == L9_4 or not L9_4 then
        L10_4 = "Raw: "
        L11_4 = L3_4
        L10_4 = L10_4 .. L11_4
      end
      return L10_4
    end
    L2_3 = ipairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = L1_3
      L9_3 = L7_3.created_at
      L8_3 = L8_3(L9_3)
      L7_3.formatted_created_at = L8_3
      L8_3 = L1_3
      L9_3 = L7_3.updated_at
      L8_3 = L8_3(L9_3)
      L7_3.formatted_updated_at = L8_3
    end
    L2_3 = TriggerClientEvent
    L3_3 = "fs-government:client:showSubsidies"
    L4_3 = L0_2
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:auditBusiness"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L2_2.job
  L4_2 = L4_2.name
  L5_2 = L2_2.job
  L5_2 = L5_2.grade
  L6_2 = "business_audit"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if not L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = L1_2
    L5_2 = "You do not have permission to audit businesses"
    L6_2 = "error"
    L3_2(L4_2, L5_2, L6_2)
    return
  end
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT * FROM government_businesses WHERE business_name LIKE ?"
  L5_2 = {}
  L6_2 = "%"
  L7_2 = A0_2
  L8_2 = "%"
  L6_2 = L6_2 .. L7_2 .. L8_2
  L5_2[1] = L6_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L1_2
      L3_3 = "Business not found"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = A0_3[1]
    L2_3 = MySQL
    L2_3 = L2_3.query
    L3_3 = "SELECT SUM(amount) as total_tax FROM government_taxation WHERE identifier = ? AND tax_type = ?"
    L4_3 = {}
    L5_3 = L1_3.owner_identifier
    L6_3 = "business"
    L4_3[1] = L5_3
    L4_3[2] = L6_3
    function L5_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4
      L1_4 = A0_4[1]
      if L1_4 then
        L1_4 = A0_4[1]
        L1_4 = L1_4.total_tax
        if L1_4 then
          goto lbl_9
        end
      end
      L1_4 = 0
      ::lbl_9::
      L2_4 = {}
      L3_4 = L1_3.id
      L2_4.id = L3_4
      L3_4 = L1_3.business_name
      L2_4.business_name = L3_4
      L3_4 = L1_3.owner_name
      L2_4.owner_name = L3_4
      L3_4 = L1_3.business_type
      L2_4.business_type = L3_4
      L3_4 = L1_3.license_number
      L2_4.license_number = L3_4
      L3_4 = L1_3.status
      L2_4.status = L3_4
      L2_4.total_tax_paid = L1_4
      L3_4 = L1_3.tax_rate
      L2_4.tax_rate = L3_4
      L3_4 = L1_3.address
      L2_4.address = L3_4
      L3_4 = L1_3.registration_fee
      L2_4.registration_fee = L3_4
      L3_4 = L1_3.created_at
      L2_4.created_at = L3_4
      L3_4 = string
      L3_4 = L3_4.format
      L4_4 = [[
Business Audit Report:
Name: %s
Owner: %s
Type: %s
License: %s
Status: %s
Total Tax Paid: %s
Tax Rate: %.2f%%]]
      L5_4 = L1_3.business_name
      L6_4 = L1_3.owner_name
      L7_4 = L1_3.business_type
      L8_4 = L1_3.license_number
      L9_4 = L1_3.status
      L10_4 = Utils
      L10_4 = L10_4.FormatMoney
      L11_4 = L1_4
      L10_4 = L10_4(L11_4)
      L11_4 = L1_3.tax_rate
      L3_4 = L3_4(L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4)
      L4_4 = MySQL
      L4_4 = L4_4.insert
      L5_4 = "INSERT INTO business_audits (business_id, auditor_identifier, audit_date, findings) VALUES (?, ?, ?, ?)"
      L6_4 = {}
      L7_4 = L1_3.id
      L8_4 = L2_2.identifier
      L9_4 = os
      L9_4 = L9_4.date
      L10_4 = "%Y-%m-%d %H:%M:%S"
      L9_4 = L9_4(L10_4)
      L10_4 = L3_4
      L6_4[1] = L7_4
      L6_4[2] = L8_4
      L6_4[3] = L9_4
      L6_4[4] = L10_4
      L4_4(L5_4, L6_4)
      L4_4 = TriggerClientEvent
      L5_4 = "fs-government:client:showBusinessAuditResult"
      L6_4 = L1_2
      L7_4 = L2_4
      L4_4(L5_4, L6_4, L7_4)
    end
    L2_3(L3_3, L4_3, L5_3)
  end
  L3_2(L4_2, L5_2, L6_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:setBudget"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  if not L4_2 then
    return
  end
  L5_2 = Utils
  L5_2 = L5_2.HasPermission
  L6_2 = L4_2.job
  L6_2 = L6_2.name
  L7_2 = L4_2.job
  L7_2 = L7_2.grade
  L8_2 = "budget_management"
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  if not L5_2 then
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L3_2
    L7_2 = "You do not have permission to manage budgets"
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
    return
  end
  L5_2 = MySQL
  L5_2 = L5_2.query
  L6_2 = "SELECT * FROM government_budget WHERE department = ? AND fiscal_year = ?"
  L7_2 = {}
  L8_2 = A0_2
  L9_2 = A2_2
  L7_2[1] = L8_2
  L7_2[2] = L9_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L1_3 = A0_3[1]
    if L1_3 then
      L1_3 = MySQL
      L1_3 = L1_3.execute
      L2_3 = "UPDATE government_budget SET allocated_amount = ?, created_by = ? WHERE id = ?"
      L3_3 = {}
      L4_3 = A1_2
      L5_3 = L4_2.identifier
      L6_3 = A0_3[1]
      L6_3 = L6_3.id
      L3_3[1] = L4_3
      L3_3[2] = L5_3
      L3_3[3] = L6_3
      L1_3(L2_3, L3_3)
    else
      L1_3 = MySQL
      L1_3 = L1_3.insert
      L2_3 = "INSERT INTO government_budget (department, allocated_amount, fiscal_year, created_by) VALUES (?, ?, ?, ?)"
      L3_3 = {}
      L4_3 = A0_2
      L5_3 = A1_2
      L6_3 = A2_2
      L7_3 = L4_2.identifier
      L3_3[1] = L4_3
      L3_3[2] = L5_3
      L3_3[3] = L6_3
      L3_3[4] = L7_3
      L1_3(L2_3, L3_3)
    end
    L1_3 = Framework
    L1_3 = L1_3.ShowNotification
    L2_3 = L3_2
    L3_3 = "Budget set successfully for "
    L4_3 = A0_2
    L3_3 = L3_3 .. L4_3
    L4_3 = "success"
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = MySQL
    L1_3 = L1_3.insert
    L2_3 = "INSERT INTO government_transactions (transaction_type, amount, description, processed_by) VALUES (?, ?, ?, ?)"
    L3_3 = {}
    L4_3 = "expense"
    L5_3 = 0
    L6_3 = "Budget allocation for "
    L7_3 = A0_2
    L8_3 = " - FY"
    L9_3 = A2_2
    L6_3 = L6_3 .. L7_3 .. L8_3 .. L9_3
    L7_3 = L4_2.identifier
    L3_3[1] = L4_3
    L3_3[2] = L5_3
    L3_3[3] = L6_3
    L3_3[4] = L7_3
    L1_3(L2_3, L3_3)
  end
  L5_2(L6_2, L7_2, L8_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getBudget"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L2_2.job
  L4_2 = L4_2.name
  L5_2 = L2_2.job
  L5_2 = L5_2.grade
  L6_2 = "budget_management"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if not L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = L1_2
    L5_2 = "You do not have permission to view budgets"
    L6_2 = "error"
    L3_2(L4_2, L5_2, L6_2)
    return
  end
  L3_2 = A0_2 or L3_2
  if not A0_2 then
    L3_2 = tonumber
    L4_2 = os
    L4_2 = L4_2.date
    L5_2 = "%Y"
    L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
    L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2)
  end
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT * FROM government_budget WHERE fiscal_year = ?"
  L6_2 = {}
  L7_2 = L3_2
  L6_2[1] = L7_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showBudgetInfo"
    L3_3 = L1_2
    L4_3 = A0_3
    L5_3 = L3_2
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L4_2(L5_2, L6_2, L7_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:allocateFunds"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  if not L4_2 then
    return
  end
  L5_2 = Utils
  L5_2 = L5_2.HasPermission
  L6_2 = L4_2.job
  L6_2 = L6_2.name
  L7_2 = L4_2.job
  L7_2 = L7_2.grade
  L8_2 = "budget_management"
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  if not L5_2 then
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L3_2
    L7_2 = "You do not have permission to allocate funds"
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
    return
  end
  L5_2 = tonumber
  L6_2 = os
  L6_2 = L6_2.date
  L7_2 = "%Y"
  L6_2, L7_2, L8_2, L9_2, L10_2 = L6_2(L7_2)
  L5_2 = L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
  L6_2 = MySQL
  L6_2 = L6_2.query
  L7_2 = "SELECT * FROM government_budget WHERE department = ? AND fiscal_year = ?"
  L8_2 = {}
  L9_2 = A0_2
  L10_2 = L5_2
  L8_2[1] = L9_2
  L8_2[2] = L10_2
  function L9_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    L1_3 = A0_3[1]
    if not L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L3_2
      L3_3 = "No budget found for "
      L4_3 = A0_2
      L3_3 = L3_3 .. L4_3
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = A0_3[1]
    L2_3 = tonumber
    L3_3 = L1_3.spent_amount
    L2_3 = L2_3(L3_3)
    L3_3 = A1_2
    L2_3 = L2_3 + L3_3
    L3_3 = tonumber
    L4_3 = L1_3.allocated_amount
    L3_3 = L3_3(L4_3)
    if L2_3 > L3_3 then
      L3_3 = Framework
      L3_3 = L3_3.ShowNotification
      L4_3 = L3_2
      L5_3 = "Allocation exceeds budget limit"
      L6_3 = "error"
      L3_3(L4_3, L5_3, L6_3)
      return
    end
    L3_3 = MySQL
    L3_3 = L3_3.execute
    L4_3 = "UPDATE government_budget SET spent_amount = ? WHERE id = ?"
    L5_3 = {}
    L6_3 = L2_3
    L7_3 = L1_3.id
    L5_3[1] = L6_3
    L5_3[2] = L7_3
    L3_3(L4_3, L5_3)
    L3_3 = Framework
    L3_3 = L3_3.GetFramework
    L3_3 = L3_3()
    L4_3 = A0_2
    L5_3 = L4_3
    L4_3 = L4_3.lower
    L4_3 = L4_3(L5_3)
    if "esx" == L3_3 then
      L5_3 = GetResourceState
      L6_3 = "esx_society"
      L5_3 = L5_3(L6_3)
      if "started" == L5_3 then
        L5_3 = TriggerEvent
        L6_3 = "esx_addonaccount:getSharedAccount"
        L7_3 = "society_"
        L8_3 = L4_3
        L7_3 = L7_3 .. L8_3
        function L8_3(A0_4)
          local L1_4, L2_4
          if A0_4 then
            L1_4 = A0_4.addMoney
            L2_4 = A1_2
            L1_4(L2_4)
          end
        end
        L5_3(L6_3, L7_3, L8_3)
      else
        L5_3 = MySQL
        L5_3 = L5_3.execute
        L6_3 = "INSERT INTO addon_account_data (account_name, money) VALUES (?, ?) ON DUPLICATE KEY UPDATE money = money + ?"
        L7_3 = {}
        L8_3 = "society_"
        L9_3 = L4_3
        L8_3 = L8_3 .. L9_3
        L9_3 = A1_2
        L10_3 = A1_2
        L7_3[1] = L8_3
        L7_3[2] = L9_3
        L7_3[3] = L10_3
        L5_3(L6_3, L7_3)
      end
    elseif "qbcore" == L3_3 or "qbox" == L3_3 then
      L5_3 = GetResourceState
      L6_3 = "qb-bossmenu"
      L5_3 = L5_3(L6_3)
      if "started" == L5_3 then
        L5_3 = exports
        L5_3 = L5_3["qb-bossmenu"]
        L6_3 = L5_3
        L5_3 = L5_3.AddMoney
        L7_3 = L4_3
        L8_3 = A1_2
        L5_3(L6_3, L7_3, L8_3)
      else
        L5_3 = GetResourceState
        L6_3 = "qbx_bossmenu"
        L5_3 = L5_3(L6_3)
        if "started" == L5_3 then
          L5_3 = exports
          L5_3 = L5_3.qbx_bossmenu
          L6_3 = L5_3
          L5_3 = L5_3.AddMoney
          L7_3 = L4_3
          L8_3 = A1_2
          L5_3(L6_3, L7_3, L8_3)
        else
          L5_3 = GetResourceState
          L6_3 = "qb-banking"
          L5_3 = L5_3(L6_3)
          if "started" == L5_3 then
            L5_3 = exports
            L5_3 = L5_3["qb-banking"]
            L6_3 = L5_3
            L5_3 = L5_3.AddMoney
            L7_3 = L4_3
            L8_3 = A1_2
            L9_3 = "Government Fund Allocation"
            L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
            if not L5_3 then
              L6_3 = Config
              L6_3 = L6_3.Debug
              if L6_3 then
                L6_3 = Utils
                L6_3 = L6_3.DebugError
                L7_3 = "Failed to add money to account: "
                L8_3 = L4_3
                L7_3 = L7_3 .. L8_3
                L6_3(L7_3)
              end
            end
          else
            L5_3 = MySQL
            L5_3 = L5_3.query
            L6_3 = "SELECT * FROM bank_accounts WHERE account_name = ?"
            L7_3 = {}
            L8_3 = L4_3
            L7_3[1] = L8_3
            function L8_3(A0_4)
              local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4
              L1_4 = A0_4[1]
              if L1_4 then
                L1_4 = MySQL
                L1_4 = L1_4.execute
                L2_4 = "UPDATE bank_accounts SET account_balance = account_balance + ? WHERE account_name = ?"
                L3_4 = {}
                L4_4 = A1_2
                L5_4 = L4_3
                L3_4[1] = L4_4
                L3_4[2] = L5_4
                L1_4(L2_4, L3_4)
              else
                L1_4 = MySQL
                L1_4 = L1_4.execute
                L2_4 = "INSERT INTO bank_accounts (account_name, account_balance, account_type) VALUES (?, ?, ?)"
                L3_4 = {}
                L4_4 = L4_3
                L5_4 = A1_2
                L6_4 = "business"
                L3_4[1] = L4_4
                L3_4[2] = L5_4
                L3_4[3] = L6_4
                L1_4(L2_4, L3_4)
              end
            end
            L5_3(L6_3, L7_3, L8_3)
          end
        end
      end
    end
    L5_3 = MySQL
    L5_3 = L5_3.insert
    L6_3 = "INSERT INTO government_transactions (transaction_type, amount, description, processed_by) VALUES (?, ?, ?, ?)"
    L7_3 = {}
    L8_3 = "allocation"
    L9_3 = A1_2
    L10_3 = A2_2
    L11_3 = " allocated to "
    L12_3 = A0_2
    L13_3 = " society"
    L10_3 = L10_3 .. L11_3 .. L12_3 .. L13_3
    L11_3 = L4_2.identifier
    L7_3[1] = L8_3
    L7_3[2] = L9_3
    L7_3[3] = L10_3
    L7_3[4] = L11_3
    L5_3(L6_3, L7_3)
    L5_3 = Framework
    L5_3 = L5_3.ShowNotification
    L6_3 = L3_2
    L7_3 = "Funds allocated successfully to "
    L8_3 = A0_2
    L9_3 = " society balance: "
    L10_3 = Utils
    L10_3 = L10_3.FormatMoney
    L11_3 = A1_2
    L10_3 = L10_3(L11_3)
    L7_3 = L7_3 .. L8_3 .. L9_3 .. L10_3
    L8_3 = "success"
    L5_3(L6_3, L7_3, L8_3)
  end
  L6_2(L7_2, L8_2, L9_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getFinancialReport"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L2_2.job
  L4_2 = L4_2.name
  L5_2 = L2_2.job
  L5_2 = L5_2.grade
  L6_2 = "financial_reporting"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if not L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = L1_2
    L5_2 = "You do not have permission to view financial reports"
    L6_2 = "error"
    L3_2(L4_2, L5_2, L6_2)
    return
  end
  L3_2 = ""
  if "week" == A0_2 then
    L3_2 = "WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
  elseif "month" == A0_2 then
    L3_2 = "WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)"
  elseif "year" == A0_2 then
    L3_2 = "WHERE created_at >= DATE_SUB(NOW(), INTERVAL 365 DAY)"
  end
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT transaction_type, SUM(amount) as total FROM government_transactions "
  L6_2 = L3_2
  L7_2 = " GROUP BY transaction_type"
  L5_2 = L5_2 .. L6_2 .. L7_2
  L6_2 = {}
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3
    L1_3 = 0
    L2_3 = 0
    L3_3 = 0
    L4_3 = 0
    L5_3 = ipairs
    L6_3 = A0_3
    L5_3, L6_3, L7_3, L8_3 = L5_3(L6_3)
    for L9_3, L10_3 in L5_3, L6_3, L7_3, L8_3 do
      L11_3 = L10_3.transaction_type
      if "income" == L11_3 then
        L1_3 = L10_3.total
      else
        L11_3 = L10_3.transaction_type
        if "expense" == L11_3 then
          L2_3 = L10_3.total
        else
          L11_3 = L10_3.transaction_type
          if "tax" == L11_3 then
            L3_3 = L10_3.total
          else
            L11_3 = L10_3.transaction_type
            if "subsidy" == L11_3 then
              L4_3 = L10_3.total
            end
          end
        end
      end
    end
    L5_3 = L1_3 + L3_3
    L6_3 = L2_3 + L4_3
    L7_3 = L5_3 - L6_3
    L8_3 = A0_2
    if L8_3 then
      L8_3 = A0_2
      L9_3 = L8_3
      L8_3 = L8_3.sub
      L10_3 = 1
      L11_3 = 1
      L8_3 = L8_3(L9_3, L10_3, L11_3)
      L9_3 = L8_3
      L8_3 = L8_3.upper
      L8_3 = L8_3(L9_3)
      L9_3 = A0_2
      L10_3 = L9_3
      L9_3 = L9_3.sub
      L11_3 = 2
      L9_3 = L9_3(L10_3, L11_3)
      L8_3 = L8_3 .. L9_3
      if L8_3 then
        goto lbl_55
      end
    end
    L8_3 = "All Time"
    ::lbl_55::
    L9_3 = string
    L9_3 = L9_3.format
    L10_3 = [[
Financial Report (%s):

Income:
  General: %s
  Taxes: %s
  Total: %s

Expenses:
  General: %s
  Subsidies: %s
  Total: %s

Net Balance: %s]]
    L11_3 = L8_3
    L12_3 = Utils
    L12_3 = L12_3.FormatMoney
    L13_3 = L1_3
    L12_3 = L12_3(L13_3)
    L13_3 = Utils
    L13_3 = L13_3.FormatMoney
    L14_3 = L3_3
    L13_3 = L13_3(L14_3)
    L14_3 = Utils
    L14_3 = L14_3.FormatMoney
    L15_3 = L5_3
    L14_3 = L14_3(L15_3)
    L15_3 = Utils
    L15_3 = L15_3.FormatMoney
    L16_3 = L2_3
    L15_3 = L15_3(L16_3)
    L16_3 = Utils
    L16_3 = L16_3.FormatMoney
    L17_3 = L4_3
    L16_3 = L16_3(L17_3)
    L17_3 = Utils
    L17_3 = L17_3.FormatMoney
    L18_3 = L6_3
    L17_3 = L17_3(L18_3)
    L18_3 = Utils
    L18_3 = L18_3.FormatMoney
    L19_3 = L7_3
    L18_3, L19_3 = L18_3(L19_3)
    L9_3 = L9_3(L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3)
    L10_3 = Framework
    L10_3 = L10_3.ShowNotification
    L11_3 = L1_2
    L12_3 = L9_3
    L13_3 = "primary"
    L10_3(L11_3, L12_3, L13_3)
  end
  L4_2(L5_2, L6_2, L7_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:createInvestment"
function L2_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L4_2 = source
  L5_2 = Framework
  L5_2 = L5_2.GetPlayerData
  L6_2 = L4_2
  L5_2 = L5_2(L6_2)
  if not L5_2 then
    return
  end
  L6_2 = Utils
  L6_2 = L6_2.HasPermission
  L7_2 = L5_2.job
  L7_2 = L7_2.name
  L8_2 = L5_2.job
  L8_2 = L8_2.grade
  L9_2 = "investment_management"
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  if not L6_2 then
    L6_2 = Framework
    L6_2 = L6_2.ShowNotification
    L7_2 = L4_2
    L8_2 = "You do not have permission to create investments"
    L9_2 = "error"
    L6_2(L7_2, L8_2, L9_2)
    return
  end
  L6_2 = MySQL
  L6_2 = L6_2.insert
  L7_2 = "INSERT INTO government_investments (investment_type, amount, expected_return, duration_days, created_by, status) VALUES (?, ?, ?, ?, ?, ?)"
  L8_2 = {}
  L9_2 = A0_2
  L10_2 = A1_2
  L11_2 = A2_2
  L12_2 = A3_2
  L13_2 = L5_2.identifier
  L14_2 = "active"
  L8_2[1] = L9_2
  L8_2[2] = L10_2
  L8_2[3] = L11_2
  L8_2[4] = L12_2
  L8_2[5] = L13_2
  L8_2[6] = L14_2
  function L9_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = MySQL
    L1_3 = L1_3.insert
    L2_3 = "INSERT INTO government_transactions (transaction_type, amount, description, processed_by) VALUES (?, ?, ?, ?)"
    L3_3 = {}
    L4_3 = "expense"
    L5_3 = A1_2
    L6_3 = "Investment in "
    L7_3 = A0_2
    L6_3 = L6_3 .. L7_3
    L7_3 = L5_2.identifier
    L3_3[1] = L4_3
    L3_3[2] = L5_3
    L3_3[3] = L6_3
    L3_3[4] = L7_3
    L1_3(L2_3, L3_3)
    L1_3 = Framework
    L1_3 = L1_3.ShowNotification
    L2_3 = L4_2
    L3_3 = "Investment created successfully. ID: "
    L4_3 = A0_3
    L3_3 = L3_3 .. L4_3
    L4_3 = "success"
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = CreateThread
    function L2_3()
      local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4
      L0_4 = Wait
      L1_4 = A3_2
      L1_4 = L1_4 * 24
      L1_4 = L1_4 * 60
      L1_4 = L1_4 * 60
      L1_4 = L1_4 * 1000
      L0_4(L1_4)
      L0_4 = A1_2
      L1_4 = A1_2
      L2_4 = A2_2
      L2_4 = L2_4 / 100
      L1_4 = L1_4 * L2_4
      L0_4 = L0_4 + L1_4
      L1_4 = MySQL
      L1_4 = L1_4.execute
      L2_4 = "UPDATE government_investments SET status = ?, actual_return = ? WHERE id = ?"
      L3_4 = {}
      L4_4 = "matured"
      L5_4 = L0_4
      L6_4 = A0_3
      L3_4[1] = L4_4
      L3_4[2] = L5_4
      L3_4[3] = L6_4
      L1_4(L2_4, L3_4)
      L1_4 = MySQL
      L1_4 = L1_4.insert
      L2_4 = "INSERT INTO government_transactions (transaction_type, amount, description, processed_by) VALUES (?, ?, ?, ?)"
      L3_4 = {}
      L4_4 = "income"
      L5_4 = L0_4
      L6_4 = "Investment return from "
      L7_4 = A0_2
      L6_4 = L6_4 .. L7_4
      L7_4 = "system"
      L3_4[1] = L4_4
      L3_4[2] = L5_4
      L3_4[3] = L6_4
      L3_4[4] = L7_4
      L1_4(L2_4, L3_4)
    end
    L1_3(L2_3)
  end
  L6_2(L7_2, L8_2, L9_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getActiveAudits"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "business_audit"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view audits"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_audits WHERE status = ? ORDER BY created_at DESC"
  L4_2 = {}
  L5_2 = "in_progress"
  L4_2[1] = L5_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = L6_3.initiated_by
      if L7_3 then
        L7_3 = Framework
        L7_3 = L7_3.GetPlayerNameFromIdentifier
        L8_3 = L6_3.initiated_by
        L7_3 = L7_3(L8_3)
        if L7_3 then
          L6_3.initiated_by_name = L7_3
        else
          L6_3.initiated_by_name = "Unknown Officer"
        end
      else
        L6_3.initiated_by_name = "System"
      end
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showActiveAudits"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getAuditHistory"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "business_audit"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view audit history"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_audits ORDER BY created_at DESC LIMIT 50"
  L4_2 = {}
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = L6_3.initiated_by
      if L7_3 then
        L7_3 = Framework
        L7_3 = L7_3.GetPlayerNameFromIdentifier
        L8_3 = L6_3.initiated_by
        L7_3 = L7_3(L8_3)
        if L7_3 then
          L6_3.initiated_by_name = L7_3
        else
          L6_3.initiated_by_name = "Unknown Officer"
        end
      else
        L6_3.initiated_by_name = "System"
      end
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showAuditHistory"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:completeAudit"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  if not L4_2 then
    return
  end
  L5_2 = Utils
  L5_2 = L5_2.HasPermission
  L6_2 = L4_2.job
  L6_2 = L6_2.name
  L7_2 = L4_2.job
  L7_2 = L7_2.grade
  L8_2 = "business_audit"
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  if not L5_2 then
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L3_2
    L7_2 = "You do not have permission to complete audits"
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
    return
  end
  if not A2_2 then
    A2_2 = "completed"
  end
  L5_2 = MySQL
  L5_2 = L5_2.execute
  L6_2 = "UPDATE government_audits SET status = ?, findings = ?, completed_by = ?, completed_at = ? WHERE id = ?"
  L7_2 = {}
  L8_2 = A2_2
  L9_2 = A1_2
  L10_2 = L4_2.identifier
  L11_2 = os
  L11_2 = L11_2.date
  L12_2 = "%Y-%m-%d %H:%M:%S"
  L11_2 = L11_2(L12_2)
  L12_2 = A0_2
  L7_2[1] = L8_2
  L7_2[2] = L9_2
  L7_2[3] = L10_2
  L7_2[4] = L11_2
  L7_2[5] = L12_2
  L5_2(L6_2, L7_2)
  L5_2 = Framework
  L5_2 = L5_2.ShowNotification
  L6_2 = L3_2
  L7_2 = "Audit #"
  L8_2 = A0_2
  L9_2 = " has been "
  L10_2 = A2_2
  L7_2 = L7_2 .. L8_2 .. L9_2 .. L10_2
  L8_2 = "success"
  L5_2(L6_2, L7_2, L8_2)
  L5_2 = MySQL
  L5_2 = L5_2.insert
  L6_2 = "INSERT INTO government_transactions (transaction_type, amount, description, processed_by) VALUES (?, ?, ?, ?)"
  L7_2 = {}
  L8_2 = "expense"
  L9_2 = 0
  L10_2 = "Business audit completed (ID: "
  L11_2 = A0_2
  L12_2 = ") - Status: "
  L13_2 = A2_2
  L10_2 = L10_2 .. L11_2 .. L12_2 .. L13_2
  L11_2 = L4_2.identifier
  L7_2[1] = L8_2
  L7_2[2] = L9_2
  L7_2[3] = L10_2
  L7_2[4] = L11_2
  L5_2(L6_2, L7_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:searchBusinesses"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L2_2.job
  L4_2 = L4_2.name
  L5_2 = L2_2.job
  L5_2 = L5_2.grade
  L6_2 = "business_audit"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if not L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = L1_2
    L5_2 = "You do not have permission to search businesses"
    L6_2 = "error"
    L3_2(L4_2, L5_2, L6_2)
    return
  end
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT * FROM government_businesses WHERE business_name LIKE ? OR owner_name LIKE ? OR license_number LIKE ? ORDER BY created_at DESC LIMIT 20"
  L5_2 = {}
  L6_2 = "%"
  L7_2 = A0_2
  L8_2 = "%"
  L6_2 = L6_2 .. L7_2 .. L8_2
  L7_2 = "%"
  L8_2 = A0_2
  L9_2 = "%"
  L7_2 = L7_2 .. L8_2 .. L9_2
  L8_2 = "%"
  L9_2 = A0_2
  L10_2 = "%"
  L8_2 = L8_2 .. L9_2 .. L10_2
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  L5_2[3] = L8_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showBusinessSearch"
    L3_3 = L1_2
    L4_3 = A0_3
    L5_3 = A0_2
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L3_2(L4_2, L5_2, L6_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getAllBusinesses"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "business_audit"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view businesses"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SHOW TABLES LIKE \"government_businesses\""
  L4_2 = {}
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = Utils
    L1_3 = L1_3.DebugPrint
    L2_3 = "Table exists check returned: "
    L3_3 = #A0_3
    L4_3 = " results"
    L2_3 = L2_3 .. L3_3 .. L4_3
    L1_3(L2_3)
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L0_2
      L3_3 = "Business table does not exist. Please check database setup."
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = MySQL
    L1_3 = L1_3.query
    L2_3 = "SELECT * FROM government_businesses ORDER BY created_at DESC LIMIT 50"
    L3_3 = {}
    function L4_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4
      if A1_4 then
        L2_4 = Utils
        L2_4 = L2_4.DebugError
        L3_4 = "Database error in getAllBusinesses: "
        L4_4 = tostring
        L5_4 = A1_4
        L4_4 = L4_4(L5_4)
        L3_4 = L3_4 .. L4_4
        L2_4(L3_4)
        L2_4 = Framework
        L2_4 = L2_4.ShowNotification
        L3_4 = L0_2
        L4_4 = "Database error occurred. Check server console."
        L5_4 = "error"
        L2_4(L3_4, L4_4, L5_4)
        return
      end
      L2_4 = Utils
      L2_4 = L2_4.DebugPrint
      L3_4 = "getAllBusinesses query returned "
      L4_4 = #A0_4
      L5_4 = " businesses"
      L3_4 = L3_4 .. L4_4 .. L5_4
      L2_4(L3_4)
      L2_4 = #A0_4
      if L2_4 > 0 then
        L2_4 = Utils
        L2_4 = L2_4.DebugPrint
        L3_4 = "First business: "
        L4_4 = json
        L4_4 = L4_4.encode
        L5_4 = A0_4[1]
        L4_4 = L4_4(L5_4)
        L3_4 = L3_4 .. L4_4
        L2_4(L3_4)
      else
        L2_4 = Utils
        L2_4 = L2_4.DebugPrint
        L3_4 = "No businesses found in database"
        L2_4(L3_4)
      end
      L2_4 = TriggerClientEvent
      L3_4 = "fs-government:client:showAllBusinesses"
      L4_4 = L0_2
      L5_4 = A0_4
      L2_4(L3_4, L4_4, L5_4)
    end
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterCommand
L1_1 = "fixbusinesstypes"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  if 0 == A0_2 then
    L3_2 = MySQL
    L3_2 = L3_2.query
    L4_2 = "SELECT id, business_name, business_type FROM government_businesses WHERE business_type = ? OR business_type IS NULL"
    L5_2 = {}
    L6_2 = "unspecified"
    L5_2[1] = L6_2
    function L6_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
      L1_3 = #A0_3
      if 0 == L1_3 then
        L1_3 = Utils
        L1_3 = L1_3.DebugSuccess
        L2_3 = "No businesses with unspecified type found."
        L1_3(L2_3)
        return
      end
      L1_3 = Utils
      L1_3 = L1_3.DebugPrint
      L2_3 = "Found "
      L3_3 = #A0_3
      L4_3 = " businesses with unspecified type:"
      L2_3 = L2_3 .. L3_3 .. L4_3
      L1_3(L2_3)
      L1_3 = ipairs
      L2_3 = A0_3
      L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
      for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "  ID: "
        L9_3 = L6_3.id
        L10_3 = " | Name: "
        L11_3 = L6_3.business_name
        L12_3 = " | Type: "
        L13_3 = L6_3.business_type
        if not L13_3 then
          L13_3 = "NULL"
        end
        L8_3 = L8_3 .. L9_3 .. L10_3 .. L11_3 .. L12_3 .. L13_3
        L7_3(L8_3)
      end
      L1_3 = MySQL
      L1_3 = L1_3.execute
      L2_3 = "UPDATE government_businesses SET business_type = ? WHERE business_type = ? OR business_type IS NULL"
      L3_3 = {}
      L4_3 = "other"
      L5_3 = "unspecified"
      L3_3[1] = L4_3
      L3_3[2] = L5_3
      function L4_3(A0_4)
        local L1_4, L2_4, L3_4, L4_4
        L1_4 = Utils
        L1_4 = L1_4.DebugSuccess
        L2_4 = "Updated "
        L3_4 = A0_4
        L4_4 = " businesses to \"other\" type. You can manually change specific ones using: changebusinesstype <id> <type>"
        L2_4 = L2_4 .. L3_4 .. L4_4
        L1_4(L2_4)
      end
      L1_3(L2_3, L3_3, L4_3)
    end
    L3_2(L4_2, L5_2, L6_2)
  else
    L3_2 = Utils
    L3_2 = L3_2.DebugError
    L4_2 = "This command can only be run from the server console."
    L3_2(L4_2)
  end
end
L3_1 = false
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterCommand
L1_1 = "changebusinesstype"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  if 0 == A0_2 then
    L3_2 = tonumber
    L4_2 = A1_2[1]
    L3_2 = L3_2(L4_2)
    L4_2 = A1_2[2]
    if not L3_2 or not L4_2 then
      L5_2 = Utils
      L5_2 = L5_2.DebugError
      L6_2 = "Usage: changebusinesstype <business_id> <type>"
      L5_2(L6_2)
      L5_2 = Utils
      L5_2 = L5_2.DebugPrint
      L6_2 = "Available types: restaurant, retail, service, manufacturing, technology, other"
      L5_2(L6_2)
      return
    end
    L5_2 = {}
    L6_2 = "restaurant"
    L7_2 = "retail"
    L8_2 = "service"
    L9_2 = "manufacturing"
    L10_2 = "technology"
    L11_2 = "other"
    L5_2[1] = L6_2
    L5_2[2] = L7_2
    L5_2[3] = L8_2
    L5_2[4] = L9_2
    L5_2[5] = L10_2
    L5_2[6] = L11_2
    L6_2 = false
    L7_2 = ipairs
    L8_2 = L5_2
    L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
    for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
      if L4_2 == L12_2 then
        L6_2 = true
        break
      end
    end
    if not L6_2 then
      L7_2 = Utils
      L7_2 = L7_2.DebugError
      L8_2 = "Invalid business type. Available types: restaurant, retail, service, manufacturing, technology, other"
      L7_2(L8_2)
      return
    end
    L7_2 = MySQL
    L7_2 = L7_2.execute
    L8_2 = "UPDATE government_businesses SET business_type = ? WHERE id = ?"
    L9_2 = {}
    L10_2 = L4_2
    L11_2 = L3_2
    L9_2[1] = L10_2
    L9_2[2] = L11_2
    function L10_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
      if A0_3 then
        L1_3 = type
        L2_3 = A0_3
        L1_3 = L1_3(L2_3)
        if "table" == L1_3 then
          L1_3 = A0_3.affectedRows
          if not L1_3 then
            L1_3 = A0_3.changedRows
            if not L1_3 then
              L1_3 = 0
            end
          end
          L2_3 = tonumber
          L3_3 = L1_3
          L2_3 = L2_3(L3_3)
          if L2_3 then
            L2_3 = tonumber
            L3_3 = L1_3
            L2_3 = L2_3(L3_3)
            if L2_3 > 0 then
              L2_3 = Utils
              L2_3 = L2_3.DebugSuccess
              L3_3 = "Successfully updated business ID "
              L4_3 = L3_2
              L5_3 = " to type \""
              L6_3 = L4_2
              L7_3 = "\""
              L3_3 = L3_3 .. L4_3 .. L5_3 .. L6_3 .. L7_3
              L2_3(L3_3)
          end
          else
            L2_3 = Utils
            L2_3 = L2_3.DebugError
            L3_3 = "No business found with ID "
            L4_3 = L3_2
            L5_3 = " or update failed"
            L3_3 = L3_3 .. L4_3 .. L5_3
            L2_3(L3_3)
          end
      end
      else
        L1_3 = Utils
        L1_3 = L1_3.DebugWarn
        L2_3 = "Update completed, but could not verify result"
        L1_3(L2_3)
      end
    end
    L7_2(L8_2, L9_2, L10_2)
  else
    L3_2 = Utils
    L3_2 = L3_2.DebugError
    L4_2 = "This command can only be run from the server console."
    L3_2(L4_2)
  end
end
L3_1 = false
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterCommand
L1_1 = "changebusinessstatus"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  if 0 == A0_2 then
    L3_2 = tonumber
    L4_2 = A1_2[1]
    L3_2 = L3_2(L4_2)
    L4_2 = A1_2[2]
    if not L3_2 or not L4_2 then
      L5_2 = Utils
      L5_2 = L5_2.DebugError
      L6_2 = "Usage: changebusinessstatus <business_id> <status>"
      L5_2(L6_2)
      L5_2 = Utils
      L5_2 = L5_2.DebugPrint
      L6_2 = "Available statuses: active, suspended, closed"
      L5_2(L6_2)
      return
    end
    L5_2 = {}
    L6_2 = "active"
    L7_2 = "suspended"
    L8_2 = "closed"
    L5_2[1] = L6_2
    L5_2[2] = L7_2
    L5_2[3] = L8_2
    L6_2 = false
    L7_2 = ipairs
    L8_2 = L5_2
    L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
    for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
      if L4_2 == L12_2 then
        L6_2 = true
        break
      end
    end
    if not L6_2 then
      L7_2 = Utils
      L7_2 = L7_2.DebugError
      L8_2 = "Invalid business status. Available statuses: active, suspended, closed"
      L7_2(L8_2)
      return
    end
    L7_2 = MySQL
    L7_2 = L7_2.execute
    L8_2 = "UPDATE government_businesses SET status = ?, updated_at = ? WHERE id = ?"
    L9_2 = {}
    L10_2 = L4_2
    L11_2 = os
    L11_2 = L11_2.date
    L12_2 = "%Y-%m-%d %H:%M:%S"
    L11_2 = L11_2(L12_2)
    L12_2 = L3_2
    L9_2[1] = L10_2
    L9_2[2] = L11_2
    L9_2[3] = L12_2
    function L10_2(A0_3, A1_3)
      local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
      if A1_3 then
        L2_3 = Utils
        L2_3 = L2_3.DebugError
        L3_3 = "MySQL error updating business status: "
        L4_3 = tostring
        L5_3 = A1_3
        L4_3 = L4_3(L5_3)
        L3_3 = L3_3 .. L4_3
        L2_3(L3_3)
        return
      end
      if A0_3 then
        L2_3 = type
        L3_3 = A0_3
        L2_3 = L2_3(L3_3)
        if "table" == L2_3 then
          L2_3 = A0_3.affectedRows
          if not L2_3 then
            L2_3 = A0_3.changedRows
            if not L2_3 then
              L2_3 = 0
            end
          end
          L3_3 = Utils
          L3_3 = L3_3.DebugPrint
          L4_3 = "MySQL result: "
          L5_3 = json
          L5_3 = L5_3.encode
          L6_3 = A0_3
          L5_3 = L5_3(L6_3)
          L4_3 = L4_3 .. L5_3
          L3_3(L4_3)
          L3_3 = tonumber
          L4_3 = L2_3
          L3_3 = L3_3(L4_3)
          if L3_3 then
            L3_3 = tonumber
            L4_3 = L2_3
            L3_3 = L3_3(L4_3)
            if L3_3 > 0 then
              L3_3 = Utils
              L3_3 = L3_3.DebugSuccess
              L4_3 = "Successfully updated business ID "
              L5_3 = L3_2
              L6_3 = " to status \""
              L7_3 = L4_2
              L8_3 = "\""
              L4_3 = L4_3 .. L5_3 .. L6_3 .. L7_3 .. L8_3
              L3_3(L4_3)
              L3_3 = MySQL
              L3_3 = L3_3.query
              L4_3 = "SELECT id, business_name, status FROM government_businesses WHERE id = ?"
              L5_3 = {}
              L6_3 = L3_2
              L5_3[1] = L6_3
              function L6_3(A0_4)
                local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4
                if A0_4 then
                  L1_4 = #A0_4
                  if L1_4 > 0 then
                    L1_4 = Utils
                    L1_4 = L1_4.DebugPrint
                    L2_4 = "Business ID "
                    L3_4 = L3_2
                    L4_4 = " now has status: \""
                    L5_4 = tostring
                    L6_4 = A0_4[1]
                    L6_4 = L6_4.status
                    L5_4 = L5_4(L6_4)
                    L6_4 = "\""
                    L2_4 = L2_4 .. L3_4 .. L4_4 .. L5_4 .. L6_4
                    L1_4(L2_4)
                  end
                end
              end
              L3_3(L4_3, L5_3, L6_3)
          end
          else
            L3_3 = Utils
            L3_3 = L3_3.DebugError
            L4_3 = "No business found with ID "
            L5_3 = L3_2
            L6_3 = " or update failed (affected rows: "
            L7_3 = tostring
            L8_3 = L2_3
            L7_3 = L7_3(L8_3)
            L8_3 = ")"
            L4_3 = L4_3 .. L5_3 .. L6_3 .. L7_3 .. L8_3
            L3_3(L4_3)
          end
      end
      else
        L2_3 = Utils
        L2_3 = L2_3.DebugError
        L3_3 = "Unexpected result type: "
        L4_3 = type
        L5_3 = A0_3
        L4_3 = L4_3(L5_3)
        L5_3 = " - "
        L6_3 = tostring
        L7_3 = A0_3
        L6_3 = L6_3(L7_3)
        L3_3 = L3_3 .. L4_3 .. L5_3 .. L6_3
        L2_3(L3_3)
      end
    end
    L7_2(L8_2, L9_2, L10_2)
  else
    L3_2 = Utils
    L3_2 = L3_2.DebugError
    L4_2 = "This command can only be run from the server console."
    L3_2(L4_2)
  end
end
L3_1 = false
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterCommand
L1_1 = "forcebusinessstatus"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  if 0 == A0_2 then
    L3_2 = tonumber
    L4_2 = A1_2[1]
    L3_2 = L3_2(L4_2)
    L4_2 = A1_2[2]
    if not L3_2 or not L4_2 then
      L5_2 = Utils
      L5_2 = L5_2.DebugError
      L6_2 = "Usage: forcebusinessstatus <business_id> <status>"
      L5_2(L6_2)
      L5_2 = Utils
      L5_2 = L5_2.DebugPrint
      L6_2 = "Available statuses: active, suspended, closed"
      L5_2(L6_2)
      return
    end
    L5_2 = Utils
    L5_2 = L5_2.DebugPrint
    L6_2 = "Force updating business ID "
    L7_2 = L3_2
    L8_2 = " to status \""
    L9_2 = L4_2
    L10_2 = "\""
    L6_2 = L6_2 .. L7_2 .. L8_2 .. L9_2 .. L10_2
    L5_2(L6_2)
    L5_2 = MySQL
    L5_2 = L5_2.execute
    L6_2 = "UPDATE government_businesses SET status = ? WHERE id = ?"
    L7_2 = {}
    L8_2 = L4_2
    L9_2 = L3_2
    L7_2[1] = L8_2
    L7_2[2] = L9_2
    function L8_2(A0_3, A1_3)
      local L2_3, L3_3, L4_3, L5_3
      if A1_3 then
        L2_3 = Utils
        L2_3 = L2_3.DebugError
        L3_3 = "MySQL error: "
        L4_3 = tostring
        L5_3 = A1_3
        L4_3 = L4_3(L5_3)
        L3_3 = L3_3 .. L4_3
        L2_3(L3_3)
        return
      end
      L2_3 = Utils
      L2_3 = L2_3.DebugPrint
      L3_3 = "Raw MySQL result: "
      L4_3 = json
      L4_3 = L4_3.encode
      L5_3 = A0_3
      L4_3 = L4_3(L5_3)
      L3_3 = L3_3 .. L4_3
      L2_3(L3_3)
      L2_3 = MySQL
      L2_3 = L2_3.query
      L3_3 = "SELECT id, business_name, status FROM government_businesses WHERE id = ?"
      L4_3 = {}
      L5_3 = L3_2
      L4_3[1] = L5_3
      function L5_3(A0_4)
        local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4
        if A0_4 then
          L1_4 = #A0_4
          if L1_4 > 0 then
            L1_4 = Utils
            L1_4 = L1_4.DebugSuccess
            L2_4 = "Verified - Business ID "
            L3_4 = L3_2
            L4_4 = " status is now: \""
            L5_4 = tostring
            L6_4 = A0_4[1]
            L6_4 = L6_4.status
            L5_4 = L5_4(L6_4)
            L6_4 = "\""
            L2_4 = L2_4 .. L3_4 .. L4_4 .. L5_4 .. L6_4
            L1_4(L2_4)
        end
        else
          L1_4 = Utils
          L1_4 = L1_4.DebugError
          L2_4 = "Verification failed - could not find business ID "
          L3_4 = L3_2
          L2_4 = L2_4 .. L3_4
          L1_4(L2_4)
        end
      end
      L2_3(L3_3, L4_3, L5_3)
    end
    L5_2(L6_2, L7_2, L8_2)
  else
    L3_2 = Utils
    L3_2 = L3_2.DebugError
    L4_2 = "This command can only be run from the server console."
    L3_2(L4_2)
  end
end
L3_1 = false
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterCommand
L1_1 = "fixbusinessstatus"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  if 0 == A0_2 then
    L3_2 = A1_2[1]
    L4_2 = "active"
    if L3_2 and ("active" == L3_2 or "suspended" == L3_2 or "closed" == L3_2) then
      L4_2 = L3_2
      L5_2 = Utils
      L5_2 = L5_2.DebugPrint
      L6_2 = "Will set businesses to status: "
      L7_2 = L4_2
      L6_2 = L6_2 .. L7_2
      L5_2(L6_2)
    else
      L5_2 = Utils
      L5_2 = L5_2.DebugPrint
      L6_2 = "Will set businesses to default status: "
      L7_2 = L4_2
      L8_2 = " (use: fixbusinessstatus <active|suspended|closed> to specify)"
      L6_2 = L6_2 .. L7_2 .. L8_2
      L5_2(L6_2)
    end
    L5_2 = MySQL
    L5_2 = L5_2.query
    L6_2 = "SELECT id, business_name, status FROM government_businesses WHERE status = \"\" OR status IS NULL"
    L7_2 = {}
    function L8_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
      L1_3 = #A0_3
      if 0 == L1_3 then
        L1_3 = Utils
        L1_3 = L1_3.DebugSuccess
        L2_3 = "No businesses with empty status found."
        L1_3(L2_3)
        return
      end
      L1_3 = Utils
      L1_3 = L1_3.DebugPrint
      L2_3 = "Found "
      L3_3 = #A0_3
      L4_3 = " businesses with empty status:"
      L2_3 = L2_3 .. L3_3 .. L4_3
      L1_3(L2_3)
      L1_3 = ipairs
      L2_3 = A0_3
      L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
      for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "  ID: "
        L9_3 = L6_3.id
        L10_3 = " | Name: "
        L11_3 = L6_3.business_name
        L12_3 = " | Status: \""
        L13_3 = L6_3.status
        if not L13_3 then
          L13_3 = "NULL"
        end
        L14_3 = "\""
        L8_3 = L8_3 .. L9_3 .. L10_3 .. L11_3 .. L12_3 .. L13_3 .. L14_3
        L7_3(L8_3)
      end
      L1_3 = MySQL
      L1_3 = L1_3.execute
      L2_3 = "UPDATE government_businesses SET status = ? WHERE status = \"\" OR status IS NULL"
      L3_3 = {}
      L4_3 = L4_2
      L3_3[1] = L4_3
      function L4_3(A0_4)
        local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4
        if A0_4 then
          L1_4 = type
          L2_4 = A0_4
          L1_4 = L1_4(L2_4)
          if "table" == L1_4 then
            L1_4 = A0_4.affectedRows
            if not L1_4 then
              L1_4 = A0_4.changedRows
              if not L1_4 then
                L1_4 = 0
              end
            end
            L2_4 = Utils
            L2_4 = L2_4.DebugSuccess
            L3_4 = "Updated "
            L4_4 = tostring
            L5_4 = L1_4
            L4_4 = L4_4(L5_4)
            L5_4 = " businesses to \""
            L6_4 = L4_2
            L7_4 = "\" status."
            L3_4 = L3_4 .. L4_4 .. L5_4 .. L6_4 .. L7_4
            L2_4(L3_4)
            L2_4 = Config
            L2_4 = L2_4.Debug
            if L2_4 then
              L2_4 = Utils
              L2_4 = L2_4.DebugPrint
              L3_4 = "MySQL result: "
              L4_4 = json
              L4_4 = L4_4.encode
              L5_4 = A0_4
              L4_4 = L4_4(L5_4)
              L3_4 = L3_4 .. L4_4
              L2_4(L3_4)
            end
        end
        else
          L1_4 = Utils
          L1_4 = L1_4.DebugSuccess
          L2_4 = "Update completed (result type: "
          L3_4 = type
          L4_4 = A0_4
          L3_4 = L3_4(L4_4)
          L4_4 = ")"
          L2_4 = L2_4 .. L3_4 .. L4_4
          L1_4(L2_4)
          L1_4 = Config
          L1_4 = L1_4.Debug
          if L1_4 then
            L1_4 = Utils
            L1_4 = L1_4.DebugPrint
            L2_4 = "MySQL result: "
            L3_4 = tostring
            L4_4 = A0_4
            L3_4 = L3_4(L4_4)
            L2_4 = L2_4 .. L3_4
            L1_4(L2_4)
          end
        end
      end
      L1_3(L2_3, L3_3, L4_3)
    end
    L5_2(L6_2, L7_2, L8_2)
  else
    L3_2 = Utils
    L3_2 = L3_2.DebugError
    L4_2 = "This command can only be run from the server console."
    L3_2(L4_2)
  end
end
L3_1 = false
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterCommand
L1_1 = "listbusinesses"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  if 0 == A0_2 then
    L3_2 = MySQL
    L3_2 = L3_2.query
    L4_2 = "SELECT id, business_name, owner_name, status, license_number FROM government_businesses ORDER BY id"
    L5_2 = {}
    function L6_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3
      L1_3 = #A0_3
      if 0 == L1_3 then
        L1_3 = Utils
        L1_3 = L1_3.DebugSuccess
        L2_3 = "No businesses found in database."
        L1_3(L2_3)
        return
      end
      L1_3 = Utils
      L1_3 = L1_3.DebugPrint
      L2_3 = "All businesses in database:"
      L1_3(L2_3)
      L1_3 = Utils
      L1_3 = L1_3.DebugPrint
      L2_3 = "----------------------------------------"
      L1_3(L2_3)
      L1_3 = ipairs
      L2_3 = A0_3
      L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
      for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
        L7_3 = L6_3.status
        if "" == L7_3 then
          L7_3 = "EMPTY"
          if L7_3 then
            goto lbl_31
          end
        end
        L7_3 = L6_3.status
        if not L7_3 then
          L7_3 = "NULL"
        end
        ::lbl_31::
        L8_3 = Utils
        L8_3 = L8_3.DebugPrint
        L9_3 = "ID: "
        L10_3 = L6_3.id
        L11_3 = " | Name: "
        L12_3 = L6_3.business_name
        L13_3 = " | Owner: "
        L14_3 = L6_3.owner_name
        L15_3 = " | Status: \""
        L16_3 = L7_3
        L17_3 = "\" | License: "
        L18_3 = L6_3.license_number
        L9_3 = L9_3 .. L10_3 .. L11_3 .. L12_3 .. L13_3 .. L14_3 .. L15_3 .. L16_3 .. L17_3 .. L18_3
        L8_3(L9_3)
      end
      L1_3 = Utils
      L1_3 = L1_3.DebugPrint
      L2_3 = "----------------------------------------"
      L1_3(L2_3)
      L1_3 = Utils
      L1_3 = L1_3.DebugSuccess
      L2_3 = "Total: "
      L3_3 = #A0_3
      L4_3 = " businesses"
      L2_3 = L2_3 .. L3_3 .. L4_3
      L1_3(L2_3)
    end
    L3_2(L4_2, L5_2, L6_2)
  else
    L3_2 = Utils
    L3_2 = L3_2.DebugError
    L4_2 = "This command can only be run from the server console."
    L3_2(L4_2)
  end
end
L3_1 = false
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterCommand
L1_1 = "checkbusiness"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  if 0 == A0_2 then
    L3_2 = tonumber
    L4_2 = A1_2[1]
    L3_2 = L3_2(L4_2)
    if not L3_2 then
      L4_2 = Utils
      L4_2 = L4_2.DebugError
      L5_2 = "Usage: checkbusiness <business_id>"
      L4_2(L5_2)
      return
    end
    L4_2 = MySQL
    L4_2 = L4_2.query
    L5_2 = "SELECT id, business_name, owner_name, status FROM government_businesses WHERE id = ?"
    L6_2 = {}
    L7_2 = L3_2
    L6_2[1] = L7_2
    function L7_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
      L1_3 = #A0_3
      if 0 == L1_3 then
        L1_3 = Utils
        L1_3 = L1_3.DebugError
        L2_3 = "No business found with ID: "
        L3_3 = L3_2
        L2_3 = L2_3 .. L3_3
        L1_3(L2_3)
        return
      end
      L1_3 = A0_3[1]
      L2_3 = Utils
      L2_3 = L2_3.DebugPrint
      L3_3 = "Business Details for ID "
      L4_3 = L3_2
      L5_3 = ":"
      L3_3 = L3_3 .. L4_3 .. L5_3
      L2_3(L3_3)
      L2_3 = Utils
      L2_3 = L2_3.DebugPrint
      L3_3 = "  Name: "
      L4_3 = L1_3.business_name
      L3_3 = L3_3 .. L4_3
      L2_3(L3_3)
      L2_3 = Utils
      L2_3 = L2_3.DebugPrint
      L3_3 = "  Owner: "
      L4_3 = L1_3.owner_name
      L3_3 = L3_3 .. L4_3
      L2_3(L3_3)
      L2_3 = Utils
      L2_3 = L2_3.DebugPrint
      L3_3 = "  Status: \""
      L4_3 = tostring
      L5_3 = L1_3.status
      L4_3 = L4_3(L5_3)
      L5_3 = "\""
      L3_3 = L3_3 .. L4_3 .. L5_3
      L2_3(L3_3)
      L2_3 = Utils
      L2_3 = L2_3.DebugPrint
      L3_3 = "  Status Length: "
      L4_3 = string
      L4_3 = L4_3.len
      L5_3 = tostring
      L6_3 = L1_3.status
      L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3 = L5_3(L6_3)
      L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
      L3_3 = L3_3 .. L4_3
      L2_3(L3_3)
      L2_3 = Utils
      L2_3 = L2_3.DebugPrint
      L3_3 = "  Status Type: "
      L4_3 = type
      L5_3 = L1_3.status
      L4_3 = L4_3(L5_3)
      L3_3 = L3_3 .. L4_3
      L2_3(L3_3)
      L2_3 = {}
      L3_3 = 1
      L4_3 = tostring
      L5_3 = L1_3.status
      L4_3 = L4_3(L5_3)
      L4_3 = #L4_3
      L5_3 = 1
      for L6_3 = L3_3, L4_3, L5_3 do
        L7_3 = table
        L7_3 = L7_3.insert
        L8_3 = L2_3
        L9_3 = string
        L9_3 = L9_3.byte
        L10_3 = L1_3.status
        L11_3 = L6_3
        L9_3, L10_3, L11_3 = L9_3(L10_3, L11_3)
        L7_3(L8_3, L9_3, L10_3, L11_3)
      end
      L3_3 = Utils
      L3_3 = L3_3.DebugPrint
      L4_3 = "  Status Bytes: ["
      L5_3 = table
      L5_3 = L5_3.concat
      L6_3 = L2_3
      L7_3 = ", "
      L5_3 = L5_3(L6_3, L7_3)
      L6_3 = "]"
      L4_3 = L4_3 .. L5_3 .. L6_3
      L3_3(L4_3)
    end
    L4_2(L5_2, L6_2, L7_2)
  else
    L3_2 = Utils
    L3_2 = L3_2.DebugError
    L4_2 = "This command can only be run from the server console."
    L3_2(L4_2)
  end
end
L3_1 = false
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterCommand
L1_1 = "fixstatuscolumn"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  if 0 == A0_2 then
    L3_2 = Utils
    L3_2 = L3_2.DebugPrint
    L4_2 = "Checking status column definition..."
    L3_2(L4_2)
    L3_2 = MySQL
    L3_2 = L3_2.query
    L4_2 = "DESCRIBE government_businesses status"
    L5_2 = {}
    function L6_2(A0_3, A1_3)
      local L2_3, L3_3, L4_3, L5_3
      if A1_3 then
        L2_3 = Utils
        L2_3 = L2_3.DebugError
        L3_3 = "Error checking column: "
        L4_3 = tostring
        L5_3 = A1_3
        L4_3 = L4_3(L5_3)
        L3_3 = L3_3 .. L4_3
        L2_3(L3_3)
        return
      end
      if A0_3 then
        L2_3 = #A0_3
        if L2_3 > 0 then
          L2_3 = Utils
          L2_3 = L2_3.DebugPrint
          L3_3 = "Current status column definition:"
          L2_3(L3_3)
          L2_3 = Utils
          L2_3 = L2_3.DebugPrint
          L3_3 = "  Type: "
          L4_3 = tostring
          L5_3 = A0_3[1]
          L5_3 = L5_3.Type
          L4_3 = L4_3(L5_3)
          L3_3 = L3_3 .. L4_3
          L2_3(L3_3)
          L2_3 = Utils
          L2_3 = L2_3.DebugPrint
          L3_3 = "  Null: "
          L4_3 = tostring
          L5_3 = A0_3[1]
          L5_3 = L5_3.Null
          L4_3 = L4_3(L5_3)
          L3_3 = L3_3 .. L4_3
          L2_3(L3_3)
          L2_3 = Utils
          L2_3 = L2_3.DebugPrint
          L3_3 = "  Default: "
          L4_3 = tostring
          L5_3 = A0_3[1]
          L5_3 = L5_3.Default
          L4_3 = L4_3(L5_3)
          L3_3 = L3_3 .. L4_3
          L2_3(L3_3)
          L2_3 = Utils
          L2_3 = L2_3.DebugSuccess
          L3_3 = "Database schema managed by database.lua auto-initialization"
          L2_3(L3_3)
      end
      else
        L2_3 = Utils
        L2_3 = L2_3.DebugError
        L3_3 = "Could not get column information"
        L2_3(L3_3)
      end
    end
    L3_2(L4_2, L5_2, L6_2)
  else
    L3_2 = Utils
    L3_2 = L3_2.DebugError
    L4_2 = "This command can only be run from the server console."
    L3_2(L4_2)
  end
end
L3_1 = false
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterCommand
L1_1 = "testupdate"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  if 0 == A0_2 then
    L3_2 = Utils
    L3_2 = L3_2.DebugPrint
    L4_2 = "Testing MySQL UPDATE operations..."
    L3_2(L4_2)
    L3_2 = MySQL
    L3_2 = L3_2.query
    L4_2 = "SELECT id, business_name, status FROM government_businesses LIMIT 1"
    L5_2 = {}
    function L6_2(A0_3, A1_3)
      local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
      if A1_3 then
        L2_3 = Utils
        L2_3 = L2_3.DebugError
        L3_3 = "SELECT failed: "
        L4_3 = tostring
        L5_3 = A1_3
        L4_3 = L4_3(L5_3)
        L3_3 = L3_3 .. L4_3
        L2_3(L3_3)
        return
      end
      if A0_3 then
        L2_3 = #A0_3
        if L2_3 > 0 then
          L2_3 = A0_3[1]
          L3_3 = L2_3.id
          L4_3 = Utils
          L4_3 = L4_3.DebugSuccess
          L5_3 = "SELECT works - found business ID "
          L6_3 = L3_3
          L7_3 = " with status: \""
          L8_3 = tostring
          L9_3 = L2_3.status
          L8_3 = L8_3(L9_3)
          L9_3 = "\""
          L5_3 = L5_3 .. L6_3 .. L7_3 .. L8_3 .. L9_3
          L4_3(L5_3)
          L4_3 = Utils
          L4_3 = L4_3.DebugPrint
          L5_3 = "Trying UPDATE without updated_at..."
          L4_3(L5_3)
          L4_3 = MySQL
          L4_3 = L4_3.execute
          L5_3 = "UPDATE government_businesses SET status = ? WHERE id = ?"
          L6_3 = {}
          L7_3 = "test_status"
          L8_3 = L3_3
          L6_3[1] = L7_3
          L6_3[2] = L8_3
          function L7_3(A0_4, A1_4)
            local L2_4, L3_4, L4_4, L5_4
            if A1_4 then
              L2_4 = Utils
              L2_4 = L2_4.DebugError
              L3_4 = "UPDATE failed: "
              L4_4 = tostring
              L5_4 = A1_4
              L4_4 = L4_4(L5_4)
              L3_4 = L3_4 .. L4_4
              L2_4(L3_4)
              return
            end
            L2_4 = Utils
            L2_4 = L2_4.DebugPrint
            L3_4 = "UPDATE result: "
            L4_4 = json
            L4_4 = L4_4.encode
            L5_4 = A0_4
            L4_4 = L4_4(L5_4)
            L3_4 = L3_4 .. L4_4
            L2_4(L3_4)
            L2_4 = MySQL
            L2_4 = L2_4.query
            L3_4 = "SELECT id, business_name, status FROM government_businesses WHERE id = ?"
            L4_4 = {}
            L5_4 = L3_3
            L4_4[1] = L5_4
            function L5_4(A0_5, A1_5)
              local L2_5, L3_5, L4_5, L5_5, L6_5, L7_5
              if A1_5 then
                L2_5 = Utils
                L2_5 = L2_5.DebugError
                L3_5 = "Verification SELECT failed: "
                L4_5 = tostring
                L5_5 = A1_5
                L4_5 = L4_5(L5_5)
                L3_5 = L3_5 .. L4_5
                L2_5(L3_5)
                return
              end
              if A0_5 then
                L2_5 = #A0_5
                if L2_5 > 0 then
                  L2_5 = Utils
                  L2_5 = L2_5.DebugSuccess
                  L3_5 = "Verification: Business ID "
                  L4_5 = L3_3
                  L5_5 = " status is now: \""
                  L6_5 = tostring
                  L7_5 = A0_5[1]
                  L7_5 = L7_5.status
                  L6_5 = L6_5(L7_5)
                  L7_5 = "\""
                  L3_5 = L3_5 .. L4_5 .. L5_5 .. L6_5 .. L7_5
                  L2_5(L3_5)
                  L2_5 = Utils
                  L2_5 = L2_5.DebugPrint
                  L3_5 = "Trying UPDATE with updated_at..."
                  L2_5(L3_5)
                  L2_5 = MySQL
                  L2_5 = L2_5.execute
                  L3_5 = "UPDATE government_businesses SET status = ?, updated_at = ? WHERE id = ?"
                  L4_5 = {}
                  L5_5 = "test_status_2"
                  L6_5 = os
                  L6_5 = L6_5.date
                  L7_5 = "%Y-%m-%d %H:%M:%S"
                  L6_5 = L6_5(L7_5)
                  L7_5 = L3_3
                  L4_5[1] = L5_5
                  L4_5[2] = L6_5
                  L4_5[3] = L7_5
                  function L5_5(A0_6, A1_6)
                    local L2_6, L3_6, L4_6, L5_6
                    if A1_6 then
                      L2_6 = Utils
                      L2_6 = L2_6.DebugError
                      L3_6 = "UPDATE with updated_at failed: "
                      L4_6 = tostring
                      L5_6 = A1_6
                      L4_6 = L4_6(L5_6)
                      L3_6 = L3_6 .. L4_6
                      L2_6(L3_6)
                      return
                    end
                    L2_6 = Utils
                    L2_6 = L2_6.DebugPrint
                    L3_6 = "UPDATE with updated_at result: "
                    L4_6 = json
                    L4_6 = L4_6.encode
                    L5_6 = A0_6
                    L4_6 = L4_6(L5_6)
                    L3_6 = L3_6 .. L4_6
                    L2_6(L3_6)
                    L2_6 = MySQL
                    L2_6 = L2_6.query
                    L3_6 = "SELECT id, business_name, status, updated_at FROM government_businesses WHERE id = ?"
                    L4_6 = {}
                    L5_6 = L3_3
                    L4_6[1] = L5_6
                    function L5_6(A0_7)
                      local L1_7, L2_7, L3_7, L4_7, L5_7, L6_7, L7_7, L8_7
                      if A0_7 then
                        L1_7 = #A0_7
                        if L1_7 > 0 then
                          L1_7 = Utils
                          L1_7 = L1_7.DebugSuccess
                          L2_7 = "Final verification: Business ID "
                          L3_7 = L3_3
                          L4_7 = " status: \""
                          L5_7 = tostring
                          L6_7 = A0_7[1]
                          L6_7 = L6_7.status
                          L5_7 = L5_7(L6_7)
                          L6_7 = "\", updated_at: \""
                          L7_7 = tostring
                          L8_7 = A0_7[1]
                          L8_7 = L8_7.updated_at
                          L7_7 = L7_7(L8_7)
                          L8_7 = "\""
                          L2_7 = L2_7 .. L3_7 .. L4_7 .. L5_7 .. L6_7 .. L7_7 .. L8_7
                          L1_7(L2_7)
                        end
                      end
                    end
                    L2_6(L3_6, L4_6, L5_6)
                  end
                  L2_5(L3_5, L4_5, L5_5)
              end
              else
                L2_5 = Utils
                L2_5 = L2_5.DebugError
                L3_5 = "Verification failed - no results"
                L2_5(L3_5)
              end
            end
            L2_4(L3_4, L4_4, L5_4)
          end
          L4_3(L5_3, L6_3, L7_3)
      end
      else
        L2_3 = Utils
        L2_3 = L2_3.DebugError
        L3_3 = "SELECT returned no results"
        L2_3(L3_3)
      end
    end
    L3_2(L4_2, L5_2, L6_2)
  else
    L3_2 = Utils
    L3_2 = L3_2.DebugError
    L4_2 = "This command can only be run from the server console."
    L3_2(L4_2)
  end
end
L3_1 = false
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterCommand
L1_1 = "testbusiness"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  if 0 == A0_2 then
    L3_2 = MySQL
    L3_2 = L3_2.insert
    L3_2 = L3_2.await
    L4_2 = "INSERT INTO government_businesses (business_name, owner_identifier, owner_name, business_type, license_number, registration_fee, status) VALUES (?, ?, ?, ?, ?, ?, ?)"
    L5_2 = {}
    L6_2 = "Test Business Corp"
    L7_2 = "test123"
    L8_2 = "Test Owner"
    L9_2 = "retail"
    L10_2 = "TEST-001"
    L11_2 = 5000
    L12_2 = "active"
    L5_2[1] = L6_2
    L5_2[2] = L7_2
    L5_2[3] = L8_2
    L5_2[4] = L9_2
    L5_2[5] = L10_2
    L5_2[6] = L11_2
    L5_2[7] = L12_2
    L3_2 = L3_2(L4_2, L5_2)
    L4_2 = Utils
    L4_2 = L4_2.DebugSuccess
    L5_2 = "Test business created with ID: "
    L6_2 = tostring
    L7_2 = L3_2
    L6_2 = L6_2(L7_2)
    L5_2 = L5_2 .. L6_2
    L4_2(L5_2)
    L4_2 = MySQL
    L4_2 = L4_2.query
    L4_2 = L4_2.await
    L5_2 = "SELECT * FROM government_businesses"
    L4_2 = L4_2(L5_2)
    L5_2 = Utils
    L5_2 = L5_2.DebugSuccess
    L6_2 = "Total businesses in database: "
    L7_2 = #L4_2
    L6_2 = L6_2 .. L7_2
    L5_2(L6_2)
    L5_2 = ipairs
    L6_2 = L4_2
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
    for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
      L11_2 = Utils
      L11_2 = L11_2.DebugPrint
      L12_2 = "Business "
      L13_2 = L9_2
      L14_2 = ": "
      L15_2 = L10_2.business_name
      L16_2 = " - "
      L17_2 = L10_2.license_number
      L12_2 = L12_2 .. L13_2 .. L14_2 .. L15_2 .. L16_2 .. L17_2
      L11_2(L12_2)
    end
  else
    L3_2 = Utils
    L3_2 = L3_2.DebugError
    L4_2 = "This command can only be run from server console"
    L3_2(L4_2)
  end
end
L3_1 = false
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:updateBusinessStatus"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  if not L4_2 then
    return
  end
  L5_2 = Utils
  L5_2 = L5_2.HasPermission
  L6_2 = L4_2.job
  L6_2 = L6_2.name
  L7_2 = L4_2.job
  L7_2 = L7_2.grade
  L8_2 = "business_audit"
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  if not L5_2 then
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L3_2
    L7_2 = "You do not have permission to update business status"
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
    return
  end
  if not A1_2 or "" == A1_2 then
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L3_2
    L7_2 = "Invalid status value provided"
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
    L5_2 = Config
    L5_2 = L5_2.Debug
    if L5_2 then
      L5_2 = Utils
      L5_2 = L5_2.DebugError
      L6_2 = "updateBusinessStatus received empty status for business ID: "
      L7_2 = tostring
      L8_2 = A0_2
      L7_2 = L7_2(L8_2)
      L6_2 = L6_2 .. L7_2
      L5_2(L6_2)
    end
    return
  end
  L5_2 = {}
  L6_2 = "active"
  L7_2 = "suspended"
  L8_2 = "closed"
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  L5_2[3] = L8_2
  L6_2 = Utils
  L6_2 = L6_2.TableContains
  L7_2 = L5_2
  L8_2 = A1_2
  L6_2 = L6_2(L7_2, L8_2)
  if not L6_2 then
    L6_2 = Framework
    L6_2 = L6_2.ShowNotification
    L7_2 = L3_2
    L8_2 = "Invalid business status: "
    L9_2 = tostring
    L10_2 = A1_2
    L9_2 = L9_2(L10_2)
    L8_2 = L8_2 .. L9_2
    L9_2 = "error"
    L6_2(L7_2, L8_2, L9_2)
    L6_2 = Config
    L6_2 = L6_2.Debug
    if L6_2 then
      L6_2 = Utils
      L6_2 = L6_2.DebugError
      L7_2 = "updateBusinessStatus received invalid status \""
      L8_2 = tostring
      L9_2 = A1_2
      L8_2 = L8_2(L9_2)
      L9_2 = "\" for business ID: "
      L10_2 = tostring
      L11_2 = A0_2
      L10_2 = L10_2(L11_2)
      L7_2 = L7_2 .. L8_2 .. L9_2 .. L10_2
      L6_2(L7_2)
    end
    return
  end
  L6_2 = Config
  L6_2 = L6_2.Debug
  if L6_2 then
    L6_2 = Utils
    L6_2 = L6_2.DebugPrint
    L7_2 = "Updating business ID "
    L8_2 = tostring
    L9_2 = A0_2
    L8_2 = L8_2(L9_2)
    L9_2 = " status to \""
    L10_2 = A1_2
    L11_2 = "\""
    L7_2 = L7_2 .. L8_2 .. L9_2 .. L10_2 .. L11_2
    L6_2(L7_2)
  end
  L6_2 = MySQL
  L6_2 = L6_2.execute
  L7_2 = "UPDATE government_businesses SET status = ?, updated_at = ? WHERE id = ?"
  L8_2 = {}
  L9_2 = A1_2
  L10_2 = os
  L10_2 = L10_2.date
  L11_2 = "%Y-%m-%d %H:%M:%S"
  L10_2 = L10_2(L11_2)
  L11_2 = A0_2
  L8_2[1] = L9_2
  L8_2[2] = L10_2
  L8_2[3] = L11_2
  L6_2(L7_2, L8_2)
  L6_2 = Framework
  L6_2 = L6_2.ShowNotification
  L7_2 = L3_2
  L8_2 = "Business status updated to: "
  L9_2 = A1_2
  L8_2 = L8_2 .. L9_2
  L9_2 = "success"
  L6_2(L7_2, L8_2, L9_2)
  L6_2 = MySQL
  L6_2 = L6_2.insert
  L7_2 = "INSERT INTO government_transactions (transaction_type, amount, description, processed_by) VALUES (?, ?, ?, ?)"
  L8_2 = {}
  L9_2 = "expense"
  L10_2 = 0
  L11_2 = "Business status changed to "
  L12_2 = A1_2
  L13_2 = ": "
  L14_2 = A2_2 or L14_2
  if not A2_2 then
    L14_2 = "No reason provided"
  end
  L11_2 = L11_2 .. L12_2 .. L13_2 .. L14_2
  L12_2 = L4_2.identifier
  L8_2[1] = L9_2
  L8_2[2] = L10_2
  L8_2[3] = L11_2
  L8_2[4] = L12_2
  L6_2(L7_2, L8_2)
end
L0_1(L1_1, L2_1)
