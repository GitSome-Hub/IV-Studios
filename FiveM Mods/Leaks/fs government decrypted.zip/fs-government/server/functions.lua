local L0_1, L1_1, L2_1
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getFrameworkJobs"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetFramework
  L1_2 = L1_2()
  L2_2 = {}
  if "esx" == L1_2 then
    L3_2 = MySQL
    L3_2 = L3_2.query
    L4_2 = "SELECT name, label FROM jobs"
    L5_2 = {}
    function L6_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
      if A0_3 then
        L1_3 = ipairs
        L2_3 = A0_3
        L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
        for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
          L7_3 = Utils
          L7_3 = L7_3.TableContains
          L8_3 = Config
          L8_3 = L8_3.Government
          L8_3 = L8_3.jobs
          L9_3 = L6_3.name
          L7_3 = L7_3(L8_3, L9_3)
          if L7_3 then
            L7_3 = table
            L7_3 = L7_3.insert
            L8_3 = L2_2
            L9_3 = {}
            L10_3 = L6_3.name
            L9_3.name = L10_3
            L10_3 = L6_3.label
            L9_3.label = L10_3
            L7_3(L8_3, L9_3)
          end
        end
      end
      L1_3 = TriggerClientEvent
      L2_3 = "fs-government:client:receiveFrameworkJobs"
      L3_3 = L0_2
      L4_3 = L2_2
      L1_3(L2_3, L3_3, L4_3)
    end
    L3_2(L4_2, L5_2, L6_2)
  elseif "qbcore" == L1_2 or "qbox" == L1_2 then
    L3_2 = exports
    L3_2 = L3_2["qb-core"]
    L4_2 = L3_2
    L3_2 = L3_2.GetCoreObject
    L3_2 = L3_2(L4_2)
    L4_2 = L3_2.Shared
    L4_2 = L4_2.Jobs
    L5_2 = pairs
    L6_2 = L4_2
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
    for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
      L11_2 = Utils
      L11_2 = L11_2.TableContains
      L12_2 = Config
      L12_2 = L12_2.Government
      L12_2 = L12_2.jobs
      L13_2 = L9_2
      L11_2 = L11_2(L12_2, L13_2)
      if L11_2 then
        L11_2 = table
        L11_2 = L11_2.insert
        L12_2 = L2_2
        L13_2 = {}
        L13_2.name = L9_2
        L14_2 = L10_2.label
        L13_2.label = L14_2
        L11_2(L12_2, L13_2)
      end
    end
    L5_2 = TriggerClientEvent
    L6_2 = "fs-government:client:receiveFrameworkJobs"
    L7_2 = L0_2
    L8_2 = L2_2
    L5_2(L6_2, L7_2, L8_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getJobGrades"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetFramework
  L2_2 = L2_2()
  L3_2 = {}
  if "esx" == L2_2 then
    L4_2 = MySQL
    L4_2 = L4_2.query
    L5_2 = "SELECT grade, name, label, salary FROM job_grades WHERE job_name = ? ORDER BY grade ASC"
    L6_2 = {}
    L7_2 = A0_2
    L6_2[1] = L7_2
    function L7_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
      if A0_3 then
        L1_3 = ipairs
        L2_3 = A0_3
        L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
        for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
          L7_3 = table
          L7_3 = L7_3.insert
          L8_3 = L3_2
          L9_3 = {}
          L10_3 = L6_3.grade
          L9_3.grade = L10_3
          L10_3 = L6_3.name
          L9_3.name = L10_3
          L10_3 = L6_3.label
          L9_3.label = L10_3
          L10_3 = L6_3.salary
          L9_3.salary = L10_3
          L7_3(L8_3, L9_3)
        end
      end
      L1_3 = TriggerClientEvent
      L2_3 = "fs-government:client:receiveJobGrades"
      L3_3 = L1_2
      L4_3 = L3_2
      L1_3(L2_3, L3_3, L4_3)
    end
    L4_2(L5_2, L6_2, L7_2)
  elseif "qbcore" == L2_2 or "qbox" == L2_2 then
    L4_2 = exports
    L4_2 = L4_2["qb-core"]
    L5_2 = L4_2
    L4_2 = L4_2.GetCoreObject
    L4_2 = L4_2(L5_2)
    L5_2 = L4_2.Shared
    L5_2 = L5_2.Jobs
    L6_2 = L5_2[A0_2]
    if L6_2 then
      L6_2 = L5_2[A0_2]
      L6_2 = L6_2.grades
      if L6_2 then
        L6_2 = pairs
        L7_2 = L5_2[A0_2]
        L7_2 = L7_2.grades
        L6_2, L7_2, L8_2, L9_2 = L6_2(L7_2)
        for L10_2, L11_2 in L6_2, L7_2, L8_2, L9_2 do
          L12_2 = table
          L12_2 = L12_2.insert
          L13_2 = L3_2
          L14_2 = {}
          L15_2 = tonumber
          L16_2 = L10_2
          L15_2 = L15_2(L16_2)
          L14_2.grade = L15_2
          L15_2 = L11_2.name
          L14_2.name = L15_2
          L15_2 = L11_2.name
          L14_2.label = L15_2
          L15_2 = L11_2.payment
          if not L15_2 then
            L15_2 = 0
          end
          L14_2.salary = L15_2
          L12_2(L13_2, L14_2)
        end
        L6_2 = table
        L6_2 = L6_2.sort
        L7_2 = L3_2
        function L8_2(A0_3, A1_3)
          local L2_3, L3_3
          L2_3 = A0_3.grade
          L3_3 = A1_3.grade
          L2_3 = L2_3 < L3_3
          return L2_3
        end
        L6_2(L7_2, L8_2)
      end
    end
    L6_2 = TriggerClientEvent
    L7_2 = "fs-government:client:receiveJobGrades"
    L8_2 = L1_2
    L9_2 = L3_2
    L6_2(L7_2, L8_2, L9_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:hireEmployee"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  L5_2 = Framework
  L5_2 = L5_2.GetPlayerData
  L6_2 = A0_2
  L5_2 = L5_2(L6_2)
  if not L4_2 or not L5_2 then
    return
  end
  L6_2 = Utils
  L6_2 = L6_2.HasPermission
  L7_2 = L4_2.job
  L7_2 = L7_2.name
  L8_2 = L4_2.job
  L8_2 = L8_2.grade
  L9_2 = "employee_management"
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  if not L6_2 then
    L6_2 = Framework
    L6_2 = L6_2.ShowNotification
    L7_2 = L3_2
    L8_2 = "You do not have permission to hire employees"
    L9_2 = "error"
    L6_2(L7_2, L8_2, L9_2)
    return
  end
  L6_2 = Framework
  L6_2 = L6_2.GetFramework
  L6_2 = L6_2()
  L7_2 = 0
  if "esx" == L6_2 then
    L8_2 = MySQL
    L8_2 = L8_2.query
    L9_2 = "SELECT salary FROM job_grades WHERE job_name = ? AND grade = ?"
    L10_2 = {}
    L11_2 = A1_2
    L12_2 = A2_2
    L10_2[1] = L11_2
    L10_2[2] = L12_2
    function L11_2(A0_3)
      local L1_3
      if A0_3 then
        L1_3 = #A0_3
        if L1_3 > 0 then
          L1_3 = A0_3[1]
          L1_3 = L1_3.salary
          if not L1_3 then
            L1_3 = 0
          end
          L7_2 = L1_3
        end
      end
    end
    L8_2(L9_2, L10_2, L11_2)
    L8_2 = exports
    L8_2 = L8_2.es_extended
    L9_2 = L8_2
    L8_2 = L8_2.getSharedObject
    L8_2 = L8_2(L9_2)
    L9_2 = L8_2.GetPlayerFromId
    L10_2 = A0_2
    L9_2 = L9_2(L10_2)
    if L9_2 then
      L10_2 = L9_2.setJob
      L11_2 = A1_2
      L12_2 = A2_2
      L10_2(L11_2, L12_2)
      L10_2 = MySQL
      L10_2 = L10_2.insert
      L11_2 = "INSERT INTO government_employees (identifier, name, job, grade, salary) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE job = VALUES(job), grade = VALUES(grade), salary = VALUES(salary)"
      L12_2 = {}
      L13_2 = L5_2.identifier
      L14_2 = L5_2.name
      L15_2 = A1_2
      L16_2 = A2_2
      L17_2 = L7_2
      L12_2[1] = L13_2
      L12_2[2] = L14_2
      L12_2[3] = L15_2
      L12_2[4] = L16_2
      L12_2[5] = L17_2
      L10_2(L11_2, L12_2)
      L10_2 = Framework
      L10_2 = L10_2.ShowNotification
      L11_2 = L3_2
      L12_2 = "Employee hired successfully"
      L13_2 = "success"
      L10_2(L11_2, L12_2, L13_2)
      L10_2 = Framework
      L10_2 = L10_2.ShowNotification
      L11_2 = A0_2
      L12_2 = "You have been hired as "
      L13_2 = A1_2
      L14_2 = " (Grade "
      L15_2 = A2_2
      L16_2 = ")"
      L12_2 = L12_2 .. L13_2 .. L14_2 .. L15_2 .. L16_2
      L13_2 = "success"
      L10_2(L11_2, L12_2, L13_2)
    end
  elseif "qbcore" == L6_2 or "qbox" == L6_2 then
    L8_2 = exports
    L8_2 = L8_2["qb-core"]
    L9_2 = L8_2
    L8_2 = L8_2.GetCoreObject
    L8_2 = L8_2(L9_2)
    L9_2 = L8_2.Shared
    L9_2 = L9_2.Jobs
    L10_2 = L9_2[A1_2]
    if L10_2 then
      L10_2 = L9_2[A1_2]
      L10_2 = L10_2.grades
      if L10_2 then
        L10_2 = L9_2[A1_2]
        L10_2 = L10_2.grades
        L11_2 = tostring
        L12_2 = A2_2
        L11_2 = L11_2(L12_2)
        L10_2 = L10_2[L11_2]
        if L10_2 then
          L10_2 = L9_2[A1_2]
          L10_2 = L10_2.grades
          L11_2 = tostring
          L12_2 = A2_2
          L11_2 = L11_2(L12_2)
          L10_2 = L10_2[L11_2]
          L10_2 = L10_2.payment
          L7_2 = L10_2 or L7_2
          if not L10_2 then
            L7_2 = 0
          end
        end
      end
    end
    L10_2 = L8_2.Functions
    L10_2 = L10_2.GetPlayer
    L11_2 = A0_2
    L10_2 = L10_2(L11_2)
    if L10_2 then
      L11_2 = L10_2.Functions
      L11_2 = L11_2.SetJob
      L12_2 = A1_2
      L13_2 = A2_2
      L11_2(L12_2, L13_2)
      L11_2 = MySQL
      L11_2 = L11_2.insert
      L12_2 = "INSERT INTO government_employees (identifier, name, job, grade, salary) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE job = VALUES(job), grade = VALUES(grade), salary = VALUES(salary)"
      L13_2 = {}
      L14_2 = L5_2.identifier
      L15_2 = L5_2.name
      L16_2 = A1_2
      L17_2 = A2_2
      L18_2 = L7_2
      L13_2[1] = L14_2
      L13_2[2] = L15_2
      L13_2[3] = L16_2
      L13_2[4] = L17_2
      L13_2[5] = L18_2
      L11_2(L12_2, L13_2)
      L11_2 = Framework
      L11_2 = L11_2.ShowNotification
      L12_2 = L3_2
      L13_2 = "Employee hired successfully"
      L14_2 = "success"
      L11_2(L12_2, L13_2, L14_2)
      L11_2 = Framework
      L11_2 = L11_2.ShowNotification
      L12_2 = A0_2
      L13_2 = "You have been hired as "
      L14_2 = A1_2
      L15_2 = " (Grade "
      L16_2 = A2_2
      L17_2 = ")"
      L13_2 = L13_2 .. L14_2 .. L15_2 .. L16_2 .. L17_2
      L14_2 = "success"
      L11_2(L12_2, L13_2, L14_2)
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:fireEmployee"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  if not L2_2 or not L3_2 then
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L2_2.job
  L5_2 = L5_2.name
  L6_2 = L2_2.job
  L6_2 = L6_2.grade
  L7_2 = "employee_management"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L1_2
    L6_2 = "You do not have permission to fire employees"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = Framework
  L4_2 = L4_2.GetFramework
  L4_2 = L4_2()
  if "esx" == L4_2 then
    L5_2 = exports
    L5_2 = L5_2.es_extended
    L6_2 = L5_2
    L5_2 = L5_2.getSharedObject
    L5_2 = L5_2(L6_2)
    L6_2 = L5_2.GetPlayerFromId
    L7_2 = A0_2
    L6_2 = L6_2(L7_2)
    if L6_2 then
      L7_2 = L6_2.setJob
      L8_2 = "unemployed"
      L9_2 = 0
      L7_2(L8_2, L9_2)
      L7_2 = MySQL
      L7_2 = L7_2.execute
      L8_2 = "DELETE FROM government_employees WHERE identifier = ?"
      L9_2 = {}
      L10_2 = L3_2.identifier
      L9_2[1] = L10_2
      L7_2(L8_2, L9_2)
      L7_2 = Framework
      L7_2 = L7_2.ShowNotification
      L8_2 = L1_2
      L9_2 = "Employee fired successfully"
      L10_2 = "success"
      L7_2(L8_2, L9_2, L10_2)
      L7_2 = Framework
      L7_2 = L7_2.ShowNotification
      L8_2 = A0_2
      L9_2 = "You have been fired from your government position"
      L10_2 = "error"
      L7_2(L8_2, L9_2, L10_2)
    end
  elseif "qbcore" == L4_2 or "qbox" == L4_2 then
    L5_2 = exports
    L5_2 = L5_2["qb-core"]
    L6_2 = L5_2
    L5_2 = L5_2.GetCoreObject
    L5_2 = L5_2(L6_2)
    L6_2 = L5_2.Functions
    L6_2 = L6_2.GetPlayer
    L7_2 = A0_2
    L6_2 = L6_2(L7_2)
    if L6_2 then
      L7_2 = L6_2.Functions
      L7_2 = L7_2.SetJob
      L8_2 = "unemployed"
      L9_2 = 0
      L7_2(L8_2, L9_2)
      L7_2 = MySQL
      L7_2 = L7_2.execute
      L8_2 = "DELETE FROM government_employees WHERE identifier = ?"
      L9_2 = {}
      L10_2 = L3_2.identifier
      L9_2[1] = L10_2
      L7_2(L8_2, L9_2)
      L7_2 = Framework
      L7_2 = L7_2.ShowNotification
      L8_2 = L1_2
      L9_2 = "Employee fired successfully"
      L10_2 = "success"
      L7_2(L8_2, L9_2, L10_2)
      L7_2 = Framework
      L7_2 = L7_2.ShowNotification
      L8_2 = A0_2
      L9_2 = "You have been fired from your government position"
      L10_2 = "error"
      L7_2(L8_2, L9_2, L10_2)
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:setEmployeeGrade"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = A0_2
  L4_2 = L4_2(L5_2)
  if not L3_2 or not L4_2 then
    return
  end
  L5_2 = Utils
  L5_2 = L5_2.HasPermission
  L6_2 = L3_2.job
  L6_2 = L6_2.name
  L7_2 = L3_2.job
  L7_2 = L7_2.grade
  L8_2 = "employee_management"
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  if not L5_2 then
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L2_2
    L7_2 = "You do not have permission to promote/demote employees"
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
    return
  end
  L5_2 = Framework
  L5_2 = L5_2.GetFramework
  L5_2 = L5_2()
  if "esx" == L5_2 then
    L6_2 = exports
    L6_2 = L6_2.es_extended
    L7_2 = L6_2
    L6_2 = L6_2.getSharedObject
    L6_2 = L6_2(L7_2)
    L7_2 = L6_2.GetPlayerFromId
    L8_2 = A0_2
    L7_2 = L7_2(L8_2)
    if not L7_2 then
      goto lbl_178
    end
    L8_2 = L7_2.setJob
    L9_2 = L7_2.job
    L9_2 = L9_2.name
    L10_2 = A1_2
    L8_2(L9_2, L10_2)
    L8_2 = MySQL
    L8_2 = L8_2.execute
    L9_2 = "UPDATE government_employees SET grade = ?, salary = ? WHERE identifier = ?"
    L10_2 = {}
    L11_2 = A1_2
    L12_2 = Config
    L12_2 = L12_2.Government
    L12_2 = L12_2.grades
    L13_2 = L7_2.job
    L13_2 = L13_2.name
    L12_2 = L12_2[L13_2]
    if L12_2 then
      L12_2 = Config
      L12_2 = L12_2.Government
      L12_2 = L12_2.grades
      L13_2 = L7_2.job
      L13_2 = L13_2.name
      L12_2 = L12_2[L13_2]
      L12_2 = L12_2[A1_2]
      if L12_2 then
        L12_2 = Config
        L12_2 = L12_2.Government
        L12_2 = L12_2.grades
        L13_2 = L7_2.job
        L13_2 = L13_2.name
        L12_2 = L12_2[L13_2]
        L12_2 = L12_2[A1_2]
        L12_2 = L12_2.salary
        if L12_2 then
          goto lbl_85
        end
      end
    end
    L12_2 = 0
    ::lbl_85::
    L13_2 = L4_2.identifier
    L10_2[1] = L11_2
    L10_2[2] = L12_2
    L10_2[3] = L13_2
    L8_2(L9_2, L10_2)
    L8_2 = Framework
    L8_2 = L8_2.ShowNotification
    L9_2 = L2_2
    L10_2 = "Employee grade updated successfully"
    L11_2 = "success"
    L8_2(L9_2, L10_2, L11_2)
    L8_2 = Framework
    L8_2 = L8_2.ShowNotification
    L9_2 = A0_2
    L10_2 = "Your grade has been updated to "
    L11_2 = A1_2
    L10_2 = L10_2 .. L11_2
    L11_2 = "success"
    L8_2(L9_2, L10_2, L11_2)
  elseif "qbcore" == L5_2 or "qbox" == L5_2 then
    L6_2 = exports
    L6_2 = L6_2["qb-core"]
    L7_2 = L6_2
    L6_2 = L6_2.GetCoreObject
    L6_2 = L6_2(L7_2)
    L7_2 = L6_2.Functions
    L7_2 = L7_2.GetPlayer
    L8_2 = A0_2
    L7_2 = L7_2(L8_2)
    if L7_2 then
      L8_2 = L7_2.Functions
      L8_2 = L8_2.SetJob
      L9_2 = L7_2.PlayerData
      L9_2 = L9_2.job
      L9_2 = L9_2.name
      L10_2 = A1_2
      L8_2(L9_2, L10_2)
      L8_2 = MySQL
      L8_2 = L8_2.execute
      L9_2 = "UPDATE government_employees SET grade = ?, salary = ? WHERE identifier = ?"
      L10_2 = {}
      L11_2 = A1_2
      L12_2 = Config
      L12_2 = L12_2.Government
      L12_2 = L12_2.grades
      L13_2 = L7_2.PlayerData
      L13_2 = L13_2.job
      L13_2 = L13_2.name
      L12_2 = L12_2[L13_2]
      if L12_2 then
        L12_2 = Config
        L12_2 = L12_2.Government
        L12_2 = L12_2.grades
        L13_2 = L7_2.PlayerData
        L13_2 = L13_2.job
        L13_2 = L13_2.name
        L12_2 = L12_2[L13_2]
        L12_2 = L12_2[A1_2]
        if L12_2 then
          L12_2 = Config
          L12_2 = L12_2.Government
          L12_2 = L12_2.grades
          L13_2 = L7_2.PlayerData
          L13_2 = L13_2.job
          L13_2 = L13_2.name
          L12_2 = L12_2[L13_2]
          L12_2 = L12_2[A1_2]
          L12_2 = L12_2.salary
          if L12_2 then
            goto lbl_161
          end
        end
      end
      L12_2 = 0
      ::lbl_161::
      L13_2 = L4_2.identifier
      L10_2[1] = L11_2
      L10_2[2] = L12_2
      L10_2[3] = L13_2
      L8_2(L9_2, L10_2)
      L8_2 = Framework
      L8_2 = L8_2.ShowNotification
      L9_2 = L2_2
      L10_2 = "Employee grade updated successfully"
      L11_2 = "success"
      L8_2(L9_2, L10_2, L11_2)
      L8_2 = Framework
      L8_2 = L8_2.ShowNotification
      L9_2 = A0_2
      L10_2 = "Your grade has been updated to "
      L11_2 = A1_2
      L10_2 = L10_2 .. L11_2
      L11_2 = "success"
      L8_2(L9_2, L10_2, L11_2)
    end
  end
  ::lbl_178::
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getOnlineStaff"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L0_2 = source
  L1_2 = {}
  L2_2 = Framework
  L2_2 = L2_2.GetPlayers
  L2_2 = L2_2()
  L3_2 = pairs
  L4_2 = L2_2
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
    L9_2 = Framework
    L9_2 = L9_2.GetPlayerData
    L10_2 = L8_2
    L9_2 = L9_2(L10_2)
    if L9_2 then
      L10_2 = L9_2.job
      if L10_2 then
        L10_2 = Utils
        L10_2 = L10_2.TableContains
        L11_2 = Config
        L11_2 = L11_2.Government
        L11_2 = L11_2.jobs
        L12_2 = L9_2.job
        L12_2 = L12_2.name
        L10_2 = L10_2(L11_2, L12_2)
        if L10_2 then
          L10_2 = table
          L10_2 = L10_2.insert
          L11_2 = L1_2
          L12_2 = {}
          L12_2.serverId = L8_2
          L13_2 = L9_2.name
          if not L13_2 then
            L13_2 = "Player "
            L14_2 = L8_2
            L13_2 = L13_2 .. L14_2
          end
          L12_2.name = L13_2
          L13_2 = L9_2.job
          L13_2 = L13_2.name
          L12_2.job = L13_2
          L13_2 = L9_2.job
          L13_2 = L13_2.grade
          if not L13_2 then
            L13_2 = 0
          end
          L12_2.grade = L13_2
          L13_2 = L9_2.job
          L13_2 = L13_2.label
          if not L13_2 then
            L13_2 = L9_2.job
            L13_2 = L13_2.name
          end
          L12_2.label = L13_2
          L10_2(L11_2, L12_2)
        end
      end
    end
  end
  L3_2 = TriggerClientEvent
  L4_2 = "fs-government:client:showOnlineStaff"
  L5_2 = L0_2
  L6_2 = L1_2
  L3_2(L4_2, L5_2, L6_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getEmployeeList"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if L1_2 then
    L2_2 = Utils
    L2_2 = L2_2.HasPermission
    L3_2 = L1_2.job
    L3_2 = L3_2.name
    L4_2 = L1_2.job
    L4_2 = L4_2.grade
    L5_2 = "employee_management"
    L2_2 = L2_2(L3_2, L4_2, L5_2)
    if L2_2 then
      goto lbl_25
    end
  end
  L2_2 = Framework
  L2_2 = L2_2.ShowNotification
  L3_2 = L0_2
  L4_2 = "You do not have permission to view employee list"
  L5_2 = "error"
  L2_2(L3_2, L4_2, L5_2)
  do return end
  ::lbl_25::
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_employees"
  L4_2 = {}
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = A0_3 or nil
    if not A0_3 then
      L1_3 = {}
    end
    L2_3 = TriggerClientEvent
    L3_3 = "fs-government:client:showEmployeeList"
    L4_3 = L0_2
    L5_3 = L1_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:promoteEmployee"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if L3_2 then
    L4_2 = Utils
    L4_2 = L4_2.HasPermission
    L5_2 = L3_2.job
    L5_2 = L5_2.name
    L6_2 = L3_2.job
    L6_2 = L6_2.grade
    L7_2 = "employee_management"
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    if L4_2 then
      goto lbl_25
    end
  end
  L4_2 = Framework
  L4_2 = L4_2.ShowNotification
  L5_2 = L2_2
  L6_2 = "You do not have permission to promote employees"
  L7_2 = "error"
  L4_2(L5_2, L6_2, L7_2)
  do return end
  ::lbl_25::
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT * FROM government_employees WHERE identifier = ?"
  L6_2 = {}
  L7_2 = A0_2
  L6_2[1] = L7_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    if A0_3 then
      L1_3 = #A0_3
      if L1_3 > 0 then
        L1_3 = A0_3[1]
        L2_3 = 0
        L3_3 = Framework
        L3_3 = L3_3.GetFramework
        L3_3 = L3_3()
        if "esx" == L3_3 then
          L4_3 = MySQL
          L4_3 = L4_3.query
          L5_3 = "SELECT salary FROM job_grades WHERE job_name = ? AND grade = ?"
          L6_3 = {}
          L7_3 = L1_3.job
          L8_3 = A1_2
          L6_3[1] = L7_3
          L6_3[2] = L8_3
          function L7_3(A0_4)
            local L1_4
            if A0_4 then
              L1_4 = #A0_4
              if L1_4 > 0 then
                L1_4 = A0_4[1]
                L1_4 = L1_4.salary
                if not L1_4 then
                  L1_4 = 0
                end
                L2_3 = L1_4
              end
            end
          end
          L4_3(L5_3, L6_3, L7_3)
        elseif "qbcore" == L3_3 or "qbox" == L3_3 then
          L4_3 = exports
          L4_3 = L4_3["qb-core"]
          L5_3 = L4_3
          L4_3 = L4_3.GetCoreObject
          L4_3 = L4_3(L5_3)
          L5_3 = L4_3.Shared
          L5_3 = L5_3.Jobs
          L6_3 = L1_3.job
          L6_3 = L5_3[L6_3]
          if L6_3 then
            L6_3 = L1_3.job
            L6_3 = L5_3[L6_3]
            L6_3 = L6_3.grades
            if L6_3 then
              L6_3 = L1_3.job
              L6_3 = L5_3[L6_3]
              L6_3 = L6_3.grades
              L7_3 = tostring
              L8_3 = A1_2
              L7_3 = L7_3(L8_3)
              L6_3 = L6_3[L7_3]
              if L6_3 then
                L6_3 = L1_3.job
                L6_3 = L5_3[L6_3]
                L6_3 = L6_3.grades
                L7_3 = tostring
                L8_3 = A1_2
                L7_3 = L7_3(L8_3)
                L6_3 = L6_3[L7_3]
                L6_3 = L6_3.payment
                L2_3 = L6_3 or L2_3
                if not L6_3 then
                  L2_3 = 0
                end
              end
            end
          end
        end
        L4_3 = MySQL
        L4_3 = L4_3.update
        L5_3 = "UPDATE government_employees SET grade = ?, salary = ? WHERE identifier = ?"
        L6_3 = {}
        L7_3 = A1_2
        L8_3 = L2_3
        L9_3 = A0_2
        L6_3[1] = L7_3
        L6_3[2] = L8_3
        L6_3[3] = L9_3
        function L7_3(A0_4)
          local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4
          if A0_4 > 0 then
            L1_4 = Framework
            L1_4 = L1_4.GetPlayerByIdentifier
            L2_4 = A0_2
            L1_4 = L1_4(L2_4)
            if L1_4 then
              L2_4 = Framework
              L2_4 = L2_4.GetFramework
              L2_4 = L2_4()
              if "esx" == L2_4 then
                L3_4 = exports
                L3_4 = L3_4.es_extended
                L4_4 = L3_4
                L3_4 = L3_4.getSharedObject
                L3_4 = L3_4(L4_4)
                L4_4 = L3_4.GetPlayerFromId
                L5_4 = L1_4
                L4_4 = L4_4(L5_4)
                if L4_4 then
                  L5_4 = L4_4.setJob
                  L6_4 = L1_3.job
                  L7_4 = A1_2
                  L5_4(L6_4, L7_4)
                end
              elseif "qbcore" == L2_4 or "qbox" == L2_4 then
                L3_4 = exports
                L3_4 = L3_4["qb-core"]
                L4_4 = L3_4
                L3_4 = L3_4.GetCoreObject
                L3_4 = L3_4(L4_4)
                L4_4 = L3_4.Functions
                L4_4 = L4_4.GetPlayer
                L5_4 = L1_4
                L4_4 = L4_4(L5_4)
                if L4_4 then
                  L5_4 = L4_4.Functions
                  L5_4 = L5_4.SetJob
                  L6_4 = L1_3.job
                  L7_4 = A1_2
                  L5_4(L6_4, L7_4)
                end
              end
            end
            L2_4 = Framework
            L2_4 = L2_4.ShowNotification
            L3_4 = L2_2
            L4_4 = "Employee promoted successfully"
            L5_4 = "success"
            L2_4(L3_4, L4_4, L5_4)
          else
            L1_4 = Framework
            L1_4 = L1_4.ShowNotification
            L2_4 = L2_2
            L3_4 = "Failed to promote employee"
            L4_4 = "error"
            L1_4(L2_4, L3_4, L4_4)
          end
        end
        L4_3(L5_3, L6_3, L7_3)
    end
    else
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L2_2
      L3_3 = "Employee not found"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L4_2(L5_2, L6_2, L7_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:demoteEmployee"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if L3_2 then
    L4_2 = Utils
    L4_2 = L4_2.HasPermission
    L5_2 = L3_2.job
    L5_2 = L5_2.name
    L6_2 = L3_2.job
    L6_2 = L6_2.grade
    L7_2 = "employee_management"
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    if L4_2 then
      goto lbl_25
    end
  end
  L4_2 = Framework
  L4_2 = L4_2.ShowNotification
  L5_2 = L2_2
  L6_2 = "You do not have permission to demote employees"
  L7_2 = "error"
  L4_2(L5_2, L6_2, L7_2)
  do return end
  ::lbl_25::
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT * FROM government_employees WHERE identifier = ?"
  L6_2 = {}
  L7_2 = A0_2
  L6_2[1] = L7_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    if A0_3 then
      L1_3 = #A0_3
      if L1_3 > 0 then
        L1_3 = A0_3[1]
        L2_3 = 0
        L3_3 = Framework
        L3_3 = L3_3.GetFramework
        L3_3 = L3_3()
        if "esx" == L3_3 then
          L4_3 = MySQL
          L4_3 = L4_3.query
          L5_3 = "SELECT salary FROM job_grades WHERE job_name = ? AND grade = ?"
          L6_3 = {}
          L7_3 = L1_3.job
          L8_3 = A1_2
          L6_3[1] = L7_3
          L6_3[2] = L8_3
          function L7_3(A0_4)
            local L1_4
            if A0_4 then
              L1_4 = #A0_4
              if L1_4 > 0 then
                L1_4 = A0_4[1]
                L1_4 = L1_4.salary
                if not L1_4 then
                  L1_4 = 0
                end
                L2_3 = L1_4
              end
            end
          end
          L4_3(L5_3, L6_3, L7_3)
        elseif "qbcore" == L3_3 or "qbox" == L3_3 then
          L4_3 = exports
          L4_3 = L4_3["qb-core"]
          L5_3 = L4_3
          L4_3 = L4_3.GetCoreObject
          L4_3 = L4_3(L5_3)
          L5_3 = L4_3.Shared
          L5_3 = L5_3.Jobs
          L6_3 = L1_3.job
          L6_3 = L5_3[L6_3]
          if L6_3 then
            L6_3 = L1_3.job
            L6_3 = L5_3[L6_3]
            L6_3 = L6_3.grades
            if L6_3 then
              L6_3 = L1_3.job
              L6_3 = L5_3[L6_3]
              L6_3 = L6_3.grades
              L7_3 = tostring
              L8_3 = A1_2
              L7_3 = L7_3(L8_3)
              L6_3 = L6_3[L7_3]
              if L6_3 then
                L6_3 = L1_3.job
                L6_3 = L5_3[L6_3]
                L6_3 = L6_3.grades
                L7_3 = tostring
                L8_3 = A1_2
                L7_3 = L7_3(L8_3)
                L6_3 = L6_3[L7_3]
                L6_3 = L6_3.payment
                L2_3 = L6_3 or L2_3
                if not L6_3 then
                  L2_3 = 0
                end
              end
            end
          end
        end
        L4_3 = MySQL
        L4_3 = L4_3.update
        L5_3 = "UPDATE government_employees SET grade = ?, salary = ? WHERE identifier = ?"
        L6_3 = {}
        L7_3 = A1_2
        L8_3 = L2_3
        L9_3 = A0_2
        L6_3[1] = L7_3
        L6_3[2] = L8_3
        L6_3[3] = L9_3
        function L7_3(A0_4)
          local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4
          if A0_4 > 0 then
            L1_4 = Framework
            L1_4 = L1_4.GetPlayerByIdentifier
            L2_4 = A0_2
            L1_4 = L1_4(L2_4)
            if L1_4 then
              L2_4 = Framework
              L2_4 = L2_4.GetFramework
              L2_4 = L2_4()
              if "esx" == L2_4 then
                L3_4 = exports
                L3_4 = L3_4.es_extended
                L4_4 = L3_4
                L3_4 = L3_4.getSharedObject
                L3_4 = L3_4(L4_4)
                L4_4 = L3_4.GetPlayerFromId
                L5_4 = L1_4
                L4_4 = L4_4(L5_4)
                if L4_4 then
                  L5_4 = L4_4.setJob
                  L6_4 = L1_3.job
                  L7_4 = A1_2
                  L5_4(L6_4, L7_4)
                end
              elseif "qbcore" == L2_4 or "qbox" == L2_4 then
                L3_4 = exports
                L3_4 = L3_4["qb-core"]
                L4_4 = L3_4
                L3_4 = L3_4.GetCoreObject
                L3_4 = L3_4(L4_4)
                L4_4 = L3_4.Functions
                L4_4 = L4_4.GetPlayer
                L5_4 = L1_4
                L4_4 = L4_4(L5_4)
                if L4_4 then
                  L5_4 = L4_4.Functions
                  L5_4 = L5_4.SetJob
                  L6_4 = L1_3.job
                  L7_4 = A1_2
                  L5_4(L6_4, L7_4)
                end
              end
            end
            L2_4 = Framework
            L2_4 = L2_4.ShowNotification
            L3_4 = L2_2
            L4_4 = "Employee demoted successfully"
            L5_4 = "success"
            L2_4(L3_4, L4_4, L5_4)
          else
            L1_4 = Framework
            L1_4 = L1_4.ShowNotification
            L2_4 = L2_2
            L3_4 = "Failed to demote employee"
            L4_4 = "error"
            L1_4(L2_4, L3_4, L4_4)
          end
        end
        L4_3(L5_3, L6_3, L7_3)
    end
    else
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L2_2
      L3_3 = "Employee not found"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L4_2(L5_2, L6_2, L7_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:fireEmployeeById"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if L2_2 then
    L3_2 = Utils
    L3_2 = L3_2.HasPermission
    L4_2 = L2_2.job
    L4_2 = L4_2.name
    L5_2 = L2_2.job
    L5_2 = L5_2.grade
    L6_2 = "employee_management"
    L3_2 = L3_2(L4_2, L5_2, L6_2)
    if L3_2 then
      goto lbl_25
    end
  end
  L3_2 = Framework
  L3_2 = L3_2.ShowNotification
  L4_2 = L1_2
  L5_2 = "You do not have permission to fire employees"
  L6_2 = "error"
  L3_2(L4_2, L5_2, L6_2)
  do return end
  ::lbl_25::
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT * FROM government_employees WHERE identifier = ?"
  L5_2 = {}
  L6_2 = A0_2
  L5_2[1] = L6_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    if A0_3 then
      L1_3 = #A0_3
      if L1_3 > 0 then
        L1_3 = MySQL
        L1_3 = L1_3.update
        L2_3 = "DELETE FROM government_employees WHERE identifier = ?"
        L3_3 = {}
        L4_3 = A0_2
        L3_3[1] = L4_3
        function L4_3(A0_4)
          local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4
          if A0_4 > 0 then
            L1_4 = Framework
            L1_4 = L1_4.GetPlayerByIdentifier
            L2_4 = A0_2
            L1_4 = L1_4(L2_4)
            if L1_4 then
              L2_4 = Framework
              L2_4 = L2_4.GetFramework
              L2_4 = L2_4()
              if "esx" == L2_4 then
                L3_4 = exports
                L3_4 = L3_4.es_extended
                L4_4 = L3_4
                L3_4 = L3_4.getSharedObject
                L3_4 = L3_4(L4_4)
                L4_4 = L3_4.GetPlayerFromId
                L5_4 = L1_4
                L4_4 = L4_4(L5_4)
                if L4_4 then
                  L5_4 = L4_4.setJob
                  L6_4 = "unemployed"
                  L7_4 = 0
                  L5_4(L6_4, L7_4)
                end
              elseif "qbcore" == L2_4 or "qbox" == L2_4 then
                L3_4 = exports
                L3_4 = L3_4["qb-core"]
                L4_4 = L3_4
                L3_4 = L3_4.GetCoreObject
                L3_4 = L3_4(L4_4)
                L4_4 = L3_4.Functions
                L4_4 = L4_4.GetPlayer
                L5_4 = L1_4
                L4_4 = L4_4(L5_4)
                if L4_4 then
                  L5_4 = L4_4.Functions
                  L5_4 = L5_4.SetJob
                  L6_4 = "unemployed"
                  L7_4 = 0
                  L5_4(L6_4, L7_4)
                end
              end
            end
            L2_4 = Framework
            L2_4 = L2_4.ShowNotification
            L3_4 = L1_2
            L4_4 = "Employee fired successfully"
            L5_4 = "success"
            L2_4(L3_4, L4_4, L5_4)
          else
            L1_4 = Framework
            L1_4 = L1_4.ShowNotification
            L2_4 = L1_2
            L3_4 = "Failed to fire employee"
            L4_4 = "error"
            L1_4(L2_4, L3_4, L4_4)
          end
        end
        L1_3(L2_3, L3_3, L4_3)
    end
    else
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L1_2
      L3_3 = "Employee not found"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L3_2(L4_2, L5_2, L6_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getFinances"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "employee_management"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view finances"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT SUM(CASE WHEN transaction_type IN (\"income\", \"tax\", \"deposit\") THEN amount ELSE -amount END) as total_funds FROM government_transactions"
  L4_2 = {}
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = A0_3[1]
    if L1_3 then
      L1_3 = A0_3[1]
      L1_3 = L1_3.total_funds
      if L1_3 then
        goto lbl_9
      end
    end
    L1_3 = 0
    ::lbl_9::
    L2_3 = MySQL
    L2_3 = L2_3.query
    L3_3 = "SELECT transaction_type, SUM(amount) as total FROM government_transactions WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY transaction_type"
    L4_3 = {}
    function L5_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4
      L1_4 = "Government Finances:\n"
      L2_4 = L1_4
      L3_4 = "Available Funds: $"
      L4_4 = L1_3
      L5_4 = [[


]]
      L2_4 = L2_4 .. L3_4 .. L4_4 .. L5_4
      L1_4 = L2_4
      L2_4 = L1_4
      L3_4 = "Last 30 Days Activity:\n"
      L2_4 = L2_4 .. L3_4
      L1_4 = L2_4
      L2_4 = ipairs
      L3_4 = A0_4
      L2_4, L3_4, L4_4, L5_4 = L2_4(L3_4)
      for L6_4, L7_4 in L2_4, L3_4, L4_4, L5_4 do
        L8_4 = L1_4
        L9_4 = L7_4.transaction_type
        L10_4 = ": $"
        L11_4 = L7_4.total
        L12_4 = "\n"
        L8_4 = L8_4 .. L9_4 .. L10_4 .. L11_4 .. L12_4
        L1_4 = L8_4
      end
      L2_4 = Framework
      L2_4 = L2_4.ShowNotification
      L3_4 = L0_2
      L4_4 = L1_4
      L5_4 = "success"
      L2_4(L3_4, L4_4, L5_4)
    end
    L2_3(L3_3, L4_3, L5_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getFundsBalance"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "employee_management"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT SUM(CASE WHEN transaction_type IN (\"income\", \"tax\", \"deposit\") THEN amount ELSE -amount END) as total_funds FROM government_transactions"
  L4_2 = {}
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = tonumber
    L2_3 = A0_3[1]
    if L2_3 then
      L2_3 = A0_3[1]
      L2_3 = L2_3.total_funds
      if L2_3 then
        goto lbl_10
      end
    end
    L2_3 = 0
    ::lbl_10::
    L1_3 = L1_3(L2_3)
    L2_3 = Utils
    L2_3 = L2_3.DebugPrint
    L3_3 = "Total funds calculated: $"
    L4_3 = L1_3
    L3_3 = L3_3 .. L4_3
    L2_3(L3_3)
    L2_3 = MySQL
    L2_3 = L2_3.query
    L3_3 = "SELECT transaction_type, amount, description FROM government_transactions ORDER BY created_at DESC LIMIT 5"
    L4_3 = {}
    function L5_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4
      L1_4 = Utils
      L1_4 = L1_4.DebugPrint
      L2_4 = "Recent transactions:"
      L1_4(L2_4)
      L1_4 = ipairs
      L2_4 = A0_4
      L1_4, L2_4, L3_4, L4_4 = L1_4(L2_4)
      for L5_4, L6_4 in L1_4, L2_4, L3_4, L4_4 do
        L7_4 = Utils
        L7_4 = L7_4.DebugPrint
        L8_4 = "  "
        L9_4 = L6_4.transaction_type
        L10_4 = ": $"
        L11_4 = L6_4.amount
        L12_4 = " - "
        L13_4 = L6_4.description
        L8_4 = L8_4 .. L9_4 .. L10_4 .. L11_4 .. L12_4 .. L13_4
        L7_4(L8_4)
      end
    end
    L2_3(L3_3, L4_3, L5_3)
    L2_3 = TriggerClientEvent
    L3_3 = "fs-government:client:receiveFundsBalance"
    L4_3 = L0_2
    L5_3 = L1_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:withdrawFunds"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    return
  end
  L4_2 = tonumber
  L5_2 = A0_2
  L4_2 = L4_2(L5_2)
  A0_2 = L4_2
  if not A0_2 or A0_2 <= 0 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L2_2
    L6_2 = "Invalid amount specified"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L3_2.job
  L5_2 = L5_2.name
  L6_2 = L3_2.job
  L6_2 = L6_2.grade
  L7_2 = "employee_management"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L2_2
    L6_2 = "You do not have permission to withdraw funds"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT SUM(CASE WHEN transaction_type IN (\"income\", \"tax\", \"deposit\") THEN amount ELSE -amount END) as total_funds FROM government_transactions"
  L6_2 = {}
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L1_3 = tonumber
    L2_3 = A0_3[1]
    if L2_3 then
      L2_3 = A0_3[1]
      L2_3 = L2_3.total_funds
      if L2_3 then
        goto lbl_10
      end
    end
    L2_3 = 0
    ::lbl_10::
    L1_3 = L1_3(L2_3)
    L2_3 = A0_2
    if L1_3 < L2_3 then
      L2_3 = Framework
      L2_3 = L2_3.ShowNotification
      L3_3 = L2_2
      L4_3 = "Insufficient government funds. Available: $"
      L5_3 = L1_3
      L4_3 = L4_3 .. L5_3
      L5_3 = "error"
      L2_3(L3_3, L4_3, L5_3)
      return
    end
    L2_3 = Framework
    L2_3 = L2_3.AddMoney
    L3_3 = L2_2
    L4_3 = A0_2
    L5_3 = "bank"
    L2_3 = L2_3(L3_3, L4_3, L5_3)
    if L2_3 then
      L2_3 = MySQL
      L2_3 = L2_3.insert
      L3_3 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
      L4_3 = {}
      L5_3 = "withdrawal"
      L6_3 = A0_2
      L7_3 = "Funds withdrawn by "
      L8_3 = L3_2.name
      L9_3 = ": "
      L10_3 = A1_2
      L7_3 = L7_3 .. L8_3 .. L9_3 .. L10_3
      L8_3 = L3_2.identifier
      L9_3 = L3_2.identifier
      L4_3[1] = L5_3
      L4_3[2] = L6_3
      L4_3[3] = L7_3
      L4_3[4] = L8_3
      L4_3[5] = L9_3
      L2_3(L3_3, L4_3)
      L2_3 = Framework
      L2_3 = L2_3.ShowNotification
      L3_3 = L2_2
      L4_3 = "Successfully withdrew $"
      L5_3 = A0_2
      L6_3 = " from government funds"
      L4_3 = L4_3 .. L5_3 .. L6_3
      L5_3 = "success"
      L2_3(L3_3, L4_3, L5_3)
    else
      L2_3 = Framework
      L2_3 = L2_3.ShowNotification
      L3_3 = L2_2
      L4_3 = "Failed to process withdrawal"
      L5_3 = "error"
      L2_3(L3_3, L4_3, L5_3)
    end
  end
  L4_2(L5_2, L6_2, L7_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:depositFunds"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    return
  end
  L4_2 = tonumber
  L5_2 = A0_2
  L4_2 = L4_2(L5_2)
  A0_2 = L4_2
  if not A0_2 or A0_2 <= 0 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L2_2
    L6_2 = "Invalid amount specified"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L3_2.job
  L5_2 = L5_2.name
  L6_2 = L3_2.job
  L6_2 = L6_2.grade
  L7_2 = "employee_management"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L2_2
    L6_2 = "You do not have permission to deposit funds"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = L3_2.bank
  if not L4_2 then
    L4_2 = 0
  end
  if A0_2 > L4_2 then
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L2_2
    L7_2 = "Insufficient personal funds. Available: $"
    L8_2 = L4_2
    L7_2 = L7_2 .. L8_2
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
    return
  end
  L5_2 = Framework
  L5_2 = L5_2.RemoveMoney
  L6_2 = L2_2
  L7_2 = A0_2
  L8_2 = "bank"
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  if L5_2 then
    L5_2 = Utils
    L5_2 = L5_2.DebugPrint
    L6_2 = "Depositing $"
    L7_2 = A0_2
    L8_2 = " from "
    L9_2 = L3_2.name
    L6_2 = L6_2 .. L7_2 .. L8_2 .. L9_2
    L5_2(L6_2)
    L5_2 = tostring
    L6_2 = "deposit"
    L5_2 = L5_2(L6_2)
    L6_2 = "Funds deposited by "
    L7_2 = L3_2.name
    L8_2 = ": "
    L9_2 = A1_2
    L6_2 = L6_2 .. L7_2 .. L8_2 .. L9_2
    L7_2 = L3_2.identifier
    L8_2 = Utils
    L8_2 = L8_2.DebugPrint
    L9_2 = "Inserting deposit - type: \""
    L10_2 = L5_2
    L11_2 = "\", amount: "
    L12_2 = A0_2
    L9_2 = L9_2 .. L10_2 .. L11_2 .. L12_2
    L8_2(L9_2)
    L8_2 = MySQL
    L8_2 = L8_2.query
    L9_2 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
    L10_2 = {}
    L11_2 = L5_2
    L12_2 = A0_2
    L13_2 = L6_2
    L14_2 = L7_2
    L15_2 = L7_2
    L10_2[1] = L11_2
    L10_2[2] = L12_2
    L10_2[3] = L13_2
    L10_2[4] = L14_2
    L10_2[5] = L15_2
    function L11_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3
      if A0_3 then
        L1_3 = A0_3.insertId
        if L1_3 then
          L1_3 = Utils
          L1_3 = L1_3.DebugSuccess
          L2_3 = "Deposit transaction inserted with ID: "
          L3_3 = tostring
          L4_3 = A0_3.insertId
          L3_3 = L3_3(L4_3)
          L2_3 = L2_3 .. L3_3
          L1_3(L2_3)
      end
      else
        L1_3 = Utils
        L1_3 = L1_3.DebugError
        L2_3 = "Deposit insertion failed or no insertId returned"
        L1_3(L2_3)
      end
    end
    L8_2(L9_2, L10_2, L11_2)
    L8_2 = Framework
    L8_2 = L8_2.ShowNotification
    L9_2 = L2_2
    L10_2 = "Successfully deposited $"
    L11_2 = A0_2
    L12_2 = " to government funds"
    L10_2 = L10_2 .. L11_2 .. L12_2
    L11_2 = "success"
    L8_2(L9_2, L10_2, L11_2)
  else
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L2_2
    L7_2 = "Failed to process deposit"
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:logSurveillance"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    return
  end
  L4_2 = MySQL
  L4_2 = L4_2.insert
  L5_2 = "INSERT INTO government_surveillance_logs (camera_id, viewed_by, view_duration) VALUES (?, ?, ?)"
  L6_2 = {}
  L7_2 = A0_2
  L8_2 = L3_2.identifier
  L9_2 = A1_2
  L6_2[1] = L7_2
  L6_2[2] = L8_2
  L6_2[3] = L9_2
  L4_2(L5_2, L6_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:checkLicenses"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  if not L2_2 or not L3_2 then
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L2_2.job
  L5_2 = L5_2.name
  L6_2 = L2_2.job
  L6_2 = L6_2.grade
  L7_2 = "license_management"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L1_2
    L6_2 = "You do not have permission to check licenses"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = Framework
  L4_2 = L4_2.GetFramework
  L4_2 = L4_2()
  if "esx" == L4_2 then
    L5_2 = GetResourceState
    L6_2 = "esx_license"
    L5_2 = L5_2(L6_2)
    if "started" == L5_2 then
      L5_2 = TriggerEvent
      L6_2 = "esx_license:getLicenses"
      L7_2 = A0_2
      function L8_2(A0_3)
        local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
        L1_3 = {}
        L2_3 = ipairs
        L3_3 = A0_3
        L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
        for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
          L8_3 = table
          L8_3 = L8_3.insert
          L9_3 = L1_3
          L10_3 = {}
          L11_3 = L7_3.type
          L10_3.type = L11_3
          L11_3 = L7_3.type
          L12_3 = L11_3
          L11_3 = L11_3.gsub
          L13_3 = "_"
          L14_3 = " "
          L11_3 = L11_3(L12_3, L13_3, L14_3)
          L12_3 = L11_3
          L11_3 = L11_3.upper
          L11_3 = L11_3(L12_3)
          L10_3.label = L11_3
          L8_3(L9_3, L10_3)
        end
        L2_3 = TriggerClientEvent
        L3_3 = "fs-government:client:showPlayerLicenses"
        L4_3 = L1_2
        L5_3 = {}
        L6_3 = L3_2.name
        L5_3.playerName = L6_3
        L6_3 = A0_2
        L5_3.playerId = L6_3
        L5_3.licenses = L1_3
        L2_3(L3_3, L4_3, L5_3)
      end
      L5_2(L6_2, L7_2, L8_2)
    else
      L5_2 = MySQL
      L5_2 = L5_2.query
      L6_2 = "SELECT * FROM user_licenses WHERE owner = ?"
      L7_2 = {}
      L8_2 = L3_2.identifier
      L7_2[1] = L8_2
      function L8_2(A0_3)
        local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
        L1_3 = {}
        L2_3 = ipairs
        L3_3 = A0_3
        L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
        for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
          L8_3 = table
          L8_3 = L8_3.insert
          L9_3 = L1_3
          L10_3 = {}
          L11_3 = L7_3.type
          L10_3.type = L11_3
          L11_3 = L7_3.type
          L12_3 = L11_3
          L11_3 = L11_3.gsub
          L13_3 = "_"
          L14_3 = " "
          L11_3 = L11_3(L12_3, L13_3, L14_3)
          L12_3 = L11_3
          L11_3 = L11_3.upper
          L11_3 = L11_3(L12_3)
          L10_3.label = L11_3
          L8_3(L9_3, L10_3)
        end
        L2_3 = TriggerClientEvent
        L3_3 = "fs-government:client:showPlayerLicenses"
        L4_3 = L1_2
        L5_3 = {}
        L6_3 = L3_2.name
        L5_3.playerName = L6_3
        L6_3 = A0_2
        L5_3.playerId = L6_3
        L5_3.licenses = L1_3
        L2_3(L3_3, L4_3, L5_3)
      end
      L5_2(L6_2, L7_2, L8_2)
    end
  elseif "qbcore" == L4_2 or "qbox" == L4_2 then
    L5_2 = exports
    L5_2 = L5_2["qb-core"]
    L6_2 = L5_2
    L5_2 = L5_2.GetCoreObject
    L5_2 = L5_2(L6_2)
    L6_2 = L5_2.Functions
    L6_2 = L6_2.GetPlayer
    L7_2 = A0_2
    L6_2 = L6_2(L7_2)
    L7_2 = {}
    if L6_2 then
      L8_2 = L6_2.PlayerData
      L8_2 = L8_2.metadata
      if L8_2 then
        L8_2 = L6_2.PlayerData
        L8_2 = L8_2.metadata
        L8_2 = L8_2.licences
        if L8_2 then
          L8_2 = pairs
          L9_2 = L6_2.PlayerData
          L9_2 = L9_2.metadata
          L9_2 = L9_2.licences
          L8_2, L9_2, L10_2, L11_2 = L8_2(L9_2)
          for L12_2, L13_2 in L8_2, L9_2, L10_2, L11_2 do
            if L13_2 then
              L14_2 = table
              L14_2 = L14_2.insert
              L15_2 = L7_2
              L16_2 = {}
              L16_2.type = L12_2
              L18_2 = L12_2
              L17_2 = L12_2.gsub
              L19_2 = "_"
              L20_2 = " "
              L17_2 = L17_2(L18_2, L19_2, L20_2)
              L18_2 = L17_2
              L17_2 = L17_2.upper
              L17_2 = L17_2(L18_2)
              L16_2.label = L17_2
              L14_2(L15_2, L16_2)
            end
          end
        end
      end
    end
    L8_2 = TriggerClientEvent
    L9_2 = "fs-government:client:showPlayerLicenses"
    L10_2 = L1_2
    L11_2 = {}
    L12_2 = L3_2.name
    L11_2.playerName = L12_2
    L11_2.playerId = A0_2
    L11_2.licenses = L7_2
    L8_2(L9_2, L10_2, L11_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getPlayerLicensesForRevoke"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2
  L1_2 = source
  L2_2 = Utils
  L2_2 = L2_2.DebugPrint
  L3_2 = "Server: getPlayerLicensesForRevoke called - Source:"
  L4_2 = L1_2
  L5_2 = "Target:"
  L6_2 = A0_2
  L2_2(L3_2, L4_2, L5_2, L6_2)
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  L4_2 = Utils
  L4_2 = L4_2.DebugPrint
  L5_2 = "Server: Player data - Officer:"
  if L2_2 then
    L6_2 = L2_2.name
    if L6_2 then
      goto lbl_26
    end
  end
  L6_2 = "nil"
  ::lbl_26::
  L7_2 = "Target:"
  if L3_2 then
    L8_2 = L3_2.name
    if L8_2 then
      goto lbl_33
    end
  end
  L8_2 = "nil"
  ::lbl_33::
  L4_2(L5_2, L6_2, L7_2, L8_2)
  if not L2_2 or not L3_2 then
    L4_2 = Utils
    L4_2 = L4_2.DebugError
    L5_2 = "Server: Missing player data"
    L4_2(L5_2)
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L2_2.job
  L5_2 = L5_2.name
  L6_2 = L2_2.job
  L6_2 = L6_2.grade
  L7_2 = "license_management"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Utils
    L4_2 = L4_2.DebugWarn
    L5_2 = "Server: No permission for license management"
    L4_2(L5_2)
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L1_2
    L6_2 = "You do not have permission to revoke licenses"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.DebugSuccess
  L5_2 = "Server: Permission check passed"
  L4_2(L5_2)
  L4_2 = Framework
  L4_2 = L4_2.GetFramework
  L4_2 = L4_2()
  L5_2 = Utils
  L5_2 = L5_2.DebugPrint
  L6_2 = "Server: Framework detected:"
  L7_2 = L4_2
  L5_2(L6_2, L7_2)
  if "esx" == L4_2 then
    L5_2 = Utils
    L5_2 = L5_2.DebugPrint
    L6_2 = "Server: Processing ESX framework"
    L5_2(L6_2)
    L5_2 = GetResourceState
    L6_2 = "esx_license"
    L5_2 = L5_2(L6_2)
    if "started" == L5_2 then
      L5_2 = Utils
      L5_2 = L5_2.DebugPrint
      L6_2 = "Server: Using esx_license resource"
      L5_2(L6_2)
      L5_2 = TriggerEvent
      L6_2 = "esx_license:getLicenses"
      L7_2 = A0_2
      function L8_2(A0_3)
        local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
        L1_3 = Utils
        L1_3 = L1_3.DebugPrint
        L2_3 = "Server: ESX esx_license returned:"
        L3_3 = json
        L3_3 = L3_3.encode
        L4_3 = A0_3
        L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L3_3(L4_3)
        L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
        L1_3 = {}
        L2_3 = ipairs
        L3_3 = A0_3
        L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
        for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
          L8_3 = table
          L8_3 = L8_3.insert
          L9_3 = L1_3
          L10_3 = {}
          L11_3 = L7_3.type
          L10_3.type = L11_3
          L11_3 = L7_3.type
          L12_3 = L11_3
          L11_3 = L11_3.gsub
          L13_3 = "_"
          L14_3 = " "
          L11_3 = L11_3(L12_3, L13_3, L14_3)
          L12_3 = L11_3
          L11_3 = L11_3.upper
          L11_3 = L11_3(L12_3)
          L10_3.label = L11_3
          L8_3(L9_3, L10_3)
        end
        L2_3 = Utils
        L2_3 = L2_3.DebugPrint
        L3_3 = "Server: Sending"
        L4_3 = #L1_3
        L5_3 = "formatted licenses to client"
        L2_3(L3_3, L4_3, L5_3)
        L2_3 = TriggerClientEvent
        L3_3 = "fs-government:client:showLicensesForRevoke"
        L4_3 = L1_2
        L5_3 = L1_3
        L2_3(L3_3, L4_3, L5_3)
      end
      L5_2(L6_2, L7_2, L8_2)
    else
      L5_2 = Utils
      L5_2 = L5_2.DebugPrint
      L6_2 = "Server: Using direct database query for ESX"
      L5_2(L6_2)
      L5_2 = MySQL
      L5_2 = L5_2.query
      L6_2 = "SELECT * FROM user_licenses WHERE owner = ?"
      L7_2 = {}
      L8_2 = L3_2.identifier
      L7_2[1] = L8_2
      function L8_2(A0_3)
        local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
        L1_3 = Utils
        L1_3 = L1_3.DebugPrint
        L2_3 = "Server: Database returned:"
        L3_3 = json
        L3_3 = L3_3.encode
        L4_3 = A0_3
        L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L3_3(L4_3)
        L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
        L1_3 = {}
        L2_3 = ipairs
        L3_3 = A0_3
        L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
        for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
          L8_3 = table
          L8_3 = L8_3.insert
          L9_3 = L1_3
          L10_3 = {}
          L11_3 = L7_3.type
          L10_3.type = L11_3
          L11_3 = L7_3.type
          L12_3 = L11_3
          L11_3 = L11_3.gsub
          L13_3 = "_"
          L14_3 = " "
          L11_3 = L11_3(L12_3, L13_3, L14_3)
          L12_3 = L11_3
          L11_3 = L11_3.upper
          L11_3 = L11_3(L12_3)
          L10_3.label = L11_3
          L8_3(L9_3, L10_3)
        end
        L2_3 = Utils
        L2_3 = L2_3.DebugPrint
        L3_3 = "Server: Sending"
        L4_3 = #L1_3
        L5_3 = "formatted licenses to client"
        L2_3(L3_3, L4_3, L5_3)
        L2_3 = TriggerClientEvent
        L3_3 = "fs-government:client:showLicensesForRevoke"
        L4_3 = L1_2
        L5_3 = L1_3
        L2_3(L3_3, L4_3, L5_3)
      end
      L5_2(L6_2, L7_2, L8_2)
    end
  elseif "qbcore" == L4_2 or "qbox" == L4_2 then
    L5_2 = Utils
    L5_2 = L5_2.DebugPrint
    L6_2 = "Server: Processing QBCore/QBox framework"
    L5_2(L6_2)
    L5_2 = exports
    L5_2 = L5_2["qb-core"]
    L6_2 = L5_2
    L5_2 = L5_2.GetCoreObject
    L5_2 = L5_2(L6_2)
    L6_2 = L5_2.Functions
    L6_2 = L6_2.GetPlayer
    L7_2 = A0_2
    L6_2 = L6_2(L7_2)
    L7_2 = Utils
    L7_2 = L7_2.DebugPrint
    L8_2 = "Server: QBTarget found:"
    if L6_2 then
      L9_2 = true
      if L9_2 then
        goto lbl_136
      end
    end
    L9_2 = false
    ::lbl_136::
    L7_2(L8_2, L9_2)
    L7_2 = {}
    if L6_2 then
      L8_2 = L6_2.PlayerData
      L8_2 = L8_2.metadata
      if L8_2 then
        L8_2 = L6_2.PlayerData
        L8_2 = L8_2.metadata
        L8_2 = L8_2.licences
        if L8_2 then
          L8_2 = Utils
          L8_2 = L8_2.DebugPrint
          L9_2 = "Server: QBTarget licenses found:"
          L10_2 = json
          L10_2 = L10_2.encode
          L11_2 = L6_2.PlayerData
          L11_2 = L11_2.metadata
          L11_2 = L11_2.licences
          L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2 = L10_2(L11_2)
          L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2)
          L8_2 = pairs
          L9_2 = L6_2.PlayerData
          L9_2 = L9_2.metadata
          L9_2 = L9_2.licences
          L8_2, L9_2, L10_2, L11_2 = L8_2(L9_2)
          for L12_2, L13_2 in L8_2, L9_2, L10_2, L11_2 do
            L14_2 = Utils
            L14_2 = L14_2.DebugPrint
            L15_2 = "Server: Checking license:"
            L16_2 = L12_2
            L17_2 = L13_2
            L14_2(L15_2, L16_2, L17_2)
            if L13_2 then
              L14_2 = table
              L14_2 = L14_2.insert
              L15_2 = L7_2
              L16_2 = {}
              L16_2.type = L12_2
              L18_2 = L12_2
              L17_2 = L12_2.gsub
              L19_2 = "_"
              L20_2 = " "
              L17_2 = L17_2(L18_2, L19_2, L20_2)
              L18_2 = L17_2
              L17_2 = L17_2.upper
              L17_2 = L17_2(L18_2)
              L16_2.label = L17_2
              L14_2(L15_2, L16_2)
            end
          end
      end
    end
    else
      L8_2 = Utils
      L8_2 = L8_2.DebugWarn
      L9_2 = "Server: QBTarget has no license metadata"
      L8_2(L9_2)
    end
    L8_2 = Utils
    L8_2 = L8_2.DebugPrint
    L9_2 = "Server: Sending"
    L10_2 = #L7_2
    L11_2 = "formatted licenses to client"
    L8_2(L9_2, L10_2, L11_2)
    L8_2 = TriggerClientEvent
    L9_2 = "fs-government:client:showLicensesForRevoke"
    L10_2 = L1_2
    L11_2 = L7_2
    L8_2(L9_2, L10_2, L11_2)
  else
    L5_2 = Utils
    L5_2 = L5_2.DebugError
    L6_2 = "Server: Unknown framework:"
    L7_2 = L4_2
    L5_2(L6_2, L7_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:issueLicense"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  L5_2 = Framework
  L5_2 = L5_2.GetPlayerData
  L6_2 = A0_2
  L5_2 = L5_2(L6_2)
  if not L4_2 or not L5_2 then
    return
  end
  L6_2 = Utils
  L6_2 = L6_2.HasPermission
  L7_2 = L4_2.job
  L7_2 = L7_2.name
  L8_2 = L4_2.job
  L8_2 = L8_2.grade
  L9_2 = "license_management"
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  if not L6_2 then
    return
  end
  L6_2 = Framework
  L6_2 = L6_2.GetFramework
  L6_2 = L6_2()
  if "esx" == L6_2 then
    L7_2 = GetResourceState
    L8_2 = "esx_license"
    L7_2 = L7_2(L8_2)
    if "started" == L7_2 then
      L7_2 = TriggerEvent
      L8_2 = "esx_license:addLicense"
      L9_2 = A0_2
      L10_2 = A1_2
      function L11_2(A0_3)
        local L1_3, L2_3, L3_3, L4_3, L5_3
        if A0_3 then
          L1_3 = Framework
          L1_3 = L1_3.ShowNotification
          L2_3 = L3_2
          L3_3 = "License issued successfully"
          L4_3 = "success"
          L1_3(L2_3, L3_3, L4_3)
          L1_3 = Framework
          L1_3 = L1_3.ShowNotification
          L2_3 = A0_2
          L3_3 = "You have been issued a "
          L4_3 = A1_2
          L5_3 = " license"
          L3_3 = L3_3 .. L4_3 .. L5_3
          L4_3 = "success"
          L1_3(L2_3, L3_3, L4_3)
        end
      end
      L7_2(L8_2, L9_2, L10_2, L11_2)
    end
  elseif "qbcore" == L6_2 or "qbox" == L6_2 then
    L7_2 = MySQL
    L7_2 = L7_2.insert
    L8_2 = "INSERT INTO player_licenses (citizenid, type, status) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE status = VALUES(status)"
    L9_2 = {}
    L10_2 = L5_2.identifier
    L11_2 = A1_2
    L12_2 = "valid"
    L9_2[1] = L10_2
    L9_2[2] = L11_2
    L9_2[3] = L12_2
    L7_2(L8_2, L9_2)
    L7_2 = Framework
    L7_2 = L7_2.ShowNotification
    L8_2 = L3_2
    L9_2 = "License issued successfully"
    L10_2 = "success"
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = Framework
    L7_2 = L7_2.ShowNotification
    L8_2 = A0_2
    L9_2 = "You have been issued a "
    L10_2 = A1_2
    L11_2 = " license"
    L9_2 = L9_2 .. L10_2 .. L11_2
    L10_2 = "success"
    L7_2(L8_2, L9_2, L10_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:revokeLicense"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  L5_2 = Framework
  L5_2 = L5_2.GetPlayerData
  L6_2 = A0_2
  L5_2 = L5_2(L6_2)
  if not L4_2 or not L5_2 then
    L6_2 = Framework
    L6_2 = L6_2.ShowNotification
    L7_2 = L3_2
    L8_2 = "Player data not found"
    L9_2 = "error"
    L6_2(L7_2, L8_2, L9_2)
    return
  end
  L6_2 = Utils
  L6_2 = L6_2.HasPermission
  L7_2 = L4_2.job
  L7_2 = L7_2.name
  L8_2 = L4_2.job
  L8_2 = L8_2.grade
  L9_2 = "license_management"
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  if not L6_2 then
    L6_2 = Framework
    L6_2 = L6_2.ShowNotification
    L7_2 = L3_2
    L8_2 = "You do not have permission to revoke licenses"
    L9_2 = "error"
    L6_2(L7_2, L8_2, L9_2)
    return
  end
  L6_2 = Framework
  L6_2 = L6_2.GetFramework
  L6_2 = L6_2()
  L7_2 = A2_2 or L7_2
  if not A2_2 then
    L7_2 = "No reason provided"
  end
  if "esx" == L6_2 then
    L8_2 = GetResourceState
    L9_2 = "esx_license"
    L8_2 = L8_2(L9_2)
    if "started" == L8_2 then
      L8_2 = TriggerEvent
      L9_2 = "esx_license:removeLicense"
      L10_2 = A0_2
      L11_2 = A1_2
      function L12_2(A0_3)
        local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
        if A0_3 then
          L1_3 = Framework
          L1_3 = L1_3.ShowNotification
          L2_3 = L3_2
          L3_3 = "License revoked successfully"
          L4_3 = "success"
          L1_3(L2_3, L3_3, L4_3)
          L1_3 = Framework
          L1_3 = L1_3.ShowNotification
          L2_3 = A0_2
          L3_3 = "Your "
          L4_3 = A1_2
          L5_3 = " license has been revoked. Reason: "
          L6_3 = L7_2
          L3_3 = L3_3 .. L4_3 .. L5_3 .. L6_3
          L4_3 = "error"
          L1_3(L2_3, L3_3, L4_3)
        else
          L1_3 = Framework
          L1_3 = L1_3.ShowNotification
          L2_3 = L3_2
          L3_3 = "Failed to revoke license"
          L4_3 = "error"
          L1_3(L2_3, L3_3, L4_3)
        end
      end
      L8_2(L9_2, L10_2, L11_2, L12_2)
    else
      L8_2 = MySQL
      L8_2 = L8_2.execute
      L9_2 = "DELETE FROM user_licenses WHERE owner = ? AND type = ?"
      L10_2 = {}
      L11_2 = L5_2.identifier
      L12_2 = A1_2
      L10_2[1] = L11_2
      L10_2[2] = L12_2
      function L11_2(A0_3)
        local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
        if A0_3 > 0 then
          L1_3 = Framework
          L1_3 = L1_3.ShowNotification
          L2_3 = L3_2
          L3_3 = "License revoked successfully"
          L4_3 = "success"
          L1_3(L2_3, L3_3, L4_3)
          L1_3 = Framework
          L1_3 = L1_3.ShowNotification
          L2_3 = A0_2
          L3_3 = "Your "
          L4_3 = A1_2
          L5_3 = " license has been revoked. Reason: "
          L6_3 = L7_2
          L3_3 = L3_3 .. L4_3 .. L5_3 .. L6_3
          L4_3 = "error"
          L1_3(L2_3, L3_3, L4_3)
        else
          L1_3 = Framework
          L1_3 = L1_3.ShowNotification
          L2_3 = L3_2
          L3_3 = "License not found or already revoked"
          L4_3 = "error"
          L1_3(L2_3, L3_3, L4_3)
        end
      end
      L8_2(L9_2, L10_2, L11_2)
    end
  elseif "qbcore" == L6_2 or "qbox" == L6_2 then
    L8_2 = exports
    L8_2 = L8_2["qb-core"]
    L9_2 = L8_2
    L8_2 = L8_2.GetCoreObject
    L8_2 = L8_2(L9_2)
    L9_2 = L8_2.Functions
    L9_2 = L9_2.GetPlayer
    L10_2 = A0_2
    L9_2 = L9_2(L10_2)
    if L9_2 then
      L10_2 = false
      L11_2 = L9_2.PlayerData
      L11_2 = L11_2.metadata
      if L11_2 then
        L11_2 = L9_2.PlayerData
        L11_2 = L11_2.metadata
        L11_2 = L11_2.licences
        if L11_2 then
          L11_2 = L9_2.PlayerData
          L11_2 = L11_2.metadata
          L11_2 = L11_2.licences
          L11_2 = L11_2[A1_2]
          if L11_2 then
            L11_2 = L9_2.PlayerData
            L11_2 = L11_2.metadata
            L11_2 = L11_2.licences
            L11_2[A1_2] = false
            L11_2 = L9_2.Functions
            L11_2 = L11_2.SetMetaData
            L12_2 = "licences"
            L13_2 = L9_2.PlayerData
            L13_2 = L13_2.metadata
            L13_2 = L13_2.licences
            L11_2(L12_2, L13_2)
            L10_2 = true
          end
        end
      end
      L11_2 = MySQL
      L11_2 = L11_2.execute
      L12_2 = "DELETE FROM player_licenses WHERE citizenid = ? AND type = ?"
      L13_2 = {}
      L14_2 = L5_2.identifier
      L15_2 = A1_2
      L13_2[1] = L14_2
      L13_2[2] = L15_2
      L11_2(L12_2, L13_2)
      if L10_2 then
        L11_2 = Framework
        L11_2 = L11_2.ShowNotification
        L12_2 = L3_2
        L13_2 = "License revoked successfully"
        L14_2 = "success"
        L11_2(L12_2, L13_2, L14_2)
        L11_2 = Framework
        L11_2 = L11_2.ShowNotification
        L12_2 = A0_2
        L13_2 = "Your "
        L14_2 = A1_2
        L15_2 = " license has been revoked. Reason: "
        L16_2 = L7_2
        L13_2 = L13_2 .. L14_2 .. L15_2 .. L16_2
        L14_2 = "error"
        L11_2(L12_2, L13_2, L14_2)
      else
        L11_2 = Framework
        L11_2 = L11_2.ShowNotification
        L12_2 = L3_2
        L13_2 = "License not found or already revoked"
        L14_2 = "error"
        L11_2(L12_2, L13_2, L14_2)
      end
    else
      L10_2 = Framework
      L10_2 = L10_2.ShowNotification
      L11_2 = L3_2
      L12_2 = "Target player not found"
      L13_2 = "error"
      L10_2(L11_2, L12_2, L13_2)
    end
  end
end
L0_1(L1_1, L2_1)
