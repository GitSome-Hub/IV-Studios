local L0_1, L1_1, L2_1
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:seizeItem"
function L2_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2
  L4_2 = source
  L5_2 = Framework
  L5_2 = L5_2.GetPlayerData
  L6_2 = L4_2
  L5_2 = L5_2(L6_2)
  L6_2 = Framework
  L6_2 = L6_2.GetPlayerData
  L7_2 = A0_2
  L6_2 = L6_2(L7_2)
  if not L5_2 or not L6_2 then
    return
  end
  L7_2 = Utils
  L7_2 = L7_2.HasPermission
  L8_2 = L5_2.job
  L8_2 = L8_2.name
  L9_2 = L5_2.job
  L9_2 = L9_2.grade
  L10_2 = "seizure"
  L7_2 = L7_2(L8_2, L9_2, L10_2)
  if not L7_2 then
    L7_2 = Framework
    L7_2 = L7_2.ShowNotification
    L8_2 = L4_2
    L9_2 = "You do not have permission to seize items"
    L10_2 = "error"
    L7_2(L8_2, L9_2, L10_2)
    return
  end
  L7_2 = Inventory
  L7_2 = L7_2.GetItem
  L8_2 = A0_2
  L9_2 = A1_2
  L7_2 = L7_2(L8_2, L9_2)
  if not L7_2 then
    L8_2 = Framework
    L8_2 = L8_2.ShowNotification
    L9_2 = L4_2
    L10_2 = "Target does not have this item"
    L11_2 = "error"
    L8_2(L9_2, L10_2, L11_2)
    return
  end
  L8_2 = 0
  L9_2 = type
  L10_2 = L7_2
  L9_2 = L9_2(L10_2)
  if "number" == L9_2 then
    L8_2 = L7_2
  else
    L9_2 = L7_2.count
    if L9_2 then
      L8_2 = L7_2.count
    else
      L9_2 = L7_2.amount
      if L9_2 then
        L8_2 = L7_2.amount
      else
        L9_2 = L7_2.quantity
        if L9_2 then
          L8_2 = L7_2.quantity
        end
      end
    end
  end
  if A2_2 > L8_2 then
    L9_2 = Framework
    L9_2 = L9_2.ShowNotification
    L10_2 = L4_2
    L11_2 = "Target does not have enough of this item ("
    L12_2 = L8_2
    L13_2 = "/"
    L14_2 = A2_2
    L15_2 = ")"
    L11_2 = L11_2 .. L12_2 .. L13_2 .. L14_2 .. L15_2
    L12_2 = "error"
    L9_2(L10_2, L11_2, L12_2)
    return
  end
  L9_2 = Inventory
  L9_2 = L9_2.RemoveItem
  L10_2 = A0_2
  L11_2 = A1_2
  L12_2 = A2_2
  L9_2 = L9_2(L10_2, L11_2, L12_2)
  if L9_2 then
    L9_2 = {}
    L9_2.name = A1_2
    L9_2.amount = A2_2
    L10_2 = MySQL
    L10_2 = L10_2.insert
    L11_2 = "INSERT INTO government_seizures (target_identifier, target_name, item_type, item_identifier, item_description, reason, seized_by, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    L12_2 = {}
    L13_2 = L6_2.identifier
    L14_2 = L6_2.name
    L15_2 = "item"
    L16_2 = json
    L16_2 = L16_2.encode
    L17_2 = L9_2
    L16_2 = L16_2(L17_2)
    L17_2 = A2_2
    L18_2 = "x "
    L19_2 = A1_2
    L17_2 = L17_2 .. L18_2 .. L19_2
    L18_2 = A3_2
    L19_2 = L5_2.name
    L20_2 = "seized"
    L12_2[1] = L13_2
    L12_2[2] = L14_2
    L12_2[3] = L15_2
    L12_2[4] = L16_2
    L12_2[5] = L17_2
    L12_2[6] = L18_2
    L12_2[7] = L19_2
    L12_2[8] = L20_2
    L10_2(L11_2, L12_2)
    L10_2 = Framework
    L10_2 = L10_2.ShowNotification
    L11_2 = L4_2
    L12_2 = "Item seized successfully"
    L13_2 = "success"
    L10_2(L11_2, L12_2, L13_2)
    L10_2 = GetPlayers
    L10_2 = L10_2()
    L11_2 = ipairs
    L12_2 = L10_2
    L11_2, L12_2, L13_2, L14_2 = L11_2(L12_2)
    for L15_2, L16_2 in L11_2, L12_2, L13_2, L14_2 do
      L17_2 = tonumber
      L18_2 = L16_2
      L17_2 = L17_2(L18_2)
      L18_2 = TriggerClientEvent
      L19_2 = "fs-government:client:seizureAnnouncement"
      L20_2 = L17_2
      L21_2 = {}
      L22_2 = "\240\159\154\148 GOVERNMENT SEIZURE: "
      L23_2 = A2_2
      L24_2 = "x "
      L25_2 = A1_2
      L26_2 = " seized from "
      L27_2 = L6_2.name
      L22_2 = L22_2 .. L23_2 .. L24_2 .. L25_2 .. L26_2 .. L27_2
      L21_2.message = L22_2
      L21_2.type = "primary"
      L18_2(L19_2, L20_2, L21_2)
    end
  else
    L9_2 = Framework
    L9_2 = L9_2.ShowNotification
    L10_2 = L4_2
    L11_2 = "Failed to seize item"
    L12_2 = "error"
    L9_2(L10_2, L11_2, L12_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:seizeMoney"
function L2_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2
  L4_2 = source
  L5_2 = Framework
  L5_2 = L5_2.GetPlayerData
  L6_2 = L4_2
  L5_2 = L5_2(L6_2)
  L6_2 = Framework
  L6_2 = L6_2.GetPlayerData
  L7_2 = A0_2
  L6_2 = L6_2(L7_2)
  if not L5_2 or not L6_2 then
    L7_2 = Framework
    L7_2 = L7_2.ShowNotification
    L8_2 = L4_2
    L9_2 = "Failed to get player data"
    L10_2 = "error"
    L7_2(L8_2, L9_2, L10_2)
    return
  end
  L7_2 = Utils
  L7_2 = L7_2.HasPermission
  L8_2 = L5_2.job
  L8_2 = L8_2.name
  L9_2 = L5_2.job
  L9_2 = L9_2.grade
  L10_2 = "seizure"
  L7_2 = L7_2(L8_2, L9_2, L10_2)
  if not L7_2 then
    L7_2 = Framework
    L7_2 = L7_2.ShowNotification
    L8_2 = L4_2
    L9_2 = "You do not have permission to seize money"
    L10_2 = "error"
    L7_2(L8_2, L9_2, L10_2)
    return
  end
  L7_2 = Framework
  L7_2 = L7_2.GetPlayerMoney
  L8_2 = A0_2
  L9_2 = A2_2
  L7_2 = L7_2(L8_2, L9_2)
  if not L7_2 or A1_2 > L7_2 then
    L8_2 = Framework
    L8_2 = L8_2.ShowNotification
    L9_2 = L4_2
    L10_2 = "Target has insufficient funds. Available: $"
    L11_2 = L7_2 or L11_2
    if not L7_2 then
      L11_2 = 0
    end
    L12_2 = " ("
    L13_2 = A2_2
    L14_2 = ")"
    L10_2 = L10_2 .. L11_2 .. L12_2 .. L13_2 .. L14_2
    L11_2 = "error"
    L8_2(L9_2, L10_2, L11_2)
    return
  end
  L8_2 = Framework
  L8_2 = L8_2.RemoveMoney
  L9_2 = A0_2
  L10_2 = A1_2
  L11_2 = A2_2
  L8_2 = L8_2(L9_2, L10_2, L11_2)
  if L8_2 then
    L9_2 = {}
    L9_2.amount = A1_2
    L9_2.account = A2_2
    L10_2 = MySQL
    L10_2 = L10_2.insert
    L11_2 = "INSERT INTO government_seizures (target_identifier, target_name, item_type, item_identifier, item_description, reason, seized_by, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    L12_2 = {}
    L13_2 = L6_2.identifier
    L14_2 = L6_2.name
    L15_2 = "money"
    L16_2 = json
    L16_2 = L16_2.encode
    L17_2 = L9_2
    L16_2 = L16_2(L17_2)
    L17_2 = Utils
    L17_2 = L17_2.FormatMoney
    L18_2 = A1_2
    L17_2 = L17_2(L18_2)
    L18_2 = " from "
    L19_2 = A2_2
    L17_2 = L17_2 .. L18_2 .. L19_2
    L18_2 = A3_2
    L19_2 = L5_2.name
    L20_2 = "seized"
    L12_2[1] = L13_2
    L12_2[2] = L14_2
    L12_2[3] = L15_2
    L12_2[4] = L16_2
    L12_2[5] = L17_2
    L12_2[6] = L18_2
    L12_2[7] = L19_2
    L12_2[8] = L20_2
    L10_2(L11_2, L12_2)
    L10_2 = MySQL
    L10_2 = L10_2.insert
    L11_2 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
    L12_2 = {}
    L13_2 = "income"
    L14_2 = A1_2
    L15_2 = "Money seizure: "
    L16_2 = A3_2
    L15_2 = L15_2 .. L16_2
    L16_2 = L6_2.identifier
    L17_2 = L5_2.identifier
    L12_2[1] = L13_2
    L12_2[2] = L14_2
    L12_2[3] = L15_2
    L12_2[4] = L16_2
    L12_2[5] = L17_2
    L10_2(L11_2, L12_2)
    L10_2 = Framework
    L10_2 = L10_2.ShowNotification
    L11_2 = L4_2
    L12_2 = "Money seized successfully"
    L13_2 = "success"
    L10_2(L11_2, L12_2, L13_2)
    L10_2 = GetPlayers
    L10_2 = L10_2()
    L11_2 = ipairs
    L12_2 = L10_2
    L11_2, L12_2, L13_2, L14_2 = L11_2(L12_2)
    for L15_2, L16_2 in L11_2, L12_2, L13_2, L14_2 do
      L17_2 = tonumber
      L18_2 = L16_2
      L17_2 = L17_2(L18_2)
      L18_2 = TriggerClientEvent
      L19_2 = "fs-government:client:seizureAnnouncement"
      L20_2 = L17_2
      L21_2 = {}
      L22_2 = "\240\159\154\148 GOVERNMENT SEIZURE: "
      L23_2 = Utils
      L23_2 = L23_2.FormatMoney
      L24_2 = A1_2
      L23_2 = L23_2(L24_2)
      L24_2 = " ("
      L25_2 = A2_2
      L26_2 = ") seized from "
      L27_2 = L6_2.name
      L22_2 = L22_2 .. L23_2 .. L24_2 .. L25_2 .. L26_2 .. L27_2
      L21_2.message = L22_2
      L21_2.type = "primary"
      L18_2(L19_2, L20_2, L21_2)
    end
  else
    L9_2 = Framework
    L9_2 = L9_2.ShowNotification
    L10_2 = L4_2
    L11_2 = "Failed to seize money - insufficient funds"
    L12_2 = "error"
    L9_2(L10_2, L11_2, L12_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getSeizures"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "seizure"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view seizures"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_seizures WHERE status = ? ORDER BY created_at DESC"
  L4_2 = {}
  L5_2 = "seized"
  L4_2[1] = L5_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L0_2
      L3_3 = "No active seizures found"
      L4_3 = "primary"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = Config
      L7_3 = L7_3.Debug
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "Raw created_at: "
        L9_3 = tostring
        L10_3 = L6_3.created_at
        L9_3 = L9_3(L10_3)
        L10_3 = " (type: "
        L11_3 = type
        L12_3 = L6_3.created_at
        L11_3 = L11_3(L12_3)
        L12_3 = ")"
        L8_3 = L8_3 .. L9_3 .. L10_3 .. L11_3 .. L12_3
        L7_3(L8_3)
      end
      L7_3 = Utils
      L7_3 = L7_3.FormatDate
      L8_3 = L6_3.created_at
      L7_3 = L7_3(L8_3)
      L6_3.formatted_date = L7_3
      L7_3 = L6_3.returned_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.returned_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_returned_date = L7_3
      end
      L7_3 = L6_3.deleted_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.deleted_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_deleted_date = L7_3
      end
      L7_3 = Config
      L7_3 = L7_3.Debug
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "Formatted date: "
        L9_3 = tostring
        L10_3 = L6_3.formatted_date
        L9_3 = L9_3(L10_3)
        L8_3 = L8_3 .. L9_3
        L7_3(L8_3)
      end
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showSeizures"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getSeizureHistory"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "seizure"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view seizure history"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_seizures ORDER BY created_at DESC LIMIT 50"
  L4_2 = {}
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = Config
      L7_3 = L7_3.Debug
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "Raw created_at: "
        L9_3 = tostring
        L10_3 = L6_3.created_at
        L9_3 = L9_3(L10_3)
        L10_3 = " (type: "
        L11_3 = type
        L12_3 = L6_3.created_at
        L11_3 = L11_3(L12_3)
        L12_3 = ")"
        L8_3 = L8_3 .. L9_3 .. L10_3 .. L11_3 .. L12_3
        L7_3(L8_3)
      end
      L7_3 = Utils
      L7_3 = L7_3.FormatDate
      L8_3 = L6_3.created_at
      L7_3 = L7_3(L8_3)
      L6_3.formatted_date = L7_3
      L7_3 = L6_3.returned_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.returned_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_returned_date = L7_3
      end
      L7_3 = L6_3.deleted_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.deleted_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_deleted_date = L7_3
      end
      L7_3 = Config
      L7_3 = L7_3.Debug
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "Formatted date: "
        L9_3 = tostring
        L10_3 = L6_3.formatted_date
        L9_3 = L9_3(L10_3)
        L8_3 = L8_3 .. L9_3
        L7_3(L8_3)
      end
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showSeizureHistory"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:searchSeizures"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L2_2.job
  L4_2 = L4_2.name
  L5_2 = L2_2.job
  L5_2 = L5_2.grade
  L6_2 = "seizure"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if not L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = L1_2
    L5_2 = "You do not have permission to search seizures"
    L6_2 = "error"
    L3_2(L4_2, L5_2, L6_2)
    return
  end
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT * FROM government_seizures WHERE target_name LIKE ? OR item_description LIKE ? OR reason LIKE ? ORDER BY created_at DESC LIMIT 25"
  L5_2 = {}
  L6_2 = "%"
  L7_2 = A0_2
  L8_2 = "%"
  L6_2 = L6_2 .. L7_2 .. L8_2
  L7_2 = "%"
  L8_2 = A0_2
  L9_2 = "%"
  L7_2 = L7_2 .. L8_2 .. L9_2
  L8_2 = "%"
  L9_2 = A0_2
  L10_2 = "%"
  L8_2 = L8_2 .. L9_2 .. L10_2
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  L5_2[3] = L8_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L1_2
      L3_3 = "No seizures found matching: "
      L4_3 = A0_2
      L3_3 = L3_3 .. L4_3
      L4_3 = "primary"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = Config
      L7_3 = L7_3.Debug
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "Raw created_at: "
        L9_3 = tostring
        L10_3 = L6_3.created_at
        L9_3 = L9_3(L10_3)
        L10_3 = " (type: "
        L11_3 = type
        L12_3 = L6_3.created_at
        L11_3 = L11_3(L12_3)
        L12_3 = ")"
        L8_3 = L8_3 .. L9_3 .. L10_3 .. L11_3 .. L12_3
        L7_3(L8_3)
      end
      L7_3 = Utils
      L7_3 = L7_3.FormatDate
      L8_3 = L6_3.created_at
      L7_3 = L7_3(L8_3)
      L6_3.formatted_date = L7_3
      L7_3 = L6_3.returned_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.returned_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_returned_date = L7_3
      end
      L7_3 = L6_3.deleted_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.deleted_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_deleted_date = L7_3
      end
      L7_3 = Config
      L7_3 = L7_3.Debug
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "Formatted date: "
        L9_3 = tostring
        L10_3 = L6_3.formatted_date
        L9_3 = L9_3(L10_3)
        L8_3 = L8_3 .. L9_3
        L7_3(L8_3)
      end
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showSeizures"
    L3_3 = L1_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L3_2(L4_2, L5_2, L6_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:returnSeizure"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L2_2.job
  L4_2 = L4_2.name
  L5_2 = L2_2.job
  L5_2 = L5_2.grade
  L6_2 = "seizure"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if not L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = L1_2
    L5_2 = "You do not have permission to return seizures"
    L6_2 = "error"
    L3_2(L4_2, L5_2, L6_2)
    return
  end
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT * FROM government_seizures WHERE id = ? AND status = ?"
  L5_2 = {}
  L6_2 = A0_2
  L7_2 = "seized"
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3
    L1_3 = A0_3[1]
    if not L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L1_2
      L3_3 = "Seizure not found or already processed"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = A0_3[1]
    L2_3 = MySQL
    L2_3 = L2_3.execute
    L3_3 = "UPDATE government_seizures SET status = ?, returned_by = ?, returned_at = ? WHERE id = ?"
    L4_3 = {}
    L5_3 = "returned"
    L6_3 = L2_2.identifier
    L7_3 = os
    L7_3 = L7_3.date
    L8_3 = "%Y-%m-%d %H:%M:%S"
    L7_3 = L7_3(L8_3)
    L8_3 = A0_2
    L4_3[1] = L5_3
    L4_3[2] = L6_3
    L4_3[3] = L7_3
    L4_3[4] = L8_3
    L2_3(L3_3, L4_3)
    L2_3 = MySQL
    L2_3 = L2_3.insert
    L3_3 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
    L4_3 = {}
    L5_3 = "refund"
    L6_3 = 0
    L7_3 = "Asset return: "
    L8_3 = L1_3.item_description
    L7_3 = L7_3 .. L8_3
    L8_3 = L1_3.target_identifier
    L9_3 = L2_2.identifier
    L4_3[1] = L5_3
    L4_3[2] = L6_3
    L4_3[3] = L7_3
    L4_3[4] = L8_3
    L4_3[5] = L9_3
    L2_3(L3_3, L4_3)
    L2_3 = GetPlayers
    L2_3 = L2_3()
    L3_3 = false
    L4_3 = ipairs
    L5_3 = L2_3
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      L10_3 = Framework
      L10_3 = L10_3.GetPlayerData
      L11_3 = tonumber
      L12_3 = L9_3
      L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3 = L11_3(L12_3)
      L10_3 = L10_3(L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3)
      if L10_3 then
        L11_3 = L10_3.identifier
        L12_3 = L1_3.target_identifier
        if L11_3 == L12_3 then
          L3_3 = true
          L11_3 = false
          L12_3 = L1_3.item_type
          if "item" == L12_3 then
            L12_3 = L1_3.item_identifier
            L13_3 = 1
            L14_3 = nil
            L15_3 = pcall
            L16_3 = json
            L16_3 = L16_3.decode
            L17_3 = L1_3.item_identifier
            L15_3, L16_3 = L15_3(L16_3, L17_3)
            if L15_3 and L16_3 then
              L17_3 = L16_3.name
              if L17_3 then
                L17_3 = L16_3.amount
                if L17_3 then
                  L12_3 = L16_3.name
                  L13_3 = L16_3.amount
                  L17_3 = Utils
                  L17_3 = L17_3.DebugSuccess
                  L18_3 = "Parsed JSON item data: "
                  L19_3 = L12_3
                  L20_3 = " x"
                  L21_3 = L13_3
                  L18_3 = L18_3 .. L19_3 .. L20_3 .. L21_3
                  L17_3(L18_3)
              end
            end
            else
              L12_3 = L1_3.item_identifier
              L17_3 = string
              L17_3 = L17_3.match
              L18_3 = L1_3.item_description
              L19_3 = "(%d+)x"
              L17_3 = L17_3(L18_3, L19_3)
              if not L17_3 then
                L17_3 = string
                L17_3 = L17_3.match
                L18_3 = L1_3.item_description
                L19_3 = "x(%d+)"
                L17_3 = L17_3(L18_3, L19_3)
              end
              if L17_3 then
                L18_3 = tonumber
                L19_3 = L17_3
                L18_3 = L18_3(L19_3)
                L13_3 = L18_3 or L13_3
                if not L18_3 then
                  L13_3 = 1
                end
              end
              L18_3 = Utils
              L18_3 = L18_3.DebugPrint
              L19_3 = "Using fallback parsing for item: "
              L20_3 = L12_3
              L21_3 = " x"
              L22_3 = L13_3
              L19_3 = L19_3 .. L20_3 .. L21_3 .. L22_3
              L18_3(L19_3)
            end
            L17_3 = Inventory
            L17_3 = L17_3.AddItem
            L18_3 = tonumber
            L19_3 = L9_3
            L18_3 = L18_3(L19_3)
            L19_3 = L12_3
            L20_3 = L13_3
            L17_3 = L17_3(L18_3, L19_3, L20_3)
            L11_3 = L17_3
            if L11_3 then
              L17_3 = Utils
              L17_3 = L17_3.DebugSuccess
              L18_3 = "Returned "
              L19_3 = L13_3
              L20_3 = "x "
              L21_3 = L12_3
              L22_3 = " to "
              L23_3 = L10_3.name
              L18_3 = L18_3 .. L19_3 .. L20_3 .. L21_3 .. L22_3 .. L23_3
              L17_3(L18_3)
            else
              L17_3 = Utils
              L17_3 = L17_3.DebugWarn
              L18_3 = "Failed to return item "
              L19_3 = L12_3
              L20_3 = " to "
              L21_3 = L10_3.name
              L18_3 = L18_3 .. L19_3 .. L20_3 .. L21_3
              L17_3(L18_3)
            end
          else
            L12_3 = L1_3.item_type
            if "money" == L12_3 then
              L12_3 = 0
              L13_3 = "cash"
              L14_3 = pcall
              L15_3 = json
              L15_3 = L15_3.decode
              L16_3 = L1_3.item_identifier
              L14_3, L15_3 = L14_3(L15_3, L16_3)
              if L14_3 and L15_3 then
                L16_3 = L15_3.amount
                if L16_3 then
                  L16_3 = L15_3.account
                  if L16_3 then
                    L16_3 = tonumber
                    L17_3 = L15_3.amount
                    L16_3 = L16_3(L17_3)
                    L12_3 = L16_3
                    L13_3 = L15_3.account
                    L16_3 = Utils
                    L16_3 = L16_3.DebugSuccess
                    L17_3 = "Parsed JSON money data: $"
                    L18_3 = L12_3
                    L19_3 = " ("
                    L20_3 = L13_3
                    L21_3 = ")"
                    L17_3 = L17_3 .. L18_3 .. L19_3 .. L20_3 .. L21_3
                    L16_3(L17_3)
                end
              end
              else
                L16_3 = string
                L16_3 = L16_3.match
                L17_3 = L1_3.item_description
                L18_3 = "%$([%d,]+)"
                L16_3 = L16_3(L17_3, L18_3)
                if not L16_3 then
                  L16_3 = string
                  L16_3 = L16_3.match
                  L17_3 = L1_3.item_description
                  L18_3 = "([%d,]+)"
                  L16_3 = L16_3(L17_3, L18_3)
                end
                if L16_3 then
                  L17_3 = tonumber
                  L18_3 = string
                  L18_3 = L18_3.gsub
                  L19_3 = L16_3
                  L20_3 = ","
                  L21_3 = ""
                  L18_3, L19_3, L20_3, L21_3, L22_3, L23_3 = L18_3(L19_3, L20_3, L21_3)
                  L17_3 = L17_3(L18_3, L19_3, L20_3, L21_3, L22_3, L23_3)
                  L12_3 = L17_3
                  L17_3 = L1_3.item_identifier
                  if L17_3 then
                    L17_3 = L1_3.item_identifier
                    if "" ~= L17_3 then
                      L17_3 = L1_3.item_identifier
                      if L17_3 then
                        goto lbl_221
                        L13_3 = L17_3 or L13_3
                      end
                    end
                  end
                  L13_3 = "cash"
                end
                ::lbl_221::
                L17_3 = Utils
                L17_3 = L17_3.DebugPrint
                L18_3 = "Using fallback parsing for money: $"
                L19_3 = L12_3 or L19_3
                if not L12_3 then
                  L19_3 = 0
                end
                L20_3 = " ("
                L21_3 = L13_3
                L22_3 = ")"
                L18_3 = L18_3 .. L19_3 .. L20_3 .. L21_3 .. L22_3
                L17_3(L18_3)
              end
              if L12_3 and L12_3 > 0 then
                L16_3 = Framework
                L16_3 = L16_3.AddMoney
                L17_3 = tonumber
                L18_3 = L9_3
                L17_3 = L17_3(L18_3)
                L18_3 = L12_3
                L19_3 = L13_3
                L16_3 = L16_3(L17_3, L18_3, L19_3)
                L11_3 = L16_3
                if L11_3 then
                  L16_3 = Utils
                  L16_3 = L16_3.DebugSuccess
                  L17_3 = "Returned $"
                  L18_3 = L12_3
                  L19_3 = " ("
                  L20_3 = L13_3
                  L21_3 = ") to "
                  L22_3 = L10_3.name
                  L17_3 = L17_3 .. L18_3 .. L19_3 .. L20_3 .. L21_3 .. L22_3
                  L16_3(L17_3)
                else
                  L16_3 = Utils
                  L16_3 = L16_3.DebugWarn
                  L17_3 = "Failed to return money to "
                  L18_3 = L10_3.name
                  L17_3 = L17_3 .. L18_3
                  L16_3(L17_3)
                end
              end
            else
              L12_3 = L1_3.item_type
              if "vehicle" == L12_3 then
                L11_3 = true
                L12_3 = Utils
                L12_3 = L12_3.DebugSuccess
                L13_3 = "Vehicle seizure lifted for "
                L14_3 = L10_3.name
                L15_3 = ": "
                L16_3 = L1_3.item_description
                L13_3 = L13_3 .. L14_3 .. L15_3 .. L16_3
                L12_3(L13_3)
              end
            end
          end
          if L11_3 then
            L12_3 = Framework
            L12_3 = L12_3.ShowUINotify
            L13_3 = tonumber
            L14_3 = L9_3
            L13_3 = L13_3(L14_3)
            L14_3 = "Your seized property has been returned: "
            L15_3 = L1_3.item_description
            L14_3 = L14_3 .. L15_3
            L15_3 = "success"
            L12_3(L13_3, L14_3, L15_3)
            break
          end
          L12_3 = Framework
          L12_3 = L12_3.ShowUINotify
          L13_3 = tonumber
          L14_3 = L9_3
          L13_3 = L13_3(L14_3)
          L14_3 = "There was an issue returning your seized property. Contact an administrator."
          L15_3 = "error"
          L12_3(L13_3, L14_3, L15_3)
          L12_3 = Framework
          L12_3 = L12_3.ShowNotification
          L13_3 = L1_2
          L14_3 = "Warning: Failed to return some items to player. Check server console."
          L15_3 = "error"
          L12_3(L13_3, L14_3, L15_3)
          break
        end
      end
    end
    if not L3_3 then
      L4_3 = Utils
      L4_3 = L4_3.DebugPrint
      L5_3 = "Player not online for seizure return: "
      L6_3 = L1_3.target_name
      if not L6_3 then
        L6_3 = "Unknown"
      end
      L7_3 = " (ID: "
      L8_3 = L1_3.target_identifier
      L9_3 = ")"
      L5_3 = L5_3 .. L6_3 .. L7_3 .. L8_3 .. L9_3
      L4_3(L5_3)
      L4_3 = Framework
      L4_3 = L4_3.ShowNotification
      L5_3 = L1_2
      L6_3 = "Player is not online. Items will need to be returned when they come online."
      L7_3 = "error"
      L4_3(L5_3, L6_3, L7_3)
    end
    L4_3 = Framework
    L4_3 = L4_3.ShowNotification
    L5_3 = L1_2
    L6_3 = "Seizure returned successfully"
    L7_3 = "success"
    L4_3(L5_3, L6_3, L7_3)
    L4_3 = Utils
    L4_3 = L4_3.GetPlayersByJob
    L5_3 = "police"
    L4_3 = L4_3(L5_3)
    L5_3 = ipairs
    L6_3 = L4_3
    L5_3, L6_3, L7_3, L8_3 = L5_3(L6_3)
    for L9_3, L10_3 in L5_3, L6_3, L7_3, L8_3 do
      L11_3 = L10_3.source
      L12_3 = L1_2
      if L11_3 ~= L12_3 then
        L11_3 = Framework
        L11_3 = L11_3.ShowNotification
        L12_3 = L10_3.source
        L13_3 = "Seizure returned by "
        L14_3 = L2_2.name
        L15_3 = ": "
        L16_3 = L1_3.item_description
        L13_3 = L13_3 .. L14_3 .. L15_3 .. L16_3
        L14_3 = "primary"
        L11_3(L12_3, L13_3, L14_3)
      end
    end
  end
  L3_2(L4_2, L5_2, L6_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:deleteSeizure"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L3_2.job
  L5_2 = L5_2.name
  L6_2 = L3_2.job
  L6_2 = L6_2.grade
  L7_2 = "all"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L2_2
    L6_2 = "You do not have permission to delete seizures"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT * FROM government_seizures WHERE id = ?"
  L6_2 = {}
  L7_2 = A0_2
  L6_2[1] = L7_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L1_3 = A0_3[1]
    if not L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L2_2
      L3_3 = "Seizure not found"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = A0_3[1]
    L2_3 = MySQL
    L2_3 = L2_3.execute
    L3_3 = "UPDATE government_seizures SET status = ?, deleted_by = ?, deletion_reason = ?, deleted_at = ? WHERE id = ?"
    L4_3 = {}
    L5_3 = "deleted"
    L6_3 = L3_2.identifier
    L7_3 = A1_2
    L8_3 = os
    L8_3 = L8_3.date
    L9_3 = "%Y-%m-%d %H:%M:%S"
    L8_3 = L8_3(L9_3)
    L9_3 = A0_2
    L4_3[1] = L5_3
    L4_3[2] = L6_3
    L4_3[3] = L7_3
    L4_3[4] = L8_3
    L4_3[5] = L9_3
    L2_3(L3_3, L4_3)
    L2_3 = Framework
    L2_3 = L2_3.ShowNotification
    L3_3 = L2_2
    L4_3 = "Seizure record deleted successfully"
    L5_3 = "success"
    L2_3(L3_3, L4_3, L5_3)
    L2_3 = MySQL
    L2_3 = L2_3.insert
    L3_3 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
    L4_3 = {}
    L5_3 = "admin_action"
    L6_3 = 0
    L7_3 = "Seizure deletion: "
    L8_3 = L1_3.item_description
    L9_3 = " | Reason: "
    L10_3 = A1_2
    L7_3 = L7_3 .. L8_3 .. L9_3 .. L10_3
    L8_3 = L1_3.target_identifier
    L9_3 = L3_2.identifier
    L4_3[1] = L5_3
    L4_3[2] = L6_3
    L4_3[3] = L7_3
    L4_3[4] = L8_3
    L4_3[5] = L9_3
    L2_3(L3_3, L4_3)
  end
  L4_2(L5_2, L6_2, L7_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:identityScan"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  if not L2_2 or not L3_2 then
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L2_2.job
  L5_2 = L5_2.name
  L6_2 = L2_2.job
  L6_2 = L6_2.grade
  L7_2 = "identity_control"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L1_2
    L6_2 = "You do not have permission for identity control"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = Framework
  L4_2 = L4_2.GetFramework
  L4_2 = L4_2()
  if "esx" == L4_2 then
    L5_2 = MySQL
    L5_2 = L5_2.query
    L6_2 = "SELECT u.*, j.label as job_label FROM users u LEFT JOIN jobs j ON u.job = j.name WHERE u.identifier = ?"
    L7_2 = {}
    L8_2 = L3_2.identifier
    L7_2[1] = L8_2
    function L8_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
      L1_3 = A0_3[1]
      if L1_3 then
        L1_3 = A0_3[1]
        L2_3 = GetCriminalRecord
        L3_3 = L3_2.identifier
        L2_3 = L2_3(L3_3)
        L3_3 = {}
        L4_3 = L1_3.firstname
        L5_3 = " "
        L6_3 = L1_3.lastname
        L4_3 = L4_3 .. L5_3 .. L6_3
        L3_3.name = L4_3
        L4_3 = L1_3.dateofbirth
        L3_3.dob = L4_3
        L4_3 = L1_3.sex
        L3_3.sex = L4_3
        L4_3 = L1_3.nationality
        if not L4_3 then
          L4_3 = "Unknown"
        end
        L3_3.nationality = L4_3
        L4_3 = L1_3.job_label
        if not L4_3 then
          L4_3 = L1_3.job
        end
        L3_3.job = L4_3
        L4_3 = L1_3.phone_number
        L3_3.phone = L4_3
        L3_3.criminal_record = L2_3
        L4_3 = TriggerClientEvent
        L5_3 = "fs-government:client:showAdvancedIdentity"
        L6_3 = L1_2
        L7_3 = L3_3
        L4_3(L5_3, L6_3, L7_3)
      end
    end
    L5_2(L6_2, L7_2, L8_2)
  elseif "qbcore" == L4_2 or "qbox" == L4_2 then
    L5_2 = exports
    L5_2 = L5_2["qb-core"]
    L6_2 = L5_2
    L5_2 = L5_2.GetCoreObject
    L5_2 = L5_2(L6_2)
    L6_2 = L5_2.Functions
    L6_2 = L6_2.GetPlayer
    L7_2 = A0_2
    L6_2 = L6_2(L7_2)
    if L6_2 then
      L7_2 = GetCriminalRecord
      L8_2 = L3_2.identifier
      L7_2 = L7_2(L8_2)
      L8_2 = {}
      L9_2 = L6_2.PlayerData
      L9_2 = L9_2.charinfo
      L9_2 = L9_2.firstname
      L10_2 = " "
      L11_2 = L6_2.PlayerData
      L11_2 = L11_2.charinfo
      L11_2 = L11_2.lastname
      L9_2 = L9_2 .. L10_2 .. L11_2
      L8_2.name = L9_2
      L9_2 = L6_2.PlayerData
      L9_2 = L9_2.charinfo
      L9_2 = L9_2.birthdate
      L8_2.dob = L9_2
      L9_2 = L6_2.PlayerData
      L9_2 = L9_2.charinfo
      L9_2 = L9_2.gender
      if 0 == L9_2 then
        L9_2 = "Male"
        if L9_2 then
          goto lbl_88
        end
      end
      L9_2 = "Female"
      ::lbl_88::
      L8_2.sex = L9_2
      L9_2 = L6_2.PlayerData
      L9_2 = L9_2.charinfo
      L9_2 = L9_2.nationality
      if not L9_2 then
        L9_2 = "Unknown"
      end
      L8_2.nationality = L9_2
      L9_2 = L6_2.PlayerData
      L9_2 = L9_2.job
      L9_2 = L9_2.label
      L8_2.job = L9_2
      L9_2 = L6_2.PlayerData
      L9_2 = L9_2.charinfo
      L9_2 = L9_2.phone
      L8_2.phone = L9_2
      L8_2.criminal_record = L7_2
      L9_2 = TriggerClientEvent
      L10_2 = "fs-government:client:showAdvancedIdentity"
      L11_2 = L1_2
      L12_2 = L8_2
      L9_2(L10_2, L11_2, L12_2)
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:addCriminalRecord"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  L5_2 = Framework
  L5_2 = L5_2.GetPlayerData
  L6_2 = A0_2
  L5_2 = L5_2(L6_2)
  if not L4_2 or not L5_2 then
    return
  end
  L6_2 = Utils
  L6_2 = L6_2.HasPermission
  L7_2 = L4_2.job
  L7_2 = L7_2.name
  L8_2 = L4_2.job
  L8_2 = L8_2.grade
  L9_2 = "identity_control"
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  if not L6_2 then
    L6_2 = Framework
    L6_2 = L6_2.ShowNotification
    L7_2 = L3_2
    L8_2 = "You do not have permission to add criminal records"
    L9_2 = "error"
    L6_2(L7_2, L8_2, L9_2)
    return
  end
  L6_2 = MySQL
  L6_2 = L6_2.insert
  L7_2 = "INSERT INTO criminal_records (identifier, offense, details, added_by, created_at) VALUES (?, ?, ?, ?, ?)"
  L8_2 = {}
  L9_2 = L5_2.identifier
  L10_2 = A1_2
  L11_2 = A2_2
  L12_2 = L4_2.identifier
  L13_2 = os
  L13_2 = L13_2.date
  L14_2 = "%Y-%m-%d %H:%M:%S"
  L13_2, L14_2 = L13_2(L14_2)
  L8_2[1] = L9_2
  L8_2[2] = L10_2
  L8_2[3] = L11_2
  L8_2[4] = L12_2
  L8_2[5] = L13_2
  L8_2[6] = L14_2
  L6_2(L7_2, L8_2)
  L6_2 = Framework
  L6_2 = L6_2.ShowNotification
  L7_2 = L3_2
  L8_2 = "Criminal record added successfully"
  L9_2 = "success"
  L6_2(L7_2, L8_2, L9_2)
  L6_2 = Framework
  L6_2 = L6_2.ShowNotification
  L7_2 = A0_2
  L8_2 = "A criminal record has been added to your file"
  L9_2 = "error"
  L6_2(L7_2, L8_2, L9_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:createSurveillanceReport"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  if not L4_2 then
    return
  end
  L5_2 = Utils
  L5_2 = L5_2.HasPermission
  L6_2 = L4_2.job
  L6_2 = L6_2.name
  L7_2 = L4_2.job
  L7_2 = L7_2.grade
  L8_2 = "surveillance"
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  if not L5_2 then
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L3_2
    L7_2 = "You do not have permission to create surveillance reports"
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
    return
  end
  L5_2 = MySQL
  L5_2 = L5_2.insert
  L6_2 = "INSERT INTO surveillance_reports (camera_id, observer_identifier, observations, suspicious_activity, created_at) VALUES (?, ?, ?, ?, ?)"
  L7_2 = {}
  L8_2 = A0_2
  L9_2 = L4_2.identifier
  L10_2 = A1_2
  if A2_2 then
    L11_2 = 1
    if L11_2 then
      goto lbl_40
    end
  end
  L11_2 = 0
  ::lbl_40::
  L12_2 = os
  L12_2 = L12_2.date
  L13_2 = "%Y-%m-%d %H:%M:%S"
  L12_2, L13_2 = L12_2(L13_2)
  L7_2[1] = L8_2
  L7_2[2] = L9_2
  L7_2[3] = L10_2
  L7_2[4] = L11_2
  L7_2[5] = L12_2
  L7_2[6] = L13_2
  L5_2(L6_2, L7_2)
  L5_2 = Framework
  L5_2 = L5_2.ShowNotification
  L6_2 = L3_2
  L7_2 = "Surveillance report created successfully"
  L8_2 = "success"
  L5_2(L6_2, L7_2, L8_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:issueWarrant"
function L2_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L4_2 = source
  L5_2 = Framework
  L5_2 = L5_2.GetPlayerData
  L6_2 = L4_2
  L5_2 = L5_2(L6_2)
  if not L5_2 then
    return
  end
  L6_2 = Utils
  L6_2 = L6_2.HasPermission
  L7_2 = L5_2.job
  L7_2 = L7_2.name
  L8_2 = L5_2.job
  L8_2 = L8_2.grade
  L9_2 = "warrant_issue"
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  if not L6_2 then
    L6_2 = Framework
    L6_2 = L6_2.ShowNotification
    L7_2 = L4_2
    L8_2 = "You do not have permission to issue warrants"
    L9_2 = "error"
    L6_2(L7_2, L8_2, L9_2)
    return
  end
  L6_2 = "WAR-"
  L7_2 = Utils
  L7_2 = L7_2.GenerateId
  L7_2 = L7_2()
  L6_2 = L6_2 .. L7_2
  if not A3_2 then
    A3_2 = "medium"
  end
  L7_2 = MySQL
  L7_2 = L7_2.insert
  L8_2 = "INSERT INTO government_warrants (warrant_number, target_name, offense, details, issued_by, status, urgency, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
  L9_2 = {}
  L10_2 = L6_2
  L11_2 = A0_2
  L12_2 = A1_2
  L13_2 = A2_2
  L14_2 = L5_2.identifier
  L15_2 = "active"
  L16_2 = A3_2
  L17_2 = os
  L17_2 = L17_2.date
  L18_2 = "%Y-%m-%d %H:%M:%S"
  L17_2, L18_2 = L17_2(L18_2)
  L9_2[1] = L10_2
  L9_2[2] = L11_2
  L9_2[3] = L12_2
  L9_2[4] = L13_2
  L9_2[5] = L14_2
  L9_2[6] = L15_2
  L9_2[7] = L16_2
  L9_2[8] = L17_2
  L9_2[9] = L18_2
  function L10_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3
    L1_3 = Framework
    L1_3 = L1_3.ShowNotification
    L2_3 = L4_2
    L3_3 = "Warrant issued successfully. Number: "
    L4_3 = L6_2
    L3_3 = L3_3 .. L4_3
    L4_3 = "success"
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = MySQL
    L1_3 = L1_3.insert
    L2_3 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
    L3_3 = {}
    L4_3 = "warrant_issued"
    L5_3 = 0
    L6_3 = "Warrant issued: "
    L7_3 = L6_2
    L8_3 = " - "
    L9_3 = A1_2
    L6_3 = L6_3 .. L7_3 .. L8_3 .. L9_3
    L7_3 = "system"
    L8_3 = L5_2.identifier
    L3_3[1] = L4_3
    L3_3[2] = L5_3
    L3_3[3] = L6_3
    L3_3[4] = L7_3
    L3_3[5] = L8_3
    L1_3(L2_3, L3_3)
    L1_3 = GetPlayers
    L1_3 = L1_3()
    L2_3 = ipairs
    L3_3 = L1_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = tonumber
      L9_3 = L7_3
      L8_3 = L8_3(L9_3)
      L9_3 = TriggerClientEvent
      L10_3 = "fs-government:client:warrantAnnouncement"
      L11_3 = L8_3
      L12_3 = {}
      L13_3 = "\226\154\150\239\184\143 WARRANT ISSUED: "
      L14_3 = A0_2
      L15_3 = " - "
      L16_3 = A1_2
      L17_3 = " | Reason: "
      L18_3 = A2_2
      L19_3 = " ("
      L20_3 = L6_2
      L21_3 = ")"
      L13_3 = L13_3 .. L14_3 .. L15_3 .. L16_3 .. L17_3 .. L18_3 .. L19_3 .. L20_3 .. L21_3
      L12_3.message = L13_3
      L12_3.type = "primary"
      L9_3(L10_3, L11_3, L12_3)
    end
  end
  L7_2(L8_2, L9_2, L10_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:checkWarrants"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = source
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_warrants WHERE target_name LIKE ? AND status = ?"
  L4_2 = {}
  L5_2 = "%"
  L6_2 = A0_2
  L7_2 = "%"
  L5_2 = L5_2 .. L6_2 .. L7_2
  L6_2 = "active"
  L4_2[1] = L5_2
  L4_2[2] = L6_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L1_2
      L3_3 = "No active warrants found for "
      L4_3 = A0_2
      L3_3 = L3_3 .. L4_3
      L4_3 = "primary"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = Config
      L7_3 = L7_3.Debug
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "Raw warrant created_at: "
        L9_3 = tostring
        L10_3 = L6_3.created_at
        L9_3 = L9_3(L10_3)
        L10_3 = " (type: "
        L11_3 = type
        L12_3 = L6_3.created_at
        L11_3 = L11_3(L12_3)
        L12_3 = ")"
        L8_3 = L8_3 .. L9_3 .. L10_3 .. L11_3 .. L12_3
        L7_3(L8_3)
      end
      L7_3 = Utils
      L7_3 = L7_3.FormatDate
      L8_3 = L6_3.created_at
      L7_3 = L7_3(L8_3)
      L6_3.formatted_date = L7_3
      L7_3 = L6_3.executed_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.executed_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_executed_date = L7_3
      end
      L7_3 = L6_3.cancelled_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.cancelled_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_cancelled_date = L7_3
      end
      L7_3 = Config
      L7_3 = L7_3.Debug
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "Formatted warrant date: "
        L9_3 = tostring
        L10_3 = L6_3.formatted_date
        L9_3 = L9_3(L10_3)
        L8_3 = L8_3 .. L9_3
        L7_3(L8_3)
      end
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showWarrants"
    L3_3 = L1_2
    L4_3 = A0_3
    L5_3 = A0_2
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getAllWarrants"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "warrant_issue"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view warrants"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_warrants WHERE status = ? ORDER BY created_at DESC"
  L4_2 = {}
  L5_2 = "active"
  L4_2[1] = L5_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = Config
      L7_3 = L7_3.Debug
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "Raw warrant created_at: "
        L9_3 = tostring
        L10_3 = L6_3.created_at
        L9_3 = L9_3(L10_3)
        L10_3 = " (type: "
        L11_3 = type
        L12_3 = L6_3.created_at
        L11_3 = L11_3(L12_3)
        L12_3 = ")"
        L8_3 = L8_3 .. L9_3 .. L10_3 .. L11_3 .. L12_3
        L7_3(L8_3)
      end
      L7_3 = Utils
      L7_3 = L7_3.FormatDate
      L8_3 = L6_3.created_at
      L7_3 = L7_3(L8_3)
      L6_3.formatted_date = L7_3
      L7_3 = L6_3.executed_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.executed_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_executed_date = L7_3
      end
      L7_3 = L6_3.cancelled_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.cancelled_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_cancelled_date = L7_3
      end
      L7_3 = Config
      L7_3 = L7_3.Debug
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "Formatted warrant date: "
        L9_3 = tostring
        L10_3 = L6_3.formatted_date
        L9_3 = L9_3(L10_3)
        L8_3 = L8_3 .. L9_3
        L7_3(L8_3)
      end
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showAllWarrants"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getWarrantHistory"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "warrant_issue"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view warrant history"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_warrants ORDER BY created_at DESC LIMIT 50"
  L4_2 = {}
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = Config
      L7_3 = L7_3.Debug
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "Raw warrant created_at: "
        L9_3 = tostring
        L10_3 = L6_3.created_at
        L9_3 = L9_3(L10_3)
        L10_3 = " (type: "
        L11_3 = type
        L12_3 = L6_3.created_at
        L11_3 = L11_3(L12_3)
        L12_3 = ")"
        L8_3 = L8_3 .. L9_3 .. L10_3 .. L11_3 .. L12_3
        L7_3(L8_3)
      end
      L7_3 = Utils
      L7_3 = L7_3.FormatDate
      L8_3 = L6_3.created_at
      L7_3 = L7_3(L8_3)
      L6_3.formatted_date = L7_3
      L7_3 = L6_3.executed_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.executed_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_executed_date = L7_3
      end
      L7_3 = L6_3.cancelled_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.cancelled_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_cancelled_date = L7_3
      end
      L7_3 = Config
      L7_3 = L7_3.Debug
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.DebugPrint
        L8_3 = "Formatted warrant date: "
        L9_3 = tostring
        L10_3 = L6_3.formatted_date
        L9_3 = L9_3(L10_3)
        L8_3 = L8_3 .. L9_3
        L7_3(L8_3)
      end
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showWarrantHistory"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:executeWarrant"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L3_2.job
  L5_2 = L5_2.name
  L6_2 = L3_2.job
  L6_2 = L6_2.grade
  L7_2 = "warrant_issue"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L2_2
    L6_2 = "You do not have permission to execute warrants"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT * FROM government_warrants WHERE id = ? AND status = ?"
  L6_2 = {}
  L7_2 = A0_2
  L8_2 = "active"
  L6_2[1] = L7_2
  L6_2[2] = L8_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3
    L1_3 = A0_3[1]
    if not L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L2_2
      L3_3 = "Warrant not found or already processed"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = A0_3[1]
    L2_3 = MySQL
    L2_3 = L2_3.execute
    L3_3 = "UPDATE government_warrants SET status = ?, executed_by = ?, executed_at = ? WHERE id = ?"
    L4_3 = {}
    L5_3 = "executed"
    L6_3 = L3_2.identifier
    L7_3 = os
    L7_3 = L7_3.date
    L8_3 = "%Y-%m-%d %H:%M:%S"
    L7_3 = L7_3(L8_3)
    L8_3 = A0_2
    L4_3[1] = L5_3
    L4_3[2] = L6_3
    L4_3[3] = L7_3
    L4_3[4] = L8_3
    L2_3(L3_3, L4_3)
    L2_3 = Framework
    L2_3 = L2_3.ShowNotification
    L3_3 = L2_2
    L4_3 = "Warrant executed successfully: "
    L5_3 = L1_3.warrant_number
    L4_3 = L4_3 .. L5_3
    L5_3 = "success"
    L2_3(L3_3, L4_3, L5_3)
    L2_3 = MySQL
    L2_3 = L2_3.insert
    L3_3 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
    L4_3 = {}
    L5_3 = "warrant_execution"
    L6_3 = 0
    L7_3 = "Warrant executed: "
    L8_3 = L1_3.warrant_number
    L9_3 = " - "
    L10_3 = L1_3.offense
    L7_3 = L7_3 .. L8_3 .. L9_3 .. L10_3
    L8_3 = "system"
    L9_3 = L3_2.identifier
    L4_3[1] = L5_3
    L4_3[2] = L6_3
    L4_3[3] = L7_3
    L4_3[4] = L8_3
    L4_3[5] = L9_3
    L2_3(L3_3, L4_3)
    L2_3 = GetPlayers
    L2_3 = L2_3()
    L3_3 = ipairs
    L4_3 = L2_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = tonumber
      L10_3 = L8_3
      L9_3 = L9_3(L10_3)
      L10_3 = TriggerClientEvent
      L11_3 = "fs-government:client:warrantAnnouncement"
      L12_3 = L9_3
      L13_3 = {}
      L14_3 = "\226\154\150\239\184\143 WARRANT EXECUTED: "
      L15_3 = L1_3.target_name
      L16_3 = " - "
      L17_3 = L1_3.offense
      L18_3 = " | Executed by: "
      L19_3 = L3_2.name
      L20_3 = " ("
      L21_3 = L1_3.warrant_number
      L22_3 = ")"
      L14_3 = L14_3 .. L15_3 .. L16_3 .. L17_3 .. L18_3 .. L19_3 .. L20_3 .. L21_3 .. L22_3
      L13_3.message = L14_3
      L13_3.type = "success"
      L10_3(L11_3, L12_3, L13_3)
    end
  end
  L4_2(L5_2, L6_2, L7_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:cancelWarrant"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L3_2.job
  L5_2 = L5_2.name
  L6_2 = L3_2.job
  L6_2 = L6_2.grade
  L7_2 = "warrant_issue"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L2_2
    L6_2 = "You do not have permission to cancel warrants"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT * FROM government_warrants WHERE id = ? AND status = ?"
  L6_2 = {}
  L7_2 = A0_2
  L8_2 = "active"
  L6_2[1] = L7_2
  L6_2[2] = L8_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3
    L1_3 = A0_3[1]
    if not L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L2_2
      L3_3 = "Warrant not found or already processed"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = A0_3[1]
    L2_3 = MySQL
    L2_3 = L2_3.execute
    L3_3 = "UPDATE government_warrants SET status = ?, cancelled_by = ?, cancellation_reason = ?, cancelled_at = ? WHERE id = ?"
    L4_3 = {}
    L5_3 = "cancelled"
    L6_3 = L3_2.identifier
    L7_3 = A1_2
    L8_3 = os
    L8_3 = L8_3.date
    L9_3 = "%Y-%m-%d %H:%M:%S"
    L8_3 = L8_3(L9_3)
    L9_3 = A0_2
    L4_3[1] = L5_3
    L4_3[2] = L6_3
    L4_3[3] = L7_3
    L4_3[4] = L8_3
    L4_3[5] = L9_3
    L2_3(L3_3, L4_3)
    L2_3 = Framework
    L2_3 = L2_3.ShowNotification
    L3_3 = L2_2
    L4_3 = "Warrant cancelled successfully: "
    L5_3 = L1_3.warrant_number
    L4_3 = L4_3 .. L5_3
    L5_3 = "success"
    L2_3(L3_3, L4_3, L5_3)
    L2_3 = MySQL
    L2_3 = L2_3.insert
    L3_3 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
    L4_3 = {}
    L5_3 = "warrant_cancellation"
    L6_3 = 0
    L7_3 = "Warrant cancelled: "
    L8_3 = L1_3.warrant_number
    L9_3 = " | Reason: "
    L10_3 = A1_2
    L7_3 = L7_3 .. L8_3 .. L9_3 .. L10_3
    L8_3 = "system"
    L9_3 = L3_2.identifier
    L4_3[1] = L5_3
    L4_3[2] = L6_3
    L4_3[3] = L7_3
    L4_3[4] = L8_3
    L4_3[5] = L9_3
    L2_3(L3_3, L4_3)
    L2_3 = GetPlayers
    L2_3 = L2_3()
    L3_3 = ipairs
    L4_3 = L2_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = tonumber
      L10_3 = L8_3
      L9_3 = L9_3(L10_3)
      L10_3 = TriggerClientEvent
      L11_3 = "fs-government:client:warrantAnnouncement"
      L12_3 = L9_3
      L13_3 = {}
      L14_3 = "\226\154\150\239\184\143 WARRANT CLOSED: "
      L15_3 = L1_3.target_name
      L16_3 = " - "
      L17_3 = L1_3.offense
      L18_3 = " | Reason: "
      L19_3 = A1_2
      L14_3 = L14_3 .. L15_3 .. L16_3 .. L17_3 .. L18_3 .. L19_3
      L13_3.message = L14_3
      L13_3.type = "primary"
      L10_3(L11_3, L12_3, L13_3)
    end
  end
  L4_2(L5_2, L6_2, L7_2)
end
L0_1(L1_1, L2_1)
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = {}
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM criminal_records WHERE identifier = ? ORDER BY created_at DESC LIMIT 10"
  L4_2 = {}
  L5_2 = A0_2
  L4_2[1] = L5_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = table
      L7_3 = L7_3.insert
      L8_3 = L1_2
      L9_3 = {}
      L10_3 = L6_3.offense
      L9_3.offense = L10_3
      L10_3 = L6_3.details
      L9_3.details = L10_3
      L10_3 = L6_3.created_at
      L9_3.date = L10_3
      L7_3(L8_3, L9_3)
    end
  end
  L2_2(L3_2, L4_2, L5_2)
  return L1_2
end
GetCriminalRecord = L0_1
