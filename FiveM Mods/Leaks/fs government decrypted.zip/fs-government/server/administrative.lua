local L0_1, L1_1, L2_1, L3_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2
  if not A0_2 or "" == A0_2 or "null" == A0_2 or "NULL" == A0_2 then
    L1_2 = "Unknown Date"
    return L1_2
  end
  L1_2 = type
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if "number" == L1_2 then
    L1_2 = A0_2
    L2_2 = 9999999999
    if L1_2 > L2_2 then
      L1_2 = L1_2 / 1000
    end
    L2_2 = os
    L2_2 = L2_2.date
    L3_2 = "%B %d, %Y at %I:%M %p"
    L4_2 = L1_2
    return L2_2(L3_2, L4_2)
  end
  L1_2 = tostring
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if "" == L1_2 or "0" == L1_2 or "null" == L1_2 or "NULL" == L1_2 then
    L2_2 = "Unknown Date"
    return L2_2
  end
  L2_2 = tonumber
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if L2_2 then
    L2_2 = tonumber
    L3_2 = L1_2
    L2_2 = L2_2(L3_2)
    L3_2 = 1000000000
    if L2_2 > L3_2 then
      L2_2 = tonumber
      L3_2 = L1_2
      L2_2 = L2_2(L3_2)
      L3_2 = 9999999999
      if L2_2 > L3_2 then
        L2_2 = L2_2 / 1000
      end
      L3_2 = os
      L3_2 = L3_2.date
      L4_2 = "%B %d, %Y at %I:%M %p"
      L5_2 = L2_2
      return L3_2(L4_2, L5_2)
    end
  end
  L3_2 = L1_2
  L2_2 = L1_2.match
  L4_2 = "(%d%d%d%d)-(%d%d)-(%d%d)%s+(%d%d):(%d%d):(%d%d)"
  L2_2, L3_2, L4_2, L5_2, L6_2, L7_2 = L2_2(L3_2, L4_2)
  if not L2_2 then
    L9_2 = L1_2
    L8_2 = L1_2.match
    L10_2 = "(%d%d%d%d)-(%d%d)-(%d%d)"
    L8_2, L9_2, L10_2 = L8_2(L9_2, L10_2)
    L4_2 = L10_2
    L3_2 = L9_2
    L2_2 = L8_2
    L7_2 = nil
    L8_2 = nil
    L9_2 = nil
    L6_2 = L9_2
    L5_2 = L8_2
  end
  L8_2 = Config
  L8_2 = L8_2.Debug
  if L8_2 then
    L8_2 = Utils
    L8_2 = L8_2.DebugPrint
    L9_2 = "Date pattern match results - Year:"
    L10_2 = L2_2
    L11_2 = "Month:"
    L12_2 = L3_2
    L13_2 = "Day:"
    L14_2 = L4_2
    L15_2 = "Hour:"
    L16_2 = L5_2
    L17_2 = "Min:"
    L18_2 = L6_2
    L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
  end
  if L2_2 and L3_2 and L4_2 then
    L8_2 = {}
    L9_2 = "January"
    L10_2 = "February"
    L11_2 = "March"
    L12_2 = "April"
    L13_2 = "May"
    L14_2 = "June"
    L15_2 = "July"
    L16_2 = "August"
    L17_2 = "September"
    L18_2 = "October"
    L19_2 = "November"
    L20_2 = "December"
    L8_2[1] = L9_2
    L8_2[2] = L10_2
    L8_2[3] = L11_2
    L8_2[4] = L12_2
    L8_2[5] = L13_2
    L8_2[6] = L14_2
    L8_2[7] = L15_2
    L8_2[8] = L16_2
    L8_2[9] = L17_2
    L8_2[10] = L18_2
    L8_2[11] = L19_2
    L8_2[12] = L20_2
    L9_2 = tonumber
    L10_2 = L2_2
    L9_2 = L9_2(L10_2)
    L10_2 = tonumber
    L11_2 = L3_2
    L10_2 = L10_2(L11_2)
    L11_2 = tonumber
    L12_2 = L4_2
    L11_2 = L11_2(L12_2)
    if L9_2 then
      L12_2 = 1970
      if L9_2 >= L12_2 then
        L12_2 = 3000
        if L9_2 <= L12_2 and L10_2 and L10_2 >= 1 and L10_2 <= 12 and L11_2 and L11_2 >= 1 and L11_2 <= 31 then
          L12_2 = L8_2[L10_2]
          if not L12_2 then
            L12_2 = "Month"
            L13_2 = L10_2
            L12_2 = L12_2 .. L13_2
          end
          if L5_2 and L6_2 and "" ~= L5_2 and "" ~= L6_2 then
            L13_2 = tonumber
            L14_2 = L5_2
            L13_2 = L13_2(L14_2)
            L14_2 = tonumber
            L15_2 = L6_2
            L14_2 = L14_2(L15_2)
            if L13_2 and L14_2 then
              if L13_2 >= 12 then
                L15_2 = "PM"
                if L15_2 then
                  goto lbl_177
                end
              end
              L15_2 = "AM"
              ::lbl_177::
              if L13_2 > 12 then
                L16_2 = L13_2 - 12
                if L16_2 then
                  goto lbl_189
                end
              end
              if 0 == L13_2 then
                L16_2 = 12
                if L16_2 then
                  goto lbl_189
                end
              end
              L16_2 = L13_2
              ::lbl_189::
              L17_2 = string
              L17_2 = L17_2.format
              L18_2 = "%s %d, %d at %d:%02d %s"
              L19_2 = L12_2
              L20_2 = L11_2
              L21_2 = L9_2
              L22_2 = L16_2
              L23_2 = L14_2
              L24_2 = L15_2
              L17_2 = L17_2(L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
              L18_2 = Config
              L18_2 = L18_2.Debug
              if L18_2 then
                L18_2 = Utils
                L18_2 = L18_2.DebugPrint
                L19_2 = "Formatted datetime:"
                L20_2 = L17_2
                L18_2(L19_2, L20_2)
              end
              return L17_2
            end
          end
          L13_2 = string
          L13_2 = L13_2.format
          L14_2 = "%s %d, %d"
          L15_2 = L12_2
          L16_2 = L11_2
          L17_2 = L9_2
          L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2)
          L14_2 = Config
          L14_2 = L14_2.Debug
          if L14_2 then
            L14_2 = Utils
            L14_2 = L14_2.DebugPrint
            L15_2 = "Formatted date:"
            L16_2 = L13_2
            L14_2(L15_2, L16_2)
          end
          return L13_2
        end
      end
    end
  end
  L9_2 = L1_2
  L8_2 = L1_2.match
  L10_2 = "(%d+)/(%d+)/(%d+)%s*(%d*):?(%d*)"
  L8_2, L9_2, L10_2, L11_2, L12_2 = L8_2(L9_2, L10_2)
  if L8_2 and L9_2 and L10_2 then
    L13_2 = {}
    L14_2 = "January"
    L15_2 = "February"
    L16_2 = "March"
    L17_2 = "April"
    L18_2 = "May"
    L19_2 = "June"
    L20_2 = "July"
    L21_2 = "August"
    L22_2 = "September"
    L23_2 = "October"
    L24_2 = "November"
    L25_2 = "December"
    L13_2[1] = L14_2
    L13_2[2] = L15_2
    L13_2[3] = L16_2
    L13_2[4] = L17_2
    L13_2[5] = L18_2
    L13_2[6] = L19_2
    L13_2[7] = L20_2
    L13_2[8] = L21_2
    L13_2[9] = L22_2
    L13_2[10] = L23_2
    L13_2[11] = L24_2
    L13_2[12] = L25_2
    L14_2 = tonumber
    L15_2 = L8_2
    L14_2 = L14_2(L15_2)
    L15_2 = tonumber
    L16_2 = L9_2
    L15_2 = L15_2(L16_2)
    L16_2 = tonumber
    L17_2 = L10_2
    L16_2 = L16_2(L17_2)
    L17_2 = nil
    L18_2 = nil
    L19_2 = nil
    L20_2 = 1900
    if L16_2 > L20_2 then
      if L14_2 > 12 then
        L20_2 = L14_2
        L21_2 = L15_2
        L17_2 = L16_2
        L18_2 = L21_2
        L19_2 = L20_2
      else
        L20_2 = L14_2
        L21_2 = L15_2
        L17_2 = L16_2
        L19_2 = L21_2
        L18_2 = L20_2
      end
    end
    if L17_2 and L18_2 and L19_2 and L18_2 >= 1 and L18_2 <= 12 and L19_2 >= 1 and L19_2 <= 31 then
      L20_2 = L13_2[L18_2]
      if not L20_2 then
        L20_2 = "Month"
        L21_2 = L18_2
        L20_2 = L20_2 .. L21_2
      end
      if L11_2 and "" ~= L11_2 and L12_2 and "" ~= L12_2 then
        L21_2 = tonumber
        L22_2 = L11_2
        L21_2 = L21_2(L22_2)
        L22_2 = tonumber
        L23_2 = L12_2
        L22_2 = L22_2(L23_2)
        if L21_2 and L22_2 then
          if L21_2 >= 12 then
            L23_2 = "PM"
            if L23_2 then
              goto lbl_320
            end
          end
          L23_2 = "AM"
          ::lbl_320::
          if L21_2 > 12 then
            L24_2 = L21_2 - 12
            if L24_2 then
              goto lbl_332
            end
          end
          if 0 == L21_2 then
            L24_2 = 12
            if L24_2 then
              goto lbl_332
            end
          end
          L24_2 = L21_2
          ::lbl_332::
          L25_2 = string
          L25_2 = L25_2.format
          L26_2 = "%s %d, %d at %d:%02d %s"
          L27_2 = L20_2
          L28_2 = L19_2
          L29_2 = L17_2
          L30_2 = L24_2
          L31_2 = L22_2
          L32_2 = L23_2
          L25_2 = L25_2(L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2)
          L26_2 = Config
          L26_2 = L26_2.Debug
          if L26_2 then
            L26_2 = Utils
            L26_2 = L26_2.DebugPrint
            L27_2 = "Formatted alternative datetime:"
            L28_2 = L25_2
            L26_2(L27_2, L28_2)
          end
          return L25_2
        end
      end
      L21_2 = string
      L21_2 = L21_2.format
      L22_2 = "%s %d, %d"
      L23_2 = L20_2
      L24_2 = L19_2
      L25_2 = L17_2
      L21_2 = L21_2(L22_2, L23_2, L24_2, L25_2)
      L22_2 = Config
      L22_2 = L22_2.Debug
      if L22_2 then
        L22_2 = Utils
        L22_2 = L22_2.DebugPrint
        L23_2 = "Formatted alternative date:"
        L24_2 = L21_2
        L22_2(L23_2, L24_2)
      end
      return L21_2
    end
  end
  L14_2 = L1_2
  L13_2 = L1_2.match
  L15_2 = "%d"
  L13_2 = L13_2(L14_2, L15_2)
  if L13_2 then
    L14_2 = L1_2
    L13_2 = L1_2.gsub
    L15_2 = "T"
    L16_2 = " "
    L13_2 = L13_2(L14_2, L15_2, L16_2)
    L14_2 = L13_2
    L13_2 = L13_2.gsub
    L15_2 = "%.%d+Z?$"
    L16_2 = ""
    L13_2 = L13_2(L14_2, L15_2, L16_2)
    L14_2 = L13_2
    L13_2 = L13_2.gsub
    L15_2 = "Z$"
    L16_2 = ""
    L13_2 = L13_2(L14_2, L15_2, L16_2)
    L14_2 = Config
    L14_2 = L14_2.Debug
    if L14_2 then
      L14_2 = Utils
      L14_2 = L14_2.DebugPrint
      L15_2 = "No standard pattern matched, returning cleaned string:"
      L16_2 = L13_2
      L14_2(L15_2, L16_2)
    end
    return L13_2
  else
    L13_2 = Config
    L13_2 = L13_2.Debug
    if L13_2 then
      L13_2 = Utils
      L13_2 = L13_2.DebugPrint
      L14_2 = "No recognizable date pattern, returning Unknown Date"
      L13_2(L14_2)
    end
    L13_2 = "Unknown Date"
    return L13_2
  end
end
FormatMySQLDate = L0_1
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:requestAppointment"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  if not L4_2 then
    return
  end
  L5_2 = nil
  if A2_2 and "" ~= A2_2 and "null" ~= A2_2 then
    L6_2 = tonumber
    L7_2 = A2_2
    L6_2 = L6_2(L7_2)
    if L6_2 then
      L6_2 = tonumber
      L7_2 = A2_2
      L6_2 = L6_2(L7_2)
      L7_2 = 1000000000000
      if L6_2 > L7_2 then
        L6_2 = tonumber
        L7_2 = A2_2
        L6_2 = L6_2(L7_2)
        L6_2 = L6_2 / 1000
        L7_2 = os
        L7_2 = L7_2.date
        L8_2 = "%Y-%m-%d %H:%M:%S"
        L9_2 = L6_2
        L7_2 = L7_2(L8_2, L9_2)
        L5_2 = L7_2
    end
    else
      L6_2 = tonumber
      L7_2 = A2_2
      L6_2 = L6_2(L7_2)
      if L6_2 then
        L6_2 = tonumber
        L7_2 = A2_2
        L6_2 = L6_2(L7_2)
        L7_2 = 1000000000
        if L6_2 > L7_2 then
          L6_2 = os
          L6_2 = L6_2.date
          L7_2 = "%Y-%m-%d %H:%M:%S"
          L8_2 = tonumber
          L9_2 = A2_2
          L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2 = L8_2(L9_2)
          L6_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2)
          L5_2 = L6_2
      end
      else
        L7_2 = A2_2
        L6_2 = A2_2.match
        L8_2 = "(%d%d%d%d)-(%d%d)-(%d%d)%s*(%d*):?(%d*):?(%d*)"
        L6_2, L7_2, L8_2, L9_2, L10_2, L11_2 = L6_2(L7_2, L8_2)
        if L6_2 and L7_2 and L8_2 then
          L12_2 = tonumber
          L13_2 = L6_2
          L12_2 = L12_2(L13_2)
          L13_2 = tonumber
          L14_2 = L7_2
          L13_2 = L13_2(L14_2)
          L14_2 = tonumber
          L15_2 = L8_2
          L14_2 = L14_2(L15_2)
          L15_2 = tonumber
          L16_2 = L9_2
          L15_2 = L15_2(L16_2)
          if not L15_2 then
            L15_2 = 12
          end
          L16_2 = tonumber
          L17_2 = L10_2
          L16_2 = L16_2(L17_2)
          if not L16_2 then
            L16_2 = 0
          end
          L17_2 = 1970
          if L12_2 >= L17_2 then
            L17_2 = 3000
            if L12_2 <= L17_2 and L13_2 >= 1 and L13_2 <= 12 and L14_2 >= 1 and L14_2 <= 31 then
              L17_2 = string
              L17_2 = L17_2.format
              L18_2 = "%04d-%02d-%02d %02d:%02d:00"
              L19_2 = L12_2
              L20_2 = L13_2
              L21_2 = L14_2
              L22_2 = L15_2
              L23_2 = L16_2
              L17_2 = L17_2(L18_2, L19_2, L20_2, L21_2, L22_2, L23_2)
              L5_2 = L17_2
            end
          end
        else
          L13_2 = A2_2
          L12_2 = A2_2.match
          L14_2 = "(%d+)/(%d+)/(%d+)%s*(.*)"
          L12_2, L13_2, L14_2, L15_2 = L12_2(L13_2, L14_2)
          if L12_2 and L13_2 and L14_2 then
            L16_2 = tonumber
            L17_2 = L12_2
            L16_2 = L16_2(L17_2)
            L17_2 = tonumber
            L18_2 = L13_2
            L17_2 = L17_2(L18_2)
            L18_2 = tonumber
            L19_2 = L14_2
            L18_2 = L18_2(L19_2)
            L19_2 = nil
            L20_2 = nil
            L21_2 = nil
            L22_2 = 1900
            if L18_2 > L22_2 then
              if L16_2 > 12 then
                L22_2 = L16_2
                L23_2 = L17_2
                L19_2 = L18_2
                L20_2 = L23_2
                L21_2 = L22_2
              else
                L22_2 = L16_2
                L23_2 = L17_2
                L19_2 = L18_2
                L21_2 = L23_2
                L20_2 = L22_2
              end
              L22_2 = 12
              L23_2 = 0
              if L15_2 and "" ~= L15_2 then
                L25_2 = L15_2
                L24_2 = L15_2.match
                L26_2 = "(%d+):(%d+)"
                L24_2, L25_2 = L24_2(L25_2, L26_2)
                if L24_2 and L25_2 then
                  L26_2 = tonumber
                  L27_2 = L24_2
                  L26_2 = L26_2(L27_2)
                  L27_2 = tonumber
                  L28_2 = L25_2
                  L27_2 = L27_2(L28_2)
                  L23_2 = L27_2
                  L22_2 = L26_2
                end
              end
              L24_2 = 1970
              if L19_2 >= L24_2 and L20_2 >= 1 and L20_2 <= 12 and L21_2 >= 1 and L21_2 <= 31 then
                L24_2 = string
                L24_2 = L24_2.format
                L25_2 = "%04d-%02d-%02d %02d:%02d:00"
                L26_2 = L19_2
                L27_2 = L20_2
                L28_2 = L21_2
                L29_2 = L22_2
                L30_2 = L23_2
                L24_2 = L24_2(L25_2, L26_2, L27_2, L28_2, L29_2, L30_2)
                L5_2 = L24_2
              end
            end
          end
        end
      end
    end
  end
  if not L5_2 then
    L6_2 = os
    L6_2 = L6_2.time
    L6_2 = L6_2()
    L6_2 = L6_2 + 86400
    L7_2 = os
    L7_2 = L7_2.date
    L8_2 = "%Y-%m-%d 14:00:00"
    L9_2 = L6_2
    L7_2 = L7_2(L8_2, L9_2)
    L5_2 = L7_2
  end
  L6_2 = MySQL
  L6_2 = L6_2.insert
  L7_2 = "INSERT INTO government_appointments (citizen_identifier, citizen_name, appointment_type, reason, preferred_date, status) VALUES (?, ?, ?, ?, ?, ?)"
  L8_2 = {}
  L9_2 = L4_2.identifier
  L10_2 = L4_2.name
  L11_2 = A0_2
  L12_2 = A1_2
  L13_2 = L5_2
  L14_2 = "pending"
  L8_2[1] = L9_2
  L8_2[2] = L10_2
  L8_2[3] = L11_2
  L8_2[4] = L12_2
  L8_2[5] = L13_2
  L8_2[6] = L14_2
  function L9_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L1_3 = Framework
    L1_3 = L1_3.ShowNotification
    L2_3 = L3_2
    L3_3 = "Appointment request submitted. ID: "
    L4_3 = A0_3
    L3_3 = L3_3 .. L4_3
    L4_3 = "success"
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = Utils
    L1_3 = L1_3.GetPlayersByJob
    L2_3 = "government"
    L1_3 = L1_3(L2_3)
    L2_3 = ipairs
    L3_3 = L1_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = L7_3.grade
      if L8_3 >= 3 then
        L8_3 = Framework
        L8_3 = L8_3.ShowNotification
        L9_3 = L7_3.source
        L10_3 = L4_2.name
        L11_3 = " requested: "
        L12_3 = A0_2
        L13_3 = " | ID: "
        L14_3 = A0_3
        L10_3 = L10_3 .. L11_3 .. L12_3 .. L13_3 .. L14_3
        L11_3 = "primary"
        L8_3(L9_3, L10_3, L11_3)
      end
    end
  end
  L6_2(L7_2, L8_2, L9_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getAppointments"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "employee_management"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view appointments"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT a.*, e.name as assigned_name FROM government_appointments a LEFT JOIN government_employees e ON a.assigned_to = e.identifier WHERE a.status = ? ORDER BY a.created_at DESC LIMIT 10"
  L4_2 = {}
  L5_2 = "pending"
  L4_2[1] = L5_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L0_2
      L3_3 = "No pending appointments"
      L4_3 = "primary"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = L6_3.created_at
      if L7_3 then
        L7_3 = FormatMySQLDate
        L8_3 = L6_3.created_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_created = L7_3
      else
        L6_3.formatted_created = "Unknown Date"
      end
      L7_3 = L6_3.updated_at
      if L7_3 then
        L7_3 = FormatMySQLDate
        L8_3 = L6_3.updated_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_updated = L7_3
      else
        L6_3.formatted_updated = "Not updated"
      end
      L7_3 = L6_3.preferred_date
      if L7_3 then
        L7_3 = FormatMySQLDate
        L8_3 = L6_3.preferred_date
        L7_3 = L7_3(L8_3)
        L6_3.formatted_preferred = L7_3
      else
        L6_3.formatted_preferred = "Not specified"
      end
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showAppointments"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:manageAppointment"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  if not L4_2 then
    return
  end
  L5_2 = Utils
  L5_2 = L5_2.HasPermission
  L6_2 = L4_2.job
  L6_2 = L6_2.name
  L7_2 = L4_2.job
  L7_2 = L7_2.grade
  L8_2 = "employee_management"
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  if not L5_2 then
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L3_2
    L7_2 = "You do not have permission to manage appointments"
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
    return
  end
  L5_2 = MySQL
  L5_2 = L5_2.query
  L6_2 = "SELECT * FROM government_appointments WHERE id = ?"
  L7_2 = {}
  L8_2 = A0_2
  L7_2[1] = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = A0_3[1]
    if not L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L3_2
      L3_3 = "Appointment not found"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = A0_3[1]
    L2_3 = MySQL
    L2_3 = L2_3.execute
    L3_3 = "UPDATE government_appointments SET status = ?, assigned_to = ?, notes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
    L4_3 = {}
    L5_3 = A1_2
    L6_3 = L4_2.identifier
    L7_3 = A2_2
    if not L7_3 then
      L7_3 = ""
    end
    L8_3 = A0_2
    L4_3[1] = L5_3
    L4_3[2] = L6_3
    L4_3[3] = L7_3
    L4_3[4] = L8_3
    function L5_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4
      L1_4 = type
      L2_4 = A0_4
      L1_4 = L1_4(L2_4)
      if "table" == L1_4 then
        L1_4 = A0_4.affectedRows
        if L1_4 then
          goto lbl_10
        end
      end
      L1_4 = A0_4
      ::lbl_10::
      if L1_4 then
        L2_4 = tonumber
        L3_4 = L1_4
        L2_4 = L2_4(L3_4)
        if L2_4 then
          L2_4 = tonumber
          L3_4 = L1_4
          L2_4 = L2_4(L3_4)
          if L2_4 > 0 then
            L2_4 = Framework
            L2_4 = L2_4.ShowNotification
            L3_4 = L3_2
            L4_4 = "Appointment "
            L5_4 = A1_2
            L6_4 = " successfully"
            L4_4 = L4_4 .. L5_4 .. L6_4
            L5_4 = "success"
            L2_4(L3_4, L4_4, L5_4)
            L2_4 = nil
            L3_4 = GetPlayers
            L3_4 = L3_4()
            L4_4 = ipairs
            L5_4 = L3_4
            L4_4, L5_4, L6_4, L7_4 = L4_4(L5_4)
            for L8_4, L9_4 in L4_4, L5_4, L6_4, L7_4 do
              L10_4 = Framework
              L10_4 = L10_4.GetPlayerData
              L11_4 = L9_4
              L10_4 = L10_4(L11_4)
              if L10_4 then
                L11_4 = L10_4.identifier
                L12_4 = L1_3.citizen_identifier
                if L11_4 == L12_4 then
                  L2_4 = L9_4
                  break
                end
              end
            end
            if not L2_4 then
              goto lbl_86
            end
            L4_4 = A1_2
            if "completed" == L4_4 then
              L4_4 = "completed"
              if L4_4 then
                goto lbl_62
              end
            end
            L4_4 = A1_2
            ::lbl_62::
            L5_4 = Framework
            L5_4 = L5_4.ShowNotification
            L6_4 = L2_4
            L7_4 = "Your appointment status has been updated to: "
            L8_4 = string
            L8_4 = L8_4.upper
            L10_4 = L4_4
            L9_4 = L4_4.sub
            L11_4 = 1
            L12_4 = 1
            L9_4, L10_4, L11_4, L12_4 = L9_4(L10_4, L11_4, L12_4)
            L8_4 = L8_4(L9_4, L10_4, L11_4, L12_4)
            L10_4 = L4_4
            L9_4 = L4_4.sub
            L11_4 = 2
            L9_4 = L9_4(L10_4, L11_4)
            L7_4 = L7_4 .. L8_4 .. L9_4
            L8_4 = "primary"
            L5_4(L6_4, L7_4, L8_4)
        end
      end
      else
        L2_4 = Framework
        L2_4 = L2_4.ShowNotification
        L3_4 = L3_2
        L4_4 = "Failed to update appointment"
        L5_4 = "error"
        L2_4(L3_4, L4_4, L5_4)
      end
      ::lbl_86::
    end
    L2_3(L3_3, L4_3, L5_3)
  end
  L5_2(L6_2, L7_2, L8_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:createLaw"
function L2_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L5_2 = source
  L6_2 = Framework
  L6_2 = L6_2.GetPlayerData
  L7_2 = L5_2
  L6_2 = L6_2(L7_2)
  if not L6_2 then
    return
  end
  L7_2 = Utils
  L7_2 = L7_2.HasPermission
  L8_2 = L6_2.job
  L8_2 = L8_2.name
  L9_2 = L6_2.job
  L9_2 = L9_2.grade
  L10_2 = "all"
  L7_2 = L7_2(L8_2, L9_2, L10_2)
  if not L7_2 then
    L7_2 = Framework
    L7_2 = L7_2.ShowNotification
    L8_2 = L5_2
    L9_2 = "You do not have permission to create laws"
    L10_2 = "error"
    L7_2(L8_2, L9_2, L10_2)
    return
  end
  L7_2 = MySQL
  L7_2 = L7_2.insert
  L8_2 = "INSERT INTO government_laws (title, description, content, fine_amount, jail_time, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)"
  L9_2 = {}
  L10_2 = A0_2
  L11_2 = A1_2
  L12_2 = A2_2
  L13_2 = A3_2 or L13_2
  if not A3_2 then
    L13_2 = 0
  end
  L14_2 = A4_2 or L14_2
  if not A4_2 then
    L14_2 = 0
  end
  L15_2 = "draft"
  L16_2 = L6_2.identifier
  L9_2[1] = L10_2
  L9_2[2] = L11_2
  L9_2[3] = L12_2
  L9_2[4] = L13_2
  L9_2[5] = L14_2
  L9_2[6] = L15_2
  L9_2[7] = L16_2
  function L10_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = Framework
    L1_3 = L1_3.ShowNotification
    L2_3 = L5_2
    L3_3 = "Law created successfully. ID: "
    L4_3 = A0_3
    L5_3 = ". You can now activate it from the laws menu."
    L3_3 = L3_3 .. L4_3 .. L5_3
    L4_3 = "success"
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showAdvancedAnnouncement"
    L3_3 = L5_2
    L4_3 = {}
    L4_3.title = "Law Created"
    L5_3 = "Law \""
    L6_3 = A0_2
    L7_3 = "\" has been created successfully. ID: "
    L8_3 = A0_3
    L5_3 = L5_3 .. L6_3 .. L7_3 .. L8_3
    L4_3.message = L5_3
    L4_3.type = "primary"
    L4_3.duration = 8000
    L4_3.icon = "fas fa-file-signature"
    L4_3.sound = true
    L1_3(L2_3, L3_3, L4_3)
  end
  L7_2(L8_2, L9_2, L10_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:activateLaw"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L2_2.job
  L4_2 = L4_2.name
  L5_2 = L2_2.job
  L5_2 = L5_2.grade
  L6_2 = "all"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if not L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = L1_2
    L5_2 = "You do not have permission to activate laws"
    L6_2 = "error"
    L3_2(L4_2, L5_2, L6_2)
    return
  end
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT * FROM government_laws WHERE id = ?"
  L5_2 = {}
  L6_2 = A0_2
  L5_2[1] = L6_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3
    L1_3 = A0_3[1]
    if not L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L1_2
      L3_3 = "Law not found"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = MySQL
    L1_3 = L1_3.execute
    L2_3 = "UPDATE government_laws SET status = ?, updated_by = ?, updated_at = ? WHERE id = ?"
    L3_3 = {}
    L4_3 = "active"
    L5_3 = Framework
    L5_3 = L5_3.GetPlayerData
    L6_3 = L1_2
    L5_3 = L5_3(L6_3)
    L5_3 = L5_3.identifier
    L6_3 = os
    L6_3 = L6_3.date
    L7_3 = "%Y-%m-%d %H:%M:%S"
    L6_3 = L6_3(L7_3)
    L7_3 = A0_2
    L3_3[1] = L4_3
    L3_3[2] = L5_3
    L3_3[3] = L6_3
    L3_3[4] = L7_3
    L1_3(L2_3, L3_3)
    L1_3 = Framework
    L1_3 = L1_3.ShowNotification
    L2_3 = L1_2
    L3_3 = "Law activated successfully"
    L4_3 = "success"
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = A0_3[1]
    L2_3 = GetPlayers
    L2_3 = L2_3()
    L3_3 = ipairs
    L4_3 = L2_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = tonumber
      L10_3 = L8_3
      L9_3 = L9_3(L10_3)
      L10_3 = TriggerClientEvent
      L11_3 = "fs-government:client:showAdvancedAnnouncement"
      L12_3 = L9_3
      L13_3 = {}
      L13_3.title = "\240\159\147\139 LAW UPDATES - NEW LAW ENACTED"
      L14_3 = "The Government of Los Santos has implemented a new law: \""
      L15_3 = L1_3.title
      L16_3 = "\". Description: "
      L17_3 = L1_3.description
      L18_3 = " | Violations will result in: Fine $"
      L19_3 = L1_3.fine_amount
      L20_3 = " and/or "
      L21_3 = L1_3.jail_time
      L22_3 = " minutes imprisonment."
      L14_3 = L14_3 .. L15_3 .. L16_3 .. L17_3 .. L18_3 .. L19_3 .. L20_3 .. L21_3 .. L22_3
      L13_3.message = L14_3
      L13_3.type = "alert"
      L13_3.duration = 18000
      L13_3.icon = "fas fa-balance-scale"
      L13_3.sound = true
      L13_3.priority = "high"
      L10_3(L11_3, L12_3, L13_3)
    end
  end
  L3_2(L4_2, L5_2, L6_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getLaws"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = source
  L1_2 = MySQL
  L1_2 = L1_2.query
  L2_2 = "SELECT * FROM government_laws WHERE status = ? ORDER BY created_at DESC"
  L3_2 = {}
  L4_2 = "active"
  L3_2[1] = L4_2
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L0_2
      L3_3 = "No active laws found"
      L4_3 = "primary"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = "Active Laws: "
    L2_3 = ipairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      if L6_3 <= 5 then
        L8_3 = L1_3
        L9_3 = string
        L9_3 = L9_3.format
        L10_3 = "%d. %s - Fine: %s "
        L11_3 = L7_3.id
        L12_3 = L7_3.title
        L13_3 = Utils
        L13_3 = L13_3.FormatMoney
        L14_3 = L7_3.fine_amount
        L13_3, L14_3 = L13_3(L14_3)
        L9_3 = L9_3(L10_3, L11_3, L12_3, L13_3, L14_3)
        L8_3 = L8_3 .. L9_3
        L1_3 = L8_3
      end
    end
    L2_3 = #A0_3
    if L2_3 > 5 then
      L2_3 = L1_3
      L3_3 = "... and "
      L4_3 = #A0_3
      L4_3 = L4_3 - 5
      L5_3 = " more laws"
      L2_3 = L2_3 .. L3_3 .. L4_3 .. L5_3
      L1_3 = L2_3
    end
    L2_3 = Framework
    L2_3 = L2_3.ShowNotification
    L3_3 = L0_2
    L4_3 = L1_3
    L5_3 = "success"
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2, L4_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getActiveLaws"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = source
  L1_2 = MySQL
  L1_2 = L1_2.query
  L2_2 = "SELECT * FROM government_laws WHERE status = ? ORDER BY created_at DESC"
  L3_2 = {}
  L4_2 = "active"
  L3_2[1] = L4_2
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L0_2
      L3_3 = "No active laws found"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showActiveLaws"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2, L4_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getAllLaws"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "all"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view all laws"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_laws ORDER BY created_at DESC"
  L4_2 = {}
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L0_2
      L3_3 = "No laws found in database"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showAllLaws"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:updateLawStatus"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L3_2.job
  L5_2 = L5_2.name
  L6_2 = L3_2.job
  L6_2 = L6_2.grade
  L7_2 = "all"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L2_2
    L6_2 = "You do not have permission to modify laws"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = MySQL
  L4_2 = L4_2.execute
  L5_2 = "UPDATE government_laws SET status = ?, updated_by = ?, updated_at = ? WHERE id = ?"
  L6_2 = {}
  L7_2 = A1_2
  L8_2 = L3_2.identifier
  L9_2 = os
  L9_2 = L9_2.date
  L10_2 = "%Y-%m-%d %H:%M:%S"
  L9_2 = L9_2(L10_2)
  L10_2 = A0_2
  L6_2[1] = L7_2
  L6_2[2] = L8_2
  L6_2[3] = L9_2
  L6_2[4] = L10_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = A0_3.affectedRows
    if L1_3 then
      L1_3 = A0_3.affectedRows
      if L1_3 > 0 then
        L1_3 = Framework
        L1_3 = L1_3.ShowNotification
        L2_3 = L2_2
        L3_3 = "Law status updated to: "
        L4_3 = A1_2
        L3_3 = L3_3 .. L4_3
        L4_3 = "success"
        L1_3(L2_3, L3_3, L4_3)
        L1_3 = MySQL
        L1_3 = L1_3.query
        L2_3 = "SELECT * FROM government_laws WHERE id = ?"
        L3_3 = {}
        L4_3 = A0_2
        L3_3[1] = L4_3
        function L4_3(A0_4)
          local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4, L16_4, L17_4, L18_4, L19_4, L20_4, L21_4, L22_4
          L1_4 = A0_4[1]
          if L1_4 then
            L1_4 = A0_4[1]
            L2_4 = GetPlayers
            L2_4 = L2_4()
            L3_4 = A1_2
            if "active" == L3_4 then
              L3_4 = ipairs
              L4_4 = L2_4
              L3_4, L4_4, L5_4, L6_4 = L3_4(L4_4)
              for L7_4, L8_4 in L3_4, L4_4, L5_4, L6_4 do
                L9_4 = tonumber
                L10_4 = L8_4
                L9_4 = L9_4(L10_4)
                L10_4 = TriggerClientEvent
                L11_4 = "fs-government:client:showAdvancedAnnouncement"
                L12_4 = L9_4
                L13_4 = {}
                L13_4.title = "\240\159\147\139 LAW UPDATES - NEW LAW ENACTED"
                L14_4 = "The Government of Los Santos has implemented a new law: \""
                L15_4 = L1_4.title
                L16_4 = "\". Description: "
                L17_4 = L1_4.description
                L18_4 = " | Violations will result in: Fine $"
                L19_4 = L1_4.fine_amount
                L20_4 = " and/or "
                L21_4 = L1_4.jail_time
                L22_4 = " minutes imprisonment."
                L14_4 = L14_4 .. L15_4 .. L16_4 .. L17_4 .. L18_4 .. L19_4 .. L20_4 .. L21_4 .. L22_4
                L13_4.message = L14_4
                L13_4.type = "alert"
                L13_4.duration = 18000
                L13_4.icon = "fas fa-balance-scale"
                L13_4.sound = true
                L13_4.priority = "high"
                L10_4(L11_4, L12_4, L13_4)
              end
            else
              L3_4 = A1_2
              if "inactive" == L3_4 then
                L3_4 = ipairs
                L4_4 = L2_4
                L3_4, L4_4, L5_4, L6_4 = L3_4(L4_4)
                for L7_4, L8_4 in L3_4, L4_4, L5_4, L6_4 do
                  L9_4 = tonumber
                  L10_4 = L8_4
                  L9_4 = L9_4(L10_4)
                  L10_4 = TriggerClientEvent
                  L11_4 = "fs-government:client:showAdvancedAnnouncement"
                  L12_4 = L9_4
                  L13_4 = {}
                  L13_4.title = "\240\159\147\139 LAW UPDATES - LAW REPEALED"
                  L14_4 = "The Government of Los Santos has repealed the following law: \""
                  L15_4 = L1_4.title
                  L16_4 = "\". This law is no longer in effect. Previous penalties were: Fine $"
                  L17_4 = L1_4.fine_amount
                  L18_4 = " and/or "
                  L19_4 = L1_4.jail_time
                  L20_4 = " minutes imprisonment. Description: "
                  L21_4 = L1_4.description
                  L14_4 = L14_4 .. L15_4 .. L16_4 .. L17_4 .. L18_4 .. L19_4 .. L20_4 .. L21_4
                  L13_4.message = L14_4
                  L13_4.type = "warning"
                  L13_4.duration = 15000
                  L13_4.icon = "fas fa-times-circle"
                  L13_4.sound = true
                  L13_4.priority = "normal"
                  L10_4(L11_4, L12_4, L13_4)
                end
              end
            end
          end
        end
        L1_3(L2_3, L3_3, L4_3)
    end
    else
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L2_2
      L3_3 = "Failed to update law status"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L4_2(L5_2, L6_2, L7_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getAppointmentHistory"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "employee_management"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view appointment history"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT a.*, e.name as assigned_name FROM government_appointments a LEFT JOIN government_employees e ON a.assigned_to = e.identifier WHERE a.status IN (?, ?, ?) ORDER BY a.updated_at DESC LIMIT 20"
  L4_2 = {}
  L5_2 = "approved"
  L6_2 = "completed"
  L7_2 = "rejected"
  L4_2[1] = L5_2
  L4_2[2] = L6_2
  L4_2[3] = L7_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L0_2
      L3_3 = "No appointment history found"
      L4_3 = "primary"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = L6_3.created_at
      if L7_3 then
        L7_3 = FormatMySQLDate
        L8_3 = L6_3.created_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_created = L7_3
      else
        L6_3.formatted_created = "Unknown Date"
      end
      L7_3 = L6_3.updated_at
      if L7_3 then
        L7_3 = FormatMySQLDate
        L8_3 = L6_3.updated_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_updated = L7_3
      else
        L6_3.formatted_updated = "Not updated"
      end
      L7_3 = L6_3.preferred_date
      if L7_3 then
        L7_3 = L6_3.preferred_date
        if "" ~= L7_3 then
          L7_3 = FormatMySQLDate
          L8_3 = L6_3.preferred_date
          L7_3 = L7_3(L8_3)
          L6_3.formatted_preferred = L7_3
      end
      else
        L6_3.formatted_preferred = "Not specified"
      end
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showAppointmentHistory"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterCommand
L1_1 = "appointments"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    return
  end
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT a.*, e.name as assigned_name FROM government_appointments a LEFT JOIN government_employees e ON a.assigned_to = e.identifier WHERE a.citizen_identifier = ? ORDER BY a.created_at DESC LIMIT 10"
  L6_2 = {}
  L7_2 = L3_2.identifier
  L6_2[1] = L7_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = A0_2
      L3_3 = "You have no appointments"
      L4_3 = "primary"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = L6_3.created_at
      if L7_3 then
        L7_3 = FormatMySQLDate
        L8_3 = L6_3.created_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_created = L7_3
      else
        L6_3.formatted_created = "Unknown Date"
      end
      L7_3 = L6_3.updated_at
      if L7_3 then
        L7_3 = FormatMySQLDate
        L8_3 = L6_3.updated_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_updated = L7_3
      else
        L6_3.formatted_updated = "Not updated"
      end
      L7_3 = L6_3.preferred_date
      if L7_3 then
        L7_3 = L6_3.preferred_date
        if "" ~= L7_3 then
          L7_3 = FormatMySQLDate
          L8_3 = L6_3.preferred_date
          L7_3 = L7_3(L8_3)
          L6_3.formatted_preferred = L7_3
      end
      else
        L6_3.formatted_preferred = "Not specified"
      end
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showPlayerAppointments"
    L3_3 = A0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L4_2(L5_2, L6_2, L7_2)
end
L3_1 = false
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:scheduleAppointment"
function L2_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2
  L5_2 = source
  L6_2 = Framework
  L6_2 = L6_2.GetPlayerData
  L7_2 = L5_2
  L6_2 = L6_2(L7_2)
  if not L6_2 then
    return
  end
  L7_2 = Utils
  L7_2 = L7_2.HasPermission
  L8_2 = L6_2.job
  L8_2 = L8_2.name
  L9_2 = L6_2.job
  L9_2 = L9_2.grade
  L10_2 = "employee_management"
  L7_2 = L7_2(L8_2, L9_2, L10_2)
  if not L7_2 then
    L7_2 = Framework
    L7_2 = L7_2.ShowNotification
    L8_2 = L5_2
    L9_2 = "You do not have permission to schedule appointments"
    L10_2 = "error"
    L7_2(L8_2, L9_2, L10_2)
    return
  end
  L7_2 = Framework
  L7_2 = L7_2.GetPlayerData
  L8_2 = A0_2
  L7_2 = L7_2(L8_2)
  if not L7_2 then
    L8_2 = Framework
    L8_2 = L8_2.ShowNotification
    L9_2 = L5_2
    L10_2 = "Player not found"
    L11_2 = "error"
    L8_2(L9_2, L10_2, L11_2)
    return
  end
  L8_2 = os
  L8_2 = L8_2.date
  L9_2 = "%Y-%m-%d"
  L10_2 = tonumber
  L11_2 = A2_2
  L10_2 = L10_2(L11_2)
  L10_2 = L10_2 / 1000
  L8_2 = L8_2(L9_2, L10_2)
  L9_2 = A3_2
  L10_2 = L8_2
  L11_2 = " "
  L12_2 = A3_2
  L13_2 = ":00"
  L10_2 = L10_2 .. L11_2 .. L12_2 .. L13_2
  L11_2 = MySQL
  L11_2 = L11_2.insert
  L12_2 = "INSERT INTO government_appointments (citizen_identifier, citizen_name, appointment_type, reason, preferred_date, status, assigned_to) VALUES (?, ?, ?, ?, ?, ?, ?)"
  L13_2 = {}
  L14_2 = L7_2.identifier
  L15_2 = L7_2.name
  L16_2 = A1_2
  L17_2 = "Scheduled by government official"
  L18_2 = L10_2
  L19_2 = "pending"
  L20_2 = L6_2.identifier
  L13_2[1] = L14_2
  L13_2[2] = L15_2
  L13_2[3] = L16_2
  L13_2[4] = L17_2
  L13_2[5] = L18_2
  L13_2[6] = L19_2
  L13_2[7] = L20_2
  function L14_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = Framework
    L1_3 = L1_3.ShowNotification
    L2_3 = L5_2
    L3_3 = "Appointment scheduled successfully for "
    L4_3 = L7_2.name
    L3_3 = L3_3 .. L4_3
    L4_3 = "success"
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = Framework
    L1_3 = L1_3.ShowNotification
    L2_3 = A0_2
    L3_3 = "You have a scheduled appointment: "
    L4_3 = A1_2
    L5_3 = " on "
    L6_3 = L8_2
    L7_3 = " at "
    L8_3 = L9_2
    L3_3 = L3_3 .. L4_3 .. L5_3 .. L6_3 .. L7_3 .. L8_3
    L4_3 = "success"
    L1_3(L2_3, L3_3, L4_3)
  end
  L11_2(L12_2, L13_2, L14_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:issuePermit"
function L2_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L5_2 = source
  L6_2 = Framework
  L6_2 = L6_2.GetPlayerData
  L7_2 = L5_2
  L6_2 = L6_2(L7_2)
  if not L6_2 then
    return
  end
  L7_2 = Utils
  L7_2 = L7_2.HasPermission
  L8_2 = L6_2.job
  L8_2 = L8_2.name
  L9_2 = L6_2.job
  L9_2 = L9_2.grade
  L10_2 = "license_management"
  L7_2 = L7_2(L8_2, L9_2, L10_2)
  if not L7_2 then
    L7_2 = Framework
    L7_2 = L7_2.ShowNotification
    L8_2 = L5_2
    L9_2 = "You do not have permission to issue permits"
    L10_2 = "error"
    L7_2(L8_2, L9_2, L10_2)
    return
  end
  L7_2 = Framework
  L7_2 = L7_2.GetPlayerData
  L8_2 = A0_2
  L7_2 = L7_2(L8_2)
  if not L7_2 then
    L8_2 = Framework
    L8_2 = L8_2.ShowNotification
    L9_2 = L5_2
    L10_2 = "Player not found"
    L11_2 = "error"
    L8_2(L9_2, L10_2, L11_2)
    return
  end
  L8_2 = Framework
  L8_2 = L8_2.RemoveMoney
  L9_2 = A0_2
  L10_2 = A4_2
  L11_2 = "bank"
  L8_2 = L8_2(L9_2, L10_2, L11_2)
  if not L8_2 then
    L8_2 = Framework
    L8_2 = L8_2.ShowNotification
    L9_2 = L5_2
    L10_2 = "Player has insufficient funds for permit fee ($"
    L11_2 = A4_2
    L12_2 = ")"
    L10_2 = L10_2 .. L11_2 .. L12_2
    L11_2 = "error"
    L8_2(L9_2, L10_2, L11_2)
    return
  end
  L8_2 = "PER-"
  L9_2 = Utils
  L9_2 = L9_2.GenerateId
  L9_2 = L9_2()
  L8_2 = L8_2 .. L9_2
  L9_2 = os
  L9_2 = L9_2.date
  L10_2 = "%Y-%m-%d %H:%M:%S"
  L11_2 = os
  L11_2 = L11_2.time
  L11_2 = L11_2()
  L12_2 = A3_2 * 24
  L12_2 = L12_2 * 60
  L12_2 = L12_2 * 60
  L11_2 = L11_2 + L12_2
  L9_2 = L9_2(L10_2, L11_2)
  L10_2 = MySQL
  L10_2 = L10_2.execute
  L11_2 = "INSERT INTO government_employees (identifier, name, job, grade) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name)"
  L12_2 = {}
  L13_2 = L6_2.identifier
  L14_2 = L6_2.name
  L15_2 = type
  L16_2 = L6_2.job
  L15_2 = L15_2(L16_2)
  if "table" == L15_2 then
    L15_2 = L6_2.job
    L15_2 = L15_2.name
    if L15_2 then
      goto lbl_97
    end
  end
  L15_2 = L6_2.job
  if not L15_2 then
    L15_2 = "Unknown"
  end
  ::lbl_97::
  L16_2 = type
  L17_2 = L6_2.job
  L16_2 = L16_2(L17_2)
  if "table" == L16_2 then
    L16_2 = type
    L17_2 = L6_2.job
    L17_2 = L17_2.grade
    L16_2 = L16_2(L17_2)
    if "table" == L16_2 then
      L16_2 = L6_2.job
      L16_2 = L16_2.grade
      L16_2 = L16_2.level
      if L16_2 then
        goto lbl_118
      end
    end
    L16_2 = L6_2.job
    L16_2 = L16_2.grade
    if L16_2 then
      goto lbl_118
    end
  end
  L16_2 = 0
  ::lbl_118::
  L12_2[1] = L13_2
  L12_2[2] = L14_2
  L12_2[3] = L15_2
  L12_2[4] = L16_2
  L10_2(L11_2, L12_2)
  L10_2 = MySQL
  L10_2 = L10_2.insert
  L11_2 = "INSERT INTO government_permits (permit_type, permit_number, holder_identifier, holder_name, description, expiry_date, fee, status, issued_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
  L12_2 = {}
  L13_2 = A1_2
  L14_2 = L8_2
  L15_2 = L7_2.identifier
  L16_2 = L7_2.name
  L17_2 = A2_2
  L18_2 = L9_2
  L19_2 = A4_2
  L20_2 = "active"
  L21_2 = L6_2.identifier
  L12_2[1] = L13_2
  L12_2[2] = L14_2
  L12_2[3] = L15_2
  L12_2[4] = L16_2
  L12_2[5] = L17_2
  L12_2[6] = L18_2
  L12_2[7] = L19_2
  L12_2[8] = L20_2
  L12_2[9] = L21_2
  function L13_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L1_3 = Framework
    L1_3 = L1_3.ShowNotification
    L2_3 = L5_2
    L3_3 = "Permit issued successfully. Number: "
    L4_3 = L8_2
    L3_3 = L3_3 .. L4_3
    L4_3 = "success"
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = Framework
    L1_3 = L1_3.ShowNotification
    L2_3 = A0_2
    L3_3 = "You have been issued a "
    L4_3 = A1_2
    L5_3 = " permit. Number: "
    L6_3 = L8_2
    L7_3 = " | Valid for "
    L8_3 = A3_2
    L9_3 = " days"
    L3_3 = L3_3 .. L4_3 .. L5_3 .. L6_3 .. L7_3 .. L8_3 .. L9_3
    L4_3 = "success"
    L1_3(L2_3, L3_3, L4_3)
  end
  L10_2(L11_2, L12_2, L13_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getActivePermits"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = source
  L1_2 = MySQL
  L1_2 = L1_2.query
  L2_2 = "SELECT * FROM government_permits WHERE status = ? ORDER BY issued_at DESC"
  L3_2 = {}
  L4_2 = "active"
  L3_2[1] = L4_2
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L0_2
      L3_3 = "No active permits found"
      L4_3 = "primary"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showActivePermits"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2, L4_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getAllPermits"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "license_management"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view permits"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_permits ORDER BY issued_at DESC"
  L4_2 = {}
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showAllPermits"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:searchPermits"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L2_2.job
  L4_2 = L4_2.name
  L5_2 = L2_2.job
  L5_2 = L5_2.grade
  L6_2 = "license_management"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if not L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = L1_2
    L5_2 = "You do not have permission to search permits"
    L6_2 = "error"
    L3_2(L4_2, L5_2, L6_2)
    return
  end
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT * FROM government_permits WHERE permit_number LIKE ? OR holder_name LIKE ? OR permit_type LIKE ? ORDER BY issued_at DESC LIMIT 25"
  L5_2 = {}
  L6_2 = "%"
  L7_2 = A0_2
  L8_2 = "%"
  L6_2 = L6_2 .. L7_2 .. L8_2
  L7_2 = "%"
  L8_2 = A0_2
  L9_2 = "%"
  L7_2 = L7_2 .. L8_2 .. L9_2
  L8_2 = "%"
  L9_2 = A0_2
  L10_2 = "%"
  L8_2 = L8_2 .. L9_2 .. L10_2
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  L5_2[3] = L8_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L1_2
      L3_3 = "No permits found matching: "
      L4_3 = A0_2
      L3_3 = L3_3 .. L4_3
      L4_3 = "primary"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showAllPermits"
    L3_3 = L1_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L3_2(L4_2, L5_2, L6_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:renewPermit"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L3_2.job
  L5_2 = L5_2.name
  L6_2 = L3_2.job
  L6_2 = L6_2.grade
  L7_2 = "license_management"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L2_2
    L6_2 = "You do not have permission to renew permits"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT * FROM government_permits WHERE id = ?"
  L6_2 = {}
  L7_2 = A0_2
  L6_2[1] = L7_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3
    L1_3 = A0_3[1]
    if not L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L2_2
      L3_3 = "Permit not found"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = A0_3[1]
    L2_3 = os
    L2_3 = L2_3.date
    L3_3 = "%Y-%m-%d %H:%M:%S"
    L4_3 = os
    L4_3 = L4_3.time
    L4_3 = L4_3()
    L5_3 = A1_2
    L5_3 = L5_3 * 24
    L5_3 = L5_3 * 60
    L5_3 = L5_3 * 60
    L4_3 = L4_3 + L5_3
    L2_3 = L2_3(L3_3, L4_3)
    L3_3 = MySQL
    L3_3 = L3_3.execute
    L4_3 = "UPDATE government_permits SET expiry_date = ?, status = ?, renewed_by = ?, renewed_at = ? WHERE id = ?"
    L5_3 = {}
    L6_3 = L2_3
    L7_3 = "active"
    L8_3 = L3_2.identifier
    L9_3 = os
    L9_3 = L9_3.date
    L10_3 = "%Y-%m-%d %H:%M:%S"
    L9_3 = L9_3(L10_3)
    L10_3 = A0_2
    L5_3[1] = L6_3
    L5_3[2] = L7_3
    L5_3[3] = L8_3
    L5_3[4] = L9_3
    L5_3[5] = L10_3
    L3_3(L4_3, L5_3)
    L3_3 = Framework
    L3_3 = L3_3.ShowNotification
    L4_3 = L2_2
    L5_3 = "Permit renewed successfully: "
    L6_3 = L1_3.permit_number
    L5_3 = L5_3 .. L6_3
    L6_3 = "success"
    L3_3(L4_3, L5_3, L6_3)
    L3_3 = GetPlayers
    L3_3 = L3_3()
    L4_3 = ipairs
    L5_3 = L3_3
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      L10_3 = Framework
      L10_3 = L10_3.GetPlayerData
      L11_3 = L9_3
      L10_3 = L10_3(L11_3)
      if L10_3 then
        L11_3 = L10_3.identifier
        L12_3 = L1_3.holder_identifier
        if L11_3 == L12_3 then
          L11_3 = Framework
          L11_3 = L11_3.ShowNotification
          L12_3 = L9_3
          L13_3 = "Your "
          L14_3 = L1_3.permit_type
          L15_3 = " permit has been renewed until "
          L16_3 = L2_3
          L13_3 = L13_3 .. L14_3 .. L15_3 .. L16_3
          L14_3 = "success"
          L11_3(L12_3, L13_3, L14_3)
          break
        end
      end
    end
    L4_3 = MySQL
    L4_3 = L4_3.insert
    L5_3 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
    L6_3 = {}
    L7_3 = "permit_renewal"
    L8_3 = 0
    L9_3 = "Permit renewal: "
    L10_3 = L1_3.permit_number
    L11_3 = " extended for "
    L12_3 = A1_2
    L13_3 = " days"
    L9_3 = L9_3 .. L10_3 .. L11_3 .. L12_3 .. L13_3
    L10_3 = L1_3.holder_identifier
    L11_3 = L3_2.identifier
    L6_3[1] = L7_3
    L6_3[2] = L8_3
    L6_3[3] = L9_3
    L6_3[4] = L10_3
    L6_3[5] = L11_3
    L4_3(L5_3, L6_3)
  end
  L4_2(L5_2, L6_2, L7_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:suspendPermit"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  if not L4_2 then
    return
  end
  L5_2 = Utils
  L5_2 = L5_2.HasPermission
  L6_2 = L4_2.job
  L6_2 = L6_2.name
  L7_2 = L4_2.job
  L7_2 = L7_2.grade
  L8_2 = "license_management"
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  if not L5_2 then
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L3_2
    L7_2 = "You do not have permission to suspend permits"
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
    return
  end
  L5_2 = MySQL
  L5_2 = L5_2.query
  L6_2 = "SELECT * FROM government_permits WHERE id = ?"
  L7_2 = {}
  L8_2 = A0_2
  L7_2[1] = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
    L1_3 = A0_3[1]
    if not L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L3_2
      L3_3 = "Permit not found"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = A0_3[1]
    L2_3 = A2_2
    if L2_3 then
      L2_3 = os
      L2_3 = L2_3.date
      L3_3 = "%Y-%m-%d %H:%M:%S"
      L4_3 = os
      L4_3 = L4_3.time
      L4_3 = L4_3()
      L5_3 = A2_2
      L5_3 = L5_3 * 24
      L5_3 = L5_3 * 60
      L5_3 = L5_3 * 60
      L4_3 = L4_3 + L5_3
      L2_3 = L2_3(L3_3, L4_3)
      if L2_3 then
        goto lbl_34
      end
    end
    L2_3 = nil
    ::lbl_34::
    L3_3 = MySQL
    L3_3 = L3_3.execute
    L4_3 = "UPDATE government_permits SET status = ?, suspended_by = ?, suspension_reason = ?, suspended_at = ?, unsuspend_date = ? WHERE id = ?"
    L5_3 = {}
    L6_3 = "suspended"
    L7_3 = L4_2.identifier
    L8_3 = A1_2
    L9_3 = os
    L9_3 = L9_3.date
    L10_3 = "%Y-%m-%d %H:%M:%S"
    L9_3 = L9_3(L10_3)
    L10_3 = L2_3
    L11_3 = A0_2
    L5_3[1] = L6_3
    L5_3[2] = L7_3
    L5_3[3] = L8_3
    L5_3[4] = L9_3
    L5_3[5] = L10_3
    L5_3[6] = L11_3
    L3_3(L4_3, L5_3)
    L3_3 = Framework
    L3_3 = L3_3.ShowNotification
    L4_3 = L3_2
    L5_3 = "Permit suspended successfully: "
    L6_3 = L1_3.permit_number
    L5_3 = L5_3 .. L6_3
    L6_3 = "success"
    L3_3(L4_3, L5_3, L6_3)
    L3_3 = GetPlayers
    L3_3 = L3_3()
    L4_3 = ipairs
    L5_3 = L3_3
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      L10_3 = Framework
      L10_3 = L10_3.GetPlayerData
      L11_3 = L9_3
      L10_3 = L10_3(L11_3)
      if L10_3 then
        L11_3 = L10_3.identifier
        L12_3 = L1_3.holder_identifier
        if L11_3 == L12_3 then
          L11_3 = "Your "
          L12_3 = L1_3.permit_type
          L13_3 = " permit has been suspended. Reason: "
          L14_3 = A1_2
          L11_3 = L11_3 .. L12_3 .. L13_3 .. L14_3
          L12_3 = A2_2
          if L12_3 then
            L12_3 = L11_3
            L13_3 = " (Duration: "
            L14_3 = A2_2
            L15_3 = " days)"
            L12_3 = L12_3 .. L13_3 .. L14_3 .. L15_3
            L11_3 = L12_3
          else
            L12_3 = L11_3
            L13_3 = " (Indefinite)"
            L12_3 = L12_3 .. L13_3
            L11_3 = L12_3
          end
          L12_3 = Framework
          L12_3 = L12_3.ShowNotification
          L13_3 = L9_3
          L14_3 = L11_3
          L15_3 = "error"
          L12_3(L13_3, L14_3, L15_3)
          break
        end
      end
    end
  end
  L5_2(L6_2, L7_2, L8_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:registerBusiness"
function L2_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2
  L5_2 = source
  L6_2 = Framework
  L6_2 = L6_2.GetPlayerData
  L7_2 = L5_2
  L6_2 = L6_2(L7_2)
  if not L6_2 then
    return
  end
  L7_2 = Utils
  L7_2 = L7_2.HasPermission
  L8_2 = L6_2.job
  L8_2 = L8_2.name
  L9_2 = L6_2.job
  L9_2 = L9_2.grade
  L10_2 = "employee_management"
  L7_2 = L7_2(L8_2, L9_2, L10_2)
  if not L7_2 then
    L7_2 = Framework
    L7_2 = L7_2.ShowNotification
    L8_2 = L5_2
    L9_2 = "You do not have permission to register businesses"
    L10_2 = "error"
    L7_2(L8_2, L9_2, L10_2)
    return
  end
  L7_2 = L6_2.identifier
  L8_2 = L6_2.name
  if A1_2 then
    L9_2 = Framework
    L9_2 = L9_2.GetPlayerData
    L10_2 = A1_2
    L9_2 = L9_2(L10_2)
    if L9_2 then
      L7_2 = L9_2.identifier
      L8_2 = L9_2.name
    end
  end
  L9_2 = "BUS-"
  L10_2 = Utils
  L10_2 = L10_2.GenerateId
  L10_2 = L10_2()
  L9_2 = L9_2 .. L10_2
  L10_2 = A4_2 or L10_2
  if not A4_2 then
    L10_2 = 5000
  end
  L11_2 = A1_2 or L11_2
  if not A1_2 then
    L11_2 = L5_2
  end
  if L11_2 then
    L12_2 = Framework
    L12_2 = L12_2.GetPlayerData
    L13_2 = L11_2
    L12_2 = L12_2(L13_2)
    if L12_2 then
      goto lbl_58
    end
  end
  L12_2 = L6_2
  ::lbl_58::
  L13_2 = Framework
  L13_2 = L13_2.RemoveMoney
  L14_2 = L11_2 or L14_2
  if not L11_2 then
    L14_2 = L5_2
  end
  L15_2 = L10_2
  L16_2 = "bank"
  L13_2 = L13_2(L14_2, L15_2, L16_2)
  if not L13_2 then
    L13_2 = Framework
    L13_2 = L13_2.ShowNotification
    L14_2 = L5_2
    L15_2 = "Insufficient funds for registration fee ($"
    L16_2 = L10_2
    L17_2 = ")"
    L15_2 = L15_2 .. L16_2 .. L17_2
    L16_2 = "error"
    L13_2(L14_2, L15_2, L16_2)
    if L11_2 and L11_2 ~= L5_2 then
      L13_2 = Framework
      L13_2 = L13_2.ShowNotification
      L14_2 = L11_2
      L15_2 = "Business registration failed - insufficient funds ($"
      L16_2 = L10_2
      L17_2 = ")"
      L15_2 = L15_2 .. L16_2 .. L17_2
      L16_2 = "error"
      L13_2(L14_2, L15_2, L16_2)
    end
    return
  end
  L13_2 = MySQL
  L13_2 = L13_2.insert
  L14_2 = "INSERT INTO government_businesses (business_name, owner_identifier, owner_name, business_type, license_number, registration_fee, status) VALUES (?, ?, ?, ?, ?, ?, ?)"
  L15_2 = {}
  L16_2 = A0_2
  L17_2 = L7_2
  L18_2 = L8_2
  L19_2 = A2_2
  L20_2 = L9_2
  L21_2 = L10_2
  L22_2 = "active"
  L15_2[1] = L16_2
  L15_2[2] = L17_2
  L15_2[3] = L18_2
  L15_2[4] = L19_2
  L15_2[5] = L20_2
  L15_2[6] = L21_2
  L15_2[7] = L22_2
  function L16_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    if A0_3 then
      L1_3 = MySQL
      L1_3 = L1_3.insert
      L2_3 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
      L3_3 = {}
      L4_3 = "income"
      L5_3 = L10_2
      L6_3 = "Business registration fee for "
      L7_3 = A0_2
      L6_3 = L6_3 .. L7_3
      L7_3 = L7_2
      L8_3 = L6_2.identifier
      L3_3[1] = L4_3
      L3_3[2] = L5_3
      L3_3[3] = L6_3
      L3_3[4] = L7_3
      L3_3[5] = L8_3
      L1_3(L2_3, L3_3)
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L5_2
      L3_3 = "Business registered successfully. License: "
      L4_3 = L9_2
      L5_3 = " (Fee: $"
      L6_3 = L10_2
      L7_3 = ")"
      L3_3 = L3_3 .. L4_3 .. L5_3 .. L6_3 .. L7_3
      L4_3 = "success"
      L1_3(L2_3, L3_3, L4_3)
      L1_3 = L11_2
      if L1_3 then
        L1_3 = L11_2
        L2_3 = L5_2
        if L1_3 ~= L2_3 then
          L1_3 = Framework
          L1_3 = L1_3.ShowNotification
          L2_3 = L11_2
          L3_3 = "Your business \""
          L4_3 = A0_2
          L5_3 = "\" has been registered. License: "
          L6_3 = L9_2
          L7_3 = " (Fee: $"
          L8_3 = L10_2
          L9_3 = ")"
          L3_3 = L3_3 .. L4_3 .. L5_3 .. L6_3 .. L7_3 .. L8_3 .. L9_3
          L4_3 = "success"
          L1_3(L2_3, L3_3, L4_3)
        end
      end
    else
      L1_3 = Framework
      L1_3 = L1_3.AddMoney
      L2_3 = L11_2
      if not L2_3 then
        L2_3 = L5_2
      end
      L3_3 = L10_2
      L4_3 = "bank"
      L1_3(L2_3, L3_3, L4_3)
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L5_2
      L3_3 = "Business registration failed"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L13_2(L14_2, L15_2, L16_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getBusinesses"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = source
  L1_2 = MySQL
  L1_2 = L1_2.query
  L2_2 = "SELECT * FROM government_businesses WHERE status = ? ORDER BY created_at DESC LIMIT 20"
  L3_2 = {}
  L4_2 = "active"
  L3_2[1] = L4_2
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L0_2
      L3_3 = "No registered businesses found"
      L4_3 = "primary"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = "Registered Businesses: "
    L2_3 = ipairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = L1_3
      L9_3 = string
      L9_3 = L9_3.format
      L10_3 = "%s (%s) - %s "
      L11_3 = L7_3.business_name
      L12_3 = L7_3.business_type
      L13_3 = L7_3.owner_name
      L9_3 = L9_3(L10_3, L11_3, L12_3, L13_3)
      L8_3 = L8_3 .. L9_3
      L1_3 = L8_3
    end
    L2_3 = Framework
    L2_3 = L2_3.ShowNotification
    L3_3 = L0_2
    L4_3 = L1_3
    L5_3 = "success"
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2, L4_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:createPermit"
function L2_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L4_2 = source
  L5_2 = Framework
  L5_2 = L5_2.GetPlayerData
  L6_2 = L4_2
  L5_2 = L5_2(L6_2)
  if not L5_2 then
    return
  end
  L6_2 = Utils
  L6_2 = L6_2.HasPermission
  L7_2 = L5_2.job
  L7_2 = L7_2.name
  L8_2 = L5_2.job
  L8_2 = L8_2.grade
  L9_2 = "license_management"
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  if not L6_2 then
    L6_2 = Framework
    L6_2 = L6_2.ShowNotification
    L7_2 = L4_2
    L8_2 = "You do not have permission to create permits"
    L9_2 = "error"
    L6_2(L7_2, L8_2, L9_2)
    return
  end
  L6_2 = "PER-"
  L7_2 = Utils
  L7_2 = L7_2.GenerateId
  L7_2 = L7_2()
  L6_2 = L6_2 .. L7_2
  L7_2 = os
  L7_2 = L7_2.date
  L8_2 = "%Y-%m-%d %H:%M:%S"
  L9_2 = os
  L9_2 = L9_2.time
  L9_2 = L9_2()
  L10_2 = A3_2 * 24
  L10_2 = L10_2 * 60
  L10_2 = L10_2 * 60
  L9_2 = L9_2 + L10_2
  L7_2 = L7_2(L8_2, L9_2)
  L8_2 = MySQL
  L8_2 = L8_2.execute
  L9_2 = "INSERT INTO government_employees (identifier, name, job, grade) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name)"
  L10_2 = {}
  L11_2 = L5_2.identifier
  L12_2 = L5_2.name
  L13_2 = type
  L14_2 = L5_2.job
  L13_2 = L13_2(L14_2)
  if "table" == L13_2 then
    L13_2 = L5_2.job
    L13_2 = L13_2.name
    if L13_2 then
      goto lbl_66
    end
  end
  L13_2 = L5_2.job
  if not L13_2 then
    L13_2 = "Unknown"
  end
  ::lbl_66::
  L14_2 = type
  L15_2 = L5_2.job
  L14_2 = L14_2(L15_2)
  if "table" == L14_2 then
    L14_2 = type
    L15_2 = L5_2.job
    L15_2 = L15_2.grade
    L14_2 = L14_2(L15_2)
    if "table" == L14_2 then
      L14_2 = L5_2.job
      L14_2 = L14_2.grade
      L14_2 = L14_2.level
      if L14_2 then
        goto lbl_87
      end
    end
    L14_2 = L5_2.job
    L14_2 = L14_2.grade
    if L14_2 then
      goto lbl_87
    end
  end
  L14_2 = 0
  ::lbl_87::
  L10_2[1] = L11_2
  L10_2[2] = L12_2
  L10_2[3] = L13_2
  L10_2[4] = L14_2
  L8_2(L9_2, L10_2)
  L8_2 = MySQL
  L8_2 = L8_2.insert
  L9_2 = "INSERT INTO government_permits (permit_type, permit_number, holder_identifier, holder_name, description, expiry_date, status, issued_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
  L10_2 = {}
  L11_2 = A0_2
  L12_2 = L6_2
  L13_2 = L5_2.identifier
  L14_2 = A1_2
  L15_2 = A2_2
  L16_2 = L7_2
  L17_2 = "active"
  L18_2 = L5_2.identifier
  L10_2[1] = L11_2
  L10_2[2] = L12_2
  L10_2[3] = L13_2
  L10_2[4] = L14_2
  L10_2[5] = L15_2
  L10_2[6] = L16_2
  L10_2[7] = L17_2
  L10_2[8] = L18_2
  function L11_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L1_3 = Framework
    L1_3 = L1_3.ShowNotification
    L2_3 = L4_2
    L3_3 = "Permit created successfully. Number: "
    L4_3 = L6_2
    L3_3 = L3_3 .. L4_3
    L4_3 = "success"
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = GetPlayers
    L1_3 = L1_3()
    L2_3 = ipairs
    L3_3 = L1_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = Framework
      L8_3 = L8_3.GetPlayerData
      L9_3 = L7_3
      L8_3 = L8_3(L9_3)
      if L8_3 then
        L9_3 = L8_3.name
        L10_3 = A1_2
        if L9_3 == L10_3 then
          L9_3 = Framework
          L9_3 = L9_3.ShowNotification
          L10_3 = L7_3
          L11_3 = "You have been issued a "
          L12_3 = A0_2
          L13_3 = " permit. Number: "
          L14_3 = L6_2
          L11_3 = L11_3 .. L12_3 .. L13_3 .. L14_3
          L12_3 = "success"
          L9_3(L10_3, L11_3, L12_3)
          break
        end
      end
    end
  end
  L8_2(L9_2, L10_2, L11_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:revokePermit"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L3_2.job
  L5_2 = L5_2.name
  L6_2 = L3_2.job
  L6_2 = L6_2.grade
  L7_2 = "license_management"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L2_2
    L6_2 = "You do not have permission to revoke permits"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT * FROM government_permits WHERE permit_number = ?"
  L6_2 = {}
  L7_2 = A0_2
  L6_2[1] = L7_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
    L1_3 = A0_3[1]
    if not L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L2_2
      L3_3 = "Permit not found"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = MySQL
    L1_3 = L1_3.execute
    L2_3 = "UPDATE government_permits SET status = ? WHERE permit_number = ?"
    L3_3 = {}
    L4_3 = "revoked"
    L5_3 = A0_2
    L3_3[1] = L4_3
    L3_3[2] = L5_3
    L1_3(L2_3, L3_3)
    L1_3 = Framework
    L1_3 = L1_3.ShowNotification
    L2_3 = L2_2
    L3_3 = "Permit revoked successfully"
    L4_3 = "success"
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = A0_3[1]
    L2_3 = GetPlayers
    L2_3 = L2_3()
    L3_3 = ipairs
    L4_3 = L2_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = Framework
      L9_3 = L9_3.GetPlayerData
      L10_3 = L8_3
      L9_3 = L9_3(L10_3)
      if L9_3 then
        L10_3 = L9_3.identifier
        L11_3 = L1_3.holder_identifier
        if L10_3 == L11_3 then
          L10_3 = Framework
          L10_3 = L10_3.ShowNotification
          L11_3 = L8_3
          L12_3 = "Your "
          L13_3 = L1_3.permit_type
          L14_3 = " permit has been revoked. Reason: "
          L15_3 = A1_2
          L12_3 = L12_3 .. L13_3 .. L14_3 .. L15_3
          L13_3 = "error"
          L10_3(L11_3, L12_3, L13_3)
          break
        end
      end
    end
  end
  L4_2(L5_2, L6_2, L7_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:checkPermit"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = source
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_permits WHERE permit_number = ?"
  L4_2 = {}
  L5_2 = A0_2
  L4_2[1] = L5_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L1_3 = A0_3[1]
    if not L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L1_2
      L3_3 = "Permit not found"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = A0_3[1]
    L2_3 = L1_3.status
    if "suspended" == L2_3 then
      L3_3 = L1_3.unsuspend_date
      if L3_3 then
        L3_3 = os
        L3_3 = L3_3.time
        L4_3 = {}
        L5_3 = tonumber
        L6_3 = string
        L6_3 = L6_3.sub
        L7_3 = L1_3.unsuspend_date
        L8_3 = 1
        L9_3 = 4
        L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
        L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
        L4_3.year = L5_3
        L5_3 = tonumber
        L6_3 = string
        L6_3 = L6_3.sub
        L7_3 = L1_3.unsuspend_date
        L8_3 = 6
        L9_3 = 7
        L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
        L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
        L4_3.month = L5_3
        L5_3 = tonumber
        L6_3 = string
        L6_3 = L6_3.sub
        L7_3 = L1_3.unsuspend_date
        L8_3 = 9
        L9_3 = 10
        L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
        L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
        L4_3.day = L5_3
        L5_3 = tonumber
        L6_3 = string
        L6_3 = L6_3.sub
        L7_3 = L1_3.unsuspend_date
        L8_3 = 12
        L9_3 = 13
        L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
        L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
        L4_3.hour = L5_3
        L5_3 = tonumber
        L6_3 = string
        L6_3 = L6_3.sub
        L7_3 = L1_3.unsuspend_date
        L8_3 = 15
        L9_3 = 16
        L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
        L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
        L4_3.min = L5_3
        L5_3 = tonumber
        L6_3 = string
        L6_3 = L6_3.sub
        L7_3 = L1_3.unsuspend_date
        L8_3 = 18
        L9_3 = 19
        L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
        L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
        L4_3.sec = L5_3
        L3_3 = L3_3(L4_3)
        L4_3 = os
        L4_3 = L4_3.time
        L4_3 = L4_3()
        if L3_3 <= L4_3 then
          L2_3 = "active"
          L4_3 = MySQL
          L4_3 = L4_3.execute
          L5_3 = "UPDATE government_permits SET status = ?, unsuspended_at = ? WHERE id = ?"
          L6_3 = {}
          L7_3 = "active"
          L8_3 = os
          L8_3 = L8_3.date
          L9_3 = "%Y-%m-%d %H:%M:%S"
          L8_3 = L8_3(L9_3)
          L9_3 = L1_3.id
          L6_3[1] = L7_3
          L6_3[2] = L8_3
          L6_3[3] = L9_3
          L4_3(L5_3, L6_3)
        end
      end
    end
    if "active" == L2_3 then
      L3_3 = os
      L3_3 = L3_3.time
      L4_3 = {}
      L5_3 = tonumber
      L6_3 = string
      L6_3 = L6_3.sub
      L7_3 = L1_3.expiry_date
      L8_3 = 1
      L9_3 = 4
      L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
      L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
      L4_3.year = L5_3
      L5_3 = tonumber
      L6_3 = string
      L6_3 = L6_3.sub
      L7_3 = L1_3.expiry_date
      L8_3 = 6
      L9_3 = 7
      L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
      L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
      L4_3.month = L5_3
      L5_3 = tonumber
      L6_3 = string
      L6_3 = L6_3.sub
      L7_3 = L1_3.expiry_date
      L8_3 = 9
      L9_3 = 10
      L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
      L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
      L4_3.day = L5_3
      L5_3 = tonumber
      L6_3 = string
      L6_3 = L6_3.sub
      L7_3 = L1_3.expiry_date
      L8_3 = 12
      L9_3 = 13
      L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
      L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
      L4_3.hour = L5_3
      L5_3 = tonumber
      L6_3 = string
      L6_3 = L6_3.sub
      L7_3 = L1_3.expiry_date
      L8_3 = 15
      L9_3 = 16
      L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
      L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
      L4_3.min = L5_3
      L5_3 = tonumber
      L6_3 = string
      L6_3 = L6_3.sub
      L7_3 = L1_3.expiry_date
      L8_3 = 18
      L9_3 = 19
      L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
      L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
      L4_3.sec = L5_3
      L3_3 = L3_3(L4_3)
      L4_3 = os
      L4_3 = L4_3.time
      L4_3 = L4_3()
      if L3_3 < L4_3 then
        L2_3 = "expired"
        L4_3 = MySQL
        L4_3 = L4_3.execute
        L5_3 = "UPDATE government_permits SET status = ? WHERE id = ?"
        L6_3 = {}
        L7_3 = "expired"
        L8_3 = L1_3.id
        L6_3[1] = L7_3
        L6_3[2] = L8_3
        L4_3(L5_3, L6_3)
      end
    end
    L3_3 = TriggerClientEvent
    L4_3 = "fs-government:client:showPermitDetails"
    L5_3 = L1_2
    L6_3 = {}
    L7_3 = L1_3.permit_number
    L6_3.permit_number = L7_3
    L7_3 = L1_3.permit_type
    L6_3.permit_type = L7_3
    L7_3 = L1_3.holder_name
    L6_3.holder_name = L7_3
    L7_3 = L1_3.description
    L6_3.description = L7_3
    L6_3.status = L2_3
    L7_3 = L1_3.expiry_date
    L6_3.expiry_date = L7_3
    L7_3 = L1_3.issued_at
    L6_3.issued_at = L7_3
    L7_3 = L1_3.fee
    L6_3.fee = L7_3
    L7_3 = L1_3.suspension_reason
    L6_3.suspension_reason = L7_3
    L7_3 = L1_3.unsuspend_date
    L6_3.unsuspend_date = L7_3
    L3_3(L4_3, L5_3, L6_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getExpiredPermits"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = Utils
  L2_2 = L2_2.HasPermission
  L3_2 = L1_2.job
  L3_2 = L3_2.name
  L4_2 = L1_2.job
  L4_2 = L4_2.grade
  L5_2 = "license_management"
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "You do not have permission to view expired permits"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.execute
  L3_2 = "UPDATE government_permits SET status = ? WHERE status = ? AND expiry_date < NOW()"
  L4_2 = {}
  L5_2 = "expired"
  L6_2 = "active"
  L4_2[1] = L5_2
  L4_2[2] = L6_2
  L2_2(L3_2, L4_2)
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_permits WHERE status = ? ORDER BY expiry_date DESC"
  L4_2 = {}
  L5_2 = "expired"
  L4_2[1] = L5_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L0_2
      L3_3 = "No expired permits found"
      L4_3 = "primary"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showExpiredPermits"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getExpiringPermits"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L2_2.job
  L4_2 = L4_2.name
  L5_2 = L2_2.job
  L5_2 = L5_2.grade
  L6_2 = "license_management"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if not L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = L1_2
    L5_2 = "You do not have permission to view expiring permits"
    L6_2 = "error"
    L3_2(L4_2, L5_2, L6_2)
    return
  end
  if not A0_2 then
    A0_2 = 30
  end
  L3_2 = os
  L3_2 = L3_2.date
  L4_2 = "%Y-%m-%d %H:%M:%S"
  L5_2 = os
  L5_2 = L5_2.time
  L5_2 = L5_2()
  L6_2 = A0_2 * 24
  L6_2 = L6_2 * 60
  L6_2 = L6_2 * 60
  L5_2 = L5_2 + L6_2
  L3_2 = L3_2(L4_2, L5_2)
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT * FROM government_permits WHERE status = ? AND expiry_date BETWEEN NOW() AND ? ORDER BY expiry_date ASC"
  L6_2 = {}
  L7_2 = "active"
  L8_2 = L3_2
  L6_2[1] = L7_2
  L6_2[2] = L8_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L1_2
      L3_3 = "No permits expiring in the next "
      L4_3 = A0_2
      L5_3 = " days"
      L3_3 = L3_3 .. L4_3 .. L5_3
      L4_3 = "primary"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showExpiringPermits"
    L3_3 = L1_2
    L4_3 = A0_3
    L5_3 = A0_2
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L4_2(L5_2, L6_2, L7_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getPlayerPermits"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "Unable to retrieve player data"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT p.*, e.name as issued_by_name FROM government_permits p LEFT JOIN government_employees e ON p.issued_by = e.identifier WHERE p.holder_identifier = ? ORDER BY p.issued_at DESC"
  L4_2 = {}
  L5_2 = L1_2.identifier
  L4_2[1] = L5_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L0_2
      L3_3 = "You have no permits on record"
      L4_3 = "primary"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = L6_3.status
      if "active" == L7_3 then
        L7_3 = L6_3.expiry_date
        if L7_3 then
          L7_3 = L6_3.expiry_date
          L8_3 = os
          L8_3 = L8_3.time
          L8_3 = L8_3()
          L9_3 = type
          L10_3 = L7_3
          L9_3 = L9_3(L10_3)
          if "string" == L9_3 then
            L9_3 = "(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)"
            L11_3 = L7_3
            L10_3 = L7_3.match
            L12_3 = L9_3
            L10_3, L11_3, L12_3, L13_3, L14_3, L15_3 = L10_3(L11_3, L12_3)
            if L10_3 then
              L16_3 = os
              L16_3 = L16_3.time
              L17_3 = {}
              L17_3.year = L10_3
              L17_3.month = L11_3
              L17_3.day = L12_3
              L17_3.hour = L13_3
              L17_3.min = L14_3
              L17_3.sec = L15_3
              L16_3 = L16_3(L17_3)
              L7_3 = L16_3
            end
          end
          L9_3 = type
          L10_3 = L7_3
          L9_3 = L9_3(L10_3)
          if "number" == L9_3 and L8_3 > L7_3 then
            L6_3.status = "expired"
            L9_3 = MySQL
            L9_3 = L9_3.execute
            L10_3 = "UPDATE government_permits SET status = ? WHERE id = ?"
            L11_3 = {}
            L12_3 = "expired"
            L13_3 = L6_3.id
            L11_3[1] = L12_3
            L11_3[2] = L13_3
            L9_3(L10_3, L11_3)
          end
        end
      end
      L7_3 = Utils
      L7_3 = L7_3.FormatDate
      L8_3 = L6_3.issued_at
      L7_3 = L7_3(L8_3)
      L6_3.formatted_issued_date = L7_3
      L7_3 = L6_3.expiry_date
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.expiry_date
        L7_3 = L7_3(L8_3)
        L6_3.formatted_expiry_date = L7_3
      end
      L7_3 = L6_3.renewed_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.renewed_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_renewed_date = L7_3
      end
      L7_3 = L6_3.suspended_at
      if L7_3 then
        L7_3 = Utils
        L7_3 = L7_3.FormatDate
        L8_3 = L6_3.suspended_at
        L7_3 = L7_3(L8_3)
        L6_3.formatted_suspended_date = L7_3
      end
    end
    L1_3 = TriggerClientEvent
    L2_3 = "fs-government:client:showPlayerPermits"
    L3_3 = L0_2
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:getPermitDocument"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT p.*, e.name as issued_by_name FROM government_permits p LEFT JOIN government_employees e ON p.issued_by = e.identifier WHERE p.id = ? AND p.holder_identifier = ?"
  L5_2 = {}
  L6_2 = A0_2
  L7_2 = L2_2.identifier
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = A0_3[1]
    if not L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L1_2
      L3_3 = "Permit not found or access denied"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = A0_3[1]
    L2_3 = L2_2.name
    L1_3.holder_name = L2_3
    L2_3 = Utils
    L2_3 = L2_3.FormatDate
    L3_3 = L1_3.issued_at
    L2_3 = L2_3(L3_3)
    L1_3.formatted_issued_date = L2_3
    L2_3 = L1_3.expiry_date
    if L2_3 then
      L2_3 = Utils
      L2_3 = L2_3.FormatDate
      L3_3 = L1_3.expiry_date
      L2_3 = L2_3(L3_3)
      L1_3.formatted_expiry_date = L2_3
    end
    L2_3 = os
    L2_3 = L2_3.date
    L3_3 = "%B %d, %Y"
    L2_3 = L2_3(L3_3)
    L1_3.current_date = L2_3
    L2_3 = TriggerClientEvent
    L3_3 = "fs-government:client:showPermitDocument"
    L4_3 = L1_2
    L5_3 = L1_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L3_2(L4_2, L5_2, L6_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "fs-government:server:showPermitToNearby"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT p.*, e.name as issued_by_name FROM government_permits p LEFT JOIN government_employees e ON p.issued_by = e.identifier WHERE p.id = ? AND p.holder_identifier = ?"
  L5_2 = {}
  L6_2 = A0_2
  L7_2 = L2_2.identifier
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3
    L1_3 = A0_3[1]
    if not L1_3 then
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L1_2
      L3_3 = "Permit not found or access denied"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
      return
    end
    L1_3 = A0_3[1]
    L2_3 = Utils
    L2_3 = L2_3.FormatDate
    L3_3 = L1_3.issued_at
    L2_3 = L2_3(L3_3)
    L1_3.formatted_issued_date = L2_3
    L2_3 = L1_3.expiry_date
    if L2_3 then
      L2_3 = Utils
      L2_3 = L2_3.FormatDate
      L3_3 = L1_3.expiry_date
      L2_3 = L2_3(L3_3)
      L1_3.formatted_expiry_date = L2_3
    end
    L2_3 = os
    L2_3 = L2_3.date
    L3_3 = "%B %d, %Y"
    L2_3 = L2_3(L3_3)
    L1_3.current_date = L2_3
    L2_3 = L2_2.name
    L1_3.shown_by = L2_3
    L2_3 = GetPlayers
    L2_3 = L2_3()
    L3_3 = GetEntityCoords
    L4_3 = GetPlayerPed
    L5_3 = L1_2
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3 = L4_3(L5_3)
    L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
    L4_3 = ipairs
    L5_3 = L2_3
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      L10_3 = tonumber
      L11_3 = L9_3
      L10_3 = L10_3(L11_3)
      if L10_3 then
        L11_3 = L1_2
        if L10_3 ~= L11_3 then
          L11_3 = GetEntityCoords
          L12_3 = GetPlayerPed
          L13_3 = L10_3
          L12_3, L13_3, L14_3, L15_3, L16_3, L17_3 = L12_3(L13_3)
          L11_3 = L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
          L12_3 = L3_3 - L11_3
          L12_3 = #L12_3
          if L12_3 <= 5.0 then
            L13_3 = TriggerClientEvent
            L14_3 = "fs-government:client:viewNearbyPermit"
            L15_3 = L10_3
            L16_3 = L1_3
            L17_3 = L2_2.name
            L13_3(L14_3, L15_3, L16_3, L17_3)
          end
        end
      end
    end
    L4_3 = Framework
    L4_3 = L4_3.ShowNotification
    L5_3 = L1_2
    L6_3 = "Permit shown to nearby players"
    L7_3 = "success"
    L4_3(L5_3, L6_3, L7_3)
  end
  L3_2(L4_2, L5_2, L6_2)
end
L0_1(L1_1, L2_1)
