local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
L0_1 = {}
Database = L0_1
L0_1 = {}
L0_1.government_employees = [[
        CREATE TABLE IF NOT EXISTS `government_employees` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `identifier` varchar(60) NOT NULL,
            `name` varchar(100) NOT NULL,
            `job` varchar(50) NOT NULL,
            `grade` int(11) NOT NULL DEFAULT 0,
            `hired_date` timestamp DEFAULT CURRENT_TIMESTAMP,
            `salary` int(11) NOT NULL DEFAULT 0,
            `last_paycheck` timestamp NULL DEFAULT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `identifier_job` (`identifier`, `job`)
        )
    ]]
L0_1.government_taxation = [[
        CREATE TABLE IF NOT EXISTS `government_taxation` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `identifier` varchar(60) NOT NULL,
            `tax_type` varchar(50) NOT NULL,
            `amount` decimal(10,2) NOT NULL,
            `original_amount` decimal(10,2) NOT NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_elections = [[
        CREATE TABLE IF NOT EXISTS `government_elections` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `title` varchar(255) NOT NULL,
            `description` text,
            `start_date` datetime NOT NULL,
            `end_date` datetime NOT NULL,
            `status` enum('pending','active','completed','cancelled') DEFAULT 'pending',
            `created_by` varchar(60) NOT NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_candidates = [[
        CREATE TABLE IF NOT EXISTS `government_candidates` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `election_id` int(11) NOT NULL,
            `identifier` varchar(60) NOT NULL,
            `name` varchar(100) NOT NULL,
            `campaign_message` text,
            `votes` int(11) DEFAULT 0,
            `registered_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            INDEX `idx_election_id` (`election_id`)
        )
    ]]
L0_1.government_votes = [[
        CREATE TABLE IF NOT EXISTS `government_votes` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `election_id` int(11) NOT NULL,
            `candidate_id` int(11) NOT NULL,
            `voter_identifier` varchar(60) NOT NULL,
            `voted_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `unique_vote` (`election_id`, `voter_identifier`),
            INDEX `idx_election_id` (`election_id`),
            INDEX `idx_candidate_id` (`candidate_id`)
        )
    ]]
L0_1.government_laws = [[
        CREATE TABLE IF NOT EXISTS `government_laws` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `title` varchar(255) NOT NULL,
            `description` text NOT NULL,
            `content` longtext NOT NULL,
            `fine_amount` decimal(10,2) DEFAULT 0,
            `jail_time` int(11) DEFAULT 0,
            `status` enum('active','inactive','draft') DEFAULT 'draft',
            `created_by` varchar(60) NOT NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            `updated_by` varchar(60) DEFAULT NULL,
            `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_appointments = [[
        CREATE TABLE IF NOT EXISTS `government_appointments` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `citizen_identifier` varchar(60) NOT NULL,
            `citizen_name` varchar(100) NOT NULL,
            `appointment_type` varchar(100) NOT NULL,
            `reason` text NOT NULL,
            `preferred_date` datetime NOT NULL,
            `status` enum('pending','approved','rejected','completed') DEFAULT 'pending',
            `assigned_to` varchar(60) NULL,
            `notes` text NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_announcements = [[
        CREATE TABLE IF NOT EXISTS `government_announcements` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `title` varchar(255) NOT NULL,
            `message` text NOT NULL,
            `sender` varchar(100) NOT NULL,
            `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_businesses = [[
        CREATE TABLE IF NOT EXISTS `government_businesses` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `business_name` varchar(255) NOT NULL,
            `owner_identifier` varchar(60) NOT NULL,
            `owner_name` varchar(100) NOT NULL,
            `business_type` varchar(100) NOT NULL,
            `license_number` varchar(50) UNIQUE NOT NULL,
            `registration_fee` decimal(10,2) NOT NULL,
            `tax_rate` decimal(5,2) DEFAULT 12.00,
            `status` enum('active','suspended','revoked') DEFAULT 'active',
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_permits = [[
        CREATE TABLE IF NOT EXISTS `government_permits` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `permit_type` varchar(100) NOT NULL,
            `permit_number` varchar(50) UNIQUE NOT NULL,
            `holder_identifier` varchar(60) NOT NULL,
            `holder_name` varchar(100) NOT NULL,
            `description` text,
            `issued_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            `expiry_date` datetime NOT NULL,
            `status` enum('active','expired','revoked','suspended') DEFAULT 'active',
            `issued_by` varchar(60) NOT NULL,
            `fee` decimal(10,2) DEFAULT 0,
            `renewed_by` varchar(60) NULL,
            `renewed_at` timestamp NULL,
            `suspended_by` varchar(60) NULL,
            `suspension_reason` text NULL,
            `suspended_at` timestamp NULL,
            `unsuspend_date` timestamp NULL,
            `unsuspended_at` timestamp NULL,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_subsidies = [[
        CREATE TABLE IF NOT EXISTS `government_subsidies` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `recipient_identifier` varchar(60) NOT NULL,
            `recipient_name` varchar(100) NOT NULL,
            `subsidy_type` varchar(100) NOT NULL,
            `amount` decimal(15,2) NOT NULL,
            `description` text DEFAULT NULL,
            `duration_days` int(11) DEFAULT NULL,
            `status` enum('pending','approved','paid','rejected','cancelled') DEFAULT 'pending',
            `approved_by` varchar(60) DEFAULT NULL,
            `paid_by` varchar(60) DEFAULT NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_budget = [[
        CREATE TABLE IF NOT EXISTS `government_budget` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `department` varchar(100) NOT NULL,
            `allocated_amount` decimal(15,2) NOT NULL,
            `spent_amount` decimal(15,2) DEFAULT 0,
            `fiscal_year` int(11) NOT NULL,
            `created_by` varchar(60) NOT NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_transactions = [[
        CREATE TABLE IF NOT EXISTS `government_transactions` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `transaction_type` enum('income','expense','tax','fine','subsidy','deposit','withdrawal') NOT NULL,
            `amount` decimal(15,2) NOT NULL,
            `description` text NOT NULL,
            `source_identifier` varchar(60) NULL,
            `processed_by` varchar(60) NOT NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_surveillance_logs = [[
        CREATE TABLE IF NOT EXISTS `government_surveillance_logs` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `camera_id` int(11) NOT NULL,
            `viewed_by` varchar(60) NOT NULL,
            `view_duration` int(11) NOT NULL,
            `notes` text NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_seizures = [[
        CREATE TABLE IF NOT EXISTS `government_seizures` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `target_identifier` varchar(60) NOT NULL,
            `target_name` varchar(100) NOT NULL,
            `item_type` enum('vehicle','item','money') NOT NULL,
            `item_identifier` varchar(255) NOT NULL,
            `item_description` text NOT NULL,
            `reason` text NOT NULL,
            `seized_by` varchar(60) NOT NULL,
            `status` enum('seized','returned','destroyed','deleted') DEFAULT 'seized',
            `returned_by` varchar(60) NULL,
            `returned_at` timestamp NULL,
            `deleted_by` varchar(60) NULL,
            `deletion_reason` text NULL,
            `deleted_at` timestamp NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_settings = [[
        CREATE TABLE IF NOT EXISTS `government_settings` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `setting_key` varchar(100) UNIQUE NOT NULL,
            `setting_value` longtext NOT NULL,
            `updated_by` varchar(60) NOT NULL,
            `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.business_audits = [[
        CREATE TABLE IF NOT EXISTS `business_audits` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `business_id` int(11) NOT NULL,
            `auditor_identifier` varchar(60) NOT NULL,
            `audit_date` timestamp DEFAULT CURRENT_TIMESTAMP,
            `findings` text NOT NULL,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_investments = [[
        CREATE TABLE IF NOT EXISTS `government_investments` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `investment_type` varchar(100) NOT NULL,
            `amount` decimal(15,2) NOT NULL,
            `expected_return` decimal(5,2) NOT NULL,
            `actual_return` decimal(15,2) DEFAULT NULL,
            `duration_days` int(11) NOT NULL,
            `created_by` varchar(60) NOT NULL,
            `status` enum('active','matured','cancelled') DEFAULT 'active',
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.criminal_records = [[
        CREATE TABLE IF NOT EXISTS `criminal_records` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `identifier` varchar(60) NOT NULL,
            `offense` varchar(255) NOT NULL,
            `details` text,
            `added_by` varchar(60) NOT NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.surveillance_reports = [[
        CREATE TABLE IF NOT EXISTS `surveillance_reports` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `camera_id` int(11) NOT NULL,
            `observer_identifier` varchar(60) NOT NULL,
            `observations` text NOT NULL,
            `suspicious_activity` tinyint(1) DEFAULT 0,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_warrants = [[
        CREATE TABLE IF NOT EXISTS `government_warrants` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `warrant_number` varchar(50) UNIQUE NOT NULL,
            `target_name` varchar(100) NOT NULL,
            `offense` varchar(255) NOT NULL,
            `details` text,
            `issued_by` varchar(60) NOT NULL,
            `status` enum('active','executed','cancelled') DEFAULT 'active',
            `urgency` enum('low','medium','high') DEFAULT 'medium',
            `executed_by` varchar(60) NULL,
            `executed_at` timestamp NULL,
            `cancelled_by` varchar(60) NULL,
            `cancellation_reason` text NULL,
            `cancelled_at` timestamp NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_audits = [[
        CREATE TABLE IF NOT EXISTS `government_audits` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `business_name` varchar(200) NOT NULL,
            `owner_identifier` varchar(60) NOT NULL,
            `owner_name` varchar(100) NOT NULL,
            `business_type` varchar(50) DEFAULT NULL,
            `audit_type` varchar(100) NOT NULL,
            `reason` text NOT NULL,
            `status` enum('in_progress','completed','cancelled') DEFAULT 'in_progress',
            `findings` text DEFAULT NULL,
            `initiated_by` varchar(60) NOT NULL,
            `completed_by` varchar(60) DEFAULT NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            `completed_at` timestamp NULL DEFAULT NULL,
            PRIMARY KEY (`id`)
        )
    ]]
L0_1.government_fines = [[
        CREATE TABLE IF NOT EXISTS `government_fines` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `identifier` varchar(60) NOT NULL,
            `name` varchar(100) NOT NULL,
            `amount` decimal(10,2) NOT NULL,
            `reason` text NOT NULL,
            `issued_by` varchar(60) NOT NULL,
            `issued_by_name` varchar(100) NOT NULL,
            `status` enum('unpaid','paid','cancelled') DEFAULT 'unpaid',
            `paid_at` timestamp NULL DEFAULT NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        )
    ]]
L1_1 = {}
L2_1 = {}
L2_1.key = "defcon_level"
L2_1.value = "5"
L2_1.updatedBy = "system"
L3_1 = {}
L3_1.key = "current_mayor"
L3_1.value = ""
L3_1.updatedBy = "system"
L4_1 = {}
L4_1.key = "tax_rates"
L4_1.value = "{\"salary\":0.15,\"business\":0.12,\"vehicle\":0.08,\"property\":0.10}"
L4_1.updatedBy = "system"
L5_1 = {}
L5_1.key = "government_budget"
L5_1.value = "1000000"
L5_1.updatedBy = "system"
L1_1[1] = L2_1
L1_1[2] = L3_1
L1_1[3] = L4_1
L1_1[4] = L5_1
L2_1 = Database
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2
  L0_2 = Utils
  L0_2 = L0_2.DebugSuccess
  L1_2 = "Initializing database tables..."
  L0_2(L1_2)
  L0_2 = {}
  L1_2 = "government_employees"
  L2_2 = "government_taxation"
  L3_2 = "government_elections"
  L4_2 = "government_candidates"
  L5_2 = "government_votes"
  L6_2 = "government_laws"
  L7_2 = "government_appointments"
  L8_2 = "government_announcements"
  L9_2 = "government_businesses"
  L10_2 = "government_permits"
  L11_2 = "government_subsidies"
  L12_2 = "government_budget"
  L13_2 = "government_transactions"
  L14_2 = "government_surveillance_logs"
  L15_2 = "government_seizures"
  L16_2 = "government_settings"
  L17_2 = "business_audits"
  L18_2 = "government_investments"
  L19_2 = "criminal_records"
  L20_2 = "surveillance_reports"
  L21_2 = "government_warrants"
  L22_2 = "government_audits"
  L23_2 = "government_fines"
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L0_2[4] = L4_2
  L0_2[5] = L5_2
  L0_2[6] = L6_2
  L0_2[7] = L7_2
  L0_2[8] = L8_2
  L0_2[9] = L9_2
  L0_2[10] = L10_2
  L0_2[11] = L11_2
  L0_2[12] = L12_2
  L0_2[13] = L13_2
  L0_2[14] = L14_2
  L0_2[15] = L15_2
  L0_2[16] = L16_2
  L0_2[17] = L17_2
  L0_2[18] = L18_2
  L0_2[19] = L19_2
  L0_2[20] = L20_2
  L0_2[21] = L21_2
  L0_2[22] = L22_2
  L0_2[23] = L23_2
  function L1_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = L0_2
    L1_3 = #L1_3
    if A0_3 > L1_3 then
      L1_3 = Database
      L1_3 = L1_3.InitializeSettings
      L1_3()
      return
    end
    L1_3 = L0_2
    L1_3 = L1_3[A0_3]
    L2_3 = L0_1
    L2_3 = L2_3[L1_3]
    if L2_3 then
      L3_3 = MySQL
      L3_3 = L3_3.query
      L4_3 = L2_3
      L5_3 = {}
      function L6_3(A0_4, A1_4)
        local L2_4, L3_4, L4_4, L5_4
        if false ~= A0_4 and not A1_4 then
          L2_4 = Utils
          L2_4 = L2_4.DebugSuccess
          L3_4 = "\226\156\147 Created/verified table: "
          L4_4 = L1_3
          L3_4 = L3_4 .. L4_4
          L2_4(L3_4)
        else
          L2_4 = Utils
          L2_4 = L2_4.DebugError
          L3_4 = "\226\156\151 Failed to create table: "
          L4_4 = L1_3
          L3_4 = L3_4 .. L4_4
          L2_4(L3_4)
          if A1_4 then
            L2_4 = Utils
            L2_4 = L2_4.DebugError
            L3_4 = "  Error: "
            L4_4 = tostring
            L5_4 = A1_4
            L4_4 = L4_4(L5_4)
            L3_4 = L3_4 .. L4_4
            L2_4(L3_4)
          end
        end
        L2_4 = L1_2
        L3_4 = A0_3
        L3_4 = L3_4 + 1
        L2_4(L3_4)
      end
      L3_3(L4_3, L5_3, L6_3)
    else
      L3_3 = Utils
      L3_3 = L3_3.DebugError
      L4_3 = "No query found for table: "
      L5_3 = L1_3
      L4_3 = L4_3 .. L5_3
      L3_3(L4_3)
      L3_3 = L1_2
      L4_3 = A0_3 + 1
      L3_3(L4_3)
    end
  end
  L2_2 = L1_2
  L3_2 = 1
  L2_2(L3_2)
end
L2_1.Initialize = L3_1
L2_1 = Database
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L0_2 = Utils
  L0_2 = L0_2.DebugSuccess
  L1_2 = "Initializing default settings..."
  L0_2(L1_2)
  L0_2 = ipairs
  L1_2 = L1_1
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = MySQL
    L6_2 = L6_2.execute
    L7_2 = [[
            INSERT INTO government_settings (setting_key, setting_value, updated_by)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
        ]]
    L8_2 = {}
    L9_2 = L5_2.key
    L10_2 = L5_2.value
    L11_2 = L5_2.updatedBy
    L8_2[1] = L9_2
    L8_2[2] = L10_2
    L8_2[3] = L11_2
    function L9_2(A0_3, A1_3)
      local L2_3, L3_3, L4_3, L5_3
      if A0_3 and not A1_3 then
        L2_3 = Utils
        L2_3 = L2_3.DebugSuccess
        L3_3 = "\226\156\147 Initialized setting: "
        L4_3 = L5_2.key
        L3_3 = L3_3 .. L4_3
        L2_3(L3_3)
      else
        L2_3 = Utils
        L2_3 = L2_3.DebugError
        L3_3 = "\226\156\151 Failed to initialize setting: "
        L4_3 = L5_2.key
        L3_3 = L3_3 .. L4_3
        L2_3(L3_3)
        if A1_3 then
          L2_3 = Utils
          L2_3 = L2_3.DebugError
          L3_3 = "  Error: "
          L4_3 = tostring
          L5_3 = A1_3
          L4_3 = L4_3(L5_3)
          L3_3 = L3_3 .. L4_3
          L2_3(L3_3)
        end
      end
    end
    L6_2(L7_2, L8_2, L9_2)
  end
  L0_2 = Wait
  L1_2 = 1000
  L0_2(L1_2)
  L0_2 = Utils
  L0_2 = L0_2.DebugSuccess
  L1_2 = "\240\159\142\137 Database initialization completed!"
  L0_2(L1_2)
end
L2_1.InitializeSettings = L3_1
L2_1 = Database
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SHOW TABLES LIKE ?"
  L4_2 = {}
  L5_2 = A0_2
  L4_2[1] = L5_2
  function L5_2(A0_3)
    local L1_3, L2_3
    L1_3 = A1_2
    L2_3 = A0_3 or L2_3
    if A0_3 then
      L2_3 = #A0_3
      L2_3 = L2_3 > 0
    end
    L1_3(L2_3)
  end
  L2_2(L3_2, L4_2, L5_2)
end
L2_1.TableExists = L3_1
L2_1 = Database
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L1_2 = {}
  L2_2 = {}
  L1_2.tables = L2_2
  L2_2 = {}
  L1_2.settings = L2_2
  L1_2.initialized = false
  L2_2 = 0
  L3_2 = 0
  L4_2 = pairs
  L5_2 = L0_1
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
  for L8_2 in L4_2, L5_2, L6_2, L7_2 do
    L3_2 = L3_2 + 1
  end
  L4_2 = pairs
  L5_2 = L0_1
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
  for L8_2 in L4_2, L5_2, L6_2, L7_2 do
    L9_2 = Database
    L9_2 = L9_2.TableExists
    L10_2 = L8_2
    function L11_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3
      L1_3 = L1_2.tables
      L2_3 = L8_2
      L1_3[L2_3] = A0_3
      L1_3 = L2_2
      L1_3 = L1_3 + 1
      L2_2 = L1_3
      L1_3 = L2_2
      L2_3 = L3_2
      if L1_3 == L2_3 then
        L1_3 = MySQL
        L1_3 = L1_3.query
        L2_3 = "SELECT setting_key, setting_value FROM government_settings"
        L3_3 = {}
        function L4_3(A0_4)
          local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4
          if A0_4 then
            L1_4 = ipairs
            L2_4 = A0_4
            L1_4, L2_4, L3_4, L4_4 = L1_4(L2_4)
            for L5_4, L6_4 in L1_4, L2_4, L3_4, L4_4 do
              L7_4 = L1_2.settings
              L8_4 = L6_4.setting_key
              L9_4 = L6_4.setting_value
              L7_4[L8_4] = L9_4
            end
          end
          L1_4 = true
          L2_4 = pairs
          L3_4 = L1_2.tables
          L2_4, L3_4, L4_4, L5_4 = L2_4(L3_4)
          for L6_4, L7_4 in L2_4, L3_4, L4_4, L5_4 do
            if not L7_4 then
              L1_4 = false
              break
            end
          end
          L2_4 = L1_4 or L2_4
          if L1_4 then
            L2_4 = A0_4 or L2_4
            if not A0_4 then
              L2_4 = {}
            end
            L2_4 = #L2_4
            L2_4 = L2_4 > 0
          end
          L1_2.initialized = L2_4
          L2_4 = A0_2
          L3_4 = L1_2
          L2_4(L3_4)
        end
        L1_3(L2_3, L3_3, L4_3)
      end
    end
    L9_2(L10_2, L11_2)
  end
end
L2_1.GetStatus = L3_1
