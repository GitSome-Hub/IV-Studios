local L0_1, L1_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2
  if not A0_2 or "" == A0_2 or "NULL" == A0_2 then
    L1_2 = "Unknown Date"
    return L1_2
  end
  L1_2 = tostring
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  L2_2 = {}
  L3_2 = {}
  L3_2.pattern = "(%d%d%d%d)-(%d%d)-(%d%d) (%d%d):(%d%d):(%d%d)"
  L3_2.format = "%s %d, %s at %02d:%02d"
  L4_2 = {}
  L4_2.pattern = "(%d%d%d%d)-(%d%d)-(%d%d)"
  L4_2.format = "%s %d, %s"
  L5_2 = {}
  L5_2.pattern = "(%d%d%d%d)-(%d%d)-(%d%d)T(%d%d):(%d%d):(%d%d)"
  L5_2.format = "%s %d, %s at %02d:%02d"
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L3_2 = {}
  L4_2 = "Jan"
  L5_2 = "Feb"
  L6_2 = "Mar"
  L7_2 = "Apr"
  L8_2 = "May"
  L9_2 = "Jun"
  L10_2 = "Jul"
  L11_2 = "Aug"
  L12_2 = "Sep"
  L13_2 = "Oct"
  L14_2 = "Nov"
  L15_2 = "Dec"
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L3_2[3] = L6_2
  L3_2[4] = L7_2
  L3_2[5] = L8_2
  L3_2[6] = L9_2
  L3_2[7] = L10_2
  L3_2[8] = L11_2
  L3_2[9] = L12_2
  L3_2[10] = L13_2
  L3_2[11] = L14_2
  L3_2[12] = L15_2
  L4_2 = ipairs
  L5_2 = L2_2
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
  for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
    L11_2 = L1_2
    L10_2 = L1_2.match
    L12_2 = L9_2.pattern
    L10_2, L11_2, L12_2, L13_2, L14_2, L15_2 = L10_2(L11_2, L12_2)
    if L10_2 and L11_2 and L12_2 then
      L16_2 = tonumber
      L17_2 = L10_2
      L16_2 = L16_2(L17_2)
      L10_2 = L16_2
      L16_2 = tonumber
      L17_2 = L11_2
      L16_2 = L16_2(L17_2)
      L11_2 = L16_2
      L16_2 = tonumber
      L17_2 = L12_2
      L16_2 = L16_2(L17_2)
      L12_2 = L16_2
      L16_2 = tonumber
      L17_2 = L13_2
      L16_2 = L16_2(L17_2)
      L13_2 = L16_2 or L13_2
      if not L16_2 then
        L13_2 = 0
      end
      L16_2 = tonumber
      L17_2 = L14_2
      L16_2 = L16_2(L17_2)
      L14_2 = L16_2 or L14_2
      if not L16_2 then
        L14_2 = 0
      end
      if L10_2 then
        L16_2 = 1970
        if L10_2 > L16_2 then
          L16_2 = 3000
          if L10_2 < L16_2 and L11_2 and L11_2 >= 1 and L11_2 <= 12 and L12_2 and L12_2 >= 1 and L12_2 <= 31 then
            L16_2 = L3_2[L11_2]
            if not L16_2 then
              L16_2 = "Unknown"
            end
            if L13_2 > 0 or L14_2 > 0 then
              L17_2 = string
              L17_2 = L17_2.format
              L18_2 = "%s %d, %d at %02d:%02d"
              L19_2 = L16_2
              L20_2 = L12_2
              L21_2 = L10_2
              L22_2 = L13_2
              L23_2 = L14_2
              return L17_2(L18_2, L19_2, L20_2, L21_2, L22_2, L23_2)
            else
              L17_2 = string
              L17_2 = L17_2.format
              L18_2 = "%s %d, %d"
              L19_2 = L16_2
              L20_2 = L12_2
              L21_2 = L10_2
              return L17_2(L18_2, L19_2, L20_2, L21_2)
            end
          end
        end
      end
    end
  end
  L5_2 = L1_2
  L4_2 = L1_2.gsub
  L6_2 = "T"
  L7_2 = " "
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  L5_2 = L4_2
  L4_2 = L4_2.gsub
  L6_2 = "%.%d+Z?"
  L7_2 = ""
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  L5_2 = L4_2
  L4_2 = L4_2.gsub
  L6_2 = "Z"
  L7_2 = ""
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  L5_2 = L4_2 or L5_2
  if "" == L4_2 or not L4_2 then
    L5_2 = "Invalid Date"
  end
  return L5_2
end
SafeFormatDatetime = L0_1
L0_1 = SafeFormatDatetime
return L0_1
