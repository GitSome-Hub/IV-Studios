local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1
L0_1 = {}
L1_1 = {}
L2_1 = {}
L3_1 = {}
L4_1 = CreateThread
function L5_1()
  local L0_2, L1_2, L2_2, L3_2
  while true do
    L0_2 = GetResourceState
    L1_2 = "oxmysql"
    L0_2 = L0_2(L1_2)
    if "started" == L0_2 then
      break
    end
    L0_2 = Wait
    L1_2 = 100
    L0_2(L1_2)
  end
  L0_2 = Database
  L0_2 = L0_2.Initialize
  L0_2()
  L0_2 = Wait
  L1_2 = 8000
  L0_2(L1_2)
  L0_2 = InitializeInventory
  L0_2()
  L0_2 = InitializeTaxation
  L0_2()
  L0_2 = Utils
  L0_2 = L0_2.DebugSuccess
  L1_2 = "Server started successfully"
  L0_2(L1_2)
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    while true do
      L0_3 = GetGameTimer
      L0_3 = L0_3()
      L1_3 = pairs
      L2_3 = L2_1
      L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
      for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
        if L6_3 < L0_3 then
          L7_3 = L2_1
          L7_3[L5_3] = nil
        end
      end
      L1_3 = Wait
      L2_3 = 30000
      L1_3(L2_3)
    end
  end
  L0_2(L1_2)
  L0_2 = Config
  L0_2 = L0_2.Debug
  if L0_2 then
    L0_2 = RegisterCommand
    L1_2 = "gov_debug_armory"
    function L2_2(A0_3, A1_3, A2_3)
      local L3_3, L4_3, L5_3, L6_3, L7_3
      L3_3 = Inventory
      L3_3 = L3_3.GetType
      L3_3 = L3_3()
      L4_3 = Utils
      L4_3 = L4_3.DebugPrint
      L5_3 = "Current inventory type: "
      L6_3 = tostring
      L7_3 = L3_3
      L6_3 = L6_3(L7_3)
      L5_3 = L5_3 .. L6_3
      L4_3(L5_3)
      L4_3 = Utils
      L4_3 = L4_3.DebugPrint
      L5_3 = "Available weapons: "
      L6_3 = Config
      L6_3 = L6_3.Weapons
      L6_3 = #L6_3
      L5_3 = L5_3 .. L6_3
      L4_3(L5_3)
      L4_3 = Utils
      L4_3 = L4_3.DebugPrint
      L5_3 = "Available items: "
      L6_3 = Config
      L6_3 = L6_3.Items
      L6_3 = #L6_3
      L5_3 = L5_3 .. L6_3
      L4_3(L5_3)
      if 0 == A0_3 then
        L4_3 = Utils
        L4_3 = L4_3.DebugPrint
        L5_3 = "Armory shop should be accessible to government employees with armory_access permission"
        L4_3(L5_3)
      else
        L4_3 = TriggerClientEvent
        L5_3 = "fs-government:client:openArmoryMenu"
        L6_3 = A0_3
        L4_3(L5_3, L6_3)
      end
    end
    L3_2 = true
    L0_2(L1_2, L2_2, L3_2)
    L0_2 = RegisterCommand
    L1_2 = "gov_reregister_shop"
    function L2_2(A0_3, A1_3, A2_3)
      local L3_3, L4_3
      if 0 ~= A0_3 then
        return
      end
      L3_3 = Utils
      L3_3 = L3_3.DebugPrint
      L4_3 = "Re-registering armory shop..."
      L3_3(L4_3)
      L3_3 = Inventory
      L3_3 = L3_3.SetupArmoryShop
      L3_3()
    end
    L3_2 = true
    L0_2(L1_2, L2_2, L3_2)
    L0_2 = RegisterCommand
    L1_2 = "gov_db_status"
    function L2_2(A0_3, A1_3, A2_3)
      local L3_3, L4_3
      if 0 ~= A0_3 then
        return
      end
      L3_3 = Utils
      L3_3 = L3_3.DebugPrint
      L4_3 = "Checking database status..."
      L3_3(L4_3)
      L3_3 = Database
      L3_3 = L3_3.GetStatus
      function L4_3(A0_4)
        local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4
        L1_4 = Utils
        L1_4 = L1_4.DebugSuccess
        L2_4 = "Database Status:"
        L1_4(L2_4)
        L1_4 = Utils
        L1_4 = L1_4.DebugPrint
        L2_4 = "Initialized: "
        L3_4 = tostring
        L4_4 = A0_4.initialized
        L3_4 = L3_4(L4_4)
        L2_4 = L2_4 .. L3_4
        L1_4(L2_4)
        L1_4 = Utils
        L1_4 = L1_4.DebugPrint
        L2_4 = "Tables:"
        L1_4(L2_4)
        L1_4 = pairs
        L2_4 = A0_4.tables
        L1_4, L2_4, L3_4, L4_4 = L1_4(L2_4)
        for L5_4, L6_4 in L1_4, L2_4, L3_4, L4_4 do
          if L6_4 then
            L7_4 = "^2EXISTS^7"
            if L7_4 then
              goto lbl_27
            end
          end
          L7_4 = "^1MISSING^7"
          ::lbl_27::
          L8_4 = Utils
          L8_4 = L8_4.DebugPrint
          L9_4 = "  - "
          L10_4 = L5_4
          L11_4 = ": "
          L12_4 = L7_4
          L9_4 = L9_4 .. L10_4 .. L11_4 .. L12_4
          L8_4(L9_4)
        end
        L1_4 = Utils
        L1_4 = L1_4.DebugPrint
        L2_4 = "Settings Count: "
        L3_4 = A0_4.settings
        if L3_4 then
          L3_4 = A0_4.settings
          L3_4 = #L3_4
          if L3_4 then
            goto lbl_49
          end
        end
        L3_4 = 0
        ::lbl_49::
        L2_4 = L2_4 .. L3_4
        L1_4(L2_4)
      end
      L3_3(L4_3)
    end
    L3_2 = true
    L0_2(L1_2, L2_2, L3_2)
    L0_2 = RegisterCommand
    L1_2 = "gov_db_init"
    function L2_2(A0_3, A1_3, A2_3)
      local L3_3, L4_3
      if 0 ~= A0_3 then
        return
      end
      L3_3 = Utils
      L3_3 = L3_3.DebugPrint
      L4_3 = "Force initializing database..."
      L3_3(L4_3)
      L3_3 = Database
      L3_3 = L3_3.Initialize
      L3_3()
    end
    L3_2 = true
    L0_2(L1_2, L2_2, L3_2)
    L0_2 = RegisterCommand
    L1_2 = "gov_test_tables"
    function L2_2(A0_3, A1_3, A2_3)
      local L3_3, L4_3, L5_3, L6_3
      if 0 ~= A0_3 then
        return
      end
      L3_3 = Utils
      L3_3 = L3_3.DebugPrint
      L4_3 = "Testing table access..."
      L3_3(L4_3)
      L3_3 = MySQL
      L3_3 = L3_3.query
      L4_3 = "SELECT COUNT(*) as count FROM government_settings"
      L5_3 = {}
      function L6_3(A0_4, A1_4)
        local L2_4, L3_4, L4_4, L5_4
        if A1_4 then
          L2_4 = Utils
          L2_4 = L2_4.DebugError
          L3_4 = "government_settings table error: "
          L4_4 = tostring
          L5_4 = A1_4
          L4_4 = L4_4(L5_4)
          L3_4 = L3_4 .. L4_4
          L2_4(L3_4)
        else
          L2_4 = Utils
          L2_4 = L2_4.DebugSuccess
          L3_4 = "government_settings table OK: "
          L4_4 = A0_4[1]
          if L4_4 then
            L4_4 = A0_4[1]
            L4_4 = L4_4.count
            if L4_4 then
              goto lbl_23
            end
          end
          L4_4 = 0
          ::lbl_23::
          L5_4 = " records"
          L3_4 = L3_4 .. L4_4 .. L5_4
          L2_4(L3_4)
        end
      end
      L3_3(L4_3, L5_3, L6_3)
      L3_3 = MySQL
      L3_3 = L3_3.query
      L4_3 = "SELECT COUNT(*) as count FROM government_businesses"
      L5_3 = {}
      function L6_3(A0_4, A1_4)
        local L2_4, L3_4, L4_4, L5_4
        if A1_4 then
          L2_4 = Utils
          L2_4 = L2_4.DebugError
          L3_4 = "government_businesses table error: "
          L4_4 = tostring
          L5_4 = A1_4
          L4_4 = L4_4(L5_4)
          L3_4 = L3_4 .. L4_4
          L2_4(L3_4)
        else
          L2_4 = Utils
          L2_4 = L2_4.DebugSuccess
          L3_4 = "government_businesses table OK: "
          L4_4 = A0_4[1]
          if L4_4 then
            L4_4 = A0_4[1]
            L4_4 = L4_4.count
            if L4_4 then
              goto lbl_23
            end
          end
          L4_4 = 0
          ::lbl_23::
          L5_4 = " records"
          L3_4 = L3_4 .. L4_4 .. L5_4
          L2_4(L3_4)
        end
      end
      L3_3(L4_3, L5_3, L6_3)
    end
    L3_2 = true
    L0_2(L1_2, L2_2, L3_2)
  end
end
L4_1(L5_1)
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = Inventory
  L0_2 = L0_2.GetType
  L0_2 = L0_2()
  L1_2 = Utils
  L1_2 = L1_2.DebugPrint
  L2_2 = "Initializing inventory with type: "
  L3_2 = tostring
  L4_2 = L0_2
  L3_2 = L3_2(L4_2)
  L2_2 = L2_2 .. L3_2
  L1_2(L2_2)
  L1_2 = Inventory
  L1_2 = L1_2.SetupArmoryStash
  L1_2()
  L1_2 = Inventory
  L1_2 = L1_2.SetupSharedStash
  L1_2()
  L1_2 = Inventory
  L1_2 = L1_2.SetupArmoryShop
  L1_2()
  L1_2 = Utils
  L1_2 = L1_2.DebugSuccess
  L2_2 = "Inventory initialization completed"
  L1_2(L2_2)
end
InitializeInventory = L4_1
function L4_1()
  local L0_2, L1_2
  L0_2 = Config
  L0_2 = L0_2.Taxation
  L0_2 = L0_2.enabled
  if L0_2 then
    L0_2 = CreateThread
    function L1_2()
      local L0_3, L1_3
      while true do
        L0_3 = CollectSalaryTax
        L0_3()
        L0_3 = Wait
        L1_3 = Config
        L1_3 = L1_3.Taxation
        L1_3 = L1_3.intervals
        L1_3 = L1_3.salary
        L0_3(L1_3)
      end
    end
    L0_2(L1_2)
    L0_2 = CreateThread
    function L1_2()
      local L0_3, L1_3
      while true do
        L0_3 = CollectBusinessTax
        L0_3()
        L0_3 = Wait
        L1_3 = Config
        L1_3 = L1_3.Taxation
        L1_3 = L1_3.intervals
        L1_3 = L1_3.business
        L0_3(L1_3)
      end
    end
    L0_2(L1_2)
  end
end
InitializeTaxation = L4_1
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L0_2 = GetPlayers
  L0_2 = L0_2()
  L1_2 = ipairs
  L2_2 = L0_2
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = Framework
    L7_2 = L7_2.GetPlayerData
    L8_2 = L6_2
    L7_2 = L7_2(L8_2)
    if L7_2 then
      L8_2 = L7_2.job
      if L8_2 then
        L8_2 = Utils
        L8_2 = L8_2.TableContains
        L9_2 = Config
        L9_2 = L9_2.Government
        L9_2 = L9_2.jobs
        L10_2 = L7_2.job
        L10_2 = L10_2.name
        L8_2 = L8_2(L9_2, L10_2)
        if L8_2 then
          L8_2 = 0
          L9_2 = Framework
          L9_2 = L9_2.GetFramework
          L9_2 = L9_2()
          if "esx" == L9_2 then
            L10_2 = MySQL
            L10_2 = L10_2.query
            L11_2 = "SELECT salary FROM job_grades WHERE job_name = ? AND grade = ?"
            L12_2 = {}
            L13_2 = L7_2.job
            L13_2 = L13_2.name
            L14_2 = L7_2.job
            L14_2 = L14_2.grade
            L12_2[1] = L13_2
            L12_2[2] = L14_2
            function L13_2(A0_3)
              local L1_3, L2_3, L3_3, L4_3
              if A0_3 then
                L1_3 = #A0_3
                if L1_3 > 0 then
                  L1_3 = A0_3[1]
                  L1_3 = L1_3.salary
                  if not L1_3 then
                    L1_3 = 0
                  end
                  L8_2 = L1_3
                  L1_3 = ProcessSalaryTax
                  L2_3 = L6_2
                  L3_3 = L7_2
                  L4_3 = L8_2
                  L1_3(L2_3, L3_3, L4_3)
                end
              end
            end
            L10_2(L11_2, L12_2, L13_2)
          elseif "qbcore" == L9_2 or "qbox" == L9_2 then
            L10_2 = exports
            L10_2 = L10_2["qb-core"]
            L11_2 = L10_2
            L10_2 = L10_2.GetCoreObject
            L10_2 = L10_2(L11_2)
            L11_2 = L10_2.Shared
            L11_2 = L11_2.Jobs
            L12_2 = L7_2.job
            L12_2 = L12_2.name
            L12_2 = L11_2[L12_2]
            if L12_2 then
              L12_2 = L7_2.job
              L12_2 = L12_2.name
              L12_2 = L11_2[L12_2]
              L12_2 = L12_2.grades
              if L12_2 then
                L12_2 = L7_2.job
                L12_2 = L12_2.name
                L12_2 = L11_2[L12_2]
                L12_2 = L12_2.grades
                L13_2 = tostring
                L14_2 = L7_2.job
                L14_2 = L14_2.grade
                L13_2 = L13_2(L14_2)
                L12_2 = L12_2[L13_2]
                if L12_2 then
                  L12_2 = L7_2.job
                  L12_2 = L12_2.name
                  L12_2 = L11_2[L12_2]
                  L12_2 = L12_2.grades
                  L13_2 = tostring
                  L14_2 = L7_2.job
                  L14_2 = L14_2.grade
                  L13_2 = L13_2(L14_2)
                  L12_2 = L12_2[L13_2]
                  L12_2 = L12_2.payment
                  L8_2 = L12_2 or L8_2
                  if not L12_2 then
                    L8_2 = 0
                  end
                end
              end
            end
            L12_2 = ProcessSalaryTax
            L13_2 = L6_2
            L14_2 = L7_2
            L15_2 = L8_2
            L12_2(L13_2, L14_2, L15_2)
          end
        end
      end
    end
  end
end
CollectSalaryTax = L4_1
function L4_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  if A2_2 > 0 then
    L3_2 = Config
    L3_2 = L3_2.Taxation
    L3_2 = L3_2.rates
    L3_2 = L3_2.salary
    L3_2 = A2_2 * L3_2
    L4_2 = Framework
    L4_2 = L4_2.RemoveMoney
    L5_2 = A0_2
    L6_2 = L3_2
    L7_2 = "bank"
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    if L4_2 then
      L4_2 = MySQL
      L4_2 = L4_2.insert
      L5_2 = "INSERT INTO government_taxation (identifier, tax_type, amount, original_amount) VALUES (?, ?, ?, ?)"
      L6_2 = {}
      L7_2 = A1_2.identifier
      L8_2 = "salary"
      L9_2 = L3_2
      L10_2 = A2_2
      L6_2[1] = L7_2
      L6_2[2] = L8_2
      L6_2[3] = L9_2
      L6_2[4] = L10_2
      L4_2(L5_2, L6_2)
      L4_2 = MySQL
      L4_2 = L4_2.insert
      L5_2 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
      L6_2 = {}
      L7_2 = "tax"
      L8_2 = L3_2
      L9_2 = "Salary tax collection"
      L10_2 = A1_2.identifier
      L11_2 = "system"
      L6_2[1] = L7_2
      L6_2[2] = L8_2
      L6_2[3] = L9_2
      L6_2[4] = L10_2
      L6_2[5] = L11_2
      L4_2(L5_2, L6_2)
    end
  end
end
ProcessSalaryTax = L4_1
function L4_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = MySQL
  L0_2 = L0_2.query
  L1_2 = "SELECT * FROM government_businesses WHERE status = ?"
  L2_2 = {}
  L3_2 = "active"
  L2_2[1] = L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
    L1_3 = ipairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = math
      L7_3 = L7_3.random
      L8_3 = 1000
      L9_3 = 5000
      L7_3 = L7_3(L8_3, L9_3)
      L8_3 = L6_3.tax_rate
      L8_3 = L8_3 / 100
      L7_3 = L7_3 * L8_3
      L8_3 = MySQL
      L8_3 = L8_3.insert
      L9_3 = "INSERT INTO government_taxation (identifier, tax_type, amount, original_amount) VALUES (?, ?, ?, ?)"
      L10_3 = {}
      L11_3 = L6_3.owner_identifier
      L12_3 = "business"
      L13_3 = L7_3
      L14_3 = L6_3.tax_rate
      L14_3 = L14_3 / 100
      L14_3 = L7_3 / L14_3
      L10_3[1] = L11_3
      L10_3[2] = L12_3
      L10_3[3] = L13_3
      L10_3[4] = L14_3
      L8_3(L9_3, L10_3)
      L8_3 = MySQL
      L8_3 = L8_3.insert
      L9_3 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
      L10_3 = {}
      L11_3 = "tax"
      L12_3 = L7_3
      L13_3 = "Business tax for "
      L14_3 = L6_3.business_name
      L13_3 = L13_3 .. L14_3
      L14_3 = L6_3.owner_identifier
      L15_3 = "system"
      L10_3[1] = L11_3
      L10_3[2] = L12_3
      L10_3[3] = L13_3
      L10_3[4] = L14_3
      L10_3[5] = L15_3
      L8_3(L9_3, L10_3)
    end
  end
  L0_2(L1_2, L2_2, L3_2)
end
CollectBusinessTax = L4_1
L4_1 = RegisterNetEvent
L5_1 = "fs-government:server:toggleDuty"
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  if A0_2 then
    L3_2 = L0_1
    L4_2 = {}
    L5_2 = L2_2.identifier
    L4_2.identifier = L5_2
    L5_2 = L2_2.name
    L4_2.name = L5_2
    L5_2 = L2_2.job
    L4_2.job = L5_2
    L5_2 = L2_2.grade
    L4_2.grade = L5_2
    L5_2 = os
    L5_2 = L5_2.time
    L5_2 = L5_2()
    L4_2.startTime = L5_2
    L3_2[L1_2] = L4_2
  else
    L3_2 = L0_1
    L3_2 = L3_2[L1_2]
    if L3_2 then
      L3_2 = os
      L3_2 = L3_2.time
      L3_2 = L3_2()
      L4_2 = L0_1
      L4_2 = L4_2[L1_2]
      L4_2 = L4_2.startTime
      L3_2 = L3_2 - L4_2
      L4_2 = type
      L5_2 = L2_2.job
      L4_2 = L4_2(L5_2)
      if "table" == L4_2 then
        L4_2 = L2_2.job
        L4_2 = L4_2.name
        if L4_2 then
          goto lbl_50
        end
      end
      L4_2 = L2_2.job
      ::lbl_50::
      L5_2 = type
      L6_2 = L2_2.job
      L5_2 = L5_2(L6_2)
      if "table" == L5_2 then
        L5_2 = L2_2.job
        L5_2 = L5_2.grade
        if L5_2 then
          L5_2 = type
          L6_2 = L2_2.job
          L6_2 = L6_2.grade
          L5_2 = L5_2(L6_2)
          if "table" == L5_2 then
            L5_2 = L2_2.job
            L5_2 = L5_2.grade
            L5_2 = L5_2.level
            if L5_2 then
              goto lbl_81
            end
          end
          L5_2 = L2_2.job
          L5_2 = L5_2.grade
          if L5_2 then
            goto lbl_81
          end
        end
        L5_2 = 0
        if L5_2 then
          goto lbl_81
        end
      end
      L5_2 = L2_2.grade
      if not L5_2 then
        L5_2 = 0
      end
      ::lbl_81::
      L6_2 = MySQL
      L6_2 = L6_2.insert
      L7_2 = "INSERT INTO government_employees (identifier, name, job, grade, last_paycheck) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE last_paycheck = VALUES(last_paycheck)"
      L8_2 = {}
      L9_2 = L2_2.identifier
      L10_2 = L2_2.name
      L11_2 = L4_2
      L12_2 = L5_2
      L13_2 = os
      L13_2 = L13_2.date
      L14_2 = "%Y-%m-%d %H:%M:%S"
      L13_2, L14_2 = L13_2(L14_2)
      L8_2[1] = L9_2
      L8_2[2] = L10_2
      L8_2[3] = L11_2
      L8_2[4] = L12_2
      L8_2[5] = L13_2
      L8_2[6] = L14_2
      L6_2(L7_2, L8_2)
      L6_2 = L0_1
      L6_2[L1_2] = nil
    end
  end
end
L4_1(L5_1, L6_1)
L4_1 = RegisterNetEvent
L5_1 = "fs-government:server:searchPlayer"
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  if not L2_2 or not L3_2 then
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L2_2.job
  L5_2 = L5_2.name
  L6_2 = L2_2.job
  L6_2 = L6_2.grade
  L7_2 = "search_players"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L1_2
    L6_2 = "You do not have permission to search players"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = Framework
  L4_2 = L4_2.GetFramework
  L4_2 = L4_2()
  L5_2 = {}
  L6_2 = {}
  if "esx" == L4_2 then
    L7_2 = exports
    L7_2 = L7_2.es_extended
    L8_2 = L7_2
    L7_2 = L7_2.getSharedObject
    L7_2 = L7_2(L8_2)
    L8_2 = L7_2.GetPlayerFromId
    L9_2 = A0_2
    L8_2 = L8_2(L9_2)
    if L8_2 then
      L9_2 = L8_2.inventory
      L5_2 = L9_2 or L5_2
      if not L9_2 then
        L9_2 = {}
        L5_2 = L9_2
      end
      L9_2 = MySQL
      L9_2 = L9_2.query
      L10_2 = "SELECT * FROM user_licenses WHERE owner = ?"
      L11_2 = {}
      L12_2 = L3_2.identifier
      L11_2[1] = L12_2
      function L12_2(A0_3)
        local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
        if A0_3 then
          L1_3 = ipairs
          L2_3 = A0_3
          L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
          for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
            L7_3 = table
            L7_3 = L7_3.insert
            L8_3 = L6_2
            L9_3 = {}
            L10_3 = L6_3.type
            L9_3.type = L10_3
            L10_3 = L6_3.type
            L11_3 = L10_3
            L10_3 = L10_3.gsub
            L12_3 = "_"
            L13_3 = " "
            L10_3 = L10_3(L11_3, L12_3, L13_3)
            L11_3 = L10_3
            L10_3 = L10_3.upper
            L10_3 = L10_3(L11_3)
            L9_3.label = L10_3
            L7_3(L8_3, L9_3)
          end
        end
        L1_3 = {}
        L2_3 = L3_2.name
        L1_3.targetName = L2_3
        L2_3 = A0_2
        L1_3.targetId = L2_3
        L2_3 = L5_2
        L1_3.inventory = L2_3
        L2_3 = L6_2
        L1_3.licenses = L2_3
        L2_3 = L5_2
        L2_3 = #L2_3
        L1_3.itemCount = L2_3
        L2_3 = TriggerClientEvent
        L3_3 = "fs-government:client:showSearchResults"
        L4_3 = L1_2
        L5_3 = L1_3
        L2_3(L3_3, L4_3, L5_3)
        L2_3 = Framework
        L2_3 = L2_3.ShowNotification
        L3_3 = A0_2
        L4_3 = "You are being searched by "
        L5_3 = L2_2.name
        L4_3 = L4_3 .. L5_3
        L5_3 = "primary"
        L2_3(L3_3, L4_3, L5_3)
      end
      L9_2(L10_2, L11_2, L12_2)
    end
  elseif "qbcore" == L4_2 or "qbox" == L4_2 then
    L7_2 = exports
    L7_2 = L7_2["qb-core"]
    L8_2 = L7_2
    L7_2 = L7_2.GetCoreObject
    L7_2 = L7_2(L8_2)
    L8_2 = L7_2.Functions
    L8_2 = L8_2.GetPlayer
    L9_2 = A0_2
    L8_2 = L8_2(L9_2)
    if L8_2 then
      L9_2 = L8_2.PlayerData
      L9_2 = L9_2.items
      L5_2 = L9_2 or L5_2
      if not L9_2 then
        L9_2 = {}
        L5_2 = L9_2
      end
      L9_2 = L8_2.PlayerData
      L9_2 = L9_2.metadata
      if L9_2 then
        L9_2 = L8_2.PlayerData
        L9_2 = L9_2.metadata
        L9_2 = L9_2.licences
        if L9_2 then
          L9_2 = pairs
          L10_2 = L8_2.PlayerData
          L10_2 = L10_2.metadata
          L10_2 = L10_2.licences
          L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
          for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
            if L14_2 then
              L15_2 = table
              L15_2 = L15_2.insert
              L16_2 = L6_2
              L17_2 = {}
              L17_2.type = L13_2
              L19_2 = L13_2
              L18_2 = L13_2.gsub
              L20_2 = "_"
              L21_2 = " "
              L18_2 = L18_2(L19_2, L20_2, L21_2)
              L19_2 = L18_2
              L18_2 = L18_2.upper
              L18_2 = L18_2(L19_2)
              L17_2.label = L18_2
              L15_2(L16_2, L17_2)
            end
          end
        end
      end
      L9_2 = {}
      L10_2 = L3_2.name
      L9_2.targetName = L10_2
      L9_2.targetId = A0_2
      L9_2.inventory = L5_2
      L9_2.licenses = L6_2
      L10_2 = #L5_2
      L9_2.itemCount = L10_2
      L10_2 = TriggerClientEvent
      L11_2 = "fs-government:client:showSearchResults"
      L12_2 = L1_2
      L13_2 = L9_2
      L10_2(L11_2, L12_2, L13_2)
      L10_2 = Framework
      L10_2 = L10_2.ShowNotification
      L11_2 = A0_2
      L12_2 = "You are being searched by "
      L13_2 = L2_2.name
      L12_2 = L12_2 .. L13_2
      L13_2 = "primary"
      L10_2(L11_2, L12_2, L13_2)
    end
  end
end
L4_1(L5_1, L6_1)
L4_1 = RegisterNetEvent
L5_1 = "fs-government:server:openPlayerInventory"
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  if not L2_2 or not L3_2 then
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L2_2.job
  L5_2 = L5_2.name
  L6_2 = L2_2.job
  L6_2 = L6_2.grade
  L7_2 = "search_players"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L1_2
    L6_2 = "You do not have permission to access player inventories"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = Framework
  L4_2 = L4_2.GetFramework
  L4_2 = L4_2()
  if "esx" == L4_2 then
    L5_2 = exports
    L5_2 = L5_2.es_extended
    L6_2 = L5_2
    L5_2 = L5_2.getSharedObject
    L5_2 = L5_2(L6_2)
    L6_2 = L5_2.GetPlayerFromId
    L7_2 = A0_2
    L6_2 = L6_2(L7_2)
    if L6_2 then
      L7_2 = exports
      L7_2 = L7_2.ox_inventory
      if L7_2 then
        L7_2 = exports
        L7_2 = L7_2.ox_inventory
        L8_2 = L7_2
        L7_2 = L7_2.forceOpenInventory
        L9_2 = L1_2
        L10_2 = "player"
        L11_2 = A0_2
        L7_2(L8_2, L9_2, L10_2, L11_2)
      else
        L7_2 = Framework
        L7_2 = L7_2.ShowNotification
        L8_2 = L1_2
        L9_2 = "Inventory system not supported"
        L10_2 = "error"
        L7_2(L8_2, L9_2, L10_2)
      end
    end
  elseif "qbcore" == L4_2 or "qbox" == L4_2 then
    L5_2 = exports
    L5_2 = L5_2["qb-core"]
    L6_2 = L5_2
    L5_2 = L5_2.GetCoreObject
    L5_2 = L5_2(L6_2)
    L6_2 = L5_2.Functions
    L6_2 = L6_2.GetPlayer
    L7_2 = A0_2
    L6_2 = L6_2(L7_2)
    if L6_2 then
      L7_2 = exports
      L7_2 = L7_2["qb-inventory"]
      if L7_2 then
        L7_2 = TriggerClientEvent
        L8_2 = "inventory:client:SetCurrentStash"
        L9_2 = L1_2
        L10_2 = L6_2.PlayerData
        L10_2 = L10_2.citizenid
        L7_2(L8_2, L9_2, L10_2)
        L7_2 = TriggerClientEvent
        L8_2 = "inventory:client:OpenInventory"
        L9_2 = L1_2
        L10_2 = "stash"
        L11_2 = L6_2.PlayerData
        L11_2 = L11_2.citizenid
        L7_2(L8_2, L9_2, L10_2, L11_2)
      else
        L7_2 = exports
        L7_2 = L7_2.ox_inventory
        if L7_2 then
          L7_2 = exports
          L7_2 = L7_2.ox_inventory
          L8_2 = L7_2
          L7_2 = L7_2.forceOpenInventory
          L9_2 = L1_2
          L10_2 = "player"
          L11_2 = A0_2
          L7_2(L8_2, L9_2, L10_2, L11_2)
        else
          L7_2 = Framework
          L7_2 = L7_2.ShowNotification
          L8_2 = L1_2
          L9_2 = "Inventory system not supported"
          L10_2 = "error"
          L7_2(L8_2, L9_2, L10_2)
        end
      end
    end
  end
  L5_2 = Framework
  L5_2 = L5_2.ShowNotification
  L6_2 = A0_2
  L7_2 = "Your inventory is being accessed by "
  L8_2 = L2_2.name
  L7_2 = L7_2 .. L8_2
  L8_2 = "primary"
  L5_2(L6_2, L7_2, L8_2)
end
L4_1(L5_1, L6_1)
L4_1 = RegisterNetEvent
L5_1 = "fs-government:server:toggleHandcuffs"
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  if not L2_2 or not L3_2 then
    return
  end
  if L1_2 == A0_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L1_2
    L6_2 = "You cannot handcuff yourself"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L2_2.job
  L5_2 = L5_2.name
  L6_2 = L2_2.job
  L6_2 = L6_2.grade
  L7_2 = "handcuff"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L1_2
    L6_2 = "You do not have permission to handcuff players"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = "handcuff_"
  L5_2 = L1_2
  L6_2 = "_"
  L7_2 = A0_2
  L4_2 = L4_2 .. L5_2 .. L6_2 .. L7_2
  L5_2 = L2_1
  if L5_2 then
    L5_2 = L2_1
    L5_2 = L5_2[L4_2]
    if L5_2 then
      L5_2 = L2_1
      L5_2 = L5_2[L4_2]
      L6_2 = GetGameTimer
      L6_2 = L6_2()
      if L5_2 > L6_2 then
        return
      end
    end
  end
  L5_2 = L2_1
  if not L5_2 then
    L5_2 = {}
    L2_1 = L5_2
  end
  L5_2 = L2_1
  L6_2 = GetGameTimer
  L6_2 = L6_2()
  L6_2 = L6_2 + 1000
  L5_2[L4_2] = L6_2
  L5_2 = L1_1
  L5_2 = L5_2[A0_2]
  if L5_2 then
    L5_2 = L1_1
    L5_2[A0_2] = nil
    L5_2 = TriggerClientEvent
    L6_2 = "fs-government:client:setHandcuffState"
    L7_2 = A0_2
    L8_2 = false
    L5_2(L6_2, L7_2, L8_2)
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L1_2
    L7_2 = "Player uncuffed successfully"
    L8_2 = "success"
    L5_2(L6_2, L7_2, L8_2)
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = A0_2
    L7_2 = "You have been uncuffed by "
    L8_2 = L2_2.name
    L7_2 = L7_2 .. L8_2
    L8_2 = "success"
    L5_2(L6_2, L7_2, L8_2)
  else
    L5_2 = L1_1
    L5_2[A0_2] = true
    L5_2 = TriggerClientEvent
    L6_2 = "fs-government:client:setHandcuffState"
    L7_2 = A0_2
    L8_2 = true
    L5_2(L6_2, L7_2, L8_2)
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = L1_2
    L7_2 = "Player handcuffed successfully"
    L8_2 = "primary"
    L5_2(L6_2, L7_2, L8_2)
    L5_2 = Framework
    L5_2 = L5_2.ShowNotification
    L6_2 = A0_2
    L7_2 = "You have been handcuffed by "
    L8_2 = L2_2.name
    L7_2 = L7_2 .. L8_2
    L8_2 = "error"
    L5_2(L6_2, L7_2, L8_2)
  end
end
L4_1(L5_1, L6_1)
L4_1 = RegisterNetEvent
L5_1 = "fs-government:server:checkIdentity"
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  if not L2_2 or not L3_2 then
    return
  end
  L4_2 = Framework
  L4_2 = L4_2.GetFramework
  L4_2 = L4_2()
  L5_2 = {}
  if "esx" == L4_2 then
    L6_2 = MySQL
    L6_2 = L6_2.query
    L7_2 = "SELECT * FROM users WHERE identifier = ?"
    L8_2 = {}
    L9_2 = L3_2.identifier
    L8_2[1] = L9_2
    function L9_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
      L1_3 = A0_3[1]
      if L1_3 then
        L1_3 = "Unknown"
        L2_3 = 0
        L3_3 = L3_2.job
        if L3_3 then
          L3_3 = type
          L4_3 = L3_2.job
          L3_3 = L3_3(L4_3)
          if "table" == L3_3 then
            L3_3 = L3_2.job
            L3_3 = L3_3.name
            L1_3 = L3_3 or L1_3
            if not L3_3 then
              L3_3 = L3_2.job
              L3_3 = L3_3.label
              L1_3 = L3_3 or L1_3
              if not L3_3 then
                L1_3 = "Unknown"
              end
            end
            L3_3 = L3_2.job
            L3_3 = L3_3.grade
            if L3_3 then
              L3_3 = type
              L4_3 = L3_2.job
              L4_3 = L4_3.grade
              L3_3 = L3_3(L4_3)
              if "table" == L3_3 then
                L3_3 = L3_2.job
                L3_3 = L3_3.grade
                L3_3 = L3_3.level
                L2_3 = L3_3 or L2_3
                if not L3_3 then
                  L2_3 = 0
                end
              else
                L3_3 = L3_2.job
                L3_3 = L3_3.grade
                L2_3 = L3_3 or L2_3
                if not L3_3 then
                  L2_3 = 0
                end
              end
            end
          else
            L1_3 = L3_2.job
          end
        end
        L3_3 = L3_2.grade
        if L3_3 and not L2_3 then
          L2_3 = L3_2.grade
        end
        L3_3 = "Grade "
        L4_3 = L2_3
        L3_3 = L3_3 .. L4_3
        L4_3 = Config
        L4_3 = L4_3.Government
        L4_3 = L4_3.ranks
        if L4_3 then
          L4_3 = Config
          L4_3 = L4_3.Government
          L4_3 = L4_3.ranks
          L4_3 = L4_3[L1_3]
          if L4_3 then
            L4_3 = Config
            L4_3 = L4_3.Government
            L4_3 = L4_3.ranks
            L4_3 = L4_3[L1_3]
            L4_3 = L4_3[L2_3]
            L3_3 = L4_3 or L3_3
            if not L4_3 then
            end
          end
        end
        L5_3 = L1_3
        L4_3 = L1_3.sub
        L6_3 = 1
        L7_3 = 1
        L4_3 = L4_3(L5_3, L6_3, L7_3)
        L5_3 = L4_3
        L4_3 = L4_3.upper
        L4_3 = L4_3(L5_3)
        L6_3 = L1_3
        L5_3 = L1_3.sub
        L7_3 = 2
        L5_3 = L5_3(L6_3, L7_3)
        L4_3 = L4_3 .. L5_3
        L5_3 = {}
        L6_3 = A0_3[1]
        L6_3 = L6_3.firstname
        L7_3 = " "
        L8_3 = A0_3[1]
        L8_3 = L8_3.lastname
        L6_3 = L6_3 .. L7_3 .. L8_3
        L5_3.name = L6_3
        L6_3 = A0_3[1]
        L6_3 = L6_3.dateofbirth
        L5_3.dateofbirth = L6_3
        L6_3 = A0_3[1]
        L6_3 = L6_3.sex
        L5_3.sex = L6_3
        L6_3 = A0_3[1]
        L6_3 = L6_3.nationality
        if not L6_3 then
          L6_3 = "Unknown"
        end
        L5_3.nationality = L6_3
        L5_3.job = L4_3
        L5_3.rank = L3_3
        L5_2 = L5_3
        L5_3 = TriggerClientEvent
        L6_3 = "fs-government:client:showIdentity"
        L7_3 = L1_2
        L8_3 = L5_2
        L5_3(L6_3, L7_3, L8_3)
      end
    end
    L6_2(L7_2, L8_2, L9_2)
  elseif "qbcore" == L4_2 or "qbox" == L4_2 then
    L6_2 = exports
    L6_2 = L6_2["qb-core"]
    L7_2 = L6_2
    L6_2 = L6_2.GetCoreObject
    L6_2 = L6_2(L7_2)
    L7_2 = L6_2.Functions
    L7_2 = L7_2.GetPlayer
    L8_2 = A0_2
    L7_2 = L7_2(L8_2)
    if L7_2 then
      L8_2 = "Unknown"
      L9_2 = 0
      L10_2 = L3_2.job
      if L10_2 then
        L10_2 = type
        L11_2 = L3_2.job
        L10_2 = L10_2(L11_2)
        if "table" == L10_2 then
          L10_2 = L3_2.job
          L10_2 = L10_2.name
          L8_2 = L10_2 or L8_2
          if not L10_2 then
            L10_2 = L3_2.job
            L10_2 = L10_2.label
            L8_2 = L10_2 or L8_2
            if not L10_2 then
              L8_2 = "Unknown"
            end
          end
          L10_2 = L3_2.job
          L10_2 = L10_2.grade
          if L10_2 then
            L10_2 = type
            L11_2 = L3_2.job
            L11_2 = L11_2.grade
            L10_2 = L10_2(L11_2)
            if "table" == L10_2 then
              L10_2 = L3_2.job
              L10_2 = L10_2.grade
              L10_2 = L10_2.level
              L9_2 = L10_2 or L9_2
              if not L10_2 then
                L9_2 = 0
              end
            else
              L10_2 = L3_2.job
              L10_2 = L10_2.grade
              L9_2 = L10_2 or L9_2
              if not L10_2 then
                L9_2 = 0
              end
            end
          end
        else
          L8_2 = L3_2.job
        end
      end
      L10_2 = L3_2.grade
      if L10_2 and 0 == L9_2 then
        L9_2 = L3_2.grade
      end
      L10_2 = "Grade "
      L11_2 = L9_2
      L10_2 = L10_2 .. L11_2
      L11_2 = Config
      L11_2 = L11_2.Government
      L11_2 = L11_2.ranks
      if L11_2 then
        L11_2 = Config
        L11_2 = L11_2.Government
        L11_2 = L11_2.ranks
        L11_2 = L11_2[L8_2]
        if L11_2 then
          L11_2 = Config
          L11_2 = L11_2.Government
          L11_2 = L11_2.ranks
          L11_2 = L11_2[L8_2]
          L11_2 = L11_2[L9_2]
          L10_2 = L11_2 or L10_2
          if not L11_2 then
          end
        end
      end
      L12_2 = L8_2
      L11_2 = L8_2.sub
      L13_2 = 1
      L14_2 = 1
      L11_2 = L11_2(L12_2, L13_2, L14_2)
      L12_2 = L11_2
      L11_2 = L11_2.upper
      L11_2 = L11_2(L12_2)
      L13_2 = L8_2
      L12_2 = L8_2.sub
      L14_2 = 2
      L12_2 = L12_2(L13_2, L14_2)
      L11_2 = L11_2 .. L12_2
      L12_2 = {}
      L13_2 = L7_2.PlayerData
      L13_2 = L13_2.charinfo
      L13_2 = L13_2.firstname
      L14_2 = " "
      L15_2 = L7_2.PlayerData
      L15_2 = L15_2.charinfo
      L15_2 = L15_2.lastname
      L13_2 = L13_2 .. L14_2 .. L15_2
      L12_2.name = L13_2
      L13_2 = L7_2.PlayerData
      L13_2 = L13_2.charinfo
      L13_2 = L13_2.birthdate
      L12_2.dateofbirth = L13_2
      L13_2 = L7_2.PlayerData
      L13_2 = L13_2.charinfo
      L13_2 = L13_2.gender
      if 0 == L13_2 then
        L13_2 = "Male"
        if L13_2 then
          goto lbl_150
        end
      end
      L13_2 = "Female"
      ::lbl_150::
      L12_2.sex = L13_2
      L13_2 = L7_2.PlayerData
      L13_2 = L13_2.charinfo
      L13_2 = L13_2.nationality
      if not L13_2 then
        L13_2 = "Unknown"
      end
      L12_2.nationality = L13_2
      L12_2.job = L11_2
      L12_2.rank = L10_2
      L5_2 = L12_2
      L12_2 = TriggerClientEvent
      L13_2 = "fs-government:client:showIdentity"
      L14_2 = L1_2
      L15_2 = L5_2
      L12_2(L13_2, L14_2, L15_2)
    end
  end
end
L4_1(L5_1, L6_1)
L4_1 = RegisterNetEvent
L5_1 = "fs-government:server:billNearestPlayer"
function L6_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L3_2 = source
  L4_2 = Framework
  L4_2 = L4_2.GetPlayerData
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  L5_2 = Framework
  L5_2 = L5_2.GetPlayerData
  L6_2 = A0_2
  L5_2 = L5_2(L6_2)
  if not L4_2 or not L5_2 then
    return
  end
  L6_2 = Utils
  L6_2 = L6_2.HasPermission
  L7_2 = L4_2.job
  L7_2 = L7_2.name
  L8_2 = L4_2.job
  L8_2 = L8_2.grade
  L9_2 = "billing"
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  if not L6_2 then
    L6_2 = Framework
    L6_2 = L6_2.ShowNotification
    L7_2 = L3_2
    L8_2 = "You do not have permission to send bills"
    L9_2 = "error"
    L6_2(L7_2, L8_2, L9_2)
    return
  end
  if A1_2 <= 0 then
    L6_2 = Framework
    L6_2 = L6_2.ShowNotification
    L7_2 = L3_2
    L8_2 = "Invalid fine amount"
    L9_2 = "error"
    L6_2(L7_2, L8_2, L9_2)
    return
  end
  L6_2 = MySQL
  L6_2 = L6_2.insert
  L7_2 = "INSERT INTO government_fines (identifier, name, amount, reason, issued_by, issued_by_name) VALUES (?, ?, ?, ?, ?, ?)"
  L8_2 = {}
  L9_2 = L5_2.identifier
  L10_2 = L5_2.name
  L11_2 = A1_2
  L12_2 = A2_2
  L13_2 = L4_2.identifier
  L14_2 = L4_2.name
  L8_2[1] = L9_2
  L8_2[2] = L10_2
  L8_2[3] = L11_2
  L8_2[4] = L12_2
  L8_2[5] = L13_2
  L8_2[6] = L14_2
  function L9_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    if A0_3 then
      L1_3 = Framework
      L1_3 = L1_3.GetFramework
      L1_3 = L1_3()
      if "esx" == L1_3 then
        L2_3 = GetResourceState
        L3_3 = "esx_billing"
        L2_3 = L2_3(L3_3)
        if "started" == L2_3 then
          L2_3 = TriggerEvent
          L3_3 = "esx_billing:sendBill"
          L4_3 = A0_2
          L5_3 = "government"
          L6_3 = L4_2.name
          L7_3 = A1_2
          L8_3 = A2_2
          L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
        end
      elseif "qbcore" == L1_3 or "qbox" == L1_3 then
        L2_3 = GetResourceState
        L3_3 = "qb-billing"
        L2_3 = L2_3(L3_3)
        if "started" == L2_3 then
          L2_3 = exports
          L2_3 = L2_3["qb-billing"]
          L3_3 = L2_3
          L2_3 = L2_3.CreateBill
          L4_3 = A0_2
          L5_3 = A1_2
          L6_3 = "government"
          L7_3 = A2_2
          L2_3(L3_3, L4_3, L5_3, L6_3, L7_3)
        end
      end
      L2_3 = Framework
      L2_3 = L2_3.ShowNotification
      L3_3 = L3_2
      L4_3 = "Fine issued successfully: $"
      L5_3 = A1_2
      L6_3 = " to "
      L7_3 = L5_2.name
      L4_3 = L4_3 .. L5_3 .. L6_3 .. L7_3
      L5_3 = "success"
      L2_3(L3_3, L4_3, L5_3)
      L2_3 = Framework
      L2_3 = L2_3.ShowNotification
      L3_3 = A0_2
      L4_3 = "You have been issued a fine of $"
      L5_3 = A1_2
      L6_3 = " for: "
      L7_3 = A2_2
      L4_3 = L4_3 .. L5_3 .. L6_3 .. L7_3
      L5_3 = "error"
      L2_3(L3_3, L4_3, L5_3)
    else
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L3_2
      L3_3 = "Failed to issue fine"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L6_2(L7_2, L8_2, L9_2)
end
L4_1(L5_1, L6_1)
L4_1 = RegisterNetEvent
L5_1 = "fs-government:server:getVehicles"
function L6_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = 0
  L3_2 = L1_2.job
  L3_2 = L3_2.grade
  if L3_2 then
    L3_2 = type
    L4_2 = L1_2.job
    L4_2 = L4_2.grade
    L3_2 = L3_2(L4_2)
    if "table" == L3_2 then
      L3_2 = L1_2.job
      L3_2 = L3_2.grade
      L3_2 = L3_2.level
      L2_2 = L3_2 or L2_2
      if not L3_2 then
        L2_2 = 0
      end
    else
      L3_2 = L1_2.job
      L2_2 = L3_2.grade
    end
  end
  L3_2 = Utils
  L3_2 = L3_2.HasPermission
  L4_2 = L1_2.job
  L4_2 = L4_2.name
  L5_2 = L2_2
  L6_2 = "garage_access"
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if not L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.ShowNotification
    L4_2 = L0_2
    L5_2 = "Access denied - insufficient permissions"
    L6_2 = "error"
    L3_2(L4_2, L5_2, L6_2)
    return
  end
  L3_2 = {}
  L4_2 = pairs
  L5_2 = L3_1
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
  for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
    L10_2 = L9_2.owner
    if L10_2 == L0_2 then
      L10_2 = DoesEntityExist
      L11_2 = L9_2.entity
      L10_2 = L10_2(L11_2)
      if L10_2 then
        L10_2 = table
        L10_2 = L10_2.insert
        L11_2 = L3_2
        L12_2 = {}
        L12_2.plate = L8_2
        L13_2 = L9_2.model
        L12_2.model = L13_2
        L13_2 = L9_2.entity
        L12_2.entity = L13_2
        L10_2(L11_2, L12_2)
      end
    end
  end
  L4_2 = TriggerClientEvent
  L5_2 = "fs-government:client:showVehicleMenu"
  L6_2 = L0_2
  L7_2 = L3_2
  L4_2(L5_2, L6_2, L7_2)
end
L4_1(L5_1, L6_1)
L4_1 = RegisterNetEvent
L5_1 = "fs-government:server:spawnVehicle"
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = 0
  L4_2 = L2_2.job
  L4_2 = L4_2.grade
  if L4_2 then
    L4_2 = type
    L5_2 = L2_2.job
    L5_2 = L5_2.grade
    L4_2 = L4_2(L5_2)
    if "table" == L4_2 then
      L4_2 = L2_2.job
      L4_2 = L4_2.grade
      L4_2 = L4_2.level
      L3_2 = L4_2 or L3_2
      if not L4_2 then
        L3_2 = 0
      end
    else
      L4_2 = L2_2.job
      L3_2 = L4_2.grade
    end
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L2_2.job
  L5_2 = L5_2.name
  L6_2 = L3_2
  L7_2 = "garage_access"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    return
  end
  L4_2 = GetPlayerPed
  L5_2 = L1_2
  L4_2 = L4_2(L5_2)
  L5_2 = GetEntityCoords
  L6_2 = L4_2
  L5_2 = L5_2(L6_2)
  L6_2 = GetEntityHeading
  L7_2 = L4_2
  L6_2 = L6_2(L7_2)
  L7_2 = CreateVehicle
  L8_2 = GetHashKey
  L9_2 = A0_2
  L8_2 = L8_2(L9_2)
  L9_2 = L5_2.x
  L9_2 = L9_2 + 2
  L10_2 = L5_2.y
  L11_2 = L5_2.z
  L12_2 = L6_2
  L13_2 = true
  L14_2 = true
  L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
  L8_2 = "GOV"
  L9_2 = math
  L9_2 = L9_2.random
  L10_2 = 1000
  L11_2 = 9999
  L9_2 = L9_2(L10_2, L11_2)
  L8_2 = L8_2 .. L9_2
  L9_2 = SetVehicleNumberPlateText
  L10_2 = L7_2
  L11_2 = L8_2
  L9_2(L10_2, L11_2)
  L9_2 = L3_1
  L10_2 = {}
  L10_2.entity = L7_2
  L10_2.model = A0_2
  L10_2.owner = L1_2
  L10_2.plate = L8_2
  L11_2 = os
  L11_2 = L11_2.time
  L11_2 = L11_2()
  L10_2.spawnTime = L11_2
  L9_2[L8_2] = L10_2
  L9_2 = Framework
  L9_2 = L9_2.GetFramework
  L9_2 = L9_2()
  if "esx" == L9_2 then
    L10_2 = exports
    L10_2 = L10_2.es_extended
    L11_2 = L10_2
    L10_2 = L10_2.getSharedObject
    L10_2 = L10_2(L11_2)
    L11_2 = L10_2.GetPlayerFromId
    L12_2 = L1_2
    L11_2 = L11_2(L12_2)
    if L11_2 then
      L12_2 = TriggerEvent
      L13_2 = "esx_vehiclelock:givekey"
      L14_2 = L11_2.source
      L15_2 = L8_2
      L12_2(L13_2, L14_2, L15_2)
    end
  elseif "qbcore" == L9_2 or "qbox" == L9_2 then
    L10_2 = exports
    L10_2 = L10_2["qb-core"]
    L11_2 = L10_2
    L10_2 = L10_2.GetCoreObject
    L10_2 = L10_2(L11_2)
    L11_2 = TriggerEvent
    L12_2 = "qb-vehiclekeys:server:GiveKeys"
    L13_2 = L1_2
    L14_2 = L8_2
    L11_2(L12_2, L13_2, L14_2)
  end
  L10_2 = Framework
  L10_2 = L10_2.ShowNotification
  L11_2 = L1_2
  L12_2 = "Vehicle spawned with plate: "
  L13_2 = L8_2
  L12_2 = L12_2 .. L13_2
  L13_2 = "success"
  L10_2(L11_2, L12_2, L13_2)
end
L4_1(L5_1, L6_1)
L4_1 = RegisterNetEvent
L5_1 = "fs-government:server:storeVehicle"
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = 0
  L4_2 = L2_2.job
  L4_2 = L4_2.grade
  if L4_2 then
    L4_2 = type
    L5_2 = L2_2.job
    L5_2 = L5_2.grade
    L4_2 = L4_2(L5_2)
    if "table" == L4_2 then
      L4_2 = L2_2.job
      L4_2 = L4_2.grade
      L4_2 = L4_2.level
      L3_2 = L4_2 or L3_2
      if not L4_2 then
        L3_2 = 0
      end
    else
      L4_2 = L2_2.job
      L3_2 = L4_2.grade
    end
  end
  L4_2 = Utils
  L4_2 = L4_2.HasPermission
  L5_2 = L2_2.job
  L5_2 = L5_2.name
  L6_2 = L3_2
  L7_2 = "garage_access"
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  if not L4_2 then
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L1_2
    L6_2 = "Access denied - insufficient permissions"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
    return
  end
  L4_2 = L3_1
  L4_2 = L4_2[A0_2]
  if L4_2 then
    L4_2 = L3_1
    L4_2 = L4_2[A0_2]
    L5_2 = L4_2.owner
    if L5_2 ~= L1_2 then
      L5_2 = Framework
      L5_2 = L5_2.ShowNotification
      L6_2 = L1_2
      L7_2 = "You can only store vehicles you spawned"
      L8_2 = "error"
      L5_2(L6_2, L7_2, L8_2)
      return
    end
    L5_2 = DoesEntityExist
    L6_2 = L4_2.entity
    L5_2 = L5_2(L6_2)
    if L5_2 then
      L5_2 = DeleteEntity
      L6_2 = L4_2.entity
      L5_2(L6_2)
      L5_2 = L3_1
      L5_2[A0_2] = nil
      L5_2 = Framework
      L5_2 = L5_2.ShowNotification
      L6_2 = L1_2
      L7_2 = "Vehicle stored successfully"
      L8_2 = "success"
      L5_2(L6_2, L7_2, L8_2)
    else
      L5_2 = L3_1
      L5_2[A0_2] = nil
      L5_2 = Framework
      L5_2 = L5_2.ShowNotification
      L6_2 = L1_2
      L7_2 = "Vehicle was already destroyed - removed from tracking"
      L8_2 = "primary"
      L5_2(L6_2, L7_2, L8_2)
    end
  else
    L4_2 = Framework
    L4_2 = L4_2.ShowNotification
    L5_2 = L1_2
    L6_2 = "Vehicle not found in government fleet"
    L7_2 = "error"
    L4_2(L5_2, L6_2, L7_2)
  end
end
L4_1(L5_1, L6_1)
L4_1 = AddEventHandler
L5_1 = "playerDropped"
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = source
  L2_2 = pairs
  L3_2 = L3_1
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L7_2.owner
    if L8_2 == L1_2 then
      L8_2 = DoesEntityExist
      L9_2 = L7_2.entity
      L8_2 = L8_2(L9_2)
      if L8_2 then
        L8_2 = DeleteEntity
        L9_2 = L7_2.entity
        L8_2(L9_2)
      end
      L8_2 = L3_1
      L8_2[L6_2] = nil
    end
  end
end
L4_1(L5_1, L6_1)
L4_1 = exports
L5_1 = "useGovernmentTablet"
function L6_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  if "usingItem" == A0_2 then
    L5_2 = A2_2.id
    L6_2 = Framework
    L6_2 = L6_2.GetPlayerData
    L7_2 = L5_2
    L6_2 = L6_2(L7_2)
    if L6_2 then
      L7_2 = L6_2.job
      if L7_2 then
        goto lbl_21
      end
    end
    L7_2 = Framework
    L7_2 = L7_2.ShowNotification
    L8_2 = L5_2
    L9_2 = "Unable to access player data"
    L10_2 = "error"
    L7_2(L8_2, L9_2, L10_2)
    L7_2 = false
    do return L7_2 end
    ::lbl_21::
    L7_2 = Utils
    L7_2 = L7_2.TableContains
    L8_2 = Config
    L8_2 = L8_2.Government
    L8_2 = L8_2.jobs
    L9_2 = L6_2.job
    L9_2 = L9_2.name
    L7_2 = L7_2(L8_2, L9_2)
    if not L7_2 then
      L7_2 = Framework
      L7_2 = L7_2.ShowNotification
      L8_2 = L5_2
      L9_2 = "Access denied - Not a government employee"
      L10_2 = "error"
      L7_2(L8_2, L9_2, L10_2)
      L7_2 = false
      return L7_2
    end
    L7_2 = TriggerClientEvent
    L8_2 = "fs-government:client:useTablet"
    L9_2 = L5_2
    L7_2(L8_2, L9_2)
    L7_2 = false
    return L7_2
  end
end
L4_1(L5_1, L6_1)
L4_1 = RegisterNetEvent
L5_1 = "fs-government:server:useTablet"
function L6_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if L1_2 then
    L2_2 = L1_2.job
    if L2_2 then
      goto lbl_18
    end
  end
  L2_2 = Framework
  L2_2 = L2_2.ShowNotification
  L3_2 = L0_2
  L4_2 = "Unable to access player data"
  L5_2 = "error"
  L2_2(L3_2, L4_2, L5_2)
  do return end
  ::lbl_18::
  L2_2 = Utils
  L2_2 = L2_2.TableContains
  L3_2 = Config
  L3_2 = L3_2.Government
  L3_2 = L3_2.jobs
  L4_2 = L1_2.job
  L4_2 = L4_2.name
  L2_2 = L2_2(L3_2, L4_2)
  if not L2_2 then
    L2_2 = Framework
    L2_2 = L2_2.ShowNotification
    L3_2 = L0_2
    L4_2 = "Access denied - Not a government employee"
    L5_2 = "error"
    L2_2(L3_2, L4_2, L5_2)
    return
  end
  L2_2 = TriggerClientEvent
  L3_2 = "fs-government:client:useTablet"
  L4_2 = L0_2
  L2_2(L3_2, L4_2)
end
L4_1(L5_1, L6_1)
L4_1 = CreateThread
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = Wait
  L1_2 = 2000
  L0_2(L1_2)
  L0_2 = Framework
  L0_2 = L0_2.GetFramework
  L0_2 = L0_2()
  if "esx" == L0_2 then
    L1_2 = RegisterNetEvent
    L2_2 = "esx:onPlayerLoaded"
    function L3_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3
      L1_3 = Wait
      L2_3 = 1000
      L1_3(L2_3)
      L1_3 = exports
      L1_3 = L1_3.es_extended
      L2_3 = L1_3
      L1_3 = L1_3.getSharedObject
      L1_3 = L1_3(L2_3)
      L2_3 = L1_3.RegisterUsableItem
      L3_3 = "gov_tablet"
      function L4_3(A0_4)
        local L1_4, L2_4, L3_4
        L1_4 = TriggerEvent
        L2_4 = "fs-government:server:useTablet"
        L3_4 = A0_4
        L1_4(L2_4, L3_4)
      end
      L2_3(L3_3, L4_3)
    end
    L1_2(L2_2, L3_2)
    L1_2 = pcall
    function L2_2()
      local L0_3, L1_3, L2_3, L3_3
      L0_3 = exports
      L0_3 = L0_3.es_extended
      L1_3 = L0_3
      L0_3 = L0_3.getSharedObject
      L0_3 = L0_3(L1_3)
      L1_3 = L0_3.RegisterUsableItem
      L2_3 = "gov_tablet"
      function L3_3(A0_4, A1_4)
        local L2_4, L3_4, L4_4
        L2_4 = TriggerEvent
        L3_4 = "fs-government:server:useTablet"
        L4_4 = A0_4
        L2_4(L3_4, L4_4)
      end
      L1_3(L2_3, L3_3)
    end
    L1_2, L2_2 = L1_2(L2_2)
    if L1_2 then
      L3_2 = Utils
      L3_2 = L3_2.DebugSuccess
      L4_2 = "ESX: Registered gov_tablet usable item"
      L3_2(L4_2)
    else
      L3_2 = Utils
      L3_2 = L3_2.DebugError
      L4_2 = "ESX: Failed to register gov_tablet: "
      L5_2 = tostring
      L6_2 = L2_2
      L5_2 = L5_2(L6_2)
      L4_2 = L4_2 .. L5_2
      L3_2(L4_2)
    end
  elseif "qbcore" == L0_2 or "qbox" == L0_2 then
    L1_2 = pcall
    function L2_2()
      local L0_3, L1_3, L2_3, L3_3
      L0_3 = exports
      L0_3 = L0_3["qb-core"]
      L1_3 = L0_3
      L0_3 = L0_3.GetCoreObject
      L0_3 = L0_3(L1_3)
      L1_3 = L0_3.Functions
      L1_3 = L1_3.CreateUseableItem
      L2_3 = "gov_tablet"
      function L3_3(A0_4, A1_4)
        local L2_4, L3_4, L4_4
        L2_4 = TriggerEvent
        L3_4 = "fs-government:server:useTablet"
        L4_4 = A0_4
        L2_4(L3_4, L4_4)
      end
      L1_3(L2_3, L3_3)
    end
    L1_2, L2_2 = L1_2(L2_2)
    if L1_2 then
      L3_2 = Utils
      L3_2 = L3_2.DebugSuccess
      L4_2 = "QBCore: Registered gov_tablet usable item"
      L3_2(L4_2)
    else
      L3_2 = Utils
      L3_2 = L3_2.DebugError
      L4_2 = "QBCore: Failed to register gov_tablet: "
      L5_2 = tostring
      L6_2 = L2_2
      L5_2 = L5_2(L6_2)
      L4_2 = L4_2 .. L5_2
      L3_2(L4_2)
    end
  end
end
L4_1(L5_1)
L4_1 = CreateThread
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  while true do
    L0_2 = Wait
    L1_2 = 60000
    L0_2(L1_2)
    L0_2 = pairs
    L1_2 = L3_1
    L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
    for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
      L6_2 = DoesEntityExist
      L7_2 = L5_2.entity
      L6_2 = L6_2(L7_2)
      if not L6_2 then
        L6_2 = L3_1
        L6_2[L4_2] = nil
        L6_2 = Utils
        L6_2 = L6_2.DebugPrint
        L7_2 = "Cleaned up destroyed vehicle with plate: "
        L8_2 = L4_2
        L7_2 = L7_2 .. L8_2
        L6_2(L7_2)
      end
    end
  end
end
L4_1(L5_1)
L4_1 = RegisterNetEvent
L5_1 = "fs-government:server:getPlayerFines"
function L6_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = Framework
  L1_2 = L1_2.GetPlayerData
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L2_2 = MySQL
  L2_2 = L2_2.query
  L3_2 = "SELECT * FROM government_fines WHERE identifier = ? ORDER BY created_at DESC"
  L4_2 = {}
  L5_2 = L1_2.identifier
  L4_2[1] = L5_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    if A0_3 then
      L1_3 = TriggerClientEvent
      L2_3 = "fs-government:client:showPlayerFines"
      L3_3 = L0_2
      L4_3 = A0_3
      L1_3(L2_3, L3_3, L4_3)
    else
      L1_3 = TriggerClientEvent
      L2_3 = "fs-government:client:showPlayerFines"
      L3_3 = L0_2
      L4_3 = {}
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L2_2(L3_2, L4_2, L5_2)
end
L4_1(L5_1, L6_1)
L4_1 = RegisterNetEvent
L5_1 = "fs-government:server:payFine"
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.GetPlayerData
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT * FROM government_fines WHERE id = ? AND identifier = ? AND status = ?"
  L5_2 = {}
  L6_2 = A0_2
  L7_2 = L2_2.identifier
  L8_2 = "unpaid"
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  L5_2[3] = L8_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    if A0_3 then
      L1_3 = #A0_3
      if L1_3 > 0 then
        L1_3 = A0_3[1]
        L2_3 = Framework
        L2_3 = L2_3.RemoveMoney
        L3_3 = L1_2
        L4_3 = tonumber
        L5_3 = L1_3.amount
        L4_3 = L4_3(L5_3)
        if not L4_3 then
          L4_3 = 0
        end
        L5_3 = "bank"
        L2_3 = L2_3(L3_3, L4_3, L5_3)
        if L2_3 then
          L2_3 = MySQL
          L2_3 = L2_3.execute
          L3_3 = "UPDATE government_fines SET status = ?, paid_at = ? WHERE id = ?"
          L4_3 = {}
          L5_3 = "paid"
          L6_3 = os
          L6_3 = L6_3.date
          L7_3 = "%Y-%m-%d %H:%M:%S"
          L6_3 = L6_3(L7_3)
          L7_3 = A0_2
          L4_3[1] = L5_3
          L4_3[2] = L6_3
          L4_3[3] = L7_3
          function L5_3()
            local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4
            L0_4 = Framework
            L0_4 = L0_4.ShowNotification
            L1_4 = L1_2
            L2_4 = "Fine paid successfully: $"
            L3_4 = L1_3.amount
            L2_4 = L2_4 .. L3_4
            L3_4 = "success"
            L0_4(L1_4, L2_4, L3_4)
            L0_4 = MySQL
            L0_4 = L0_4.insert
            L1_4 = "INSERT INTO government_transactions (transaction_type, amount, description, source_identifier, processed_by) VALUES (?, ?, ?, ?, ?)"
            L2_4 = {}
            L3_4 = "fine"
            L4_4 = L1_3.amount
            L5_4 = "Fine payment: "
            L6_4 = L1_3.reason
            L5_4 = L5_4 .. L6_4
            L6_4 = L2_2.identifier
            L7_4 = L2_2.name
            L2_4[1] = L3_4
            L2_4[2] = L4_4
            L2_4[3] = L5_4
            L2_4[4] = L6_4
            L2_4[5] = L7_4
            L0_4(L1_4, L2_4)
          end
          L2_3(L3_3, L4_3, L5_3)
        else
          L2_3 = Framework
          L2_3 = L2_3.ShowNotification
          L3_3 = L1_2
          L4_3 = "Insufficient funds"
          L5_3 = "error"
          L2_3(L3_3, L4_3, L5_3)
        end
    end
    else
      L1_3 = Framework
      L1_3 = L1_3.ShowNotification
      L2_3 = L1_2
      L3_3 = "Fine not found or already paid"
      L4_3 = "error"
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L3_2(L4_2, L5_2, L6_2)
end
L4_1(L5_1, L6_1)
L4_1 = RegisterCommand
L5_1 = "myfines"
function L6_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = Framework
  L3_2 = L3_2.GetPlayerData
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    return
  end
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT * FROM government_fines WHERE identifier = ? ORDER BY created_at DESC"
  L6_2 = {}
  L7_2 = L3_2.identifier
  L6_2[1] = L7_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    if A0_3 then
      L1_3 = TriggerClientEvent
      L2_3 = "fs-government:client:showPlayerFines"
      L3_3 = A0_2
      L4_3 = A0_3
      L1_3(L2_3, L3_3, L4_3)
    else
      L1_3 = TriggerClientEvent
      L2_3 = "fs-government:client:showPlayerFines"
      L3_3 = A0_2
      L4_3 = {}
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L4_2(L5_2, L6_2, L7_2)
end
L7_1 = false
L4_1(L5_1, L6_1, L7_1)
L4_1 = AddEventHandler
L5_1 = "playerDropped"
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = source
  L2_2 = L0_1
  L2_2 = L2_2[L1_2]
  if L2_2 then
    L2_2 = L0_1
    L2_2[L1_2] = nil
  end
  L2_2 = L1_1
  L2_2 = L2_2[L1_2]
  if L2_2 then
    L2_2 = L1_1
    L2_2[L1_2] = nil
  end
  L2_2 = pairs
  L3_2 = L2_1
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = string
    L8_2 = L8_2.find
    L9_2 = L6_2
    L10_2 = "_"
    L11_2 = L1_2
    L12_2 = "_"
    L10_2 = L10_2 .. L11_2 .. L12_2
    L8_2 = L8_2(L9_2, L10_2)
    if not L8_2 then
      L8_2 = string
      L8_2 = L8_2.find
      L9_2 = L6_2
      L10_2 = "_"
      L11_2 = "_"
      L12_2 = L1_2
      L10_2 = L10_2 .. L11_2 .. L12_2
      L8_2 = L8_2(L9_2, L10_2)
      if not L8_2 then
        goto lbl_40
      end
    end
    L8_2 = L2_1
    L8_2[L6_2] = nil
    ::lbl_40::
  end
end
L4_1(L5_1, L6_1)
