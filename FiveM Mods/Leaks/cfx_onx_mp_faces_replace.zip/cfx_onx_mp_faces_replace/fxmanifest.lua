-- Using game build 2802

fx_version 'cerulean'
game 'gta5'
author 'ONX/Ceptar'
contributors 'Ceptar, GTAWiseguy, JunkyWRX, YoinksOG, Manic'
description 'New Multiplayer Ped Model Faces'
version '1.0.0'
lua54 'yes'

files {
}

dependency '/assetpacks'