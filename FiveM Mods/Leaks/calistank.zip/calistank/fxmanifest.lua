author 'Skylar & SoCal Thero'
description 'I fucked with you'
version '1.0.2'


game 'gta5'
fx_version 'cerulean'

files {
    'stream/**/*.meta'
}
data_file 'VEHICLE_LAYOUTS_FILE' 'stream/**/vehiclelayouts.meta'
data_file 'EXPLOSION_INFO_FILE' 'stream/**/explosion.meta'
data_file 'HANDLING_FILE' 'stream/**/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'stream/**/vehicles.meta'
data_file 'CARCOLS_FILE' 'stream/**/carcols.meta'
data_file 'VEHICLE_VARIATION_FILE' 'stream/**/carvariations.meta'
data_file 'WEAPON_METADATA_FILE' 'stream/**/weaponarchetypes.meta'
data_file 'WEAPONINFO_FILE' 'stream/**/vehicleweapons_*.meta'
data_file 'CONTENT_UNLOCKING_META_FILE' 'stream/**/contentunlocks.meta'