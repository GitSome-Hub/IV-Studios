CreateThread(function()
    AddTextEntry('gamename', 'Display Name') -- Gamename = Vehicle model name // Display Name = Name it shows ingame
end)
