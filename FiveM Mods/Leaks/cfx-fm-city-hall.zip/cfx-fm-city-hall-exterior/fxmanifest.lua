fx_version 'bodacious'
game 'gta5'

author 'FM'
description 'CITY HALL EXTERIOR'
version '1.0'


data_file "SCENARIO_POINTS_OVERRIDE_PSO_FILE" "pillbox_hill.ymt"


data_file "SCENARIO_POINTS_OVERRIDE_PSO_FILE" "downtown.ymt"

this_is_a_map 'yes'


escrow_ignore {
    'stream/[editable]/fm_ct_exterior_build_lights_01.ydr',

  }
