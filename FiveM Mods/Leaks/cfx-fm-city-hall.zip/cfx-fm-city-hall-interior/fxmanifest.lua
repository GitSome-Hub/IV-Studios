fx_version 'bodacious'
game 'gta5'

author 'FM'
description 'CITY HALL INTERIOR'
version '1.0'

this_is_a_map 'yes'


data_file 'AUDIO_GAMEDATA' 'audio/fm_cityhall_game.dat'
data_file 'TIMECYCLEMOD_FILE' 'fm_timecycle_list_cityhall.xml'

files {
    'fm_timecycle_list_cityhall.xml',
    'audio/fm_cityhall_game.dat151.rel',
}