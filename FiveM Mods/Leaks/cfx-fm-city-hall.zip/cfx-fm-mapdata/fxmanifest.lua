fx_version 'bodacious'
game 'gta5'

author 'FM'
description 'MAP DATA'

this_is_a_map 'yes'

replace_level_meta 'gta5'

data_file 'AUDIO_GAMEDATA' 'audio/[doors]/fm_doors_sounds_game.dat'

files { 
    'gta5.meta',
    'doortuning.ymt',
    'audio/[doors]/fm_doors_sounds_game.dat151.rel',
}