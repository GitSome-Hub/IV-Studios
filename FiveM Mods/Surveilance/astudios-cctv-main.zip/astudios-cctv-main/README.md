### ASTUDIOS | Development - Job Activity: CCTV ###

Introducing our new CCTV script - the perfect addition to any FiveM server with a player-run dispatch. With this simple surveillance camera script, police and other security jobs can access any camera around the city. Features include the ability to add cameras to existing targets or place them wherever you want, add as many cameras as you need in different categories, and choose whether or not they are rotatable. Our script is optimized for performance and easy to use. Don't miss out on this essential tool for keeping your city safe and secure!
Enjoy!

### INFO ###

- qb-target & qb-menu for almost all of the interactions

### INSTALL ###

1) Drag and drop `astudios-cctv` into your server resources ensuring that all dependencies are started prior **IF UNSURE REFER TO LOAD ORDER IN OUR GITBOOK**
2) Customise `config.lua` to your liking 
3) Restart your server

### PREVIEW ###
- Coming soon
### SUPPORT ###
https://discord.gg/BWMwh57sFP
