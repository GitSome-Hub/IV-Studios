config = {}


config.notifyName = "CCTV"
config.notifyDesc = "Security Cameras"
config.notifyIcon = "CHAR_GANGAPP"
config.command = "nv-cams"