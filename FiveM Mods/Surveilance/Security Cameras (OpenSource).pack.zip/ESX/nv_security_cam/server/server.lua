RegisterNetEvent("nv_security_cam:server:checkJob")
AddEventHandler("nv_security_cam:server:checkJob",function()

	local xPlayer = ESX.GetPlayerFromId(source)
	local playerJob = xPlayer.getJob().name

	for _,job in pairs(config.jobsThatCanOpenTablet) do
		if playerJob == job then
			TriggerClientEvent("nv_security_cam:client:setJob",source,true)
			break
		else
			TriggerClientEvent("nv_security_cam:client:setJob",source,false)
		end
	end

end)