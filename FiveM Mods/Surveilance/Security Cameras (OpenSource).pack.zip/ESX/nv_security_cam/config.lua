config = {}

config.notifyName = "CCTV"
config.notifyDesc = "Security Cameras"
config.notifyIcon = "CHAR_GANGAPP"

config.command = "nv-cams"

config.jobsThatCanOpenTablet = {
	"police",
	"swat"
}

config.noJobMsg = "You need to have Police Job to open Security Tablet."