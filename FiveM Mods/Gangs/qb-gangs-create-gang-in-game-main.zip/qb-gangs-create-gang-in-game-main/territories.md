# Version 2.5-dev - Territories Update

## What is it?
This update brings gang territories to the map using PolyZones and server side calculations to provide synchronized gang turfs to fight over.

## What do they do?
At the moment, nothing. This is in a development stage and currently only exists as a zone to fight over.

## Who can capture a zone?
Anyone in a gang or the police can capture a zone.

## Yeah but how do I use it?
Right now I wouldn't recommend using it since it is in early stages of development and things **will** be broken.



## Contributions
Contributions and issues are always welcome, if you want to test it out please submit any and all bugs with this so I can get this in a final state quicker!
