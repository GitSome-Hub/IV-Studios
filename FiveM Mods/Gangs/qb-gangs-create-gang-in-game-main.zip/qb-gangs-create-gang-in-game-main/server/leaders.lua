Config = {
	["GangLeaders"] = {
		["ballas"] = {
			"ORJ52463" -- Add Citizen IDs for gang leaders to add and remove people
		},
		["marabunta"] = {

		},
		["vagos"] = {

		},
		["families"] = {
			
		},
		["lost"] = {

		}
	}
}
