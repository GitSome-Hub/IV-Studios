
fx_version 'cerulean'
game 'gta5'

description 'QB-Gangs'

version '1.0.0'

author 'Floki'

shared_scripts {
    'config.lua',
}

client_scripts {
	'client/main.lua'

}

lua54 'yes'
