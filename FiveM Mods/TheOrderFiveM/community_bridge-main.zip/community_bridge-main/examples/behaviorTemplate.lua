-- -- Make sure to include filename in the init (prefix of the .lua)Utility = Utility or Require("lib/utility/client/utility.lua")
-- local ParticlesBehaviors = {
--     tag = "isTemplate",
--     default = {
--     }

-- }

-- function ParticlesBehaviors.OnSpawn(entityData)
-- end


-- function ParticlesBehaviors.OnRemove(entityData)
-- end

-- function ParticlesBehaviors.OnUpdate(entityData)

-- end

-- return ParticlesBehaviors
