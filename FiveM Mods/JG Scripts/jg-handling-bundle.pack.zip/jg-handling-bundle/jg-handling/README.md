# JG Handling

Hey there! Thanks so much for purchasing, it really means a lot to me. I've spent a lot of time on this script, and I hope you love it. This document has a bunch of the essential information that should help you out:

## Installation

Full instruction installations can be found in the docs here: https://docs.jgscripts.com/handling/installation

## Dependencies

You MUST have the following set up and ensured BEFORE JG Handling in order for the script to work:

- [oxmysql](https://github.com/overextended/oxmysql/releases)
- [ox_lib](https://github.com/overextended/ox_lib/releases)
- OneSync Infinity

## Support

Join Discord https://discord.gg/jgscripts for personalised support and guidance with using JG Handling! We will do whatever it takes to help you out and get you up and running!
