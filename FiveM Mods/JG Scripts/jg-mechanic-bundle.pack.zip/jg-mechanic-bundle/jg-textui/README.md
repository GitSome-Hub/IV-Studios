# jg-textui

Show text UI:

```lua
exports['jg-textui']:DrawText(text)
```

Hide text UI:

```lua
exports['jg-textui']:HideText()
```
