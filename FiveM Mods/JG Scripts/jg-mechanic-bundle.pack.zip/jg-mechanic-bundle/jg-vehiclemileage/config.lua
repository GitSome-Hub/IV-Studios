Config = {}
Config.AutoRunSQL = true

Config.Framework = "auto" -- or "QBCore", "Qbox", "ESX"
Config.ShowMileage = true
Config.Unit = "miles" -- "miles" or "kilometers"
Config.Position = "bottom-right" -- "bottom-right" or "bottom-left" or "top-right" or "top-left" or "bottom-center" or "top-center"