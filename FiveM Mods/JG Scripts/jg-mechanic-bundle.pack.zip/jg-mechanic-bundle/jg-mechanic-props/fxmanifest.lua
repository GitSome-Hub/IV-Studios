fx_version "cerulean"
game "gta5"
lua54 "yes"

description "Props for jg-mechanic"
version " v1.0.1"
author "JG Scripts"

data_file "DLC_ITYP_REQUEST" "stream/jg_carlift.ytyp"

dependency '/assetpacks'