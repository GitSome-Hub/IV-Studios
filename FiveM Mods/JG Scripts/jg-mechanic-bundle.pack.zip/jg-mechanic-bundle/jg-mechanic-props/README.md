# JG Mechanic Props

### Included Props
- Car Lift (created by @john_rosso)

### Intended Use

These props are intended to be used with JG Mechanic and are bundled with the purchase. They are, however, open source and you can use them with your own scripts if you'd like

### Links

Store: https://jgscripts.com

Discord: https://discord.gg/jgscripts
